/**
 * CodingLab - Arduino Coding tab for the Electrical Lab
 *
 * Hosts the sketch editor and connects the Arduino Coding Core
 * (ArduinoRuntime, see /src/arduino) to whatever Arduino/Mega/Nano board
 * component is currently placed on the Circuit Simulator canvas, via
 * CircuitPinIO. Everything simulator-side (rendering, the electrical
 * solve, component visuals) is untouched - this tab only drives pin state
 * on the board component; CircuitEditor's own per-frame loop picks up those
 * changes and reflects them everywhere else (LEDs, motors, servos, etc.)
 * automatically.
 */

import React, {
  forwardRef, useImperativeHandle, useEffect, useRef, useState, useCallback,
} from 'react';
import { Wrench, Play, Square, RotateCcw, CheckCircle2, XCircle, Cpu } from 'lucide-react';
import type { CircuitEditor } from '../circuit/CircuitEditor';
import { ArduinoRuntime } from '../arduino/ArduinoRuntime';
import { CircuitPinIO, type BoardLike } from '../arduino/CircuitPinIO';
import type { Diagnostic, RuntimeStatus } from '../arduino/types';
import { runSimulatorCompatibilitySuite } from '../arduino/testing/simulatorCompatibility';

export type Language = 'javascript' | 'python' | 'cpp' | 'arduino';

interface CodingLabProps {
  /** Returns the live CircuitEditor instance from the Circuit Simulator tab, if mounted. */
  getEditor: () => CircuitEditor | null;
  /** Whether this tab is currently the visible one. */
  active: boolean;
}

export interface CodingLabHandle {
  insertCode: (language: Language, code: string) => void;
}

const DEFAULT_SKETCH = `// Blink the LED wired to pin 13
void setup() {
  pinMode(13, OUTPUT);
}

void loop() {
  digitalWrite(13, HIGH);
  delay(500);
  digitalWrite(13, LOW);
  delay(500);
}
`;

const BOARD_TYPES = new Set(['arduino', 'arduinoMega', 'arduinoNano']);

const CodingLab = forwardRef<CodingLabHandle, CodingLabProps>(({ getEditor, active }, ref) => {
  const [code, setCode] = useState(DEFAULT_SKETCH);
  const [status, setStatus] = useState<RuntimeStatus>('idle');
  const [diagnostics, setDiagnostics] = useState<Diagnostic[]>([]);
  const [serial, setSerial] = useState<string>('');
  const [boardLabel, setBoardLabel] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Array<{ name: string; passed: boolean; message?: string }> | null>(null);

  const runtimeRef = useRef<ArduinoRuntime | null>(null);
  const pinIORef = useRef<CircuitPinIO | null>(null);
  const boardIdRef = useRef<number | null>(null);
  const rafRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);

  useImperativeHandle(ref, () => ({
    insertCode: (_language: Language, insertedCode: string) => {
      setCode(insertedCode);
    },
  }), []);

  const findBoard = useCallback((): BoardLike | undefined => {
    const editor = getEditor();
    if (!editor) return undefined;
    if (boardIdRef.current !== null) {
      const held = editor.state.components.find(c => c.id === boardIdRef.current);
      if (held) return held as unknown as BoardLike;
    }
    const found = editor.state.components.find(c => BOARD_TYPES.has(c.type));
    if (found) boardIdRef.current = found.id;
    return found as unknown as BoardLike | undefined;
  }, [getEditor]);

  // Keep the detected board's friendly name up to date while idle, so the
  // person can see which board a Run will target before pressing it.
  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => {
      const editor = getEditor();
      const board = editor?.state.components.find(c => BOARD_TYPES.has(c.type));
      setBoardLabel(board ? board.label || board.type : null);
    }, 500);
    return () => window.clearInterval(id);
  }, [active, getEditor]);

  const stopLoop = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = 0;
  }, []);

  const refreshRuntimeUI = useCallback(() => {
    const rt = runtimeRef.current;
    if (!rt) return;
    setStatus(rt.getStatus());
    setDiagnostics(rt.getDiagnostics());
    setSerial(rt.getSerialLog().map(e => e.text).join(''));
  }, []);

  const handleStop = useCallback(() => {
    stopLoop();
    runtimeRef.current?.stop();
    setStatus(runtimeRef.current?.getStatus() ?? 'stopped');
  }, [stopLoop]);

  const handleRun = useCallback(() => {
    const board = findBoard();
    if (!board) {
      setDiagnostics([{ line: 1, column: 1, severity: 'error', message: 'No Arduino/Mega/Nano board found on the Circuit Simulator canvas. Place one and wire it up first.' }]);
      setStatus('error');
      return;
    }

    stopLoop();
    const rt = new ArduinoRuntime();
    const compiled = rt.compile(code);
    setDiagnostics(compiled.errors);
    if (!compiled.success) {
      setStatus('error');
      return;
    }

    const pinIO = new CircuitPinIO(() => findBoard());
    rt.attachPinIO(pinIO);
    rt.start();
    runtimeRef.current = rt;
    pinIORef.current = pinIO;
    setStatus(rt.getStatus());
    setSerial('');

    lastTimeRef.current = performance.now();
    const loop = (time: number) => {
      const dt = time - lastTimeRef.current;
      lastTimeRef.current = time;
      // Board component removed/undo mid-run: keep ticking (CircuitPinIO's
      // getBoard() is re-resolved every call, so it degrades to a harmless
      // no-op rather than crashing) so the user can re-place it and resume.
      rt.tick(Math.min(dt, 100)); // clamp huge dt spikes (tab backgrounded) so delay()-timed loops don't jump wildly
      refreshRuntimeUI();
      if (rt.getStatus() === 'running') {
        rafRef.current = requestAnimationFrame(loop);
      } else {
        stopLoop();
      }
    };
    rafRef.current = requestAnimationFrame(loop);
  }, [code, findBoard, stopLoop, refreshRuntimeUI]);

  const handleReset = useCallback(() => {
    stopLoop();
    runtimeRef.current?.reset();
    runtimeRef.current = null;
    pinIORef.current = null;
    setStatus('idle');
    setDiagnostics([]);
    setSerial('');
  }, [stopLoop]);

  const handleSelfTest = useCallback(() => {
    setTestResults(runSimulatorCompatibilitySuite());
  }, []);

  useEffect(() => () => stopLoop(), [stopLoop]);

  const errorCount = diagnostics.filter(d => d.severity === 'error').length;

  return (
    <div className="h-full flex flex-col gap-3 p-3 bg-slate-900/60 border border-slate-700/50 rounded-lg overflow-hidden">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2 text-slate-300 text-sm">
          <Cpu size={16} className="text-amber-400" />
          <span>{boardLabel ? `Target: ${boardLabel}` : 'No board detected on canvas'}</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleRun}
            disabled={status === 'running'}
            className="flex items-center gap-1 px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-sm"
          >
            <Play size={14} /> Run
          </button>
          <button
            onClick={handleStop}
            disabled={status !== 'running'}
            className="flex items-center gap-1 px-3 py-1.5 rounded bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white text-sm"
          >
            <Square size={14} /> Stop
          </button>
          <button
            onClick={handleReset}
            className="flex items-center gap-1 px-3 py-1.5 rounded bg-slate-700 hover:bg-slate-600 text-white text-sm"
          >
            <RotateCcw size={14} /> Reset
          </button>
          <button
            onClick={handleSelfTest}
            className="flex items-center gap-1 px-3 py-1.5 rounded bg-sky-700 hover:bg-sky-600 text-white text-sm"
          >
            <Wrench size={14} /> Run compatibility tests
          </button>
        </div>
      </div>

      <textarea
        value={code}
        onChange={e => setCode(e.target.value)}
        spellCheck={false}
        className="flex-1 min-h-[200px] w-full resize-none rounded-md bg-slate-950 text-slate-100 font-mono text-sm p-3 border border-slate-700 focus:outline-none focus:border-amber-500"
      />

      <div className="grid grid-cols-2 gap-3 max-h-40">
        <div className="overflow-y-auto rounded border border-slate-700 bg-slate-950/60 p-2 text-xs">
          <div className="text-slate-400 mb-1 flex items-center gap-1">
            Status: <span className={status === 'error' ? 'text-rose-400' : status === 'running' ? 'text-emerald-400' : 'text-slate-300'}>{status}</span>
            {errorCount > 0 && <span className="text-rose-400">({errorCount} error{errorCount === 1 ? '' : 's'})</span>}
          </div>
          {diagnostics.map((d, i) => (
            <div key={i} className={d.severity === 'error' ? 'text-rose-400' : 'text-amber-400'}>
              Line {d.line}: {d.message}
            </div>
          ))}
        </div>
        <div className="overflow-y-auto rounded border border-slate-700 bg-slate-950/60 p-2 text-xs">
          <div className="text-slate-400 mb-1">Serial Monitor</div>
          <pre className="whitespace-pre-wrap text-slate-200">{serial || '(no output yet)'}</pre>
        </div>
      </div>

      {testResults && (
        <div className="max-h-32 overflow-y-auto rounded border border-slate-700 bg-slate-950/60 p-2 text-xs">
          <div className="text-slate-400 mb-1">
            Compatibility tests: {testResults.filter(t => t.passed).length}/{testResults.length} passed
          </div>
          {testResults.map((t, i) => (
            <div key={i} className={`flex items-center gap-1 ${t.passed ? 'text-emerald-400' : 'text-rose-400'}`}>
              {t.passed ? <CheckCircle2 size={12} /> : <XCircle size={12} />}
              <span>{t.name}</span>
              {!t.passed && t.message && <span className="text-slate-400">— {t.message}</span>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
});

CodingLab.displayName = 'CodingLab';

export default CodingLab;
