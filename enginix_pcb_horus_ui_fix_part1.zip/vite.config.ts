import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"
import { inspectAttr } from 'kimi-plugin-inspect-react'

// https://vite.dev/config/
export default defineConfig(({ command }) => ({
  base: './',
  // inspectAttr() injects a click-to-inspect overlay (DOM nodes appended
  // outside the React tree, positioned via getBoundingClientRect()). It
  // must only run against the local dev server — if it's active in a
  // built/served bundle, its overlay boxes get stale bounding-rect
  // snapshots whenever content re-renders (e.g. the theme-switch hero
  // re-render) and are left stuck on screen, since nothing in the React
  // tree owns or can clean up nodes it didn't create. Only a full
  // page/root remount (navigating away and back) re-initializes it.
  plugins: [command === 'serve' ? inspectAttr() : null, react()].filter(Boolean),
  server: {
    port: 3000,
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  test: {
    environment: 'jsdom',
  },
}));
