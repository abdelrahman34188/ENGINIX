import { ArduinoRuntime } from './src/arduino/ArduinoRuntime';
import { MemoryPinIO } from './src/arduino/testing/MemoryPinIO';
import { runRegressionSuite } from './src/arduino/testing/regression';

type Check = { name: string; run: () => void };
const checks: Check[] = [];
function check(name: string, run: () => void) { checks.push({ name, run }); }
function ok(cond: boolean, msg: string) { if (!cond) throw new Error(msg); }
function eq(a: unknown, b: unknown, msg: string) { if (a !== b) throw new Error(`${msg}: expected ${b}, got ${a}`); }

function fresh() {
  const io = new MemoryPinIO();
  const rt = new ArduinoRuntime();
  return { io, rt };
}

function noErrors(rt: ArduinoRuntime) {
  const errs = rt.getDiagnostics().filter(d => d.severity === 'error');
  ok(errs.length === 0, `unexpected diagnostics: ${JSON.stringify(errs)}`);
  eq(rt.getStatus(), 'running', 'runtime should still be running');
}

// 1. Blink
check('Blink', () => {
  const { io, rt } = fresh();
  const src = `
    void setup() { pinMode(13, OUTPUT); }
    void loop() {
      digitalWrite(13, HIGH);
      delay(1000);
      digitalWrite(13, LOW);
      delay(1000);
    }
  `;
  ok(rt.compile(src).success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  rt.tick(0);
  eq(io.digitalOut.get(13), 1, 'LED should be HIGH first');
  rt.tick(1000);
  eq(io.digitalOut.get(13), 0, 'LED should go LOW after 1000ms');
  rt.tick(1000);
  eq(io.digitalOut.get(13), 1, 'LED should go HIGH again after another 1000ms');
  noErrors(rt);
});

// 2. Servo Sweep
check('Servo Sweep', () => {
  const { io, rt } = fresh();
  const src = `
    #include <Servo.h>
    Servo myServo;
    int pos = 0;
    void setup() { myServo.attach(9); }
    void loop() {
      for (pos = 0; pos <= 180; pos += 30) {
        myServo.write(pos);
        delay(15);
      }
    }
  `;
  ok(rt.compile(src).success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  let maxAngleSeen = -1;
  for (let i = 0; i < 7; i++) { rt.tick(15); maxAngleSeen = Math.max(maxAngleSeen, io.servoAngles.get(9) ?? -1); }
  eq(maxAngleSeen, 180, 'servo should sweep up to 180 over successive ticks');
  noErrors(rt);
});

// 3. Relay
check('Relay', () => {
  const { io, rt } = fresh();
  const src = `
    int relayPin = 7;
    void setup() { pinMode(relayPin, OUTPUT); }
    void loop() {
      digitalWrite(relayPin, HIGH);
      delay(500);
      digitalWrite(relayPin, LOW);
      delay(500);
    }
  `;
  ok(rt.compile(src).success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  rt.tick(0);
  eq(io.modes.get(7), 'OUTPUT', 'relay pin should be OUTPUT');
  eq(io.digitalOut.get(7), 1, 'relay should energize HIGH first');
  rt.tick(500);
  eq(io.digitalOut.get(7), 0, 'relay should de-energize after 500ms');
  noErrors(rt);
});

// 4. RGB LED
check('RGB LED', () => {
  const { io, rt } = fresh();
  const src = `
    int redPin = 9, greenPin = 10, bluePin = 11;
    void setup() {
      pinMode(redPin, OUTPUT); pinMode(greenPin, OUTPUT); pinMode(bluePin, OUTPUT);
    }
    void loop() {
      analogWrite(redPin, 255);
      analogWrite(greenPin, 128);
      analogWrite(bluePin, 0);
    }
  `;
  ok(rt.compile(src).success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  rt.tick(0);
  eq(io.analogOut.get(9), 255, 'red channel');
  eq(io.analogOut.get(10), 128, 'green channel');
  eq(io.analogOut.get(11), 0, 'blue channel');
  noErrors(rt);
});

// 5. Potentiometer
check('Potentiometer', () => {
  const { io, rt } = fresh();
  const src = `
    void setup() { pinMode(9, OUTPUT); }
    void loop() {
      int val = analogRead(0);
      int mapped = map(val, 0, 1023, 0, 255);
      analogWrite(9, mapped);
    }
  `;
  ok(rt.compile(src).success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  io.setAnalogInput(0, 512);
  rt.tick(0);
  eq(io.analogOut.get(9), 127, 'midpoint pot reading should map to ~127 PWM');
  noErrors(rt);
});

// 6. LDR (light sensor)
check('LDR', () => {
  const { io, rt } = fresh();
  const src = `
    int ledPin = 8;
    void setup() { pinMode(ledPin, OUTPUT); }
    void loop() {
      int light = analogRead(0);
      if (light < 300) {
        digitalWrite(ledPin, HIGH);
      } else {
        digitalWrite(ledPin, LOW);
      }
    }
  `;
  ok(rt.compile(src).success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  io.setAnalogInput(0, 100); // dark
  rt.tick(0);
  eq(io.digitalOut.get(8), 1, 'LED should turn on when dark');
  io.setAnalogInput(0, 800); // bright
  rt.tick(0);
  eq(io.digitalOut.get(8), 0, 'LED should turn off when bright');
  noErrors(rt);
});

// 7. Ultrasonic (HC-SR04) — exercises the new pulseIn() implementation
check('Ultrasonic', () => {
  const { io, rt } = fresh();
  const src = `
    int trigPin = 9;
    int echoPin = 10;
    long duration = 0;
    long distanceCm = 0;
    void setup() {
      pinMode(trigPin, OUTPUT);
      pinMode(echoPin, INPUT);
    }
    void loop() {
      digitalWrite(trigPin, LOW);
      delayMicroseconds(2);
      digitalWrite(trigPin, HIGH);
      delayMicroseconds(10);
      digitalWrite(trigPin, LOW);
      duration = pulseIn(echoPin, HIGH);
      distanceCm = duration * 0.0343 / 2;
    }
  `;
  const compiled = rt.compile(src);
  ok(compiled.success, `compile failed: ${JSON.stringify(compiled.errors)}`);
  rt.attachPinIO(io);
  rt.start();

  // Drive echo pin like a simulated HC-SR04 responding to a ~10cm object:
  // round trip ~582us. We schedule the echo HIGH pulse "by hand" across
  // ticks the same way a circuit-driven PinIO would.
  io.setDigitalInput(10, 0);
  rt.tick(0); // runs setup, enters loop, sends trigger pulse, starts polling for echo HIGH
  io.setDigitalInput(10, 1); // echo goes high
  rt.tick(1); // pulseIn detects rising edge, starts timing
  rt.tick(0); // still HIGH
  io.setDigitalInput(10, 0); // echo returns low ~0.6ms later
  rt.tick(1);
  ok(rt.getStatus() === 'running', 'runtime should not crash on pulseIn()');
  noErrors(rt);
});

// 8. PIR motion sensor
check('PIR', () => {
  const { io, rt } = fresh();
  const src = `
    int pirPin = 2;
    int ledPin = 13;
    void setup() { pinMode(pirPin, INPUT); pinMode(ledPin, OUTPUT); }
    void loop() {
      int motion = digitalRead(pirPin);
      digitalWrite(ledPin, motion);
    }
  `;
  ok(rt.compile(src).success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  io.setDigitalInput(2, 1);
  rt.tick(0);
  eq(io.digitalOut.get(13), 1, 'LED should follow motion HIGH');
  io.setDigitalInput(2, 0);
  rt.tick(0);
  eq(io.digitalOut.get(13), 0, 'LED should follow motion LOW');
  noErrors(rt);
});

// 9. Flame sensor
check('Flame Sensor', () => {
  const { io, rt } = fresh();
  const src = `
    int flamePin = 3;
    int buzzerPin = 4;
    void setup() { pinMode(flamePin, INPUT); pinMode(buzzerPin, OUTPUT); }
    void loop() {
      int flame = digitalRead(flamePin);
      if (flame == LOW) { // most flame sensors pull LOW when fire is detected
        digitalWrite(buzzerPin, HIGH);
      } else {
        digitalWrite(buzzerPin, LOW);
      }
    }
  `;
  ok(rt.compile(src).success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  io.setDigitalInput(3, 0); // flame detected
  rt.tick(0);
  eq(io.digitalOut.get(4), 1, 'buzzer should sound on flame detection');
  io.setDigitalInput(3, 1); // no flame
  rt.tick(0);
  eq(io.digitalOut.get(4), 0, 'buzzer should be silent with no flame');
  noErrors(rt);
});

// 10. DC Motor (via H-bridge direction pins + PWM speed)
check('DC Motor', () => {
  const { io, rt } = fresh();
  const src = `
    int in1 = 5, in2 = 6, enable = 9;
    void setup() {
      pinMode(in1, OUTPUT); pinMode(in2, OUTPUT); pinMode(enable, OUTPUT);
    }
    void loop() {
      digitalWrite(in1, HIGH);
      digitalWrite(in2, LOW);
      analogWrite(enable, 200);
    }
  `;
  ok(rt.compile(src).success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  rt.tick(0);
  eq(io.digitalOut.get(5), 1, 'in1 HIGH for forward direction');
  eq(io.digitalOut.get(6), 0, 'in2 LOW for forward direction');
  eq(io.analogOut.get(9), 200, 'enable pin PWM speed');
  noErrors(rt);
});

// 11. Stepper (28BYJ-48 / driver style, 4-wire)
check('Stepper', () => {
  const { io, rt } = fresh();
  const src = `
    #include <Stepper.h>
    const int stepsPerRevolution = 200;
    Stepper myStepper(stepsPerRevolution, 8, 9, 10, 11);
    void setup() { myStepper.setSpeed(60); }
    void loop() { myStepper.step(stepsPerRevolution); }
  `;
  ok(rt.compile(src).success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  const start = Date.now();
  rt.tick(0);
  rt.tick(2000);
  ok(Date.now() - start < 3000, 'stepper full revolution should not hang the engine');
  const coilWrites = io.writeHistory.filter(w => w.kind === 'digital' && [8, 9, 10, 11].includes(w.pin));
  ok(coilWrites.length > 0, 'stepper should drive coil pins');
  noErrors(rt);
});

// 12. Water Pump (relay-driven, same pattern as Relay but distinct timing profile)
check('Water Pump', () => {
  const { io, rt } = fresh();
  const src = `
    int pumpPin = 4;
    int moisturePin = 0;
    void setup() { pinMode(pumpPin, OUTPUT); }
    void loop() {
      int moisture = analogRead(moisturePin);
      if (moisture < 400) {
        digitalWrite(pumpPin, HIGH);
      } else {
        digitalWrite(pumpPin, LOW);
      }
    }
  `;
  ok(rt.compile(src).success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  io.setAnalogInput(0, 200); // dry soil
  rt.tick(0);
  eq(io.digitalOut.get(4), 1, 'pump should run when soil is dry');
  io.setAnalogInput(0, 700); // wet soil
  rt.tick(0);
  eq(io.digitalOut.get(4), 0, 'pump should stop when soil is wet');
  noErrors(rt);
});

let passed = 0, failed = 0;
const failures: string[] = [];
for (const c of checks) {
  try {
    c.run();
    passed++;
    console.log(`PASS  ${c.name}`);
  } catch (e) {
    failed++;
    failures.push(`${c.name}: ${(e as Error).message}`);
    console.log(`FAIL  ${c.name} -> ${(e as Error).message}`);
  }
}

console.log('\n--- Component suite:', passed, 'passed,', failed, 'failed', '---');

console.log('\n--- Running existing regression suite (src/arduino/testing/regression.ts) ---');
const reg = runRegressionSuite();
for (const r of reg.results) {
  console.log(`${r.passed ? 'PASS' : 'FAIL'}  ${r.name}${r.message ? ' -> ' + r.message : ''}`);
}
console.log('\n--- Regression suite:', reg.passed, 'passed,', reg.failed, 'failed', '---');

if (failed > 0 || reg.failed > 0) process.exit(1);
