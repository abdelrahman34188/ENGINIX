# HORUS AI — Electrical Engineering Copilot

**Status: architecture stage, with two working infrastructure pieces.**
No AI conversation logic and no AI vendor connection exist yet — `AICore`
and the Knowledge Base modules still throw
`Not implemented — HORUS AI architecture stage only.` from their methods
on purpose. Two pieces of plumbing are fully functional ahead of that,
because they're infrastructure rather than AI behavior: the **Context
Manager**'s source providers (live state collection) and the **AI Event
Bus** (event delivery).

## Modules

| Module | File | Responsibility (once implemented) |
|---|---|---|
| AI Core | `core/AICore.ts` | Orchestrates a request across every other module |
| AI Configuration | `core/AIConfiguration.ts` | Holds each provider's settings (name, API key, model, temperature, max tokens, validation state) independently, plus which provider is active; provides switching |
| AI Provider Manager | `provider/AIProviderManager.ts` | Registers/removes provider adapters (delegates storage to `ProviderRegistry`) and resolves/switches the active provider (delegates active-id bookkeeping to `AIConfiguration`) — `registerProvider`, `removeProvider`, `setActiveProvider`, `getActiveProvider`, `listProviders` |
| Gemini Client | `provider/GeminiClient.ts` | Gemini-specific request/header/payload preparation and response-parser construction, mirroring `src/services/GeminiService.ts`'s shapes; delegated to by `GeminiProvider` so shaping logic isn't duplicated. No HTTP. |
| Intent Router | `router/IntentRouter.ts` | Fully functional. Deterministic map from each HORUS action button (`components/horus-ai/HorusAIView.tsx`) to a fixed internal intent id — plain lookup, no classification, no AI call, no execution. Distinct from `core/Brain/IntentAnalyzer.ts`, which will classify free-text requests once implemented. |
| Conversation Manager | `conversation/ConversationManager.ts` | Owns chat turn history |
| Context Manager | `context/ContextManager.ts` | Composes 6 isolated source providers (Simulator, PCB, Coding, Workspace, Project Gallery, Project — see `context/providers/`) and merges them into one `UnifiedHorusContext`. Simulator, PCB, Coding, Workspace, and Project providers are live (collect real data pushed via `update()`); Project Gallery remains a skeleton. |
| AI Event Bus | `events/AIEventBus.ts` | Publish/subscribe/broadcast infrastructure notifying HORUS whenever something changes in Simulator, PCB, Coding, Workspace, Project, or Settings. Fully functional transport — carries events, does not interpret them. Event shape lives in `events/HorusEvent.ts`. Per-module event names + payload shapes live in `events/catalog/*Events.ts`; typed `publish()` wrappers for every cataloged action live in `events/emitters/*EventEmitter.ts`, composed into one `HorusEventEmitters` registry. Business-logic modules call these emitters once wired up — none of them are called from business logic yet. |
| Knowledge Base Manager | `knowledge/KnowledgeBaseManager.ts` | Composes 7 domain repositories (Components, Pins, Libraries, APIs, Simulator Features, PCB Features, Coding Features) — see `knowledge/repositories/` |
| Tool Manager | `tools/ToolManager.ts` | Registers and dispatches callable tools |
| Validation Engine | `validation/ValidationEngine.ts` | Judges AI output validity |
| Auto Fix Engine | `autofix/AutoFixEngine.ts` | Attempts to correct invalid output |
| Memory Manager | `memory/MemoryManager.ts` | Durable, cross-session recall |

## Design principles

- **Isolation** — each module lives in its own folder, exposes one
  interface (`I<Name>`) and one implementation, and does not import any
  other module's concrete class — only interfaces/types it depends on.
  Neither the context providers nor the AI Event Bus import from
  `src/circuit`, `src/pcb`, `src/arduino`, the Project Gallery, or
  Settings — those modules will call into HORUS (via `update()` on a
  provider, or `publish()`/`broadcast()` on the event bus) once wired up,
  not the other way around.
- **Dependency Inversion** — `AICore` depends on `AIProvider` and every
  manager purely through their interfaces, injected via its constructor
  (`AICoreDependencies`). Swapping an implementation never requires
  changing `AICore`.
- **Open/Closed** — `ProviderRegistry` and `ToolManager` are the
  extension points for new AI vendors and new callable tools; adding one
  doesn't require modifying existing modules.
- **No vendor hardcoding** — `provider/AIProvider.ts` defines a
  vendor-agnostic contract. Concrete adapters (Gemini, OpenAI, Groq,
  OpenRouter, ...) are future work and are not present in this tree.

## Not included yet

- Any concrete `AIProvider` adapter
- Any AI conversation/request-response logic in `AICore`
- Anything subscribing to the AI Event Bus with real AI behavior (today
  it only carries events; nothing yet reacts to them)
- Any call from business logic (Simulator, Coding, PCB, Workspace,
  Settings) into a `HorusEventEmitters` method — the emitters exist and
  are ready to be called, but no business-logic file has been modified
  to call them
- Wiring into the AI Assistant page beyond the "HORUS AI is
  initializing..." placeholder

