/**
 * HORUS AI — Memory Manager.
 *
 * Responsible (once implemented) for durable, cross-session recall — e.g.
 * user preferences learned over time, or facts worth remembering beyond a
 * single conversation. Isolated from Conversation Manager (single-session
 * chat turns) and Knowledge Base Manager (reference/domain knowledge, not
 * user-specific memory).
 *
 * Interface + skeleton only — no logic implemented yet.
 */

export interface HorusMemoryEntry {
  key: string;
  value: unknown;
  updatedAt: number;
}

export interface IMemoryManager {
  /** Store or overwrite a memory entry. */
  remember(entry: HorusMemoryEntry): void;

  /** Retrieve a memory entry by key. */
  recall(key: string): HorusMemoryEntry | undefined;

  /** Remove a memory entry. */
  forget(key: string): void;

  /** List all stored memory keys. */
  listKeys(): string[];
}

export class MemoryManager implements IMemoryManager {
  remember(_entry: HorusMemoryEntry): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  recall(_key: string): HorusMemoryEntry | undefined {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  forget(_key: string): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  listKeys(): string[] {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
