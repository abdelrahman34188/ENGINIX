/**
 * HORUS AI — module identity.
 *
 * Static identity only; no behavior.
 */
export const HORUS_AI_NAME = 'HORUS AI';
export const HORUS_AI_ROLE = 'Electrical Engineering Copilot';
export const HORUS_AI_INITIALIZING_MESSAGE = 'HORUS AI is initializing...';
