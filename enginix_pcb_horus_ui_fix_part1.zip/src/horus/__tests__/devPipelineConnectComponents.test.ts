// @vitest-environment jsdom
/**
 * Developer test — full circuit-edit pipeline, end to end:
 *
 *   HORUS request -> CircuitEditPlanner -> EditValidator -> EditApplier
 *   -> CircuitToolBridge -> CircuitTool (the real CircuitEditor)
 *
 * Request under test: "Connect LED anode to R1."
 *
 * Expected, per spec:
 *  - Planner creates a `connect` action.
 *  - Executor (`EditApplier`) executes it.
 *  - CircuitTool (the real `CircuitEditor`, via `connectByLabel`)
 *    creates the wire.
 *  - Success is returned only after the wire already exists in the
 *    simulator's real state — never before, never as a guess.
 *  - No UI redesign: same editor/canvas/container instance throughout,
 *    no DOM churn.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { CircuitEditPlanner } from '../core/Brain/CircuitEditPlanner';
import { EditValidator } from '../tools/EditValidator';
import { EditApplier } from '../tools/EditApplier';
import { circuitToolBridge } from '../tools/CircuitToolBridge';

function makeEditor(): { editor: CircuitEditor; canvas: HTMLCanvasElement; container: HTMLDivElement } {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    beginPath: () => {},
    fillRect: () => {},
    strokeRect: () => {},
    fill: () => {},
    stroke: () => {},
    arc: () => {},
    moveTo: () => {},
    lineTo: () => {},
    fillText: () => {},
    setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return { editor: new CircuitEditor(canvas, container), canvas, container };
}

describe('dev pipeline: Planner -> Executor -> CircuitToolBridge -> CircuitTool ("Connect LED anode to R1")', () => {
  let editor: CircuitEditor;
  let canvas: HTMLCanvasElement;
  let container: HTMLDivElement;
  const planner = new CircuitEditPlanner();
  const validator = new EditValidator(circuitToolBridge);
  const applier = new EditApplier(circuitToolBridge);

  beforeEach(() => {
    ({ editor, canvas, container } = makeEditor());
    circuitToolBridge.register(editor);
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('Planner creates a connect action', () => {
    const request = 'Connect LED anode to R1.';
    expect(planner.isEditRequest({ request })).toBe(true);

    const plan = planner.planEdit({ request });
    expect(plan).not.toBeNull();
    expect(plan!.action).toBe('connect_components');
    expect(plan!.target?.raw.toLowerCase()).toBe('led anode');
    expect(plan!.secondaryTarget?.raw).toBe('R1');
  });

  it('Executor executes it, CircuitTool creates the wire, and success is only returned once it exists', () => {
    const led = editor.addComponentAt('led', 0, 0);
    const r1 = editor.addComponentAt('resistor', 5, 0);
    r1.label = 'R1';
    expect(editor.state.wires.length).toBe(0);

    const request = 'Connect LED anode to R1.';
    const plan = planner.planEdit({ request });
    const validated = validator.validate(plan!);
    expect(validated.valid).toBe(true);
    expect(validated.plan.action).toBe('connect');

    // Spy on the real CircuitEditor method the Bridge calls through to,
    // proving the wire is created by CircuitTool itself.
    const connectSpy = vi.spyOn(editor, 'connectByLabel');

    const result = applier.apply(validated);

    expect(result.status).toBe('applied');
    expect(connectSpy).toHaveBeenCalledTimes(1);
    // LED's anode is terminal 'A'; no pin was named on R1, so its first
    // terminal ('1') is used.
    expect(connectSpy).toHaveBeenCalledWith(
      expect.objectContaining({ id: led.id }),
      'A',
      expect.objectContaining({ id: r1.id }),
      '1'
    );

    // The wire genuinely exists in CircuitTool's own state — this is
    // what "return success only after the wire exists" is checked
    // against, not the Applier's own say-so.
    expect(result.wireId).toBeDefined();
    const wire = editor.state.wires.find((w) => w.id === result.wireId);
    expect(wire).toBeDefined();
    expect(wire!.fromCompId).toBe(led.id);
    expect(wire!.toCompId).toBe(r1.id);

    // And it's visible back through the read side of the same bridge.
    expect(
      circuitToolBridge.getWires().some((w) => w.fromComponentId === led.id && w.toComponentId === r1.id)
    ).toBe(true);

    connectSpy.mockRestore();
  });

  it('returns a structured error, and creates no wire, when the named component does not exist', () => {
    editor.addComponentAt('led', 0, 0); // no R1 on the circuit

    const plan = planner.planEdit({ request: 'Connect LED anode to R1.' });
    const validated = validator.validate(plan!);
    expect(validated.valid).toBe(false);

    let result;
    expect(() => {
      result = applier.apply(validated);
    }).not.toThrow();

    expect(result!.status).toBe('error');
    expect(typeof result!.message).toBe('string');
    expect(editor.state.wires.length).toBe(0);
  });

  it('no UI redesign: same editor/canvas/container instance, no DOM churn', () => {
    const led = editor.addComponentAt('led', 0, 0);
    const r1 = editor.addComponentAt('resistor', 5, 0);
    r1.label = 'R1';

    const bodyChildrenBefore = document.body.childElementCount;
    const containerChildrenBefore = container.childElementCount;

    const plan = planner.planEdit({ request: 'Connect LED anode to R1.' });
    const validated = validator.validate(plan!);
    const result = applier.apply(validated);
    expect(result.status).toBe('applied');

    expect(document.body.childElementCount).toBe(bodyChildrenBefore);
    expect(container.childElementCount).toBe(containerChildrenBefore);
    expect(document.body.contains(canvas)).toBe(false);
    // Same component/editor identity — connect never rebuilds anything.
    expect(editor.state.components.map((c) => c.id).sort()).toEqual([led.id, r1.id].sort());
  });
});
