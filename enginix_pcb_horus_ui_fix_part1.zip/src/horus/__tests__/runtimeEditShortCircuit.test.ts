import { describe, it, expect } from 'vitest';
import { sendChatMessage } from '../runtime';

/**
 * Only exercises the edit-request short-circuit path added to
 * `sendChatMessage()`. That path returns before any AI-provider call
 * is made (no API key lookup result is used, no network request is
 * possible), so this test needs no Gemini mocking — unlike the AI
 * text path, which is already covered end-to-end by
 * `tools/__tests__/circuitContextPipeline.test.ts`.
 *
 * No `CircuitEditor` is mounted in this test environment, so
 * `circuitToolBridge` falls back to an empty circuit with no mutators
 * wired up — every edit request here either fails validation (target
 * doesn't exist) or fails at apply time ("No circuit is currently
 * open."). Both are exercised below; what matters for this suite is
 * that `text`/`error` is always a short message, never a serialized
 * `EditPlan`.
 */
describe('sendChatMessage — edit-request short-circuit', () => {
  it('rejects an invalid plan with a short reason instead of calling the AI provider', async () => {
    const result = await sendChatMessage('edit-test-conversation', 'Rename R1 to Main Resistor');

    // "R1" doesn't exist on the empty circuit, so EditValidator marks
    // this invalid and EditExecutor rejects it without ever calling
    // CircuitToolBridge.
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.error).toBe('No component matching "R1" was found on the circuit.');
    // Never the raw EditPlan/JSON.
    expect(result.error.trim().startsWith('{')).toBe(false);
  });

  it('reports an apply-time failure with a short reason, not a serialized plan', async () => {
    // "Add capacitor" needs no pre-existing target, so it passes
    // EditValidator — but with no CircuitEditor mounted, EditExecutor's
    // call through EditApplier/CircuitToolBridge fails to actually add
    // it, and that failure is surfaced as a short message too.
    const result = await sendChatMessage('edit-test-conversation-2', 'Add capacitor');

    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.error).toBe('No circuit is currently open.');
    expect(result.error.trim().startsWith('{')).toBe(false);
  });

  it('never exposes an "editPlan" field — only a short confirmation/error string', async () => {
    const result = await sendChatMessage('edit-test-conversation-3', 'Add capacitor');
    expect(result).not.toHaveProperty('editPlan');
  });
});
