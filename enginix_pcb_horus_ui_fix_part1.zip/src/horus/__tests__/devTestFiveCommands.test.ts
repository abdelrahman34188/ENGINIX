// @vitest-environment jsdom
/**
 * HORUS AI — Developer Test.
 *
 * Exercises the exact five commands from the test brief through the
 * real, public entry point (`sendChatMessage()` in `runtime.ts`) —
 * not the internal pieces directly — against a real (headless)
 * `CircuitEditor`, the same construction the other dev-pipeline tests
 * use. For each command:
 *   - The simulator (`editor.state`) is asserted to have actually
 *     changed by the time `sendChatMessage()` resolves — "updates the
 *     simulator immediately" means synchronously, not eventually.
 *   - On failure, `result.error` is asserted to be the exact,
 *     human-readable reason — never a serialized `EditPlan`/JSON blob.
 *
 * Commands under test, in the order and rename-free wiring the brief
 * implies (an LED must exist before "Change R1..." can mean anything
 * real, so a resistor is added first to give "R1" something to refer
 * to — this test doesn't invent commands, it only sets up the
 * component each command needs):
 *   1. Add LED
 *   2. Remove LED          (re-added after, so the rest have an LED)
 *   3. Change R1 to 220Ω
 *   4. Connect LED to R1
 *   5. Disconnect LED
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { circuitToolBridge } from '../tools/CircuitToolBridge';
import { sendChatMessage } from '../runtime';
import { conversationManager } from '../core/Chat/ConversationManager';

/** Same headless-editor construction used across the other CircuitEditor
 *  and pipeline tests — a real `CircuitEditor` against a mocked canvas
 *  context, not a stub circuit. */
function makeEditor(): { editor: CircuitEditor; canvas: HTMLCanvasElement; container: HTMLDivElement } {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    beginPath: () => {},
    fillRect: () => {},
    strokeRect: () => {},
    fill: () => {},
    stroke: () => {},
    arc: () => {},
    moveTo: () => {},
    lineTo: () => {},
    fillText: () => {},
    setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return { editor: new CircuitEditor(canvas, container), canvas, container };
}

/** True when `text` reads as a serialized EditPlan/JSON blob rather
 *  than a short natural-language sentence — used to assert the
 *  "never return EditPlan JSON" requirement on every result, success
 *  or failure. */
function looksLikeJson(text: string): boolean {
  const trimmed = text.trim();
  return trimmed.startsWith('{') || trimmed.startsWith('[');
}

describe('Developer Test — five commands update the simulator immediately, never return EditPlan JSON', () => {
  let editor: CircuitEditor;
  let conversationId: string;

  beforeEach(() => {
    ({ editor } = makeEditor());
    circuitToolBridge.register(editor);
    conversationId = `dev-test-${Math.random()}`;
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('1. "Add LED" — LED appears in the simulator immediately, confirmation only', async () => {
    expect(editor.state.components.length).toBe(0);

    const result = await sendChatMessage(conversationId, 'Add LED');

    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(looksLikeJson(result.text)).toBe(false);
    expect(result.text).toMatch(/added successfully/i);

    // Simulator actually updated — real CircuitEditor state, not a
    // mirrored/fake copy.
    expect(editor.state.components.length).toBe(1);
    expect(editor.state.components[0].type).toBe('led');
  });

  it('2. "Remove LED" — LED disappears from the simulator immediately', async () => {
    editor.addComponentAt('led', 0, 0);
    editor.updateAllTerminalPositions();
    expect(editor.state.components.length).toBe(1);

    const result = await sendChatMessage(conversationId, 'Remove LED');

    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(looksLikeJson(result.text)).toBe(false);
    expect(result.text).toMatch(/removed successfully/i);
    expect(editor.state.components.length).toBe(0);
  });

  it('3. "Change R1 to 220Ω" — the real resistor\'s resistance updates immediately', async () => {
    const r1 = editor.addComponentAt('resistor', 0, 0)!;
    editor.updateAllTerminalPositions();
    expect(r1.props.resistance).not.toBe(220);

    const result = await sendChatMessage(conversationId, `Change ${r1.label} to 220Ω`);

    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(looksLikeJson(result.text)).toBe(false);
    expect(result.text).toMatch(/updated successfully/i);
    expect(editor.state.components.find((c) => c.id === r1.id)!.props.resistance).toBe(220);
  });

  it('4. "Connect LED to R1" — a real wire exists between them immediately', async () => {
    const led = editor.addComponentAt('led', 0, 0)!;
    const r1 = editor.addComponentAt('resistor', 4, 0)!;
    editor.updateAllTerminalPositions();
    expect(editor.state.wires.length).toBe(0);

    const result = await sendChatMessage(conversationId, `Connect ${led.label} to ${r1.label}`);

    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(looksLikeJson(result.text)).toBe(false);
    expect(result.text).toMatch(/connected .* successfully/i);
    expect(editor.state.wires.length).toBe(1);
    const wire = editor.state.wires[0];
    expect([wire.fromCompId, wire.toCompId].sort()).toEqual([led.id, r1.id].sort());
  });

  it('5. "Disconnect LED" — the wire is actually removed from the simulator immediately', async () => {
    const led = editor.addComponentAt('led', 0, 0)!;
    const r1 = editor.addComponentAt('resistor', 4, 0)!;
    editor.updateAllTerminalPositions();
    editor.connectByLabel(led, 'A', r1, '1');
    expect(editor.state.wires.length).toBe(1);

    const result = await sendChatMessage(conversationId, `Disconnect ${led.label}`);

    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(looksLikeJson(result.text)).toBe(false);
    expect(result.text).toMatch(/disconnected successfully/i);
    expect(editor.state.wires.length).toBe(0);
  });

  it('Failure path — an exact reason is returned, never EditPlan JSON (component missing)', async () => {
    // No CircuitEditor mounted state has "R1" — bridge is registered
    // but the circuit is empty, so validation fails immediately.
    const result = await sendChatMessage(conversationId, 'Change R1 to 220Ω');

    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(looksLikeJson(result.error)).toBe(false);
    expect(result.error).toBe('No component matching "R1" was found on the circuit.');
  });

  it('Failure path — apply-time failure (e.g. no editor registered) is also an exact short reason', async () => {
    circuitToolBridge.unregister(editor); // simulate Electrical Lab not open
    const result = await sendChatMessage(conversationId, 'Add LED');

    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(looksLikeJson(result.error)).toBe(false);
    expect(result.error).toBe('No circuit is currently open.');

    circuitToolBridge.register(editor); // restore for afterEach's unregister
  });

  it('Chat history records the confirmation text, not the EditPlan object', async () => {
    editor.addComponentAt('led', 0, 0);
    editor.updateAllTerminalPositions();

    await sendChatMessage(conversationId, 'Remove LED');
    const history = conversationManager.getHistory(conversationId);
    const assistantTurn = history.find((t) => t.role === 'assistant');

    expect(typeof assistantTurn?.content).toBe('string');
    expect(looksLikeJson(assistantTurn!.content as string)).toBe(false);
  });
});
