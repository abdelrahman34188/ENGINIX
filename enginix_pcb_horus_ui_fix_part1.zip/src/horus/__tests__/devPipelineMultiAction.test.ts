// @vitest-environment jsdom
/**
 * Developer test — full multi-action circuit-edit pipeline, end to end:
 *
 *   request -> MultiActionExecutor -> CircuitEditPlanner -> EditValidator
 *   -> EditApplier -> CircuitToolBridge -> CircuitTool (the real
 *   CircuitEditor)
 *
 * Mirrors `devPipelineReplaceComponent.test.ts`'s real-editor setup, but
 * exercises a request describing several actions at once and checks the
 * sequencing/stop-on-failure contract `MultiActionExecutor` adds on top
 * of the existing single-action pipeline.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { CircuitEditPlanner } from '../core/Brain/CircuitEditPlanner';
import { EditValidator } from '../tools/EditValidator';
import { EditApplier } from '../tools/EditApplier';
import { MultiActionExecutor } from '../tools/MultiActionExecutor';
import { circuitToolBridge } from '../tools/CircuitToolBridge';

function makeEditor(): CircuitEditor {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    beginPath: () => {},
    fillRect: () => {},
    strokeRect: () => {},
    fill: () => {},
    stroke: () => {},
    arc: () => {},
    moveTo: () => {},
    lineTo: () => {},
    fillText: () => {},
    setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return new CircuitEditor(canvas, container);
}

describe('dev pipeline: MultiActionExecutor (multiple actions in one request)', () => {
  let editor: CircuitEditor;
  const executor = new MultiActionExecutor(
    new CircuitEditPlanner(),
    new EditValidator(circuitToolBridge),
    new EditApplier(circuitToolBridge),
  );

  beforeEach(() => {
    editor = makeEditor();
    circuitToolBridge.register(editor);
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('"Replace R1 with 220Ω. Add LED. Connect LED to R1." applies all three actions in order', () => {
    const r1 = editor.addComponentAt('resistor', 0, 0);
    r1.label = 'R1';
    const r1Id = r1.id;
    expect(r1.props.resistance).toBe(1000);

    const result = executor.executeAll('Replace R1 with 220Ω. Add LED. Connect LED to R1.');

    expect(result.failedAction).toBeNull();
    expect(result.reason).toBeNull();
    expect(result.completedActions).toHaveLength(3);
    expect(result.completedActions.map((a) => a.status)).toEqual(['applied', 'applied', 'applied']);

    // Action 1: R1 updated in place.
    const updatedR1 = editor.state.components.find((c) => c.id === r1Id);
    expect(updatedR1?.props.resistance).toBe(220);

    // Action 2: an LED was actually created on the real circuit.
    const led = editor.state.components.find((c) => c.type === 'led');
    expect(led).toBeDefined();

    // Action 3: LED and R1 are actually wired together.
    const wire = editor.state.wires.find(
      (w) =>
        (w.fromCompId === r1Id && w.toCompId === led!.id) ||
        (w.fromCompId === led!.id && w.toCompId === r1Id),
    );
    expect(wire).toBeDefined();
  });

  it('stops at the first failing action and never attempts the ones after it', () => {
    const r1 = editor.addComponentAt('resistor', 0, 0);
    r1.label = 'R1';
    const r1Id = r1.id;
    const countBeforeSecondAction = editor.state.components.length;

    // No LED exists yet, so action 2 ("Connect LED to R1") fails
    // validation — action 3 ("Add capacitor") must never run.
    const result = executor.executeAll('Replace R1 with 220Ω. Connect LED to R1. Add capacitor.');

    expect(result.completedActions).toHaveLength(1);
    expect(result.completedActions[0].status).toBe('applied');
    expect(result.completedActions[0].componentId).toBe(r1Id);

    expect(result.failedAction).not.toBeNull();
    expect(result.failedAction?.index).toBe(1);
    expect(result.failedAction?.requestText).toBe('Connect LED to R1');
    expect(result.failedAction?.stage).toBe('validate');
    expect(typeof result.reason).toBe('string');
    expect(result.reason!.length).toBeGreaterThan(0);

    // Action 1 really did apply (R1 updated)...
    const updatedR1 = editor.state.components.find((c) => c.id === r1Id);
    expect(updatedR1?.props.resistance).toBe(220);

    // ...but action 3 never ran: no capacitor was added, and the
    // component count only reflects action 1 (an in-place edit, not a
    // new component) — still just R1.
    expect(editor.state.components.length).toBe(countBeforeSecondAction);
    expect(editor.state.components.some((c) => c.type === 'capacitor')).toBe(false);
  });

  it('stops immediately when a clause is not a recognizable edit action at all', () => {
    const result = executor.executeAll('Add LED. Blah blah not an edit. Remove R1.');

    expect(result.completedActions).toHaveLength(1);
    expect(result.failedAction).not.toBeNull();
    expect(result.failedAction?.index).toBe(1);
    expect(result.failedAction?.stage).toBe('plan');
    expect(result.failedAction?.plan).toBeNull();

    // "Remove R1" (action 3) never ran.
    expect(editor.state.components.some((c) => c.type === 'resistor')).toBe(false);
  });

  it('a single-action request behaves the same as before — one completed action, no failure', () => {
    editor.addComponentAt('resistor', 0, 0).label = 'R1';

    const result = executor.executeAll('Remove R1');

    expect(result.completedActions).toHaveLength(1);
    expect(result.failedAction).toBeNull();
    expect(result.reason).toBeNull();
    expect(editor.state.components.length).toBe(0);
  });
});
