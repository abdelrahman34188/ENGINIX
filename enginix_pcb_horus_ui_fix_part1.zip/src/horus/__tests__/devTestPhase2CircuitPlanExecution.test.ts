// @vitest-environment jsdom
/**
 * HORUS AI — Phase 2 Developer Test.
 *
 * Exercises "Create a simple LED circuit" through the real, public
 * entry point (`sendChatMessage()` in `runtime.ts`) against a real
 * (headless) `CircuitEditor` — same construction
 * `devTestFiveCommands.test.ts` uses — asserting the simulator itself
 * (`editor.state`), not HORUS's own text, is what confirms success.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { circuitToolBridge } from '../tools/CircuitToolBridge';
import { sendChatMessage } from '../runtime';

function makeEditor(): { editor: CircuitEditor; canvas: HTMLCanvasElement; container: HTMLDivElement } {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    beginPath: () => {},
    fillRect: () => {},
    strokeRect: () => {},
    fill: () => {},
    stroke: () => {},
    arc: () => {},
    moveTo: () => {},
    lineTo: () => {},
    fillText: () => {},
    setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return { editor: new CircuitEditor(canvas, container), canvas, container };
}

describe('Phase 2 — "Create a simple LED circuit" plans and actually executes against the simulator', () => {
  let editor: CircuitEditor;
  let conversationId: string;

  beforeEach(() => {
    ({ editor } = makeEditor());
    circuitToolBridge.register(editor);
    conversationId = `dev-test-phase2-${Math.random()}`;
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('creates battery, resistor, switch, and LED in the live simulator with their planned properties applied', async () => {
    expect(editor.state.components.length).toBe(0);

    const result = await sendChatMessage(conversationId, 'Create a simple LED circuit');

    expect(result.ok).toBe(true);
    if (!result.ok) return;

    // The simulator's own state is the source of truth — not just a
    // "success" flag in the response.
    expect(editor.state.components.length).toBe(4);
    const types = editor.state.components.map((c) => c.type).sort();
    expect(types).toEqual(['battery', 'led', 'resistor', 'switch'].sort());

    const battery = editor.state.components.find((c) => c.type === 'battery');
    const resistor = editor.state.components.find((c) => c.type === 'resistor');
    expect(battery?.props.voltage).toBe(9);
    expect(resistor?.props.resistance).toBe(220);

    // planExecution carries the verified (read-back-confirmed) result.
    expect(result.planExecution).toBeTruthy();
    expect(result.planExecution?.status).toBe('completed');
    expect(result.planExecution?.created.length).toBe(4);
    expect(result.planExecution?.failed.length).toBe(0);
    for (const instance of result.planExecution?.created ?? []) {
      for (const prop of instance.properties) {
        expect(prop.applied).toBe(true);
      }
    }
  });

  it('reports a clear reason and creates nothing when no circuit is open', async () => {
    circuitToolBridge.unregister(editor); // simulate "no circuit open"

    const result = await sendChatMessage(conversationId, 'Create a simple LED circuit');

    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.error).toMatch(/no circuit is currently open/i);
    expect(editor.state.components.length).toBe(0);
  });
});
