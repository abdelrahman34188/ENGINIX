// @vitest-environment jsdom
/**
 * HORUS AI — Dev Test: lightweight IntentResolver (Arabic requests).
 *
 * Exercises the exact four brief examples through the real public
 * entry point (`sendChatMessage()`), against a real headless
 * `CircuitEditor`, plus IntentResolver's own ambiguity handling and
 * confirmation that English requests are completely unaffected.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { circuitToolBridge } from '../tools/CircuitToolBridge';
import { sendChatMessage } from '../runtime';
import { intentResolver } from '../core/Brain/IntentResolver';

function makeEditor(): { editor: CircuitEditor; canvas: HTMLCanvasElement; container: HTMLDivElement } {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {}, save: () => {}, restore: () => {}, translate: () => {}, rotate: () => {},
    beginPath: () => {}, fillRect: () => {}, strokeRect: () => {}, fill: () => {}, stroke: () => {},
    arc: () => {}, moveTo: () => {}, lineTo: () => {}, fillText: () => {}, setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return { editor: new CircuitEditor(canvas, container), canvas, container };
}

describe('IntentResolver: natural Arabic requests (dev brief scenarios)', () => {
  let editor: CircuitEditor;
  let conversationId: string;

  beforeEach(() => {
    ({ editor } = makeEditor());
    circuitToolBridge.register(editor);
    conversationId = `intent-resolver-${Math.random()}`;
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('"ضيف Arduino Mega" -> ADD_COMPONENT, real arduinoMega created', async () => {
    const result = await sendChatMessage(conversationId, 'ضيف Arduino Mega');
    expect(result.ok).toBe(true);
    expect(editor.state.components.length).toBe(1);
    expect(editor.state.components[0].type).toBe('arduinoMega');
  });

  it('"شيل الليد الأخضر" -> REMOVE_COMPONENT, the real green LED is removed (not just any LED)', async () => {
    await sendChatMessage(conversationId, 'ضيف Arduino Mega'); // decoy, unrelated component
    await sendChatMessage(conversationId, 'Add a Green LED');
    await sendChatMessage(conversationId, 'Add a Blue LED');
    expect(editor.state.components.length).toBe(3);

    const result = await sendChatMessage(conversationId, 'شيل الليد الأخضر');
    expect(result.ok).toBe(true);
    expect(editor.state.components.length).toBe(2);
    const remainingTypes = editor.state.components.map((c) => c.type);
    expect(remainingTypes).toContain('arduinoMega');
    const remainingLed = editor.state.components.find((c) => c.type === 'led');
    expect(remainingLed?.props.color).toBe('#0000ff'); // blue LED survives
  });

  it('"خلي الليد أزرق" -> MODIFY_PROPERTY, changes the real LED\'s color to blue', async () => {
    await sendChatMessage(conversationId, 'Add LED'); // default red
    const before = editor.state.components[0];
    expect(before.props.color).toBe('#ff0000');

    const result = await sendChatMessage(conversationId, 'خلي الليد أزرق');
    expect(result.ok).toBe(true);
    const after = editor.state.components.find((c) => c.id === before.id)!;
    expect(after.props.color).toBe('#0000ff');
  });

  it('"غير المقاومة لـ220Ω" -> MODIFY_PROPERTY, changes the real resistor\'s value to 220', async () => {
    await sendChatMessage(conversationId, 'Add resistor');
    const before = editor.state.components[0];

    const result = await sendChatMessage(conversationId, 'غير المقاومة لـ220Ω');
    expect(result.ok).toBe(true);
    const after = editor.state.components.find((c) => c.id === before.id)!;
    expect(after.props.resistance).toBe(220);
  });

  it('an incomplete Arabic request asks for clarification and creates nothing', async () => {
    const result = await sendChatMessage(conversationId, 'ضيف');
    expect(result.ok).toBe(false);
    expect(editor.state.components.length).toBe(0);
  });

  it('the clarification answer is merged with the pending Arabic request and actually executes', async () => {
    const first = await sendChatMessage(conversationId, 'ضيف');
    expect(first.ok).toBe(false);
    expect(editor.state.components.length).toBe(0);

    const second = await sendChatMessage(conversationId, 'resistor');
    expect(second.ok).toBe(true);
    expect(editor.state.components.length).toBe(1);
    expect(editor.state.components[0].type).toBe('resistor');
  });

  it('English requests are completely unaffected (IntentResolver stays out of the way)', () => {
    expect(intentResolver.resolve('Add LED').status).toBe('unrecognized');
    expect(intentResolver.resolve('Change R1 to 220 ohms').status).toBe('unrecognized');
  });

  it('plain Arabic conversation with no recognized action verb is left alone (falls through unchanged)', () => {
    expect(intentResolver.resolve('مرحبا كيف حالك').status).toBe('unrecognized');
  });
});
