// @vitest-environment jsdom
/**
 * HORUS AI — Dev Test: clarification follow-up execution fix.
 *
 * Bug: "Add Arduino" -> HORUS asks "Which Arduino?" -> user answers
 * "Mega" alone -> HORUS could reply as if it added something, but
 * "Mega" alone never reaches the edit-execution path (it has no
 * `add`/`remove`/etc. keyword), so nothing was ever created.
 *
 * Fix: the ambiguous request text is kept as pending context for the
 * conversation; the next message is merged into it ("Add Arduino" +
 * "Mega" -> "Add Arduino Mega") and *that* is what actually gets
 * planned, resolved, and executed through the real `CircuitToolBridge`
 * — so a reported success always corresponds to a real component.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { circuitToolBridge } from '../tools/CircuitToolBridge';
import { sendChatMessage } from '../runtime';

function makeEditor(): { editor: CircuitEditor; canvas: HTMLCanvasElement; container: HTMLDivElement } {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {}, save: () => {}, restore: () => {}, translate: () => {}, rotate: () => {},
    beginPath: () => {}, fillRect: () => {}, strokeRect: () => {}, fill: () => {}, stroke: () => {},
    arc: () => {}, moveTo: () => {}, lineTo: () => {}, fillText: () => {}, setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return { editor: new CircuitEditor(canvas, container), canvas, container };
}

describe('HORUS clarification follow-up execution (dev brief scenario)', () => {
  let editor: CircuitEditor;
  let conversationId: string;

  beforeEach(() => {
    ({ editor } = makeEditor());
    circuitToolBridge.register(editor);
    conversationId = `clarify-followup-${Math.random()}`;
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('"Add Arduino" asks a clarifying question and creates nothing yet', async () => {
    const result = await sendChatMessage(conversationId, 'Add Arduino');
    expect(result.ok).toBe(false);
    expect(editor.state.components.length).toBe(0);
  });

  it('the follow-up answer "Mega" is merged into the pending request and actually creates arduinoMega', async () => {
    const first = await sendChatMessage(conversationId, 'Add Arduino');
    expect(first.ok).toBe(false);
    expect(editor.state.components.length).toBe(0);

    const second = await sendChatMessage(conversationId, 'Mega');
    expect(second.ok).toBe(true);
    expect(editor.state.components.length).toBe(1);
    expect(editor.state.components[0].type).toBe('arduinoMega');
  });

  it('an unrelated fresh command after a clarification question is treated as its own request, not merged', async () => {
    const first = await sendChatMessage(conversationId, 'Add Arduino');
    expect(first.ok).toBe(false);
    expect(editor.state.components.length).toBe(0);

    const second = await sendChatMessage(conversationId, 'Add resistor');
    expect(second.ok).toBe(true);
    expect(editor.state.components.length).toBe(1);
    expect(editor.state.components[0].type).toBe('resistor');
  });

  it('a stale clarification does not leak into a later, unrelated follow-up once consumed', async () => {
    const first = await sendChatMessage(conversationId, 'Add Arduino');
    expect(first.ok).toBe(false);

    const second = await sendChatMessage(conversationId, 'Mega');
    expect(second.ok).toBe(true);
    expect(editor.state.components.length).toBe(1);

    // Pending context was consumed by "Mega" above — a further
    // unrelated message must not still try to merge onto "Add Arduino".
    const third = await sendChatMessage(conversationId, 'Add resistor');
    expect(third.ok).toBe(true);
    expect(editor.state.components.length).toBe(2);
    expect(editor.state.components[1].type).toBe('resistor');
  });
});
