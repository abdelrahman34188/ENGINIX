// @vitest-environment jsdom
/**
 * Developer test — full circuit-edit pipeline, end to end:
 *
 *   HORUS request -> CircuitEditPlanner -> EditValidator -> EditApplier
 *   -> CircuitToolBridge -> CircuitTool (the real CircuitEditor)
 *
 * Request under test: "Add LED."
 *
 * Expected, per spec:
 *  - Planner generates an `add` action.
 *  - Executor (`EditApplier`) calls the Bridge.
 *  - Bridge (`CircuitToolBridge`) calls CircuitTool (the real
 *    `CircuitEditor`, via `addComponentAt`).
 *  - The LED appears in the simulator's real component list.
 *  - No UI changes: no DOM node is created/removed, no canvas
 *    re-context, no new `CircuitEditor`/container/canvas — the same
 *    editor instance, wired to the same canvas and container it
 *    started with, just gains one component in its state.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { CircuitEditPlanner } from '../core/Brain/CircuitEditPlanner';
import { EditValidator } from '../tools/EditValidator';
import { EditApplier } from '../tools/EditApplier';
import { circuitToolBridge } from '../tools/CircuitToolBridge';

/** Same headless-editor construction used across the other CircuitEditor
 *  and pipeline tests — a real `CircuitEditor` against a mocked canvas
 *  context, not a stub circuit. */
function makeEditor(): { editor: CircuitEditor; canvas: HTMLCanvasElement; container: HTMLDivElement } {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    beginPath: () => {},
    fillRect: () => {},
    strokeRect: () => {},
    fill: () => {},
    stroke: () => {},
    arc: () => {},
    moveTo: () => {},
    lineTo: () => {},
    fillText: () => {},
    setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return { editor: new CircuitEditor(canvas, container), canvas, container };
}

describe('dev pipeline: Planner -> Executor -> CircuitToolBridge -> CircuitTool ("Add LED")', () => {
  let editor: CircuitEditor;
  let canvas: HTMLCanvasElement;
  let container: HTMLDivElement;
  const planner = new CircuitEditPlanner();
  const validator = new EditValidator(circuitToolBridge);
  const applier = new EditApplier(circuitToolBridge);

  beforeEach(() => {
    ({ editor, canvas, container } = makeEditor());
    circuitToolBridge.register(editor);
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('"Add LED" — Planner emits an add action', () => {
    const request = 'Add LED.';
    expect(planner.isEditRequest({ request })).toBe(true);

    const plan = planner.planEdit({ request });
    expect(plan).not.toBeNull();
    expect(plan!.action).toBe('add_component');
    expect(plan!.target?.raw.toLowerCase()).toBe('led');
    expect(plan!.target?.componentType).toBe('led');
  });

  it('"Add LED" — Executor calls the Bridge, Bridge calls CircuitTool, LED appears in the simulator', () => {
    expect(editor.state.components.length).toBe(0);

    const request = 'Add LED.';
    const plan = planner.planEdit({ request });
    const validated = validator.validate(plan!);
    expect(validated.valid).toBe(true);
    expect(validated.plan.action).toBe('add');

    // Spy on the Bridge to prove the Executor actually calls through to
    // it (rather than faking success), and on the real CircuitEditor
    // method the Bridge itself calls through to.
    const bridgeSpy = vi.spyOn(circuitToolBridge, 'addComponent');
    const editorSpy = vi.spyOn(editor, 'addComponentAt');

    const result = applier.apply(validated);

    expect(result.status).toBe('applied');
    expect(bridgeSpy).toHaveBeenCalledTimes(1);
    expect(bridgeSpy).toHaveBeenCalledWith('led');
    expect(editorSpy).toHaveBeenCalledTimes(1);
    expect(editorSpy).toHaveBeenCalledWith('led', expect.any(Number), expect.any(Number));

    // The LED is a real component in the simulator's own state, not a
    // fake/mirrored copy.
    const led = editor.state.components.find((c) => c.id === result.componentId);
    expect(led).toBeDefined();
    expect(led!.type).toBe('led');
    expect(editor.state.components.length).toBe(1);

    // And it's visible back through the read side of the same bridge.
    expect(circuitToolBridge.getComponents().some((c) => c.id === result.componentId)).toBe(true);

    bridgeSpy.mockRestore();
    editorSpy.mockRestore();
  });

  it('"Add LED" — no UI changes: same editor/canvas/container instance, no DOM churn', () => {
    const request = 'Add LED.';
    const plan = planner.planEdit({ request });
    const validated = validator.validate(plan!);

    const bodyChildrenBefore = document.body.childElementCount;
    const containerChildrenBefore = container.childElementCount;

    const result = applier.apply(validated);
    expect(result.status).toBe('applied');

    // No new DOM nodes anywhere, no swapped canvas/container, and the
    // bridge is still backed by this exact editor instance — an "add"
    // is a state mutation only, never a UI rebuild.
    expect(document.body.childElementCount).toBe(bodyChildrenBefore);
    expect(container.childElementCount).toBe(containerChildrenBefore);
    expect(document.body.contains(canvas)).toBe(false); // never attached; still the same detached node
    expect(circuitToolBridge.getComponents().length).toBe(1);
  });
});
