// @vitest-environment jsdom
/**
 * HORUS AI — Dev Test: discovery + property-aware creation fix.
 *
 * Exercises the exact six scenarios from the brief through the real
 * public entry point (`sendChatMessage()`), against a real headless
 * `CircuitEditor`:
 *   1. Add IR Obstacle Sensor  — a real simulator component with no
 *      entry in the hand-written alias list, discovered via its own
 *      real display name instead.
 *   2. Add Flame Sensor        — same, different part.
 *   3. Add Gas Sensor          — same, matched against "MQ-2 Gas
 *      Sensor" by partial real name, not a hardcoded special case.
 *   4. Add Green LED           — property-aware creation: the LED is
 *      created with its Color property already applied, not the
 *      default color.
 *   5. Add Blue LED            — same, different color.
 *   6. Change an existing LED's color — a non-numeric property edit
 *      on an already-placed component.
 *
 * None of "irObstacle", "flameSensor", "mq2Gas" appear in this file's
 * assertions by coincidence of a hardcoded fix — they're exactly the
 * simulator's own `ComponentType` keys the fix discovers dynamically
 * from `componentDefs.ts`'s real catalog.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { circuitToolBridge } from '../tools/CircuitToolBridge';
import { sendChatMessage } from '../runtime';

function makeEditor(): { editor: CircuitEditor; canvas: HTMLCanvasElement; container: HTMLDivElement } {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {}, save: () => {}, restore: () => {}, translate: () => {}, rotate: () => {},
    beginPath: () => {}, fillRect: () => {}, strokeRect: () => {}, fill: () => {}, stroke: () => {},
    arc: () => {}, moveTo: () => {}, lineTo: () => {}, fillText: () => {}, setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return { editor: new CircuitEditor(canvas, container), canvas, container };
}

describe('HORUS discovery + property-aware creation (dev brief scenarios)', () => {
  let editor: CircuitEditor;
  let conversationId: string;

  beforeEach(() => {
    ({ editor } = makeEditor());
    circuitToolBridge.register(editor);
    conversationId = `discovery-prop-${Math.random()}`;
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('1) "Add IR Obstacle Sensor" -> irObstacle, discovered by real name (no alias entry exists for it)', async () => {
    const result = await sendChatMessage(conversationId, 'Add IR Obstacle Sensor');
    expect(result.ok).toBe(true);
    expect(editor.state.components.length).toBe(1);
    expect(editor.state.components[0].type).toBe('irObstacle');
  });

  it('2) "Add Flame Sensor" -> flameSensor, discovered by real name', async () => {
    const result = await sendChatMessage(conversationId, 'Add Flame Sensor');
    expect(result.ok).toBe(true);
    expect(editor.state.components.length).toBe(1);
    expect(editor.state.components[0].type).toBe('flameSensor');
  });

  it('3) "Add Gas Sensor" -> mq2Gas, matched against its real partial name ("MQ-2 Gas Sensor")', async () => {
    const result = await sendChatMessage(conversationId, 'Add Gas Sensor');
    expect(result.ok).toBe(true);
    expect(editor.state.components.length).toBe(1);
    expect(editor.state.components[0].type).toBe('mq2Gas');
  });

  it('4) "Add a Green LED" -> led created with Color already applied (not the default red)', async () => {
    const result = await sendChatMessage(conversationId, 'Add a Green LED');
    expect(result.ok).toBe(true);
    expect(editor.state.components.length).toBe(1);
    const comp = editor.state.components[0];
    expect(comp.type).toBe('led');
    expect(comp.props.color).toBe('#00ff00');
  });

  it('5) "Add a Blue LED" -> led created with Color already applied', async () => {
    const result = await sendChatMessage(conversationId, 'Add a Blue LED');
    expect(result.ok).toBe(true);
    expect(editor.state.components.length).toBe(1);
    const comp = editor.state.components[0];
    expect(comp.type).toBe('led');
    expect(comp.props.color).toBe('#0000ff');
  });

  it('6) changing an existing LED\'s color edits the real Color property, not the primary numeric one', async () => {
    await sendChatMessage(conversationId, 'Add LED');
    const before = editor.state.components[0];
    expect(before.props.color).toBe('#ff0000'); // default red

    const result = await sendChatMessage(conversationId, `Change ${before.label} color to Blue`);
    expect(result.ok).toBe(true);

    const after = editor.state.components.find((c) => c.id === before.id)!;
    expect(after.props.color).toBe('#0000ff');
    // The unrelated numeric property must be untouched by the color edit.
    expect(after.props.forwardVoltage).toBe(before.props.forwardVoltage);
  });

  it('a requested-but-unsupported property is reported clearly, never silently dropped', async () => {
    const result = await sendChatMessage(conversationId, 'Add a Loud LED');
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.error.toLowerCase()).toMatch(/not (a )?supported|isn't a supported/);
    // Nothing should have been created with a silently-ignored qualifier.
    expect(editor.state.components.length).toBe(0);
  });
});
