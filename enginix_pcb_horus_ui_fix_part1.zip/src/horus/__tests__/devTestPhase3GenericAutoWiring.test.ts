// @vitest-environment jsdom
/**
 * HORUS AI — Phase 3 Developer Test (Generic Auto Wiring).
 *
 * `ConnectionPlanner.planConnections()` is generic — it reasons from
 * each component's electrical role (power source / passthrough / load
 * / controller), never from a named scenario. These tests build
 * `PlannedComponent` lists directly (the same shape `CircuitPlanner`
 * itself produces from `resolveNeed()`), bypassing goal-text matching
 * entirely, to prove the wiring system works for arbitrary component
 * sets — not just the one scenario Phase 2/3's earlier test covered.
 *
 * Every test executes against a real (headless) `CircuitEditor` and
 * asserts `editor.state.wires` (the simulator itself) — never HORUS's
 * own text or a mutator's return value.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { defaultProperties } from '../../circuit/componentDefs';
import { circuitToolBridge } from '../tools/CircuitToolBridge';
import { circuitBuildOrchestrator } from '../tools/CircuitBuildOrchestrator';
import type { CircuitPlan, PlannedComponent } from '../core/Brain/CircuitPlanner';
import { planConnections } from '../core/Brain/ConnectionPlanner';

function makeEditor(): { editor: CircuitEditor } {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {}, save: () => {}, restore: () => {}, translate: () => {}, rotate: () => {},
    beginPath: () => {}, fillRect: () => {}, strokeRect: () => {}, fill: () => {}, stroke: () => {},
    arc: () => {}, moveTo: () => {}, lineTo: () => {}, fillText: () => {}, setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return { editor: new CircuitEditor(canvas, container) };
}

/** Builds a real `PlannedComponent` (same shape `CircuitPlanner`
 *  itself produces) straight from the simulator's own
 *  `defaultProperties` schema — never a hand-invented property list. */
function plannedComponent(type: string, quantity: number, overrides: Record<string, number | string | boolean> = {}): PlannedComponent {
  const schema = defaultProperties[type] ?? [];
  return {
    type,
    name: type,
    quantity,
    properties: schema.map((p) => ({
      key: p.key,
      name: p.name,
      unit: p.unit,
      value: Object.prototype.hasOwnProperty.call(overrides, p.key) ? overrides[p.key] : p.defaultValue,
    })),
    rationale: 'dev test',
    alternativeTypes: [],
  };
}

function planFor(components: PlannedComponent[]): CircuitPlan {
  return {
    goal: 'dev test',
    scenario: 'dev_test',
    summary: 'Dev test circuit.',
    components,
    unavailableComponents: [],
    functionalRequirements: [],
    circuitRequirements: [],
    plannedConnections: planConnections(components),
  };
}

function isWired(editor: CircuitEditor, aId: number, bId: number): boolean {
  return editor.state.wires.some(
    (w) => (w.fromCompId === aId && w.toCompId === bId) || (w.fromCompId === bId && w.toCompId === aId)
  );
}

describe('Phase 3 — generic auto wiring across arbitrary circuit shapes', () => {
  let editor: CircuitEditor;

  beforeEach(() => {
    ({ editor } = makeEditor());
    circuitToolBridge.register(editor);
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('Battery -> Resistor -> LED -> GND', () => {
    const plan = planFor([
      plannedComponent('battery', 1, { voltage: 9 }),
      plannedComponent('resistor', 1, { resistance: 220 }),
      plannedComponent('led', 1),
    ]);

    const { planExecution, wiringExecution } = circuitBuildOrchestrator.build(plan);

    expect(planExecution.status).toBe('completed');
    expect(planExecution.failed).toEqual([]);
    expect(wiringExecution.status).toBe('completed');
    expect(wiringExecution.failed).toEqual([]);
    expect(editor.state.wires.length).toBe(3);

    const battery = editor.state.components.find((c) => c.type === 'battery')!;
    const resistor = editor.state.components.find((c) => c.type === 'resistor')!;
    const led = editor.state.components.find((c) => c.type === 'led')!;
    expect(isWired(editor, battery.id, resistor.id)).toBe(true);
    expect(isWired(editor, resistor.id, led.id)).toBe(true);
    expect(isWired(editor, led.id, battery.id)).toBe(true);
  });

  it('Battery -> Switch -> Resistor -> LED -> GND', () => {
    const plan = planFor([
      plannedComponent('battery', 1, { voltage: 9 }),
      plannedComponent('resistor', 1, { resistance: 220 }),
      plannedComponent('switch', 1),
      plannedComponent('led', 1),
    ]);

    const { planExecution, wiringExecution } = circuitBuildOrchestrator.build(plan);

    expect(planExecution.status).toBe('completed');
    expect(wiringExecution.status).toBe('completed');
    expect(wiringExecution.failed).toEqual([]);
    expect(editor.state.wires.length).toBe(4);

    const battery = editor.state.components.find((c) => c.type === 'battery')!;
    const resistor = editor.state.components.find((c) => c.type === 'resistor')!;
    const sw = editor.state.components.find((c) => c.type === 'switch')!;
    const led = editor.state.components.find((c) => c.type === 'led')!;
    expect(isWired(editor, battery.id, resistor.id)).toBe(true);
    expect(isWired(editor, resistor.id, sw.id)).toBe(true);
    expect(isWired(editor, sw.id, led.id)).toBe(true);
    expect(isWired(editor, led.id, battery.id)).toBe(true);
  });

  it('Arduino -> LED using a digital pin and GND', () => {
    const plan = planFor([plannedComponent('arduino', 1), plannedComponent('led', 1)]);

    const { planExecution, wiringExecution } = circuitBuildOrchestrator.build(plan);

    expect(planExecution.status).toBe('completed');
    expect(wiringExecution.status).toBe('completed');
    expect(wiringExecution.failed).toEqual([]);
    expect(editor.state.wires.length).toBe(2);

    const arduino = editor.state.components.find((c) => c.type === 'arduino')!;
    const led = editor.state.components.find((c) => c.type === 'led')!;

    const d2Terminal = arduino.terminals.find((t) => t.label === 'D2')!;
    const gndTerminal = arduino.terminals.find((t) => t.label === 'GND')!;
    const anodeTerminal = led.terminals.find((t) => t.label === 'A')!;
    const cathodeTerminal = led.terminals.find((t) => t.label === 'K')!;

    const hasWireBetween = (termAId: number, termBId: number) =>
      editor.state.wires.some(
        (w) =>
          (w.fromTerminalId === termAId && w.toTerminalId === termBId) ||
          (w.fromTerminalId === termBId && w.toTerminalId === termAId)
      );

    expect(hasWireBetween(d2Terminal.id, anodeTerminal.id)).toBe(true);
    expect(hasWireBetween(cathodeTerminal.id, gndTerminal.id)).toBe(true);
  });

  it('Arduino -> multiple LEDs using different digital pins', () => {
    const plan = planFor([plannedComponent('arduino', 1), plannedComponent('led', 3)]);

    const { planExecution, wiringExecution } = circuitBuildOrchestrator.build(plan);

    expect(planExecution.status).toBe('completed');
    expect(planExecution.created.length).toBe(4); // 1 arduino + 3 LEDs
    expect(wiringExecution.status).toBe('completed');
    expect(wiringExecution.failed).toEqual([]);
    expect(editor.state.wires.length).toBe(6); // 2 wires (pin + GND) per LED

    const arduino = editor.state.components.find((c) => c.type === 'arduino')!;
    const leds = editor.state.components.filter((c) => c.type === 'led');
    expect(leds.length).toBe(3);

    const usedDigitalPins = new Set<string>();
    for (const led of leds) {
      const anode = led.terminals.find((t) => t.label === 'A')!;
      const wireToAnode = editor.state.wires.find(
        (w) => w.fromTerminalId === anode.id || w.toTerminalId === anode.id
      )!;
      const otherTerminalId =
        wireToAnode.fromTerminalId === anode.id ? wireToAnode.toTerminalId : wireToAnode.fromTerminalId;
      const pinTerminal = arduino.terminals.find((t) => t.id === otherTerminalId)!;
      expect(pinTerminal.label).toMatch(/^D\d+$/);
      usedDigitalPins.add(pinTerminal.label);

      const cathode = led.terminals.find((t) => t.label === 'K')!;
      const gnd = arduino.terminals.find((t) => t.label === 'GND')!;
      const wiredToGnd = editor.state.wires.some(
        (w) =>
          (w.fromTerminalId === cathode.id && w.toTerminalId === gnd.id) ||
          (w.fromTerminalId === gnd.id && w.toTerminalId === cathode.id)
      );
      expect(wiredToGnd).toBe(true);
    }
    // Every LED landed on a distinct digital pin — never reused.
    expect(usedDigitalPins.size).toBe(3);
  });

  it('reports the exact missing component when a planned connection references one that was never created', () => {
    // No circuit registered — nothing can be created, so every planned
    // connection's endpoints resolve to "never created".
    circuitToolBridge.unregister(editor);

    const plan = planFor([plannedComponent('battery', 1), plannedComponent('resistor', 1), plannedComponent('led', 1)]);
    const { planExecution, wiringExecution } = circuitBuildOrchestrator.build(plan);

    expect(planExecution.created.length).toBe(0);
    expect(wiringExecution.status).toBe('failed');
    expect(wiringExecution.connected).toEqual([]);
    expect(wiringExecution.failed.length).toBeGreaterThan(0);
    expect(wiringExecution.failed[0].reason).toMatch(/battery #1 was never created/i);
  });
});
