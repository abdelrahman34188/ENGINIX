// @vitest-environment jsdom
/**
 * HORUS AI — Dev Test: component discovery + CRUD only (no wiring).
 *
 * Exercises the exact five scenarios from the brief through the real
 * public entry point (`sendChatMessage()`), against a real headless
 * `CircuitEditor`:
 *   1. Add an existing component using a natural name.
 *   2. Remove it.
 *   3. Change one of its properties.
 *   4. Several different component types (including multi-word,
 *      camelCase types like "push button" -> `pushButton`).
 *   5. An unknown component -> reported unavailable.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { circuitToolBridge } from '../tools/CircuitToolBridge';
import { sendChatMessage } from '../runtime';

function makeEditor(): { editor: CircuitEditor; canvas: HTMLCanvasElement; container: HTMLDivElement } {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {}, save: () => {}, restore: () => {}, translate: () => {}, rotate: () => {},
    beginPath: () => {}, fillRect: () => {}, strokeRect: () => {}, fill: () => {}, stroke: () => {},
    arc: () => {}, moveTo: () => {}, lineTo: () => {}, fillText: () => {}, setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return { editor: new CircuitEditor(canvas, container), canvas, container };
}

describe('HORUS discovery + CRUD (no wiring)', () => {
  let editor: CircuitEditor;
  let conversationId: string;

  beforeEach(() => {
    ({ editor } = makeEditor());
    circuitToolBridge.register(editor);
    conversationId = `discovery-crud-${Math.random()}`;
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('1) adds an existing component using a natural name ("add a lamp" -> bulb)', async () => {
    const before = editor.state.components.length;
    const result = await sendChatMessage(conversationId, 'Add a lamp');
    expect(result.ok).toBe(true);
    expect(editor.state.components.length).toBe(before + 1);
    expect(editor.state.components[editor.state.components.length - 1].type).toBe('bulb');
  });

  it('2) removes the component just added', async () => {
    await sendChatMessage(conversationId, 'Add a lamp');
    const countAfterAdd = editor.state.components.length;
    const result = await sendChatMessage(conversationId, 'Remove the bulb');
    expect(result.ok).toBe(true);
    expect(editor.state.components.length).toBe(countAfterAdd - 1);
  });

  it('3) changes one of its properties', async () => {
    await sendChatMessage(conversationId, 'Add a resistor');
    const result = await sendChatMessage(conversationId, 'Change the resistor to 220 ohm');
    expect(result.ok).toBe(true);
    const comp = editor.state.components.find((c) => c.type === 'resistor')!;
    expect(comp.props.resistance).toBe(220);
  });

  it('4) several different component types via natural names', async () => {
    const cases: Array<[string, string]> = [
      ['Add a knob', 'potentiometer'],
      ['Add a push button', 'pushButton'],
      ['Add a battery', 'battery'],
      ['Add a capacitor', 'capacitor'],
      ['Add a dc motor', 'dcMotor'],
      ['Add a stepper', 'stepperMotor'],
    ];
    for (const [command, expectedType] of cases) {
      const before = editor.state.components.length;
      const result = await sendChatMessage(conversationId, command);
      expect(result.ok).toBe(true);
      expect(editor.state.components.length).toBe(before + 1);
      expect(editor.state.components[editor.state.components.length - 1].type).toBe(expectedType);
    }
  });

  it('5) reports an unknown component as unavailable', async () => {
    const before = editor.state.components.length;
    const result = await sendChatMessage(conversationId, 'Add a photonic emitter');
    expect(editor.state.components.length).toBe(before);
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.error.toLowerCase()).toMatch(/not (a )?recognized|unavailable|not available/);
  });
});
