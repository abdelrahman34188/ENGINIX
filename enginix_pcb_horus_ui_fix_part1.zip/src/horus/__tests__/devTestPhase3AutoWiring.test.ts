// @vitest-environment jsdom
/**
 * HORUS AI — Phase 3 Developer Test (Auto Wiring).
 *
 * Exercises "Create a simple LED circuit" end to end through the real
 * public entry point (`sendChatMessage()`), against a real (headless)
 * `CircuitEditor` — same construction `devTestPhase2CircuitPlanExecution.test.ts`
 * uses. Asserts the simulator's own `editor.state.wires` (not HORUS's
 * own text, not the mutator's return value) is what confirms every
 * connection was actually made.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { circuitToolBridge } from '../tools/CircuitToolBridge';
import { sendChatMessage } from '../runtime';

function makeEditor(): { editor: CircuitEditor; canvas: HTMLCanvasElement; container: HTMLDivElement } {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    beginPath: () => {},
    fillRect: () => {},
    strokeRect: () => {},
    fill: () => {},
    stroke: () => {},
    arc: () => {},
    moveTo: () => {},
    lineTo: () => {},
    fillText: () => {},
    setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return { editor: new CircuitEditor(canvas, container), canvas, container };
}

describe('Phase 3 — "Create a simple LED circuit" builds AND wires the circuit in the live simulator', () => {
  let editor: CircuitEditor;
  let conversationId: string;

  beforeEach(() => {
    ({ editor } = makeEditor());
    circuitToolBridge.register(editor);
    conversationId = `dev-test-phase3-${Math.random()}`;
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('creates battery, switch, resistor, LED and wires them into one closed series loop', async () => {
    const result = await sendChatMessage(conversationId, 'Create a simple LED circuit');

    expect(result.ok).toBe(true);
    if (!result.ok) return;

    // Components: same Phase 2 guarantee, unchanged.
    expect(editor.state.components.length).toBe(4);

    // Wiring: the simulator's own wire list is the source of truth.
    expect(editor.state.wires.length).toBe(4);

    const battery = editor.state.components.find((c) => c.type === 'battery')!;
    const sw = editor.state.components.find((c) => c.type === 'switch')!;
    const resistor = editor.state.components.find((c) => c.type === 'resistor')!;
    const led = editor.state.components.find((c) => c.type === 'led')!;

    const isWired = (aId: number, bId: number) =>
      editor.state.wires.some(
        (w) =>
          (w.fromCompId === aId && w.toCompId === bId) || (w.fromCompId === bId && w.toCompId === aId)
      );

    // Generic series topology: power source, then passthrough parts in
    // plan order (battery, resistor, switch — `planSimpleLedCircuit`
    // adds them in that order), then the load, back to the source.
    // The chain is a closed loop either way; only the pairing between
    // adjacent passthrough parts depends on that order.
    expect(isWired(battery.id, resistor.id)).toBe(true);
    expect(isWired(resistor.id, sw.id)).toBe(true);
    expect(isWired(sw.id, led.id)).toBe(true);
    expect(isWired(led.id, battery.id)).toBe(true);

    // HORUS's own report is built from, and matches, the verified
    // outcome — never a claim ahead of the simulator's actual state.
    expect(result.wiringExecution).toBeTruthy();
    expect(result.wiringExecution?.status).toBe('completed');
    expect(result.wiringExecution?.connected.length).toBe(4);
    expect(result.wiringExecution?.failed.length).toBe(0);
    for (const wire of result.wiringExecution?.connected ?? []) {
      expect(editor.state.wires.some((w) => w.id === wire.wireId)).toBe(true);
    }
  });

  it('never claims wiring happened when no circuit is open', async () => {
    circuitToolBridge.unregister(editor); // simulate "no circuit open"

    const result = await sendChatMessage(conversationId, 'Create a simple LED circuit');

    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(editor.state.wires.length).toBe(0);
  });

  it('reports specific, per-connection reasons rather than a generic failure when a planned component was never created', async () => {
    const { wiringExecutor } = await import('../tools/WiringExecutor');
    const plan = {
      goal: 'test',
      scenario: 'test',
      summary: 'test',
      components: [],
      unavailableComponents: [],
      functionalRequirements: [],
      circuitRequirements: [],
      plannedConnections: [
        {
          from: { componentType: 'battery', instanceIndex: 0, role: 'positive' },
          to: { componentType: 'led', instanceIndex: 0, role: 'anode' },
          description: 'Battery positive to LED anode.',
        },
      ],
    };

    // Nothing was actually created — `created` is empty.
    const wiring = wiringExecutor.execute(plan, []);
    expect(wiring.status).toBe('failed');
    expect(wiring.connected.length).toBe(0);
    expect(wiring.failed.length).toBe(1);
    expect(wiring.failed[0].reason).toMatch(/battery #1 was never created/i);
  });
});
