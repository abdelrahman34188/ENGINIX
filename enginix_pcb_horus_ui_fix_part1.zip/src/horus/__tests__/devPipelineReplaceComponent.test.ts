// @vitest-environment jsdom
/**
 * Developer test — full circuit-edit pipeline, end to end:
 *
 *   HORUS request -> CircuitEditPlanner -> EditValidator -> EditApplier
 *   -> CircuitToolBridge -> CircuitTool (the real CircuitEditor)
 *
 * Request under test: "Replace R1 with 220Ω resistor."
 *
 * Expected, per spec:
 *  - The simulator's real R1 component is updated (same id, same wires,
 *    same array slot) — not deleted and recreated.
 *  - No refresh: the same CircuitEditor/canvas instance is used
 *    throughout; nothing here tears down or reconstructs it.
 *  - No rebuild: component count before/after is identical, and R1's
 *    identity (id) is unchanged.
 *  - No fake response: `EditApplier.apply()` only ever reports
 *    `'applied'` after a real `CircuitToolBridge` mutator call
 *    succeeded against the real editor state.
 *  - Missing component: a request naming a component that doesn't
 *    exist comes back as a structured `{ status: 'error', field,
 *    message }` — never a thrown exception, never a fake success.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../circuit/CircuitEditor';
import { CircuitEditPlanner } from '../core/Brain/CircuitEditPlanner';
import { EditValidator } from '../tools/EditValidator';
import { EditApplier } from '../tools/EditApplier';
import { circuitToolBridge } from '../tools/CircuitToolBridge';

/** Same headless-editor construction `CircuitEditor.autoArrange.test.ts`
 *  already uses — a real `CircuitEditor` against a mocked canvas
 *  context, not a fake/stub circuit. */
function makeEditor(): CircuitEditor {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    beginPath: () => {},
    fillRect: () => {},
    strokeRect: () => {},
    fill: () => {},
    stroke: () => {},
    arc: () => {},
    moveTo: () => {},
    lineTo: () => {},
    fillText: () => {},
    setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return new CircuitEditor(canvas, container);
}

describe('dev pipeline: Planner -> Validator -> Applier -> CircuitToolBridge -> CircuitTool', () => {
  let editor: CircuitEditor;
  const planner = new CircuitEditPlanner();
  const validator = new EditValidator(circuitToolBridge);
  const applier = new EditApplier(circuitToolBridge);

  beforeEach(() => {
    editor = makeEditor();
    circuitToolBridge.register(editor);
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('"Replace R1 with 220Ω resistor" updates R1 in place — no rebuild, no refresh', () => {
    // Arrange: a real R1 already on the circuit, wired to nothing yet,
    // at its default 1000Ω.
    const r1 = editor.addComponentAt('resistor', 0, 0);
    r1.label = 'R1';
    const r1Id = r1.id;
    const countBefore = editor.state.components.length;
    expect(r1.props.resistance).toBe(1000);

    // Act: run the real pipeline.
    const request = 'Replace R1 with 220Ω resistor.';
    expect(planner.isEditRequest({ request })).toBe(true);
    const plan = planner.planEdit({ request });
    expect(plan).not.toBeNull();

    const validated = validator.validate(plan!);
    expect(validated.valid).toBe(true);

    const result = applier.apply(validated);

    // Assert: a real, non-fake success.
    expect(result.status).toBe('applied');
    expect(result.componentId).toBe(r1Id);

    // Assert: the simulator's actual state changed.
    const updated = editor.state.components.find((c) => c.id === r1Id);
    expect(updated?.props.resistance).toBe(220);

    // Assert: no rebuild — same id, same component count, same slot;
    // R1 was edited, not deleted and recreated.
    expect(editor.state.components.length).toBe(countBefore);
    expect(editor.state.components.filter((c) => c.id === r1Id).length).toBe(1);

    // Assert: no refresh — the same CircuitEditor instance (still
    // registered with the bridge) reflects the change; nothing tore
    // it down or swapped it out.
    expect(circuitToolBridge.getComponents().find((c) => c.id === r1Id)?.label).toBe('R1');
  });

  it('returns a structured error (not a thrown exception, not a fake success) when the component does not exist', () => {
    // No R1 on the circuit at all.
    expect(editor.state.components.length).toBe(0);

    const request = 'Replace R1 with 220Ω resistor.';
    const plan = planner.planEdit({ request });
    expect(plan).not.toBeNull();

    const validated = validator.validate(plan!);
    expect(validated.valid).toBe(false);
    expect(validated.targetExists).toBe(false);

    let result;
    expect(() => {
      result = applier.apply(validated);
    }).not.toThrow();

    expect(result!.status).toBe('error');
    expect(result!.field).toBe('target');
    expect(typeof result!.message).toBe('string');
    expect(result!.message!.length).toBeGreaterThan(0);

    // And the circuit genuinely wasn't touched.
    expect(editor.state.components.length).toBe(0);
  });

  it('rejects at validation and never calls a bridge mutator when the plan is invalid', () => {
    const r1 = editor.addComponentAt('resistor', 0, 0);
    r1.label = 'R1';

    // "Replace R1 with R1" — a real EditValidator rejection (replacing
    // a component with itself), so the applier must bail out on
    // validated.valid === false without touching the circuit.
    const plan = planner.planEdit({ request: 'Replace R1 with R1.' });
    const validated = validator.validate(plan!);
    expect(validated.valid).toBe(false);

    const spy = vi.spyOn(circuitToolBridge, 'changeComponentValue');
    const result = applier.apply(validated);

    expect(result.status).toBe('error');
    expect(spy).not.toHaveBeenCalled();
    spy.mockRestore();
  });
});
