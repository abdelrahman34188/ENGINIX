/**
 * HORUS AI — Dev Test: Auto Circuit Planner (Phase 1, planning only).
 *
 * Exercises the three brief scenarios and confirms the planner never
 * mutates a circuit (there's no `CircuitEditor` instantiated at all
 * in this file — if `CircuitPlanner` needed one to run, these tests
 * simply couldn't compile/run).
 */
import { describe, it, expect } from 'vitest';
import { circuitPlanner } from '../core/Brain/CircuitPlanner';
import { componentNames, defaultProperties } from '../../circuit/componentDefs';

describe('CircuitPlanner: "Create a simple LED circuit"', () => {
  const plan = circuitPlanner.planCircuit({ goal: 'Create a simple LED circuit' });

  it('recognizes the simple LED circuit scenario', () => {
    expect(plan.scenario).toBe('simple_led_circuit');
  });

  it('requires a real LED, resistor, battery, and switch — nothing invented', () => {
    const types = plan.components.map((c) => c.type).sort();
    expect(types).toEqual(['battery', 'led', 'resistor', 'switch']);
    for (const c of plan.components) {
      expect(c.name).toBe(componentNames[c.type as keyof typeof componentNames]);
      expect(Object.keys(defaultProperties)).toContain(c.type);
    }
  });

  it('gives the resistor a current-limiting value, not the generic default', () => {
    const resistor = plan.components.find((c) => c.type === 'resistor')!;
    const resistance = resistor.properties.find((p) => p.key === 'resistance')!;
    expect(resistance.value).toBe(220);
  });

  it('reports no unavailable components', () => {
    expect(plan.unavailableComponents).toEqual([]);
  });

  it('states functional and circuit requirements, not wiring instructions', () => {
    expect(plan.functionalRequirements.length).toBeGreaterThan(0);
    expect(plan.circuitRequirements.length).toBeGreaterThan(0);
  });
});

describe('CircuitPlanner: "Create a traffic light system"', () => {
  const plan = circuitPlanner.planCircuit({ goal: 'Create a traffic light system' });

  it('recognizes the traffic light scenario', () => {
    expect(plan.scenario).toBe('traffic_light_system');
  });

  it('requires an Arduino, three LEDs, and three resistors', () => {
    const arduino = plan.components.find((c) => c.type.startsWith('arduino'));
    expect(arduino).toBeDefined();
    expect(arduino!.quantity).toBe(1);

    const led = plan.components.find((c) => c.type === 'led');
    expect(led).toBeDefined();
    expect(led!.quantity).toBe(3);

    const resistor = plan.components.find((c) => c.type === 'resistor');
    expect(resistor).toBeDefined();
    expect(resistor!.quantity).toBe(3);
  });

  it('describes sequencing behavior as a functional requirement', () => {
    expect(plan.functionalRequirements.some((r) => /green|yellow|red/i.test(r))).toBe(true);
  });
});

describe('CircuitPlanner: "Create a fire alarm system"', () => {
  const plan = circuitPlanner.planCircuit({ goal: 'Create a fire alarm system' });

  it('recognizes the fire alarm scenario', () => {
    expect(plan.scenario).toBe('fire_alarm_system');
  });

  it('requires an Arduino, a flame sensor, a buzzer, and an LED', () => {
    const types = plan.components.map((c) => c.type);
    expect(types).toContain('flameSensor');
    expect(types.some((t) => t.startsWith('arduino'))).toBe(true);
    expect(types.some((t) => t === 'buzzer' || t === 'activeBuzzer' || t === 'passiveBuzzer')).toBe(true);
    expect(types).toContain('led');
  });

  it('reports no unavailable components', () => {
    expect(plan.unavailableComponents).toEqual([]);
  });
});

describe('CircuitPlanner: unavailable/unknown parts are reported, never invented', () => {
  it('never fabricates a component type that is not in the real registry', () => {
    const plan = circuitPlanner.planCircuit({ goal: 'Create a circuit with a quantum flux stabilizer' });
    for (const c of plan.components) {
      expect(Object.keys(defaultProperties)).toContain(c.type);
    }
    expect(plan.components.some((c) => /flux|stabilizer|quantum/i.test(c.type) || /flux|stabilizer|quantum/i.test(c.name))).toBe(false);
  });
});

describe('CircuitPlanner: planning-only guarantee', () => {
  it('planCircuit is a pure function of its input — calling it twice yields structurally equal plans', () => {
    const a = circuitPlanner.planCircuit({ goal: 'Create a simple LED circuit' });
    const b = circuitPlanner.planCircuit({ goal: 'Create a simple LED circuit' });
    expect(a).toEqual(b);
  });
});
