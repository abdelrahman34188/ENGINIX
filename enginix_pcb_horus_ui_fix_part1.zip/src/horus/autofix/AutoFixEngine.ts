/**
 * HORUS AI — Auto Fix Engine.
 *
 * Responsible (once implemented) for attempting to correct output that
 * Validation Engine flagged as invalid (e.g. snapping an out-of-range
 * component value back into range) and reporting what it changed. Takes
 * a `ValidationResult` as input rather than re-validating itself, so
 * validation rules live in exactly one place.
 *
 * Interface + skeleton only — no logic implemented yet.
 */

import type { ValidationResult } from '../validation/ValidationEngine';

export interface AutoFixChange {
  path: string;
  before: unknown;
  after: unknown;
  reason: string;
}

export interface AutoFixResult {
  fixed: boolean;
  payload: unknown;
  changes: AutoFixChange[];
  /** Issues Auto Fix could not resolve automatically. */
  remainingIssues: ValidationResult['issues'];
}

export interface IAutoFixEngine {
  /** Attempt to fix a payload given the validation issues found on it. */
  attemptFix(payload: unknown, validation: ValidationResult): AutoFixResult;
}

export class AutoFixEngine implements IAutoFixEngine {
  attemptFix(_payload: unknown, _validation: ValidationResult): AutoFixResult {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
