/**
 * HORUS AI — Intent Router.
 *
 * A simple, deterministic map from each HORUS action button to a fixed
 * internal intent id. This is NOT `core/Brain/IntentAnalyzer.ts` — that
 * module (once implemented) will classify free-text user requests into
 * broad categories using some form of reasoning. This router does no
 * classification and no reasoning: every button already knows exactly
 * which intent it means, so routing is a plain lookup.
 *
 * Explicitly out of scope: this module does not call any AI provider,
 * does not call HORUS Brain, and does not execute anything beyond
 * resolving which intent id a button maps to. Wiring an intent to an
 * actual handler (HORUS Brain, a tool, etc.) is a separate, later step.
 */

/** Every internal intent id a HORUS action button can resolve to. */
export type HorusButtonIntent =
  | 'explain_component'
  | 'analyze_circuit'
  | 'generate_arduino'
  | 'fix_errors'
  | 'convert_pcb';

/** One HORUS action button's label paired with the intent id it maps to. */
export interface ButtonIntentMapping {
  label: string;
  intent: HorusButtonIntent;
}

/**
 * The fixed button -> intent map. One entry per HORUS action button
 * (see `components/horus-ai/HorusAIView.tsx`).
 */
export const BUTTON_INTENT_MAP: readonly ButtonIntentMapping[] = [
  { label: 'Explain Component', intent: 'explain_component' },
  { label: 'Analyze Circuit', intent: 'analyze_circuit' },
  { label: 'Generate Arduino Code', intent: 'generate_arduino' },
  { label: 'Fix Circuit Errors', intent: 'fix_errors' },
  { label: 'Convert Circuit to PCB', intent: 'convert_pcb' },
];

/** The outcome of routing a button press: which intent it resolved to. */
export interface IntentRouteResult {
  intent: HorusButtonIntent;
}

export interface IIntentRouter {
  /** Resolve a button's label to its mapped internal intent id. */
  routeByLabel(label: string): IntentRouteResult | undefined;

  /** Pass an already-known intent id straight through, unchanged. */
  route(intent: HorusButtonIntent): IntentRouteResult;

  /** List every button -> intent mapping this router knows about. */
  listMappings(): readonly ButtonIntentMapping[];
}

export class IntentRouter implements IIntentRouter {
  private readonly byLabel: ReadonlyMap<string, HorusButtonIntent> = new Map(
    BUTTON_INTENT_MAP.map(({ label, intent }) => [label, intent]),
  );

  routeByLabel(label: string): IntentRouteResult | undefined {
    const intent = this.byLabel.get(label);
    return intent ? { intent } : undefined;
  }

  route(intent: HorusButtonIntent): IntentRouteResult {
    return { intent };
  }

  listMappings(): readonly ButtonIntentMapping[] {
    return BUTTON_INTENT_MAP;
  }
}

/** Shared instance — stateless besides the fixed map above, so one
 *  instance is fine for every caller (mirrors other HORUS singletons
 *  such as `horus/runtime.ts`'s composed objects). */
export const intentRouter = new IntentRouter();
