/**
 * HORUS AI — Gemini Provider adapter.
 *
 * Concrete `AIProvider` adapter for Google Gemini. This is the one place
 * in HORUS allowed to know that "gemini" means Google's Gemini API — every
 * other module (AICore, ConversationManager, AIProviderManager, ...)
 * continues to depend only on the `AIProvider` interface.
 *
 * Request/response shaping (mapping the provider-agnostic request into
 * Gemini's shape, preparing headers/payload, and building the response
 * parser) is delegated to `GeminiClient` rather than duplicated here —
 * see `GeminiClient.ts` for that logic and its relationship to the
 * existing `src/services/GeminiService.ts` implementation it mirrors.
 * This file is only responsible for satisfying the `AIProvider` contract
 * and, once implemented, dispatching the call `GeminiClient` prepares.
 *
 * Implementation status: `generate()` is now implemented — it reads the
 * API key from `IAIConfiguration` (same source `testConnection()`
 * uses), asks `GeminiClient` to shape the request/headers/payload, does
 * the one `fetch()` call this file owns, and runs the client's response
 * parser on the result. This is the only place in HORUS that performs a
 * real Gemini network call.
 *
 * `testConnection()` was implemented ahead of `generate()`: it is a
 * lightweight, no-prompt reachability/credential check only — it never
 * sends an engineering prompt or any conversation content, it just calls
 * Gemini's `GET /v1beta/models` (list models) endpoint, mirroring
 * `testConnection()` in `src/services/GeminiService.ts`. The API key it
 * uses comes from `AIConfiguration` (`core/AIConfiguration.ts`), which
 * this file reads via the injected `IAIConfiguration` — `GeminiProvider`
 * remains the only module that knows this is a Gemini call; the
 * configuration store itself stays vendor-agnostic.
 */

import type {
  AIProvider,
  AIProviderRequest,
  AIProviderResponse,
} from './AIProvider';
import type { IGeminiClient } from './GeminiClient';
import type { IAIConfiguration } from '../core/AIConfiguration';

/** Gemini's models-list endpoint — used only for the lightweight
 *  connection test, never for `generate()`. */
const GEMINI_MODELS_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models';

export class GeminiProvider implements AIProvider {
  readonly id = 'gemini';
  readonly displayName = 'Gemini';

  constructor(
    private readonly client: IGeminiClient,
    private readonly configuration: IAIConfiguration,
  ) {}

  /**
   * Receive a provider-agnostic prompt object and return a provider-agnostic
   * response:
   *   1. `client.prepareRequest` / `client.prepareHeaders` /
   *      `client.preparePayload` — shape the call (delegated to `GeminiClient`).
   *   2. Dispatch it — the one `fetch()` call in this file.
   *   3. Run `client.prepareResponseParser()` against the raw response.
   */
  async generate(request: AIProviderRequest): Promise<AIProviderResponse> {
    const apiKey = this.configuration.getProviderConfiguration('gemini')?.apiKey?.trim();
    if (!apiKey) {
      return { ok: false, error: { code: 'missing_credentials', message: 'No Gemini API key configured.' } };
    }

    const requestPayload = this.client.prepareRequest(request);
    const headers = this.client.prepareHeaders(apiKey);
    const prepared = this.client.preparePayload(requestPayload, headers);

    let response: Response;
    try {
      response = await fetch(prepared.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': prepared.headers['Content-Type'],
          'x-goog-api-key': prepared.headers['x-goog-api-key'],
        },
        body: JSON.stringify(prepared.body),
      });
    } catch {
      return { ok: false, error: { code: 'network_error', message: 'Could not reach the Gemini API.' } };
    }

    let data: unknown;
    try {
      data = await response.json();
    } catch {
      return { ok: false, error: { code: 'invalid_response', message: 'Received an invalid response from the Gemini API.' } };
    }

    if (!response.ok) {
      if (response.status === 401 || response.status === 403) {
        return { ok: false, error: { code: 'invalid_credentials', message: 'Invalid Gemini API key.' } };
      }
      if (response.status === 429) {
        return { ok: false, error: { code: 'rate_limited', message: 'Gemini API rate limit reached.' } };
      }
      const message =
        (data as { error?: { message?: string } })?.error?.message ??
        `Gemini API request failed (status ${response.status}).`;
      return { ok: false, error: { code: 'unknown', message } };
    }

    return this.client.prepareResponseParser()(data as Parameters<ReturnType<IGeminiClient['prepareResponseParser']>>[0]);
  }

  /**
   * Lightweight reachability/credential check. Sends no engineering
   * prompt and no conversation content — just verifies the configured
   * API key can reach Gemini, via a cheap `GET /v1beta/models` call.
   */
  async testConnection(): Promise<AIProviderResponse> {
    const apiKey = this.configuration.getProviderConfiguration('gemini')?.apiKey?.trim();

    if (!apiKey) {
      this.configuration.setValidationState('gemini', 'invalid');
      return {
        ok: false,
        error: { code: 'missing_credentials', message: 'No Gemini API key configured.' },
      };
    }

    this.configuration.setValidationState('gemini', 'validating');
    const headers = this.client.prepareHeaders(apiKey);

    let response: Response;
    try {
      response = await fetch(`${GEMINI_MODELS_ENDPOINT}?pageSize=1`, {
        method: 'GET',
        headers: { 'x-goog-api-key': headers['x-goog-api-key'] },
      });
    } catch {
      this.configuration.setValidationState('gemini', 'invalid');
      return {
        ok: false,
        error: { code: 'network_error', message: 'Could not reach the Gemini API.' },
      };
    }

    if (response.status === 401 || response.status === 403) {
      this.configuration.setValidationState('gemini', 'invalid');
      return { ok: false, error: { code: 'invalid_credentials', message: 'Invalid Gemini API key.' } };
    }

    if (response.status === 429) {
      // Reachable with a recognized key, just throttled — not an
      // invalid-key situation, so leave validation state as-is.
      return { ok: false, error: { code: 'rate_limited', message: 'Gemini API rate limit reached.' } };
    }

    if (!response.ok) {
      if (response.status >= 400 && response.status < 500) {
        this.configuration.setValidationState('gemini', 'invalid');
        return { ok: false, error: { code: 'invalid_credentials', message: 'Invalid Gemini API key.' } };
      }
      this.configuration.setValidationState('gemini', 'invalid');
      return {
        ok: false,
        error: { code: 'unknown', message: `Gemini API request failed (status ${response.status}).` },
      };
    }

    this.configuration.setValidationState('gemini', 'valid');
    return { ok: true, text: 'Connected' };
  }
}
