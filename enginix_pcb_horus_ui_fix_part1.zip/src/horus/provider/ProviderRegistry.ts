/**
 * HORUS AI — Provider Registry.
 *
 * The registration point future providers (Gemini, OpenAI, Groq,
 * OpenRouter, ...) plug into. Adding a new provider means writing a new
 * `AIProvider` adapter and registering it here — no existing HORUS module
 * needs to change (Open/Closed Principle).
 *
 * Implementation status: minimal but functional — plain `Map<id, provider>`
 * bookkeeping, no provider selection logic (that's `AIProviderManager` /
 * `AIConfiguration`'s job).
 */

import type { AIProvider } from './AIProvider';

export interface IProviderRegistry {
  register(provider: AIProvider): void;
  /** Remove a previously registered provider. The sole place provider
   *  storage is mutated for removal — `AIProviderManager` delegates here
   *  rather than tracking its own copy. */
  unregister(id: string): void;
  get(id: string): AIProvider | undefined;
  list(): AIProvider[];
}

export class ProviderRegistry implements IProviderRegistry {
  private readonly providers = new Map<string, AIProvider>();

  register(provider: AIProvider): void {
    this.providers.set(provider.id, provider);
  }

  unregister(id: string): void {
    this.providers.delete(id);
  }

  get(id: string): AIProvider | undefined {
    return this.providers.get(id);
  }

  list(): AIProvider[] {
    return Array.from(this.providers.values());
  }
}
