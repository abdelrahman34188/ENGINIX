/**
 * HORUS AI — AI Provider abstraction.
 *
 * No concrete vendor (Gemini, OpenAI, Groq, OpenRouter, ...) is referenced
 * anywhere in the HORUS architecture. Every module that needs to talk to a
 * model depends only on the `AIProvider` interface below. A concrete
 * adapter (e.g. `GeminiAIProvider implements AIProvider`) can be written
 * later and swapped in without any other HORUS module changing — that's
 * the point of the abstraction (Dependency Inversion).
 *
 * This file defines the contract only. No implementation, no logic.
 */

/** A single message in a provider-agnostic chat exchange. */
export interface AIProviderMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
}

/** A tool/function definition a provider may be asked to make available. */
export interface AIProviderToolDefinition {
  name: string;
  description: string;
  /** JSON-schema-shaped parameter description; kept as unknown here since
   *  HORUS does not implement tool-calling logic yet. */
  parameters: unknown;
}

/** Everything a provider needs to produce a completion. */
export interface AIProviderRequest {
  messages: AIProviderMessage[];
  tools?: AIProviderToolDefinition[];
  temperature?: number;
  maxOutputTokens?: number;
}

/** Uniform, provider-agnostic result shape. */
export type AIProviderResponse =
  | { ok: true; text: string }
  | { ok: false; error: AIProviderError };

/** Normalized error categories every adapter must map its own errors onto. */
export type AIProviderErrorCode =
  | 'missing_credentials'
  | 'invalid_credentials'
  | 'rate_limited'
  | 'network_error'
  | 'invalid_response'
  | 'unknown';

export interface AIProviderError {
  code: AIProviderErrorCode;
  message: string;
}

/**
 * Contract every AI vendor adapter must satisfy. HORUS's other modules
 * (AICore, ConversationManager, etc.) depend on this interface only —
 * never on a specific vendor SDK or REST shape.
 */
export interface AIProvider {
  /** Stable identifier, e.g. 'gemini' | 'openai' | 'groq' | 'openrouter'. */
  readonly id: string;

  /** Human-readable label for display in Settings/UI. */
  readonly displayName: string;

  /** Send a request and get a normalized response. Not implemented yet. */
  generate(request: AIProviderRequest): Promise<AIProviderResponse>;

  /** Lightweight reachability/credential check (mirrors Settings' "Test
   *  Connection" concept, generalized across providers). Not implemented yet. */
  testConnection(): Promise<AIProviderResponse>;
}
