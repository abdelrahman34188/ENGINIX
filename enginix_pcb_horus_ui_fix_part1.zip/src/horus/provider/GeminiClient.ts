/**
 * HORUS AI — Gemini Client.
 *
 * Owns the Gemini-specific *request/response shaping* steps that
 * `GeminiProvider` delegates to, so that shaping logic exists in exactly
 * one place instead of being duplicated across HORUS.
 *
 * Reuses the existing Gemini integration rather than reinventing it:
 *  - Request/header/payload shape mirrors the working implementation in
 *    `src/services/GeminiService.ts` (`generate()` / `testConnection()`):
 *    `POST {base}/{model}:generateContent` with an `x-goog-api-key`
 *    header and a `{ contents: [{ role, parts: [{ text }] }] }` body.
 *  - Response shape mirrors `GeminiResponseBody` in the same file
 *    (`candidates[].content.parts[].text`, `promptFeedback.blockReason`,
 *    `error.message`).
 *  - API key sourcing mirrors `src/lib/geminiSettings.ts`
 *    (`getGeminiApiKey()`), consulted by whoever supplies this client its
 *    key — this file does not read settings/storage itself.
 *
 * `GeminiProvider` (`GeminiProvider.ts`) is the only HORUS module that
 * knows Gemini exists; `GeminiClient` is that provider's internal helper,
 * not a second public entry point — other HORUS modules should keep
 * depending on `AIProvider`, never on `GeminiClient` directly.
 *
 * No HTTP, no fetch/network call, no API connection — request/header/
 * payload/parser preparation only. Dispatching the prepared request is
 * `GeminiProvider`'s job.
 *
 * Implementation status: minimal but functional. Base URL and default
 * model constant mirror `GEMINI_API_BASE_URL` / `GEMINI_MODEL` in
 * `src/services/GeminiService.ts` exactly, so behavior matches the
 * existing direct integration this replaces.
 */

import type {
  AIProviderRequest,
  AIProviderResponse,
} from './AIProvider';

/** One turn in the Gemini `contents` array. */
export interface GeminiContentPart {
  text: string;
}

export interface GeminiContent {
  role: 'user' | 'model';
  parts: GeminiContentPart[];
}

/** Gemini's `generationConfig` block — maps HORUS's provider-agnostic
 *  `temperature` / `maxOutputTokens` onto Gemini's own field names. */
export interface GeminiGenerationConfig {
  temperature?: number;
  maxOutputTokens?: number;
}

/** Fully-shaped Gemini `generateContent` request body, ready to be
 *  JSON-serialized by whoever eventually dispatches it. */
export interface GeminiRequestPayload {
  contents: GeminiContent[];
  generationConfig?: GeminiGenerationConfig;
}

/** HTTP headers a Gemini call requires, keyed exactly as Gemini expects. */
export interface GeminiRequestHeaders {
  'Content-Type': 'application/json';
  'x-goog-api-key': string;
}

/** Raw Gemini `generateContent` response shape, mirroring
 *  `GeminiResponseBody` in `src/services/GeminiService.ts`. */
export interface GeminiResponseBody {
  candidates?: Array<{
    content?: { parts?: Array<{ text?: string }> };
    finishReason?: string;
  }>;
  promptFeedback?: { blockReason?: string };
  error?: { message?: string; status?: string };
}

/** A parser bound to one raw Gemini response, normalizing it into the
 *  provider-agnostic `AIProviderResponse` shape. Preparing this function
 *  is this file's job; invoking it against a real response happens once
 *  a response actually exists (not here — no HTTP happens in this file). */
export type GeminiResponseParser = (raw: GeminiResponseBody) => AIProviderResponse;

export interface IGeminiClient {
  /** Map a provider-agnostic `AIProviderRequest` into Gemini's
   *  `contents` + `generationConfig` request shape. */
  prepareRequest(request: AIProviderRequest): GeminiRequestPayload;

  /** Build the headers a Gemini call requires for the given API key. */
  prepareHeaders(apiKey: string): GeminiRequestHeaders;

  /** Combine a prepared request payload and headers into the final,
   *  ready-to-send (but not yet sent) call description. */
  preparePayload(
    request: GeminiRequestPayload,
    headers: GeminiRequestHeaders,
  ): GeminiPreparedCall;

  /** Produce a parser that normalizes a raw Gemini response body into
   *  `AIProviderResponse`. Building the parser is separate from running
   *  it against an actual response. */
  prepareResponseParser(): GeminiResponseParser;
}

/** Everything needed to make the eventual HTTP call — endpoint, headers,
 *  and body — assembled but not dispatched. Dispatching it is explicitly
 *  out of scope for this file. */
export interface GeminiPreparedCall {
  endpoint: string;
  headers: GeminiRequestHeaders;
  body: GeminiRequestPayload;
}

/** Mirrors `GEMINI_API_BASE_URL` in `src/services/GeminiService.ts`. */
const GEMINI_API_BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
/** Mirrors `GEMINI_MODEL` in `src/services/GeminiService.ts`. */
const GEMINI_MODEL = 'gemini-3.5-flash';

/** Gemini has no 'system'/'tool' role in `contents` — fold those into a
 *  'user' turn (system) or drop them (tool; HORUS doesn't implement
 *  tool-calling yet, see `AIProviderToolDefinition` in `AIProvider.ts`). */
function toGeminiRole(role: AIProviderRequest['messages'][number]['role']): GeminiContent['role'] | null {
  if (role === 'assistant') return 'model';
  if (role === 'user' || role === 'system') return 'user';
  return null;
}

export class GeminiClient implements IGeminiClient {
  prepareRequest(request: AIProviderRequest): GeminiRequestPayload {
    const contents: GeminiContent[] = [];
    for (const message of request.messages) {
      const role = toGeminiRole(message.role);
      if (!role || !message.content) continue;
      // Gemini rejects consecutive same-role turns for some models —
      // merge into the previous turn of the same role when adjacent.
      const previous = contents[contents.length - 1];
      if (previous && previous.role === role) {
        previous.parts.push({ text: message.content });
      } else {
        contents.push({ role, parts: [{ text: message.content }] });
      }
    }

    const generationConfig: GeminiGenerationConfig = {};
    if (request.temperature !== undefined) generationConfig.temperature = request.temperature;
    if (request.maxOutputTokens !== undefined) generationConfig.maxOutputTokens = request.maxOutputTokens;

    return {
      contents,
      ...(Object.keys(generationConfig).length > 0 ? { generationConfig } : {}),
    };
  }

  /**
   * Implemented ahead of `generate()`'s request shaping because
   * `GeminiProvider.testConnection()` needs it: the connection test is a
   * lightweight `GET` (no body), so it only needs headers, not the full
   * `generateContent` payload shape.
   */
  prepareHeaders(apiKey: string): GeminiRequestHeaders {
    return {
      'Content-Type': 'application/json',
      'x-goog-api-key': apiKey,
    };
  }

  preparePayload(
    request: GeminiRequestPayload,
    headers: GeminiRequestHeaders,
  ): GeminiPreparedCall {
    return {
      endpoint: `${GEMINI_API_BASE_URL}/${GEMINI_MODEL}:generateContent`,
      headers,
      body: request,
    };
  }

  prepareResponseParser(): GeminiResponseParser {
    return (raw: GeminiResponseBody): AIProviderResponse => {
      const blockReason = raw?.promptFeedback?.blockReason;
      if (blockReason) {
        return { ok: false, error: { code: 'invalid_response', message: `Gemini blocked the request (${blockReason}).` } };
      }

      if (raw?.error?.message) {
        return { ok: false, error: { code: 'unknown', message: raw.error.message } };
      }

      const text = raw?.candidates?.[0]?.content?.parts
        ?.map((part) => part.text ?? '')
        .join('')
        .trim();

      if (!text) {
        return { ok: false, error: { code: 'invalid_response', message: 'Gemini API returned no text content.' } };
      }

      return { ok: true, text };
    };
  }
}
