/**
 * HORUS AI — AI Provider Manager.
 *
 * The single place the rest of HORUS asks "which providers exist?",
 * "register/remove a provider", and "which one is active?" / "switch to
 * provider X". It depends only on the `AIProvider` abstraction — never on
 * a concrete vendor SDK — so adding a provider means writing an adapter
 * and registering it; no other HORUS module changes (Open/Closed
 * Principle).
 *
 * Composition, not duplication:
 *  - Provider *instances* (registration bookkeeping — the actual
 *    add/remove/lookup storage) live in `ProviderRegistry`. This manager
 *    does not keep its own copy of that map; `registerProvider` /
 *    `removeProvider` / `listProviders` are thin delegations to the
 *    injected `IProviderRegistry`.
 *  - Which provider is *active* is configuration, not registration state,
 *    so it is delegated to the injected `IAIConfiguration`
 *    (`core/AIConfiguration.ts`) rather than tracked again here.
 *    `setActiveProvider` / `getActiveProvider` read/write through it.
 *
 * Implementation status: minimal but functional — every method below is
 * a thin delegation to the injected `IProviderRegistry` / `IAIConfiguration`,
 * exactly as designed above. No AI logic, no API calls live here.
 */

import type { AIProvider } from './AIProvider';
import type { IProviderRegistry } from './ProviderRegistry';
import type { IAIConfiguration } from '../core/AIConfiguration';

/** Stable identifiers for every provider HORUS knows about, supported or not. */
export type AIProviderId = 'gemini' | 'openai' | 'groq' | 'openrouter';

/** Providers with a concrete adapter that can be registered today. */
export const SUPPORTED_PROVIDER_IDS: readonly AIProviderId[] = ['gemini'];

/** Providers the architecture reserves an identifier for, not yet adapted. */
export const PLANNED_PROVIDER_IDS: readonly AIProviderId[] = ['openai', 'groq', 'openrouter'];

export interface IAIProviderManager {
  /** Register a provider adapter, making it selectable as active.
   *  Delegates to `IProviderRegistry.register` — no separate storage here. */
  registerProvider(provider: AIProvider): void;

  /** Remove a previously registered provider. If it was the active
   *  provider, the active selection is left to `IAIConfiguration` /
   *  the caller to resolve — this method does not implicitly pick a
   *  replacement. Delegates to `IProviderRegistry.unregister`. */
  removeProvider(id: AIProviderId): void;

  /** Switch the active provider to a previously registered provider.
   *  Delegates the "which id is active" bookkeeping to `IAIConfiguration`. */
  setActiveProvider(id: AIProviderId): void;

  /** Resolve the active provider instance: reads the active id from
   *  `IAIConfiguration`, then looks up the matching instance in the
   *  `IProviderRegistry`. */
  getActiveProvider(): AIProvider | undefined;

  /** All providers currently registered and available for selection.
   *  Delegates to `IProviderRegistry.list`. */
  listProviders(): AIProvider[];
}

export class AIProviderManager implements IAIProviderManager {
  constructor(
    private readonly registry: IProviderRegistry,
    private readonly configuration: IAIConfiguration,
  ) {}

  registerProvider(provider: AIProvider): void {
    this.registry.register(provider);
  }

  removeProvider(id: AIProviderId): void {
    this.registry.unregister(id);
  }

  setActiveProvider(id: AIProviderId): void {
    this.configuration.setActiveProvider(id);
  }

  getActiveProvider(): AIProvider | undefined {
    const activeId = this.configuration.getActiveProviderId();
    return activeId ? this.registry.get(activeId) : undefined;
  }

  listProviders(): AIProvider[] {
    return this.registry.list();
  }
}
