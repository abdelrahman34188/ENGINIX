/**
 * HORUS AI — Knowledge Base Manager — ENGINIX project wiring.
 *
 * This is the one place that connects the Knowledge Base architecture to
 * the actual ENGINIX project. It composes each domain repository with a
 * source that reflects real, already-existing project data/exports (see
 * `knowledge/sources/*.ts`) — no knowledge entry is hand-entered anywhere
 * in this file or the sources it wires up.
 *
 * Still no AI logic: this only makes `KnowledgeBaseManager` queryable
 * with live ENGINIX data. Nothing here talks to HORUS's conversation,
 * tool, or provider layers.
 */

import {
  KnowledgeBaseManager,
  type IKnowledgeBaseManager,
} from './KnowledgeBaseManager';
import { ComponentsRepository } from './repositories/ComponentsRepository';
import { PinsRepository } from './repositories/PinsRepository';
import { LibrariesRepository } from './repositories/LibrariesRepository';
import { ApisRepository } from './repositories/ApisRepository';
import { SimulatorFeaturesRepository } from './repositories/SimulatorFeaturesRepository';
import { PCBFeaturesRepository } from './repositories/PCBFeaturesRepository';
import { CodingFeaturesRepository } from './repositories/CodingFeaturesRepository';

import { ComponentsSource } from './sources/ComponentsSource';
import { PinsSource } from './sources/PinsSource';
import { LibrariesSource } from './sources/LibrariesSource';
import { ApisSource } from './sources/ApisSource';
import { SimulatorFeaturesSource } from './sources/SimulatorFeaturesSource';
import { PCBFeaturesSource } from './sources/PCBFeaturesSource';
import { CodingFeaturesSource } from './sources/CodingFeaturesSource';

/**
 * Build a `KnowledgeBaseManager` wired to ENGINIX's real project data.
 * Repositories start empty — call `.loadAll()` (or `refreshKnowledgeBase`)
 * before querying them.
 */
export function createProjectKnowledgeBaseManager(): IKnowledgeBaseManager {
  return new KnowledgeBaseManager({
    components: new ComponentsRepository(new ComponentsSource()),
    pins: new PinsRepository(new PinsSource()),
    libraries: new LibrariesRepository(new LibrariesSource()),
    apis: new ApisRepository(new ApisSource()),
    simulatorFeatures: new SimulatorFeaturesRepository(new SimulatorFeaturesSource()),
    pcbFeatures: new PCBFeaturesRepository(new PCBFeaturesSource()),
    codingFeatures: new CodingFeaturesRepository(new CodingFeaturesSource()),
  });
}

/** Per-repository entry counts after a refresh — for visibility/logging. */
export interface KnowledgeBaseRefreshSummary {
  components: number;
  pins: number;
  libraries: number;
  apis: number;
  simulatorFeatures: number;
  pcbFeatures: number;
  codingFeatures: number;
}

/**
 * Refresh Knowledge Base.
 *
 * Re-discovers every domain from the live ENGINIX project (components,
 * categories, pins, properties, simulator capabilities, PCB capabilities,
 * Arduino libraries, coding capabilities, internal APIs) and replaces
 * each repository's contents with what's found right now — so a
 * component (or capability) added to the project after the last refresh
 * is picked up here, with nothing manually re-entered.
 */
export async function refreshKnowledgeBase(
  manager: IKnowledgeBaseManager
): Promise<KnowledgeBaseRefreshSummary> {
  await manager.refreshAll();

  return {
    components: manager.components.count(),
    pins: manager.pins.count(),
    libraries: manager.libraries.count(),
    apis: manager.apis.count(),
    simulatorFeatures: manager.simulatorFeatures.count(),
    pcbFeatures: manager.pcbFeatures.count(),
    codingFeatures: manager.codingFeatures.count(),
  };
}
