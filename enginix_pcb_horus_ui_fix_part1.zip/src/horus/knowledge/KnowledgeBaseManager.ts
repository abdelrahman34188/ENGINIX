/**
 * HORUS AI — Knowledge Base Manager.
 *
 * Provides HORUS with structured, dynamically-loaded reference knowledge
 * about ENGINIX. Isolated from Memory Manager: this owns *reference/domain
 * knowledge*, not conversation/user memory.
 *
 * No knowledge data is hardcoded anywhere in this module. Each domain
 * (Components, Pins, Libraries, APIs, Simulator Features, PCB Features,
 * Coding Features) has its own repository behind a uniform
 * `IKnowledgeRepository` contract (load / refresh / search / getById —
 * see `KnowledgeRepository.ts`). `KnowledgeBaseManager` composes those
 * repositories via constructor injection, exactly the way `AICore`
 * composes its own collaborators — no repository is instantiated here.
 *
 * Population logic is real (delegates to each repository, which delegates
 * to its injected source — see `ProjectKnowledgeBase.ts` for how this is
 * wired to actual ENGINIX project data). Still no AI logic: this module
 * only makes reference data queryable, it doesn't reason about it.
 */

import type { IComponentsRepository } from './repositories/ComponentsRepository';
import type { IPinsRepository } from './repositories/PinsRepository';
import type { ILibrariesRepository } from './repositories/LibrariesRepository';
import type { IApisRepository } from './repositories/ApisRepository';
import type { ISimulatorFeaturesRepository } from './repositories/SimulatorFeaturesRepository';
import type { IPCBFeaturesRepository } from './repositories/PCBFeaturesRepository';
import type { ICodingFeaturesRepository } from './repositories/CodingFeaturesRepository';

/** The set of domain repositories Knowledge Base Manager composes. */
export interface KnowledgeBaseManagerDependencies {
  components: IComponentsRepository;
  pins: IPinsRepository;
  libraries: ILibrariesRepository;
  apis: IApisRepository;
  simulatorFeatures: ISimulatorFeaturesRepository;
  pcbFeatures: IPCBFeaturesRepository;
  codingFeatures: ICodingFeaturesRepository;
}

export interface IKnowledgeBaseManager {
  /** Load every domain repository from its respective source. */
  loadAll(): Promise<void>;

  /** Refresh every domain repository from its respective source. */
  refreshAll(): Promise<void>;

  readonly components: IComponentsRepository;
  readonly pins: IPinsRepository;
  readonly libraries: ILibrariesRepository;
  readonly apis: IApisRepository;
  readonly simulatorFeatures: ISimulatorFeaturesRepository;
  readonly pcbFeatures: IPCBFeaturesRepository;
  readonly codingFeatures: ICodingFeaturesRepository;
}

export class KnowledgeBaseManager implements IKnowledgeBaseManager {
  readonly components: IComponentsRepository;
  readonly pins: IPinsRepository;
  readonly libraries: ILibrariesRepository;
  readonly apis: IApisRepository;
  readonly simulatorFeatures: ISimulatorFeaturesRepository;
  readonly pcbFeatures: IPCBFeaturesRepository;
  readonly codingFeatures: ICodingFeaturesRepository;

  constructor(deps: KnowledgeBaseManagerDependencies) {
    this.components = deps.components;
    this.pins = deps.pins;
    this.libraries = deps.libraries;
    this.apis = deps.apis;
    this.simulatorFeatures = deps.simulatorFeatures;
    this.pcbFeatures = deps.pcbFeatures;
    this.codingFeatures = deps.codingFeatures;
  }

  async loadAll(): Promise<void> {
    await Promise.all([
      this.components.load(),
      this.pins.load(),
      this.libraries.load(),
      this.apis.load(),
      this.simulatorFeatures.load(),
      this.pcbFeatures.load(),
      this.codingFeatures.load(),
    ]);
  }

  async refreshAll(): Promise<void> {
    await Promise.all([
      this.components.refresh(),
      this.pins.refresh(),
      this.libraries.refresh(),
      this.apis.refresh(),
      this.simulatorFeatures.refresh(),
      this.pcbFeatures.refresh(),
      this.codingFeatures.refresh(),
    ]);
  }
}
