/**
 * HORUS AI — Knowledge Base Manager — reflection helpers.
 *
 * Shared by the "capability" sources (Simulator Features, PCB Features,
 * Coding Features, Internal APIs, Arduino Libraries): rather than a
 * hand-written list of what each module can do, these introspect the
 * module's own real exports/class members at fetch time. Add a new
 * exported function to `src/circuit/simulator.ts` (for example) and it
 * appears in the Knowledge Base on the next refresh with zero changes
 * here or in the corresponding source file.
 */

/** Every exported *function* name on a module namespace object. */
export function exportedFunctionNames(moduleNamespace: object): string[] {
  return Object.keys(moduleNamespace).filter(
    (key) => typeof (moduleNamespace as Record<string, unknown>)[key] === 'function'
  );
}

/**
 * Every public method name on a class's prototype — "public" meaning it
 * doesn't start with `_` and isn't `constructor` (TypeScript's `private`/
 * `protected` are compile-time only, so genuinely private helpers are
 * still filtered out by the underscore convention this codebase already
 * uses elsewhere; anything left is real, callable API surface).
 */
export function publicPrototypeMethodNames(ctor: { prototype: object }): string[] {
  return Object.getOwnPropertyNames(ctor.prototype).filter(
    (key) =>
      key !== 'constructor' &&
      !key.startsWith('_') &&
      typeof (ctor.prototype as Record<string, unknown>)[key] === 'function'
  );
}

/** Turn `simulateDC` / `runDRC` into `Simulate DC` / `Run DRC`-ish readable text. */
export function humanizeIdentifier(identifier: string): string {
  const spaced = identifier
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2');
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}
