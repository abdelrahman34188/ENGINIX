/**
 * HORUS AI — Knowledge Base Manager — source provenance metadata.
 *
 * Optional, purely informational: each concrete `IKnowledgeSource` in
 * this folder exposes which real ENGINIX module/exports it reflects, so
 * the Knowledge Base can be inspected/debugged ("where did this entry
 * come from?") without digging through source files by hand.
 */

export interface KnowledgeSourceModuleInfo {
  /** Path (relative to the repo root) of the project module this source reads from. */
  module: string;
  /** The exported symbols read from that module. */
  exports: string[];
}
