/**
 * HORUS AI — Knowledge Base Manager — Pins source.
 *
 * Connects the Pins repository to ENGINIX's real terminal layouts in
 * `src/circuit/componentDefs.ts` (`defaultTerminals`) and their display
 * names (`componentNames`). One entry per component type, listing its
 * actual pin/terminal layout as defined in that file — nothing is typed
 * in by hand here, and a component whose terminal layout changes (or a
 * new component that gets one) shows up automatically on refresh.
 */

import type { KnowledgeSourceModuleInfo } from './moduleInfo';
import { componentNames, defaultTerminals } from '../../../circuit/componentDefs';
import type { PinEntry, PinRef } from '../repositories/PinsRepository';
import type { IKnowledgeSource } from '../KnowledgeRepository';

export class PinsSource implements IKnowledgeSource<PinEntry> {
  readonly moduleInfo: KnowledgeSourceModuleInfo = {
    module: 'src/circuit/componentDefs.ts',
    exports: ['defaultTerminals', 'componentNames'],
  };

  async fetchAll(): Promise<PinEntry[]> {
    return Object.entries(defaultTerminals).map(([type, terminals]) => {
      const pins: PinRef[] = terminals.map((t) => ({
        label: t.label,
        dx: t.dx,
        dy: t.dy,
      }));

      return {
        id: type,
        componentName: componentNames[type as keyof typeof componentNames] ?? type,
        pins,
      };
    });
  }
}
