/**
 * HORUS AI — Knowledge Base Manager — Coding Features source.
 *
 * Connects the Coding Features repository to ENGINIX's real Arduino
 * coding toolchain (`src/arduino/*.ts`) by reflecting each module's
 * exported functions, plus `ArduinoRuntime` and `Parser`'s own public
 * methods, at fetch time — no capability list is typed in by hand.
 */

import type { KnowledgeSourceModuleInfo } from './moduleInfo';
import * as ParserModule from '../../../arduino/parser';
import * as LexerModule from '../../../arduino/lexer';
import { ArduinoRuntime } from '../../../arduino/ArduinoRuntime';
import { Parser } from '../../../arduino/parser';
import {
  exportedFunctionNames,
  publicPrototypeMethodNames,
  humanizeIdentifier,
} from './reflection';
import type { CodingFeatureEntry } from '../repositories/CodingFeaturesRepository';
import type { IKnowledgeSource } from '../KnowledgeRepository';

const REFLECTED_MODULES: Array<{ label: string; namespace: object }> = [
  { label: 'src/arduino/parser.ts', namespace: ParserModule },
  { label: 'src/arduino/lexer.ts', namespace: LexerModule },
];

const REFLECTED_CLASSES: Array<{ label: string; ctor: { prototype: object } }> = [
  { label: 'src/arduino/ArduinoRuntime.ts#ArduinoRuntime', ctor: ArduinoRuntime },
  { label: 'src/arduino/parser.ts#Parser', ctor: Parser as unknown as { prototype: object } },
];

export class CodingFeaturesSource implements IKnowledgeSource<CodingFeatureEntry> {
  readonly moduleInfo: KnowledgeSourceModuleInfo = {
    module: 'src/arduino/*.ts',
    exports: ['(reflected at fetch time)'],
  };

  async fetchAll(): Promise<CodingFeatureEntry[]> {
    const entries: CodingFeatureEntry[] = [];

    for (const { label, namespace } of REFLECTED_MODULES) {
      for (const fnName of exportedFunctionNames(namespace)) {
        entries.push({
          id: `${label}#${fnName}`,
          name: humanizeIdentifier(fnName),
          description: `Exported capability \`${fnName}\` from ${label}.`,
        });
      }
    }

    for (const { label, ctor } of REFLECTED_CLASSES) {
      for (const methodName of publicPrototypeMethodNames(ctor)) {
        entries.push({
          id: `${label}.${methodName}`,
          name: humanizeIdentifier(methodName),
          description: `Method \`${methodName}\` from ${label}.`,
        });
      }
    }

    return entries;
  }
}
