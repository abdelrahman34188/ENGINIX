/**
 * HORUS AI — Knowledge Base Manager — Components source.
 *
 * Connects the Components repository to ENGINIX's real component
 * definitions in `src/circuit/componentDefs.ts`. Every entry (id, name,
 * category, properties) is derived at fetch time from that file's own
 * exported data — `componentNames`, `componentCategories`,
 * `defaultProperties` — so a component added there (a new key in any of
 * those three maps) is picked up automatically the next time this source
 * is fetched, with no change needed here. Nothing in this file is a
 * hand-entered component, category, or property.
 */

import type { KnowledgeSourceModuleInfo } from './moduleInfo';
import {
  componentNames,
  componentCategories,
  defaultProperties,
} from '../../../circuit/componentDefs';
import type {
  ComponentEntry,
  ComponentPropertyRef,
} from '../repositories/ComponentsRepository';
import type { IKnowledgeSource } from '../KnowledgeRepository';

/** Reverse-index built from `componentCategories` — category lookup by type. */
function buildCategoryIndex(): Map<string, string> {
  const index = new Map<string, string>();
  for (const [category, types] of Object.entries(componentCategories)) {
    for (const type of types) {
      index.set(type, category);
    }
  }
  return index;
}

export class ComponentsSource implements IKnowledgeSource<ComponentEntry> {
  readonly moduleInfo: KnowledgeSourceModuleInfo = {
    module: 'src/circuit/componentDefs.ts',
    exports: ['componentNames', 'componentCategories', 'defaultProperties'],
  };

  async fetchAll(): Promise<ComponentEntry[]> {
    const categoryByType = buildCategoryIndex();

    return Object.entries(componentNames).map(([type, name]) => {
      const properties: ComponentPropertyRef[] = (defaultProperties[type] ?? []).map(
        (prop) => ({
          key: prop.key,
          name: prop.name,
          ...(prop.unit ? { unit: prop.unit } : {}),
        })
      );

      return {
        id: type,
        name,
        category: categoryByType.get(type) ?? 'uncategorized',
        properties,
      };
    });
  }
}
