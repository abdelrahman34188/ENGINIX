/**
 * HORUS AI — Knowledge Base Manager — Simulator Features source.
 *
 * Connects the Simulator Features repository to ENGINIX's real circuit
 * simulator (`src/circuit/simulator.ts`) by reflecting its exported
 * functions at fetch time — no capability list is typed in by hand. A
 * new exported function added to that file becomes a new entry here on
 * the next refresh automatically.
 */

import type { KnowledgeSourceModuleInfo } from './moduleInfo';
import * as SimulatorModule from '../../../circuit/simulator';
import { exportedFunctionNames, humanizeIdentifier } from './reflection';
import type { SimulatorFeatureEntry } from '../repositories/SimulatorFeaturesRepository';
import type { IKnowledgeSource } from '../KnowledgeRepository';

export class SimulatorFeaturesSource implements IKnowledgeSource<SimulatorFeatureEntry> {
  readonly moduleInfo: KnowledgeSourceModuleInfo = {
    module: 'src/circuit/simulator.ts',
    exports: ['(reflected at fetch time)'],
  };

  async fetchAll(): Promise<SimulatorFeatureEntry[]> {
    return exportedFunctionNames(SimulatorModule).map((fnName) => ({
      id: fnName,
      name: humanizeIdentifier(fnName),
      description: `Exported capability \`${fnName}\` from src/circuit/simulator.ts.`,
    }));
  }
}
