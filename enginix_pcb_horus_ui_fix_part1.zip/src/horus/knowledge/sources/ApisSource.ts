/**
 * HORUS AI — Knowledge Base Manager — Internal APIs source.
 *
 * Connects the APIs repository to ENGINIX's real internal service layer
 * (`src/services/*.ts`) by reflecting each module's exported async
 * functions at fetch time — no API list is typed in by hand. A new
 * exported function added to a services module becomes a new entry here
 * on the next refresh automatically. "Endpoint" here means the callable
 * internal symbol path (`module#functionName`), not an HTTP route — this
 * project doesn't expose a server API.
 */

import type { KnowledgeSourceModuleInfo } from './moduleInfo';
import * as OptimizationEngineModule from '../../../services/OptimizationEngine';
import * as GeminiServiceModule from '../../../services/GeminiService';
import { exportedFunctionNames, humanizeIdentifier } from './reflection';
import type { ApiEntry } from '../repositories/ApisRepository';
import type { IKnowledgeSource } from '../KnowledgeRepository';

const REFLECTED_MODULES: Array<{ label: string; namespace: object }> = [
  { label: 'src/services/OptimizationEngine.ts', namespace: OptimizationEngineModule },
  { label: 'src/services/GeminiService.ts', namespace: GeminiServiceModule },
];

export class ApisSource implements IKnowledgeSource<ApiEntry> {
  readonly moduleInfo: KnowledgeSourceModuleInfo = {
    module: 'src/services/*.ts',
    exports: ['(reflected at fetch time)'],
  };

  async fetchAll(): Promise<ApiEntry[]> {
    const entries: ApiEntry[] = [];
    for (const { label, namespace } of REFLECTED_MODULES) {
      for (const fnName of exportedFunctionNames(namespace)) {
        entries.push({
          id: `${label}#${fnName}`,
          name: humanizeIdentifier(fnName),
          endpoint: `${label}#${fnName}`,
        });
      }
    }
    return entries;
  }
}
