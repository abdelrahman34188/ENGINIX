/**
 * HORUS AI — Knowledge Base Manager — PCB Features source.
 *
 * Connects the PCB Features repository to ENGINIX's real PCB tooling
 * (`src/pcb/*.ts`) by reflecting each module's exported functions, plus
 * `PCBEngine`'s own public methods, at fetch time — no capability list
 * is typed in by hand. A new export or a new public `PCBEngine` method
 * becomes a new entry here on the next refresh automatically.
 */

import type { KnowledgeSourceModuleInfo } from './moduleInfo';
import * as PCBEngineModule from '../../../pcb/PCBEngine';
import * as DrcModule from '../../../pcb/drc';
import * as GerberExportModule from '../../../pcb/gerberExport';
import * as FabricationExportModule from '../../../pcb/fabricationExport';
import * as PickPlaceExportModule from '../../../pcb/pickPlaceExport';
import * as BomExportModule from '../../../pcb/bomExport';
import * as ConvertFromCircuitModule from '../../../pcb/convertFromCircuit';
import { PCBEngine } from '../../../pcb/PCBEngine';
import {
  exportedFunctionNames,
  publicPrototypeMethodNames,
  humanizeIdentifier,
} from './reflection';
import type { PCBFeatureEntry } from '../repositories/PCBFeaturesRepository';
import type { IKnowledgeSource } from '../KnowledgeRepository';

const REFLECTED_MODULES: Array<{ label: string; namespace: object }> = [
  { label: 'src/pcb/PCBEngine.ts', namespace: PCBEngineModule },
  { label: 'src/pcb/drc.ts', namespace: DrcModule },
  { label: 'src/pcb/gerberExport.ts', namespace: GerberExportModule },
  { label: 'src/pcb/fabricationExport.ts', namespace: FabricationExportModule },
  { label: 'src/pcb/pickPlaceExport.ts', namespace: PickPlaceExportModule },
  { label: 'src/pcb/bomExport.ts', namespace: BomExportModule },
  { label: 'src/pcb/convertFromCircuit.ts', namespace: ConvertFromCircuitModule },
];

export class PCBFeaturesSource implements IKnowledgeSource<PCBFeatureEntry> {
  readonly moduleInfo: KnowledgeSourceModuleInfo = {
    module: 'src/pcb/*.ts',
    exports: ['(reflected at fetch time)'],
  };

  async fetchAll(): Promise<PCBFeatureEntry[]> {
    const entries: PCBFeatureEntry[] = [];

    for (const { label, namespace } of REFLECTED_MODULES) {
      for (const fnName of exportedFunctionNames(namespace)) {
        entries.push({
          id: `${label}#${fnName}`,
          name: humanizeIdentifier(fnName),
          description: `Exported capability \`${fnName}\` from ${label}.`,
        });
      }
    }

    for (const methodName of publicPrototypeMethodNames(PCBEngine)) {
      entries.push({
        id: `src/pcb/PCBEngine.ts#PCBEngine.${methodName}`,
        name: humanizeIdentifier(methodName),
        description: `PCBEngine method \`${methodName}\` from src/pcb/PCBEngine.ts.`,
      });
    }

    return entries;
  }
}
