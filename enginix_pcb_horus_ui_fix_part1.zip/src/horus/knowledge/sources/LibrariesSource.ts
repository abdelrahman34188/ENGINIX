/**
 * HORUS AI — Knowledge Base Manager — Arduino Libraries source.
 *
 * Connects the Libraries repository to ENGINIX's real Arduino runtime
 * (`src/arduino/interpreter.ts`). The interpreter dispatches every
 * supported library object (`Servo`, `Stepper`, `DHT`, `Wire`, `SPI`, ...)
 * through a `call<Name>Method` handler on its own prototype — this source
 * reflects over that prototype at fetch time and turns each handler it
 * finds into a Library entry, rather than a hand-typed list of library
 * names. Add a new `callFooMethod` handler to the interpreter to support
 * a new library, and it appears here automatically on the next refresh.
 */

import type { KnowledgeSourceModuleInfo } from './moduleInfo';
import { Interpreter } from '../../../arduino/interpreter';
import { publicPrototypeMethodNames } from './reflection';
import type { LibraryEntry } from '../repositories/LibrariesRepository';
import type { IKnowledgeSource } from '../KnowledgeRepository';

const LIBRARY_HANDLER_PATTERN = /^call([A-Za-z0-9]+)Method$/;

export class LibrariesSource implements IKnowledgeSource<LibraryEntry> {
  readonly moduleInfo: KnowledgeSourceModuleInfo = {
    module: 'src/arduino/interpreter.ts',
    exports: ['(reflected at fetch time — Interpreter.prototype)'],
  };

  async fetchAll(): Promise<LibraryEntry[]> {
    // Interpreter marks these `private`, which TypeScript erases at
    // runtime — the methods are still real, enumerable prototype members,
    // so this cast is only about satisfying the compiler, not about
    // bypassing anything that's actually hidden at runtime.
    const methodNames = publicPrototypeMethodNames(
      Interpreter as unknown as { prototype: object }
    );

    const entries: LibraryEntry[] = [];
    for (const methodName of methodNames) {
      const match = LIBRARY_HANDLER_PATTERN.exec(methodName);
      if (!match) continue;
      const libraryName = match[1];
      entries.push({
        id: libraryName,
        name: libraryName,
        description: `Supported via Interpreter.${methodName}() in src/arduino/interpreter.ts.`,
      });
    }
    return entries;
  }
}
