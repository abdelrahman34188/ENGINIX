/**
 * HORUS AI — Knowledge Base Manager — Libraries repository.
 *
 * Reference knowledge HORUS can ground answers in for this domain. No
 * data is hardcoded here — entries come from whatever `IKnowledgeSource`
 * is injected at construction time.
 *
 * Interface + skeleton only — no logic implemented yet.
 */

import type { KnowledgeEntity, IKnowledgeSource, IKnowledgeRepository } from '../KnowledgeRepository';
import { BaseKnowledgeRepository } from '../KnowledgeRepository';

export interface LibraryEntry extends KnowledgeEntity {
  name: string;
  description: string;
}

export type ILibrariesRepository = IKnowledgeRepository<LibraryEntry>;

export class LibrariesRepository
  extends BaseKnowledgeRepository<LibraryEntry>
  implements ILibrariesRepository
{
  constructor(source: IKnowledgeSource<LibraryEntry>) {
    super(source);
  }
}
