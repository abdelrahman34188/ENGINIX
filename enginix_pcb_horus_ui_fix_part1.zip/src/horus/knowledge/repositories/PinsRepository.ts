/**
 * HORUS AI — Knowledge Base Manager — Pins repository.
 *
 * Reference knowledge HORUS can ground answers in for this domain. No
 * data is hardcoded here — entries come from whatever `IKnowledgeSource`
 * is injected at construction time.
 *
 * Interface + skeleton only — no logic implemented yet.
 */

import type { KnowledgeEntity, IKnowledgeSource, IKnowledgeRepository } from '../KnowledgeRepository';
import { BaseKnowledgeRepository } from '../KnowledgeRepository';

export interface PinRef {
  label: string;
  dx: number;
  dy: number;
}

export interface PinEntry extends KnowledgeEntity {
  /** id == the owning component's type. */
  componentName: string;
  pins: PinRef[];
}

export type IPinsRepository = IKnowledgeRepository<PinEntry>;

export class PinsRepository
  extends BaseKnowledgeRepository<PinEntry>
  implements IPinsRepository
{
  constructor(source: IKnowledgeSource<PinEntry>) {
    super(source);
  }
}
