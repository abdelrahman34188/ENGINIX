/**
 * HORUS AI — Knowledge Base Manager — APIs repository.
 *
 * Reference knowledge HORUS can ground answers in for this domain. No
 * data is hardcoded here — entries come from whatever `IKnowledgeSource`
 * is injected at construction time.
 *
 * Interface + skeleton only — no logic implemented yet.
 */

import type { KnowledgeEntity, IKnowledgeSource, IKnowledgeRepository } from '../KnowledgeRepository';
import { BaseKnowledgeRepository } from '../KnowledgeRepository';

export interface ApiEntry extends KnowledgeEntity {
  name: string;
  endpoint: string;
}

export type IApisRepository = IKnowledgeRepository<ApiEntry>;

export class ApisRepository
  extends BaseKnowledgeRepository<ApiEntry>
  implements IApisRepository
{
  constructor(source: IKnowledgeSource<ApiEntry>) {
    super(source);
  }
}
