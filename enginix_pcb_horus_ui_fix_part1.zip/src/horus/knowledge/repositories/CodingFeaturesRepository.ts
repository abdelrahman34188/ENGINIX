/**
 * HORUS AI — Knowledge Base Manager — Coding Features repository.
 *
 * Reference knowledge HORUS can ground answers in for this domain. No
 * data is hardcoded here — entries come from whatever `IKnowledgeSource`
 * is injected at construction time.
 *
 * Interface + skeleton only — no logic implemented yet.
 */

import type { KnowledgeEntity, IKnowledgeSource, IKnowledgeRepository } from '../KnowledgeRepository';
import { BaseKnowledgeRepository } from '../KnowledgeRepository';

export interface CodingFeatureEntry extends KnowledgeEntity {
  name: string;
  description: string;
}

export type ICodingFeaturesRepository = IKnowledgeRepository<CodingFeatureEntry>;

export class CodingFeaturesRepository
  extends BaseKnowledgeRepository<CodingFeatureEntry>
  implements ICodingFeaturesRepository
{
  constructor(source: IKnowledgeSource<CodingFeatureEntry>) {
    super(source);
  }
}
