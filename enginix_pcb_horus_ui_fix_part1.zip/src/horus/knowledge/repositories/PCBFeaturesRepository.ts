/**
 * HORUS AI — Knowledge Base Manager — PCB Features repository.
 *
 * Reference knowledge HORUS can ground answers in for this domain. No
 * data is hardcoded here — entries come from whatever `IKnowledgeSource`
 * is injected at construction time.
 *
 * Interface + skeleton only — no logic implemented yet.
 */

import type { KnowledgeEntity, IKnowledgeSource, IKnowledgeRepository } from '../KnowledgeRepository';
import { BaseKnowledgeRepository } from '../KnowledgeRepository';

export interface PCBFeatureEntry extends KnowledgeEntity {
  name: string;
  description: string;
}

export type IPCBFeaturesRepository = IKnowledgeRepository<PCBFeatureEntry>;

export class PCBFeaturesRepository
  extends BaseKnowledgeRepository<PCBFeatureEntry>
  implements IPCBFeaturesRepository
{
  constructor(source: IKnowledgeSource<PCBFeatureEntry>) {
    super(source);
  }
}
