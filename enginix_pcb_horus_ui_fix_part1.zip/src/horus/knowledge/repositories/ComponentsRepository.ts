/**
 * HORUS AI — Knowledge Base Manager — Components repository.
 *
 * Reference knowledge about electrical components (name, category,
 * datasheet metadata, etc.) HORUS can ground answers in. No component
 * data is hardcoded here — entries come from whatever `IKnowledgeSource`
 * is injected at construction time.
 *
 * Interface + skeleton only — no logic implemented yet.
 */

import type { KnowledgeEntity, IKnowledgeSource, IKnowledgeRepository } from '../KnowledgeRepository';
import { BaseKnowledgeRepository } from '../KnowledgeRepository';

export interface ComponentPropertyRef {
  key: string;
  name: string;
  unit?: string;
}

export interface ComponentEntry extends KnowledgeEntity {
  name: string;
  category: string;
  properties: ComponentPropertyRef[];
}

export type IComponentsRepository = IKnowledgeRepository<ComponentEntry>;

export class ComponentsRepository
  extends BaseKnowledgeRepository<ComponentEntry>
  implements IComponentsRepository
{
  constructor(source: IKnowledgeSource<ComponentEntry>) {
    super(source);
  }
}
