/**
 * HORUS AI — Knowledge Base Manager — Simulator Features repository.
 *
 * Reference knowledge HORUS can ground answers in for this domain. No
 * data is hardcoded here — entries come from whatever `IKnowledgeSource`
 * is injected at construction time.
 *
 * Interface + skeleton only — no logic implemented yet.
 */

import type { KnowledgeEntity, IKnowledgeSource, IKnowledgeRepository } from '../KnowledgeRepository';
import { BaseKnowledgeRepository } from '../KnowledgeRepository';

export interface SimulatorFeatureEntry extends KnowledgeEntity {
  name: string;
  description: string;
}

export type ISimulatorFeaturesRepository = IKnowledgeRepository<SimulatorFeatureEntry>;

export class SimulatorFeaturesRepository
  extends BaseKnowledgeRepository<SimulatorFeatureEntry>
  implements ISimulatorFeaturesRepository
{
  constructor(source: IKnowledgeSource<SimulatorFeatureEntry>) {
    super(source);
  }
}
