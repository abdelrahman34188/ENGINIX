/**
 * HORUS AI — Knowledge Base Manager — generic repository contract + base
 * implementation.
 *
 * Every domain repository (Components, Pins, Libraries, APIs, Simulator
 * Features, PCB Features, Coding Features) implements this same shape so
 * KnowledgeBaseManager can treat them uniformly. No repository hardcodes
 * data — each is constructed with an injected `IKnowledgeSource<T>` that
 * is responsible for actually producing entries. The sources that get
 * injected in practice (see `knowledge/sources/`) read live, already-
 * exported data/reflection from the ENGINIX project itself (component
 * definitions, simulator/PCB module exports, the Arduino interpreter,
 * ...) — never a hand-written data literal.
 */

/** Base shape every knowledge entity must have, regardless of domain. */
export interface KnowledgeEntity {
  id: string;
}

/**
 * Pluggable source a repository loads/refreshes from. Kept separate from
 * the repository itself so where data comes from can change (static
 * bundle, remote API, generated at build time, ...) without touching
 * repository or consumer code — Dependency Inversion, same as
 * `AIProvider` does for AICore.
 */
export interface IKnowledgeSource<T extends KnowledgeEntity> {
  /** Fetch the current full set of entries from the underlying source. */
  fetchAll(): Promise<T[]>;
}

/**
 * Uniform contract for a single domain's knowledge repository.
 *
 * - `load`     — initial population from the injected source.
 * - `refresh`  — re-fetch from the source, replacing the in-memory set —
 *                this is what lets a newly-added component (or any other
 *                newly-added entry in the underlying project data) show
 *                up without restarting anything.
 * - `search`   — free-text lookup over the currently loaded entries.
 * - `getById`  — direct lookup by entity id.
 */
export interface IKnowledgeRepository<T extends KnowledgeEntity> {
  /** Populate the repository from its source. Safe to call once at startup. */
  load(): Promise<void>;

  /** Re-fetch from the source and replace the in-memory contents with it. */
  refresh(): Promise<void>;

  /** Search currently loaded entries relevant to a free-text query. */
  search(query: string): T[];

  /** Look up a single entry by id, if loaded. */
  getById(id: string): T | undefined;

  /** How many entries are currently loaded. */
  count(): number;
}

/**
 * Shared implementation so concrete repositories don't repeat the same
 * load/refresh/search/getById bookkeeping. A concrete repository extends
 * this and only adds its own entity type + any domain-specific interface
 * it satisfies (see `repositories/*.ts`) — it never overrides these
 * methods, and never contains domain data itself.
 *
 * `search` is intentionally generic (case-insensitive substring match
 * over the entry's own JSON representation) rather than per-domain, so
 * adding a field to any entity automatically becomes searchable without
 * touching this class or the concrete repository.
 */
export abstract class BaseKnowledgeRepository<T extends KnowledgeEntity>
  implements IKnowledgeRepository<T>
{
  protected readonly source: IKnowledgeSource<T>;
  private entries = new Map<string, T>();

  constructor(source: IKnowledgeSource<T>) {
    this.source = source;
  }

  async load(): Promise<void> {
    const fetched = await this.source.fetchAll();
    this.replaceAll(fetched);
  }

  async refresh(): Promise<void> {
    const fetched = await this.source.fetchAll();
    this.replaceAll(fetched);
  }

  search(query: string): T[] {
    const needle = query.trim().toLowerCase();
    if (!needle) return this.all();
    return this.all().filter((entry) =>
      JSON.stringify(entry).toLowerCase().includes(needle)
    );
  }

  getById(id: string): T | undefined {
    return this.entries.get(id);
  }

  count(): number {
    return this.entries.size;
  }

  /** All currently loaded entries, in source order. */
  protected all(): T[] {
    return Array.from(this.entries.values());
  }

  private replaceAll(fetched: T[]): void {
    const next = new Map<string, T>();
    for (const entry of fetched) {
      next.set(entry.id, entry);
    }
    this.entries = next;
  }
}
