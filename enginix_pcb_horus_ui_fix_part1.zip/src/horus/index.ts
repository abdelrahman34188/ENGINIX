/**
 * HORUS AI — Electrical Engineering Copilot.
 *
 * Architecture-only barrel export. Every module below is isolated behind
 * an interface; none has implemented logic yet (see each file's header).
 * AI Core wires the others together via constructor injection and depends
 * on no concrete AI vendor — see `provider/AIProvider.ts`.
 */

export * from './identity';

export * from './events/HorusEvent';
export * from './events/AIEventBus';
export * from './events/catalog/SimulatorEvents';
export * from './events/catalog/CodingEvents';
export * from './events/catalog/PCBEvents';
export * from './events/catalog/WorkspaceEvents';
export * from './events/catalog/SettingsEvents';
export * from './events/emitters/SimulatorEventEmitter';
export * from './events/emitters/CodingEventEmitter';
export * from './events/emitters/PCBEventEmitter';
export * from './events/emitters/WorkspaceEventEmitter';
export * from './events/emitters/SettingsEventEmitter';
export * from './events/HorusEventEmitters';

export * from './provider/AIProvider';
export * from './provider/ProviderRegistry';
export * from './provider/AIProviderManager';
export * from './provider/GeminiProvider';
export * from './provider/GeminiClient';

export * from './router/IntentRouter';

export * from './core/AICore';
export * from './core/AIConfiguration';
export * from './conversation/ConversationManager';
export * from './conversation/SessionManager';
export * from './context/ContextProvider';
export * from './context/ContextManager';
export * from './context/providers/SimulatorContextProvider';
export * from './context/providers/PCBContextProvider';
export * from './context/providers/CodingContextProvider';
export * from './context/providers/WorkspaceContextProvider';
export * from './context/providers/ProjectGalleryContextProvider';
export * from './context/providers/ProjectContextProvider';
export * from './knowledge/KnowledgeRepository';
export * from './knowledge/KnowledgeBaseManager';
export * from './knowledge/ProjectKnowledgeBase';
export * from './knowledge/repositories/ComponentsRepository';
export * from './knowledge/repositories/PinsRepository';
export * from './knowledge/repositories/LibrariesRepository';
export * from './knowledge/repositories/ApisRepository';
export * from './knowledge/repositories/SimulatorFeaturesRepository';
export * from './knowledge/repositories/PCBFeaturesRepository';
export * from './knowledge/repositories/CodingFeaturesRepository';
export * from './tools/ToolManager';
export * from './tools/CircuitContextBuilder';
export * from './tools/EditValidator';
export * from './core/Brain/CircuitEditPlanner';
export * from './core/Brain/CircuitPlanner';
export * from './validation/ValidationEngine';
export * from './autofix/AutoFixEngine';
export * from './memory/MemoryManager';
