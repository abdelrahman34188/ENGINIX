/**
 * HORUS AI — Conversation Manager.
 *
 * Responsible (once implemented) for owning conversation turns/history:
 * appending messages, trimming/summarizing history, and exposing the
 * current turn sequence to AI Core. Isolated from Context Manager (which
 * owns *environmental* state like the active circuit/page, not chat turns).
 *
 * Interface + skeleton only — no logic implemented yet.
 */

export interface HorusMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: number;
}

export interface IConversationManager {
  /** Start a new, empty conversation and return its id. */
  startConversation(): string;

  /** Append a message to a conversation. */
  appendMessage(conversationId: string, message: HorusMessage): void;

  /** Return the full ordered message history for a conversation. */
  getHistory(conversationId: string): HorusMessage[];

  /** Clear a conversation's history. */
  clearConversation(conversationId: string): void;
}

export class ConversationManager implements IConversationManager {
  startConversation(): string {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  appendMessage(_conversationId: string, _message: HorusMessage): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getHistory(_conversationId: string): HorusMessage[] {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  clearConversation(_conversationId: string): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
