/**
 * HORUS AI — Session Manager.
 *
 * Responsible (once implemented) for owning HORUS chat sessions — the
 * conversation history a user sees in the sidebar (title, timestamps,
 * message list) — as distinct from a single active turn sequence, which
 * is Conversation Manager's concern. A session is the persisted/listable
 * unit; Conversation Manager can operate on a session's messages once
 * wired together.
 *
 * Interface + skeleton only — no logic implemented yet, no AI.
 */

import type { HorusMessage } from './ConversationManager';

export interface HorusSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: HorusMessage[];
}

export interface ISessionManager {
  /** Create a new, empty session and return it. */
  createSession(title?: string): HorusSession;

  /** Return a single session by id. */
  getSession(sessionId: string): HorusSession | undefined;

  /** Return every known session. */
  listSessions(): HorusSession[];

  /** Rename a session. */
  renameSession(sessionId: string, title: string): void;

  /** Append a message to a session and bump its updated time. */
  appendMessage(sessionId: string, message: HorusMessage): void;

  /** Delete a session. */
  deleteSession(sessionId: string): void;
}

export class SessionManager implements ISessionManager {
  createSession(_title?: string): HorusSession {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getSession(_sessionId: string): HorusSession | undefined {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  listSessions(): HorusSession[] {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  renameSession(_sessionId: string, _title: string): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  appendMessage(_sessionId: string, _message: HorusMessage): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  deleteSession(_sessionId: string): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
