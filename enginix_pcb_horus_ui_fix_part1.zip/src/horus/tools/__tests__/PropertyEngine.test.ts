// @vitest-environment jsdom
/**
 * HORUS AI — Property Engine tests.
 *
 * Exercises `PropertyEngine` against a real headless `CircuitEditor`
 * through `CircuitToolBridge`, using a component (HC-05) that has five
 * properties of four different `PropertyDef` types on one part — the
 * exact shape the old "primary property + select options only" logic
 * in `EditApplier` could never fully reach — to prove discovery,
 * named-property resolution, coercion, execution, and post-write
 * verification are all generic, not LED/Resistor/Battery-specific.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../../circuit/CircuitEditor';
import { circuitToolBridge } from '../CircuitToolBridge';
import { propertyEngine } from '../PropertyEngine';

function makeEditor(): { editor: CircuitEditor } {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {}, save: () => {}, restore: () => {}, translate: () => {}, rotate: () => {},
    beginPath: () => {}, fillRect: () => {}, strokeRect: () => {}, fill: () => {}, stroke: () => {},
    arc: () => {}, moveTo: () => {}, lineTo: () => {}, fillText: () => {}, setLineDash: () => {},
    closePath: () => {}, quadraticCurveTo: () => {}, bezierCurveTo: () => {}, clip: () => {}, rect: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return { editor: new CircuitEditor(canvas, container) };
}

describe('PropertyEngine', () => {
  let editor: CircuitEditor;

  beforeEach(() => {
    ({ editor } = makeEditor());
    circuitToolBridge.register(editor);
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('discover() reports every real property HC-05 defines, with current values', () => {
    const created = circuitToolBridge.addComponent('hc05', 0, 0)!;
    const snapshot = propertyEngine.discover(created.id)!;
    expect(snapshot.type).toBe('hc05');
    const keys = snapshot.properties.map((p) => p.def.key).sort();
    expect(keys).toEqual(['baudRate', 'connected', 'logicLevel', 'partNumber', 'powered', 'role'].sort());
    const role = snapshot.properties.find((p) => p.def.key === 'role')!;
    expect(role.currentValue).toBe('Slave');
  });

  it('sets a named select property distinct from another select property on the same type', () => {
    const created = circuitToolBridge.addComponent('hc05', 0, 0)!;
    const result = propertyEngine.applyFromText(created.id, 'Baud Rate to 19200');
    expect(result.status).toBe('applied');
    expect(result.key).toBe('baudRate');
    expect(result.verified).toBe(true);
    // Role (a different select on the same component) must be untouched.
    expect(circuitToolBridge.getComponentProperties(created.id)?.role).toBe('Slave');
    expect(circuitToolBridge.getComponentProperties(created.id)?.baudRate).toBe('19200');
  });

  it('sets a boolean property by name — unreachable through the old select/primary-numeric path', () => {
    const created = circuitToolBridge.addComponent('hc05', 0, 0)!;
    expect(circuitToolBridge.getComponentProperties(created.id)?.powered).toBe(true);

    const result = propertyEngine.applyFromText(created.id, 'Powered to off');
    expect(result.status).toBe('applied');
    expect(result.value).toBe(false);
    expect(circuitToolBridge.getComponentProperties(created.id)?.powered).toBe(false);
  });

  it('sets a second, non-primary numeric property by name (Logic Level, not Baud Rate)', () => {
    const created = circuitToolBridge.addComponent('hc05', 0, 0)!;
    const result = propertyEngine.applyFromText(created.id, 'Logic Level to 3.3');
    expect(result.status).toBe('applied');
    expect(result.key).toBe('logicLevel');
    expect(circuitToolBridge.getComponentProperties(created.id)?.logicLevel).toBe(3.3);
  });

  it('rejects a value out of range for the specific property named, without touching the component', () => {
    const created = circuitToolBridge.addComponent('hc05', 0, 0)!;
    const before = circuitToolBridge.getComponentProperties(created.id);
    const result = propertyEngine.applyFromText(created.id, 'Logic Level to 50');
    expect(result.status).toBe('error');
    expect(result.message).toMatch(/Logic Level/);
    expect(circuitToolBridge.getComponentProperties(created.id)).toEqual(before);
  });

  it('reports a clearly-named error for a property the component does not have, listing what it does support', () => {
    const created = circuitToolBridge.addComponent('resistor', 0, 0)!;
    const result = propertyEngine.applyFromText(created.id, 'frequency to 5');
    expect(result.status).toBe('error');
    expect(result.message).toMatch(/Resistance/);
  });

  it('reports an error (not a silent no-op) when the component has no editable properties at all', () => {
    const created = circuitToolBridge.addComponent('screwTerminal2pin', 0, 0)!;
    const result = propertyEngine.applyFromText(created.id, 'anything to 5');
    expect(result.status).toBe('error');
    expect(result.field).toBe('property');
  });

  it('reports an error for a missing component instead of throwing', () => {
    const result = propertyEngine.applyFromText(999999, '220');
    expect(result.status).toBe('error');
    expect(result.field).toBe('target');
  });

  it('still supports the original bare-value shape (numeric primary property, e.g. resistor)', () => {
    const created = circuitToolBridge.addComponent('resistor', 0, 0)!;
    const result = propertyEngine.applyFromText(created.id, '220');
    expect(result.status).toBe('applied');
    expect(result.key).toBe('resistance');
    expect(circuitToolBridge.getComponentProperties(created.id)?.resistance).toBe(220);
  });

  it('still supports the original bare select-option shape (e.g. LED color)', () => {
    const created = circuitToolBridge.addComponent('led', 0, 0)!;
    const result = propertyEngine.applyFromText(created.id, 'green');
    expect(result.status).toBe('applied');
    expect(circuitToolBridge.getComponentProperties(created.id)?.color).toBe('#00ff00');
  });

  it('setPropertyFromText resolves by real key or by display name equivalently', () => {
    const created = circuitToolBridge.addComponent('resistor', 0, 0)!;
    const byKey = propertyEngine.setPropertyFromText(created.id, 'resistance', '470');
    expect(byKey.status).toBe('applied');
    const byName = propertyEngine.setPropertyFromText(created.id, 'Resistance', '1000');
    expect(byName.status).toBe('applied');
    expect(circuitToolBridge.getComponentProperties(created.id)?.resistance).toBe(1000);
  });
});
