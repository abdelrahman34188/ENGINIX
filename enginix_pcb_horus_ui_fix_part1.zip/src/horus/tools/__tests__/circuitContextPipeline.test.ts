/**
 * HORUS AI — pipeline test: does the current circuit reach HORUS?
 *
 *   Current Circuit -> CircuitContextBuilder -> PromptContextFormatter
 *   -> ConversationManager -> HORUSBrain -> AIGateway
 *
 * This only verifies the context reaches HORUS — it does not modify or
 * exercise any AI logic. Every real HORUS module in the chain above is
 * used as-is (`CircuitContextBuilder`, `PromptContextFormatter`,
 * `ConversationManager`, `HORUSBrain`, `AIGateway`); the only thing
 * replaced is the AI provider at the very end, with an in-memory fake
 * that records what it was asked to generate instead of calling Gemini
 * — so this test never makes a network request and never touches
 * `GeminiProvider`/`GeminiClient`.
 */

import { describe, it, expect } from 'vitest';
import {
  CircuitContextBuilder,
  type ICircuitTool,
  type CircuitToolComponent,
  type CircuitToolWire,
  type CircuitToolSelectedComponent,
} from '../CircuitContextBuilder';
import { PromptContextFormatter } from '../../core/Prompt/PromptContextFormatter';
import { ConversationManager } from '../../core/Chat/ConversationManager';
import { HORUSBrain } from '../../core/Brain/HORUSBrain';
import { PromptBuilder } from '../../core/Prompt/PromptBuilder';
import { PromptValidator } from '../../core/Prompt/PromptValidator';
import { SystemPromptManager } from '../../core/Prompt/SystemPromptManager';
import { AIGateway } from '../../core/AI/AIGateway';
import type { ICoreAIProviderManager } from '../../core/AI/AIProviderManager';
import type { AIProvider, AIProviderRequest, AIProviderResponse } from '../../../horus/provider/AIProvider';

/** A fixed, known circuit — stands in for "Current Circuit" at the top
 *  of the pipeline. */
class FakeCircuitTool implements ICircuitTool {
  getComponents(): CircuitToolComponent[] {
    return [
      { id: 1, type: 'battery', label: '9V' },
      { id: 2, type: 'led', label: 'D1' },
      { id: 3, type: 'resistor', label: '220Ω' },
    ];
  }

  getWires(): CircuitToolWire[] {
    return [{ id: 1, fromComponentId: 1, toComponentId: 2 }];
  }

  getSelectedComponent(): CircuitToolSelectedComponent {
    return { id: 2, type: 'led', label: 'D1' };
  }
}

/** Records exactly what it was asked to generate, instead of calling
 *  any real AI vendor — this is the only non-real piece in the chain. */
class RecordingProvider implements AIProvider {
  readonly id = 'recording-fake';
  readonly displayName = 'Recording Fake';
  lastRequest: AIProviderRequest | undefined;

  async generate(request: AIProviderRequest): Promise<AIProviderResponse> {
    this.lastRequest = request;
    return { ok: true, text: 'ack' };
  }

  async testConnection(): Promise<AIProviderResponse> {
    return { ok: true, text: 'ok' };
  }
}

describe('circuit context pipeline (Circuit -> ... -> AIGateway)', () => {
  it('carries the current circuit, formatted, all the way to what AIGateway sends', async () => {
    // Current Circuit -> CircuitContextBuilder
    const circuitContextBuilder = new CircuitContextBuilder(new FakeCircuitTool());
    const snapshot = circuitContextBuilder.build();
    expect(snapshot.components).toHaveLength(3);
    expect(snapshot.wires).toHaveLength(1);
    expect(snapshot.selectedComponent).toEqual({ id: 2, type: 'led', label: 'D1' });

    // CircuitContextBuilder -> PromptContextFormatter
    const formatter = new PromptContextFormatter();
    const formattedText = formatter.format(snapshot);
    expect(formattedText).toBe(
      ['Battery 9V', 'LED D1', 'Resistor 220Ω', 'Wire: 1 -> 2', 'Selected: LED D1'].join('\n')
    );

    // PromptContextFormatter -> ConversationManager (attach, storage only)
    const conversationManager = new ConversationManager();
    const conversationId = 'test-conversation';
    conversationManager.attachCircuitContext(conversationId, snapshot);
    expect(conversationManager.getCircuitContext(conversationId)).toEqual(snapshot);

    // ConversationManager -> HORUSBrain -> AIGateway, with a recording
    // provider standing in for Gemini so no AI logic runs and no
    // network call is made.
    const recordingProvider = new RecordingProvider();
    const fakeProviderManager: ICoreAIProviderManager = {
      registerProvider: () => {},
      chooseActiveProvider: () => {},
      getCurrentProvider: () => recordingProvider,
      listProviders: () => [recordingProvider],
    };
    const aiGateway = new AIGateway(fakeProviderManager);
    const horusBrain = new HORUSBrain(
      new PromptBuilder(),
      new PromptValidator(),
      new SystemPromptManager(),
      aiGateway
    );

    const response = await horusBrain.run({
      userRequest: 'What is this?',
      conversationContext: conversationManager.getHistory(conversationId),
      projectContext: formattedText,
      memory: undefined,
    });

    // The context reached HORUS: no errors reported, and the request
    // AIGateway actually handed to the provider contains the formatted
    // circuit text, labeled as circuit context, ahead of the user's
    // request — proving the full chain delivered it, not just that
    // some earlier stage produced the right string in isolation.
    expect(response.errors).toEqual([]);
    expect(recordingProvider.lastRequest).toBeDefined();
    const userMessage = recordingProvider.lastRequest!.messages.find((m) => m.role === 'user');
    expect(userMessage).toBeDefined();
    expect(userMessage!.content).toContain('Circuit context:');
    expect(userMessage!.content).toContain('Battery 9V');
    expect(userMessage!.content).toContain('LED D1');
    expect(userMessage!.content).toContain('Resistor 220Ω');
    expect(userMessage!.content).toContain('Wire: 1 -> 2');
    expect(userMessage!.content).toContain('Selected: LED D1');
    expect(userMessage!.content).toContain('What is this?');
  });

  it('reports an empty circuit just as faithfully (no components selected)', async () => {
    const emptyCircuitTool: ICircuitTool = {
      getComponents: () => [],
      getWires: () => [],
      getSelectedComponent: () => null,
    };
    const snapshot = new CircuitContextBuilder(emptyCircuitTool).build();
    const formattedText = new PromptContextFormatter().format(snapshot);
    expect(formattedText).toBe('Selected: none');

    const conversationManager = new ConversationManager();
    conversationManager.attachCircuitContext('empty-conversation', snapshot);
    expect(conversationManager.getCircuitContext('empty-conversation')).toEqual({
      components: [],
      wires: [],
      selectedComponent: null,
    });

    const recordingProvider = new RecordingProvider();
    const fakeProviderManager: ICoreAIProviderManager = {
      registerProvider: () => {},
      chooseActiveProvider: () => {},
      getCurrentProvider: () => recordingProvider,
      listProviders: () => [recordingProvider],
    };
    const aiGateway = new AIGateway(fakeProviderManager);
    const horusBrain = new HORUSBrain(
      new PromptBuilder(),
      new PromptValidator(),
      new SystemPromptManager(),
      aiGateway
    );

    await horusBrain.run({
      userRequest: 'Anything on the board?',
      conversationContext: conversationManager.getHistory('empty-conversation'),
      projectContext: formattedText,
      memory: undefined,
    });

    const userMessage = recordingProvider.lastRequest!.messages.find((m) => m.role === 'user');
    expect(userMessage!.content).toContain('Circuit context:\nSelected: none');
  });
});
