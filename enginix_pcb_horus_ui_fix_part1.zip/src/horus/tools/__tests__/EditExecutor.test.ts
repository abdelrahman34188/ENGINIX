import { describe, it, expect, vi } from 'vitest';
import { EditExecutor } from '../EditExecutor';
import type { ValidatedEditPlan } from '../EditValidator';
import type { IEditApplier, EditApplyResult } from '../EditApplier';
import type { ICircuitTool, CircuitToolComponent } from '../CircuitContextBuilder';

function validPlan(): ValidatedEditPlan {
  return {
    plan: { action: 'add', target: 'LED', value: null },
    targetExists: true,
    valueValid: true,
    connectionPossible: null,
    valid: true,
    issues: [],
  };
}

function invalidPlan(): ValidatedEditPlan {
  return {
    plan: { action: 'change_value', target: 'R9', value: '220Ω' },
    targetExists: false,
    valueValid: true,
    connectionPossible: null,
    valid: false,
    issues: [{ field: 'target', message: 'No component matching "R9" was found on the circuit.' }],
  };
}

/** Minimal `ICircuitTool` stub — just enough for `EditExecutor` to look
 *  up a component's real label after `EditApplier` reports success. */
function fakeCircuitTool(components: CircuitToolComponent[]): ICircuitTool {
  return {
    getComponents: () => components,
    getWires: () => [],
    getSelectedComponent: () => null,
    getComponentTerminalLabels: () => [],
  };
}

/** Minimal `IEditApplier` stub — returns whatever `EditApplyResult` the
 *  test configures, without touching any real `CircuitToolBridge`. */
function fakeApplier(result: EditApplyResult): IEditApplier {
  return { apply: vi.fn(() => result) };
}

describe('EditExecutor', () => {
  it('executes a valid plan through the applier (CircuitToolBridge) and returns a short confirmation', () => {
    const applier = fakeApplier({ status: 'applied', plan: { action: 'add', target: 'LED', value: null }, componentId: 7 });
    const tool = fakeCircuitTool([{ id: 7, type: 'led', label: 'LED1' }]);
    const executor = new EditExecutor(applier, tool);

    const result = executor.receivePlan(validPlan());

    expect(applier.apply).toHaveBeenCalledWith(validPlan());
    expect(result.status).toBe('applied');
    expect(result.message).toBe('LED1 added successfully.');
    expect(result.componentId).toBe(7);
    // The raw plan/EditPlanJSON is carried for structured callers, but
    // `message` — not `plan` — is what a caller shows in chat.
    expect(result.plan).toEqual({ action: 'add', target: 'LED', value: null });
    expect(executor.getLastResult()).toEqual(result);
  });

  it('falls back to the plan target when the created component has no lookup match', () => {
    const applier = fakeApplier({ status: 'applied', plan: { action: 'add', target: 'capacitor', value: null }, componentId: 99 });
    const tool = fakeCircuitTool([]); // id 99 not found
    const executor = new EditExecutor(applier, tool);

    const result = executor.receivePlan(validPlan());

    expect(result.message).toBe('capacitor added successfully.');
  });

  it('rejects an invalid plan without calling the applier at all', () => {
    const applier = fakeApplier({ status: 'applied', plan: { action: 'add', target: 'LED', value: null } });
    const tool = fakeCircuitTool([]);
    const executor = new EditExecutor(applier, tool);

    const result = executor.receivePlan(invalidPlan());

    expect(applier.apply).not.toHaveBeenCalled();
    expect(result.status).toBe('rejected');
    expect(result.message).toBe('No component matching "R9" was found on the circuit.');
    expect(result.issues).toEqual([{ field: 'target', message: 'No component matching "R9" was found on the circuit.' }]);
  });

  it('reports an applier-time failure as status "error", not "applied"', () => {
    const applier = fakeApplier({
      status: 'error',
      plan: { action: 'add', target: 'led', value: null },
      field: 'target',
      message: 'No circuit is currently open.',
    });
    const tool = fakeCircuitTool([]);
    const executor = new EditExecutor(applier, tool);

    const result = executor.receivePlan(validPlan());

    expect(result.status).toBe('error');
    expect(result.message).toBe('No circuit is currently open.');
    expect(result.issues).toEqual([{ field: 'target', message: 'No circuit is currently open.' }]);
  });

  it('builds a connect confirmation naming both components', () => {
    const applier = fakeApplier({
      status: 'applied',
      plan: { action: 'connect', target: 'LED', value: 'battery' },
      componentId: 1,
      wireId: 5,
    });
    const tool = fakeCircuitTool([{ id: 1, type: 'led', label: 'LED1' }]);
    const executor = new EditExecutor(applier, tool);

    const result = executor.receivePlan(validPlan());

    expect(result.message).toBe('LED connected to battery successfully.');
    expect(result.wireId).toBe(5);
  });

  it('never mutates the plan object it was given', () => {
    const applier = fakeApplier({ status: 'applied', plan: { action: 'add', target: 'LED', value: null }, componentId: 7 });
    const tool = fakeCircuitTool([{ id: 7, type: 'led', label: 'LED1' }]);
    const executor = new EditExecutor(applier, tool);
    const plan = validPlan();
    const snapshot = JSON.parse(JSON.stringify(plan));

    executor.receivePlan(plan);

    expect(plan).toEqual(snapshot);
  });
});
