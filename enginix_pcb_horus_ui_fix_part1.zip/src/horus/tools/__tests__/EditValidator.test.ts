import { describe, it, expect } from 'vitest';
import { EditValidator } from '../EditValidator';
import { CircuitEditPlanner } from '../../core/Brain/CircuitEditPlanner';
import type {
  ICircuitTool,
  CircuitToolComponent,
  CircuitToolWire,
  CircuitToolSelectedComponent,
} from '../CircuitContextBuilder';

/** A small fake circuit: R1 (resistor) and D1 (LED), wired together;
 *  B1 (battery) exists but isn't wired to anything. */
class FakeCircuitTool implements ICircuitTool {
  private readonly components: CircuitToolComponent[];
  private readonly wires: CircuitToolWire[];

  constructor(components: CircuitToolComponent[], wires: CircuitToolWire[]) {
    this.components = components;
    this.wires = wires;
  }

  getComponents(): CircuitToolComponent[] {
    return this.components;
  }

  getWires(): CircuitToolWire[] {
    return this.wires;
  }

  getSelectedComponent(): CircuitToolSelectedComponent {
    return null;
  }
}

function buildFixture() {
  const components: CircuitToolComponent[] = [
    { id: 1, type: 'resistor', label: 'R1' },
    { id: 2, type: 'led', label: 'D1' },
    { id: 3, type: 'battery', label: 'B1' },
  ];
  const wires: CircuitToolWire[] = [{ id: 1, fromComponentId: 1, toComponentId: 2 }];
  return { components, wires };
}

describe('EditValidator', () => {
  const planner = new CircuitEditPlanner();

  it('validates a change_value plan against an existing component with a real value', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Change R1 to 220Ω' })!;

    const result = validator.validate(plan);

    expect(result).toEqual({
      plan: { action: 'change_value', target: 'R1', value: '220Ω' },
      targetExists: true,
      valueValid: true,
      connectionPossible: null,
      valid: true,
      issues: [],
    });
  });

  it('flags a change_value plan whose target does not exist on the circuit', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Change R9 to 220Ω' })!;

    const result = validator.validate(plan);

    expect(result.targetExists).toBe(false);
    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual({
      field: 'target',
      message: expect.stringContaining('R9'),
    });
  });

  it('does not reject a non-numeric value at this stage — only PropertyEngine (per-component real schema) can know whether it is actually valid', () => {
    // "super-duper" isn't a valid Resistance for R1, but EditValidator
    // has no way to know that here — it doesn't know which property
    // "super-duper" would even target, let alone that property's real
    // type. Rejecting non-numeric text unconditionally at this stage
    // is exactly what used to make legitimate non-numeric edits (e.g.
    // "change LED_2 color to green") fail before ever reaching
    // PropertyEngine's real, per-component property check — see
    // EditApplier.test.ts / PropertyEngine.test.ts for where
    // "super-duper"-style nonsense is actually caught.
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Change R1 to super-duper' })!;

    const result = validator.validate(plan);

    expect(result.targetExists).toBe(true);
    expect(result.valueValid).toBe(true);
    expect(result.valid).toBe(true);
  });

  it('flags a change_value plan with no value text at all', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Change R1' })!;

    const result = validator.validate(plan);

    expect(result.targetExists).toBe(true);
    expect(result.valueValid).toBe(false);
    expect(result.valid).toBe(false);
  });

  it('does not require the target to pre-exist for add_component', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Add capacitor' })!;

    const result = validator.validate(plan);

    expect(result).toEqual({
      plan: { action: 'add', target: 'capacitor', value: null },
      targetExists: true,
      valueValid: true,
      connectionPossible: null,
      valid: true,
      issues: [],
    });
  });

  it('allows connecting two existing, not-yet-wired components', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Connect B1 to R1' })!;

    const result = validator.validate(plan);

    expect(result.connectionPossible).toBe(true);
    expect(result.valid).toBe(true);
  });

  it('rejects connecting two components that are already wired together', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Connect R1 to D1' })!;

    const result = validator.validate(plan);

    expect(result.connectionPossible).toBe(false);
    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual({
      field: 'connection',
      message: expect.stringContaining('already connected'),
    });
  });

  it('rejects connecting a component to itself', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Connect R1 to R1' })!;

    const result = validator.validate(plan);

    expect(result.connectionPossible).toBe(false);
    expect(result.issues).toContainEqual({
      field: 'connection',
      message: expect.stringContaining('itself'),
    });
  });

  it('rejects connecting to a component that does not exist', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Connect R1 to R9' })!;

    const result = validator.validate(plan);

    expect(result.connectionPossible).toBe(false);
    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual({
      field: 'secondaryTarget',
      message: expect.stringContaining('R9'),
    });
  });

  it('allows disconnecting a component that currently has a wire', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Disconnect R1' })!;

    const result = validator.validate(plan);

    expect(result.connectionPossible).toBe(true);
    expect(result.valid).toBe(true);
  });

  it('rejects disconnecting a component with no wires', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Disconnect B1' })!;

    const result = validator.validate(plan);

    expect(result.connectionPossible).toBe(false);
    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual({
      field: 'connection',
      message: expect.stringContaining('no connections'),
    });
  });

  it('validates rename against an existing component and a new name', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Rename R1 to Main Resistor' })!;

    const result = validator.validate(plan);

    expect(result.targetExists).toBe(true);
    expect(result.valueValid).toBe(true);
    expect(result.valid).toBe(true);
  });

  it('flags rename with no new name given', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Rename R1' })!;

    const result = validator.validate(plan);

    expect(result.targetExists).toBe(true);
    expect(result.valueValid).toBe(false);
    expect(result.valid).toBe(false);
  });

  it('validates replace against an existing component with a replacement given', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Replace R1 with a capacitor' })!;

    const result = validator.validate(plan);

    expect(result).toEqual({
      plan: { action: 'replace', target: 'R1', value: 'capacitor' },
      targetExists: true,
      valueValid: true,
      connectionPossible: null,
      valid: true,
      issues: [],
    });
  });

  it('flags a replace plan whose target does not exist on the circuit', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Replace R9 with a capacitor' })!;

    const result = validator.validate(plan);

    expect(result.targetExists).toBe(false);
    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual({
      field: 'target',
      message: expect.stringContaining('R9'),
    });
  });

  it('flags a replace plan with no replacement given', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Replace R1' })!;

    const result = validator.validate(plan);

    expect(result.targetExists).toBe(true);
    expect(result.valueValid).toBe(false);
    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual({
      field: 'value',
      message: 'No replacement component was given.',
    });
  });

  it('flags replacing a component with itself as a no-op', () => {
    const { components, wires } = buildFixture();
    const validator = new EditValidator(new FakeCircuitTool(components, wires));
    const plan = planner.planEdit({ request: 'Replace R1 with R1' })!;

    const result = validator.validate(plan);

    expect(result.valueValid).toBe(false);
    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual({
      field: 'value',
      message: expect.stringContaining('nothing to replace it with'),
    });
  });

  it('never mutates the circuit it reads — same fixture, same results across repeated validate() calls', () => {
    const { components, wires } = buildFixture();
    const circuitTool = new FakeCircuitTool(components, wires);
    const validator = new EditValidator(circuitTool);
    const plan = planner.planEdit({ request: 'Remove D1' })!;

    const first = validator.validate(plan);
    const second = validator.validate(plan);

    expect(first).toEqual(second);
    expect(circuitTool.getComponents()).toEqual(components);
    expect(circuitTool.getWires()).toEqual(wires);
  });
});
