// @vitest-environment jsdom
/**
 * `CircuitToolBridge` — `addComponent()` / `removeComponent()`.
 *
 * These already call straight through to the real `CircuitEditor`
 * (`addComponentAt` / `deleteSelected`, both wrapped where needed so a
 * single state-change notification fires) — see the file header on
 * `CircuitToolBridge.ts` for why no separate "CircuitTool" simulator
 * exists to call instead. No test previously exercised
 * `removeComponent()` directly (or the wire-cleanup it inherits from
 * `deleteSelected`), so this file closes that gap and, in the same
 * pass, pins down the four things the bridge's mutators are required
 * to guarantee:
 *
 *  - Real state: the component genuinely appears in / disappears from
 *    `CircuitEditor.state.components` — not a bridge-local shadow copy.
 *  - No new simulator API: proven by spying on the exact existing
 *    `CircuitEditor` methods (`addComponentAt`, `deleteSelected`) and
 *    asserting the bridge calls through to them, rather than
 *    reimplementing the mutation itself.
 *  - Canvas updates immediately: `CircuitEditor.addStateChangeListener`
 *    (the same hook React/the canvas subscribe through) fires
 *    synchronously, inside the bridge call — not on a later tick.
 *  - Success only on real success: `null`/`false` when there's no
 *    registered editor or the target doesn't exist; a real value only
 *    once the mutation has actually happened.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CircuitEditor } from '../../../circuit/CircuitEditor';
import { circuitToolBridge } from '../CircuitToolBridge';

function makeEditor(): CircuitEditor {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    beginPath: () => {},
    fillRect: () => {},
    strokeRect: () => {},
    fill: () => {},
    stroke: () => {},
    arc: () => {},
    moveTo: () => {},
    lineTo: () => {},
    fillText: () => {},
    setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return new CircuitEditor(canvas, container);
}

describe('CircuitToolBridge.addComponent — real simulator calls, not a placeholder', () => {
  let editor: CircuitEditor;

  beforeEach(() => {
    editor = makeEditor();
    circuitToolBridge.register(editor);
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('returns null (no success) when no CircuitEditor is registered — never a fake success', () => {
    circuitToolBridge.unregister(editor);
    const result = circuitToolBridge.addComponent('resistor');
    expect(result).toBeNull();
    expect(editor.state.components.length).toBe(0);
  });

  it('calls through to the existing CircuitEditor.addComponentAt — no new simulator API', () => {
    const spy = vi.spyOn(editor, 'addComponentAt');
    circuitToolBridge.addComponent('led', 3, 4);
    expect(spy).toHaveBeenCalledTimes(1);
    expect(spy).toHaveBeenCalledWith('led', 3, 4);
    spy.mockRestore();
  });

  it('the component genuinely exists in the real editor state, matching the returned id', () => {
    const result = circuitToolBridge.addComponent('resistor');
    expect(result).not.toBeNull();
    const real = editor.state.components.find((c) => c.id === result!.id);
    expect(real).toBeDefined();
    expect(real!.type).toBe('resistor');
    expect(result).toEqual({ id: real!.id, type: real!.type, label: real!.label });
  });

  it('the canvas is notified immediately — the state-change listener fires synchronously', () => {
    const listener = vi.fn();
    editor.addStateChangeListener(listener);
    circuitToolBridge.addComponent('capacitor');
    expect(listener).toHaveBeenCalledTimes(1);
  });

  it('defaults to grid origin (0, 0) when no position is given', () => {
    const result = circuitToolBridge.addComponent('battery');
    const real = editor.state.components.find((c) => c.id === result!.id)!;
    expect(real.x).toBe(0);
    expect(real.y).toBe(0);
  });
});

describe('CircuitToolBridge.removeComponent — real simulator calls, not a placeholder', () => {
  let editor: CircuitEditor;

  beforeEach(() => {
    editor = makeEditor();
    circuitToolBridge.register(editor);
  });

  afterEach(() => {
    circuitToolBridge.unregister(editor);
  });

  it('returns false (no success) when no CircuitEditor is registered', () => {
    const r1 = editor.addComponentAt('resistor', 0, 0);
    circuitToolBridge.unregister(editor);
    const result = circuitToolBridge.removeComponent(r1.id);
    expect(result).toBe(false);
    // Nothing was touched — the real (unregistered) editor still has it.
    expect(editor.state.components.some((c) => c.id === r1.id)).toBe(true);
  });

  it('returns false (no success) when the component does not exist — never a fake success', () => {
    expect(circuitToolBridge.removeComponent(999999)).toBe(false);
  });

  it('calls through to the existing CircuitEditor.deleteSelected — no new simulator API', () => {
    const r1 = editor.addComponentAt('resistor', 0, 0);
    const spy = vi.spyOn(editor, 'deleteSelected');
    circuitToolBridge.removeComponent(r1.id);
    expect(spy).toHaveBeenCalledTimes(1);
    spy.mockRestore();
  });

  it('the component is genuinely gone from the real editor state', () => {
    const r1 = editor.addComponentAt('resistor', 0, 0);
    const led = editor.addComponentAt('led', 5, 0);

    const result = circuitToolBridge.removeComponent(r1.id);

    expect(result).toBe(true);
    expect(editor.state.components.some((c) => c.id === r1.id)).toBe(false);
    // Only R1 was targeted — everything else is untouched.
    expect(editor.state.components.some((c) => c.id === led.id)).toBe(true);
    expect(editor.state.components.length).toBe(1);
  });

  it('wires attached to the removed component are cleaned up too, real ones on the other side survive', () => {
    const r1 = editor.addComponentAt('resistor', 0, 0);
    const led = editor.addComponentAt('led', 5, 0);
    const wire = editor.connectByLabel(r1, '1', led, 'A');
    expect(wire).not.toBeNull();
    expect(editor.state.wires.length).toBe(1);

    circuitToolBridge.removeComponent(r1.id);

    expect(editor.state.wires.length).toBe(0);
    expect(editor.state.components.some((c) => c.id === led.id)).toBe(true);
  });

  it('the canvas is notified immediately — the state-change listener fires synchronously', () => {
    const r1 = editor.addComponentAt('resistor', 0, 0);
    const listener = vi.fn();
    editor.addStateChangeListener(listener);

    circuitToolBridge.removeComponent(r1.id);

    expect(listener).toHaveBeenCalledTimes(1);
  });

  it('restores the caller\'s prior selection (minus the removed component), never clobbering it', () => {
    const r1 = editor.addComponentAt('resistor', 0, 0);
    const led = editor.addComponentAt('led', 5, 0);
    editor.state.selectedComponentIds = [r1.id, led.id];

    circuitToolBridge.removeComponent(r1.id);

    expect(editor.state.selectedComponentIds).toEqual([led.id]);
  });
});
