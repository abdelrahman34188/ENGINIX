import { describe, it, expect } from 'vitest';
import { smartComponentResolver, COMPONENT_UNAVAILABLE_MESSAGE } from '../SmartComponentResolver';
import type { CircuitToolComponent } from '../CircuitContextBuilder';

const components: CircuitToolComponent[] = [
  { id: 1, type: 'resistor', label: 'R1', x: 0, y: 0, value: '220Ω' },
  { id: 2, type: 'led', label: 'LED1', x: 0, y: 0, color: 'Red' },
  { id: 3, type: 'resistor', label: 'R2', x: 10, y: 0, value: '1000Ω' },
  { id: 4, type: 'led', label: 'LED2', x: 10, y: 0, color: 'Green' },
];

describe('SmartComponentResolver.resolve', () => {
  it('resolves an exact label unambiguously', () => {
    const result = smartComponentResolver.resolve('R1', components);
    expect(result.status).toBe('resolved');
    expect(result.component?.id).toBe(1);
  });

  it('resolves a numeric id unambiguously', () => {
    const result = smartComponentResolver.resolve('3', components);
    expect(result.status).toBe('resolved');
    expect(result.component?.id).toBe(3);
  });

  it('resolves a type reference when only one component of that type exists', () => {
    const single = [components[0], components[1]];
    const result = smartComponentResolver.resolve('LED', single);
    expect(result.status).toBe('resolved');
    expect(result.component?.id).toBe(2);
  });

  it('flags "the LED" as ambiguous when two LEDs are present and color does not disambiguate', () => {
    const result = smartComponentResolver.resolve('LED', components);
    expect(result.status).toBe('ambiguous');
    expect(result.candidates.map((c) => c.id)).toEqual([2, 4]);
    expect(result.message).toContain('LED1');
    expect(result.message).toContain('LED2');
  });

  it('flags "the resistor" as ambiguous when two resistors are present', () => {
    const result = smartComponentResolver.resolve('resistor', components);
    expect(result.status).toBe('ambiguous');
    expect(result.candidates.map((c) => c.id)).toEqual([1, 3]);
  });

  it('resolves "the last LED I added" to the most recently added matching component', () => {
    const result = smartComponentResolver.resolve('last LED I added', components);
    expect(result.status).toBe('resolved');
    expect(result.component?.id).toBe(4);
  });

  it('resolves "the last resistor" without the trailing "I added"', () => {
    const result = smartComponentResolver.resolve('last resistor', components);
    expect(result.status).toBe('resolved');
    expect(result.component?.id).toBe(3);
  });

  it('reports unavailable for a reference that names no real, supported type', () => {
    const result = smartComponentResolver.resolve('laser', components);
    expect(result.status).toBe('unavailable');
    expect(result.message).toBe(COMPONENT_UNAVAILABLE_MESSAGE);
  });

  it('reports not_found (not unavailable) for a supported type with nothing on the circuit', () => {
    const result = smartComponentResolver.resolve('capacitor', components);
    expect(result.status).toBe('not_found');
  });

  it('resolves "the green LED" using the real color property', () => {
    const result = smartComponentResolver.resolve('green LED', components);
    expect(result.status).toBe('resolved');
    expect(result.component?.id).toBe(4);
  });

  it('resolves "the 220 ohm resistor" using the real value property', () => {
    const result = smartComponentResolver.resolve('220 ohm resistor', components);
    expect(result.status).toBe('resolved');
    expect(result.component?.id).toBe(1);
  });

  it('resolves "the resistor on the right" using real grid position', () => {
    const result = smartComponentResolver.resolve('resistor on the right', components);
    expect(result.status).toBe('resolved');
    expect(result.component?.id).toBe(3);
  });

  it('resolves "the LED on the left" using real grid position', () => {
    const result = smartComponentResolver.resolve('LED on the left', components);
    expect(result.status).toBe('resolved');
    expect(result.component?.id).toBe(2);
  });

  it('resolves the alias "lamp" against a real "bulb" component on the circuit', () => {
    const withBulb: CircuitToolComponent[] = [components[0], { id: 5, type: 'bulb', label: 'LAMP1' }];
    const result = smartComponentResolver.resolve('lamp', withBulb);
    expect(result.status).toBe('resolved');
    expect(result.component?.id).toBe(5);
  });

  it('returns not_found for an empty circuit', () => {
    const result = smartComponentResolver.resolve('LED', []);
    expect(result.status).toBe('not_found');
  });

  it('never invents a component id that is not in the given list', () => {
    const result = smartComponentResolver.resolve('LED1', components);
    expect(result.status).toBe('resolved');
    expect(components.some((c) => c.id === result.component?.id)).toBe(true);
  });
});

describe('SmartComponentResolver.resolveComponentType', () => {
  it('resolves a direct, exact component type', () => {
    const result = smartComponentResolver.resolveComponentType('resistor');
    expect(result.status).toBe('resolved');
    expect(result.type).toBe('resistor');
  });

  it('maps the "lamp" alias onto the real "bulb" type', () => {
    const result = smartComponentResolver.resolveComponentType('lamp');
    expect(result.status).toBe('resolved');
    expect(result.type).toBe('bulb');
  });

  it('maps the "led" alias/word onto the real "led" type', () => {
    const result = smartComponentResolver.resolveComponentType('LED');
    expect(result.status).toBe('resolved');
    expect(result.type).toBe('led');
  });

  it('flags "light" as ambiguous between led and bulb', () => {
    const result = smartComponentResolver.resolveComponentType('light');
    expect(result.status).toBe('ambiguous');
    expect(result.candidateTypes.sort()).toEqual(['bulb', 'led']);
  });

  it('reports unavailable for a type the simulator does not support, never inventing one', () => {
    const result = smartComponentResolver.resolveComponentType('laser gun');
    expect(result.status).toBe('unavailable');
    expect(result.type).toBeNull();
    expect(result.message).toBe(COMPONENT_UNAVAILABLE_MESSAGE);
  });

  it('maps "knob" onto the real "potentiometer" type', () => {
    const result = smartComponentResolver.resolveComponentType('knob');
    expect(result.status).toBe('resolved');
    expect(result.type).toBe('potentiometer');
  });
});
