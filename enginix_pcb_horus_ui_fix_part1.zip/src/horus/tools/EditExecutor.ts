/**
 * HORUS AI — Edit Executor (Tools).
 *
 * Receives a validated `EditPlan` (see `EditValidator.ts`) and, once
 * `validated.valid` is confirmed, executes it — the pipeline stage
 * `sendChatMessage()` (`runtime.ts`) calls after `EditValidator`:
 *
 *   HORUS request -> CircuitEditPlanner -> EditValidator -> EditExecutor -> CircuitToolBridge -> CircuitTool (CircuitEditor)
 *
 * Execution itself is one call to `EditApplier.apply()` — the module
 * that already turns an `EditPlanJSON` into the matching
 * `CircuitToolBridge` (`ICircuitToolMutator`) call (`addComponent`,
 * `changeComponentValue`, `connectComponents`, ...), which is itself a
 * call-through to the real `CircuitEditor`. Nothing here talks to
 * `CircuitEditor` directly, duplicates `EditApplier`'s
 * parsing/resolution logic, or reaches around `CircuitToolBridge` — by
 * the time this module sees a result, the simulator has already been
 * updated (or the attempt has already failed) for real, synchronously.
 *
 * What changed from this module's previous "prepare only" scope: it
 * used to queue a valid plan (`status: 'queued'`) without applying it,
 * leaving `EditPlanJSON` itself as the result a caller would show. Now
 * a valid plan is executed immediately and this module hands back a
 * short, human-readable confirmation (e.g. "LED added successfully.")
 * instead — the raw `EditPlan`/`EditPlanJSON` is never the thing a
 * caller surfaces to chat; `receivePlan()`'s `message` is.
 *
 * Scope, unchanged in spirit:
 *  - No new circuit-editing logic of its own — every mutation is one
 *    `EditApplier.apply()` call, which is one `ICircuitToolMutator`
 *    call, which is one existing `CircuitEditor` method.
 *  - No AI call, no provider call, no prompt building — HORUS Brain,
 *    `CircuitEditPlanner`, and the providers are untouched.
 *  - Still checks `valid` itself rather than trusting a caller's word
 *    for it, and still carries `EditValidator`'s own issues through
 *    for a rejected plan (never applies an invalid one).
 */

import type { ValidatedEditPlan, EditPlanValidationIssue } from './EditValidator';
import type { EditPlanJSON } from '../core/Brain/CircuitEditPlanner';
import type { IEditApplier, EditApplyResult } from './EditApplier';
import { editApplier } from './EditApplier';
import type { ICircuitTool } from './CircuitContextBuilder';
import { circuitToolBridge } from './CircuitToolBridge';

/** `applied`: the plan was valid and `CircuitToolBridge` confirmed the
 *  mutation happened. `rejected`: `EditValidator` already found this
 *  plan invalid — never attempted. `error`: the plan was valid but
 *  `EditApplier`/`CircuitToolBridge` couldn't carry it out (e.g. the
 *  Electrical Lab isn't open, a race with an intervening manual edit). */
export type EditExecutionStatus = 'applied' | 'rejected' | 'error';

export interface EditExecutionResult {
  status: EditExecutionStatus;
  /** The compact plan this result concerns — passed through unchanged
   *  from the `ValidatedEditPlan` given to `receivePlan()`. Kept for
   *  callers that need the structured action, but this is not what
   *  gets shown in chat — `message` is. */
  plan: EditPlanJSON;
  /** Short, human-readable confirmation, e.g. "LED added successfully."
   *  for `applied`, or a plain-language reason for `rejected`/`error`.
   *  This — not `plan` — is what a caller should return to chat. */
  message: string;
  /** Id of the component the edit landed on (or was created as), when
   *  applicable and `status === 'applied'`. */
  componentId?: number;
  /** Id of the wire created, for a successful `connect`. */
  wireId?: number;
  /** Set for `rejected`/`error`: why it wasn't applied. For `rejected`
   *  these are `EditValidator`'s own issues; for `error`, the single
   *  issue `EditApplier` reported. Empty array is never returned here —
   *  a non-`applied` result always carries at least one. */
  issues?: EditPlanValidationIssue[];
}

export interface IEditExecutor {
  /** Validate-then-execute in one call: rejects immediately (no
   *  `CircuitToolBridge` call at all) when `validated.valid` is false,
   *  otherwise executes through `EditApplier`/`CircuitToolBridge` right
   *  away and returns a short confirmation — never the raw plan. */
  receivePlan(validated: ValidatedEditPlan): EditExecutionResult;

  /** The result of the most recent `receivePlan()` call, if any. */
  getLastResult(): EditExecutionResult | undefined;
}

export class EditExecutor implements IEditExecutor {
  private readonly applier: IEditApplier;
  private readonly circuitTool: ICircuitTool;
  private lastResult: EditExecutionResult | undefined;

  constructor(applier: IEditApplier, circuitTool: ICircuitTool) {
    this.applier = applier;
    this.circuitTool = circuitTool;
  }

  receivePlan(validated: ValidatedEditPlan): EditExecutionResult {
    if (!validated.valid) {
      const issues =
        validated.issues.length > 0
          ? validated.issues
          : [{ field: 'value' as const, message: 'EditPlan failed validation.' }];
      const result: EditExecutionResult = {
        status: 'rejected',
        plan: validated.plan,
        message: issues[0].message,
        issues,
      };
      this.lastResult = result;
      return result;
    }

    // Execute for real — CircuitToolBridge (and CircuitEditor beneath
    // it) has already been mutated by the time `apply()` returns.
    const applied: EditApplyResult = this.applier.apply(validated);

    const result: EditExecutionResult =
      applied.status === 'applied'
        ? {
            status: 'applied',
            plan: applied.plan,
            message: this.buildConfirmation(applied),
            componentId: applied.componentId,
            wireId: applied.wireId,
          }
        : {
            status: 'error',
            plan: applied.plan,
            message: applied.message ?? 'Could not apply that edit.',
            issues: [{ field: applied.field ?? 'target', message: applied.message ?? 'Could not apply that edit.' }],
          };

    this.lastResult = result;
    return result;
  }

  getLastResult(): EditExecutionResult | undefined {
    return this.lastResult;
  }

  /** The real component's own label when one was affected (e.g. "LED1",
   *  "R1") — read fresh from `CircuitToolBridge` rather than guessed
   *  from the plan's raw request text, so "LED added successfully."
   *  names the component the simulator actually now has. Falls back to
   *  the plan's own target/value text when no id applies (e.g. the
   *  component was removed and no longer exists to look up). */
  private labelFor(componentId: number | undefined): string | null {
    if (componentId === undefined) return null;
    const comp = this.circuitTool.getComponents().find((c) => c.id === componentId);
    return comp?.label ?? null;
  }

  private buildConfirmation(applied: EditApplyResult): string {
    const { plan, componentId } = applied;
    const label = this.labelFor(componentId);

    switch (plan.action) {
      case 'add':
        return `${label ?? plan.target ?? 'Component'} added successfully.`;
      case 'remove':
        return `${label ?? plan.target ?? 'Component'} removed successfully.`;
      case 'change_value':
        return `${label ?? plan.target ?? 'Component'} updated successfully.`;
      case 'replace':
        return `${label ?? plan.target ?? 'Component'} replaced successfully.`;
      case 'rename':
        return `${plan.target ?? 'Component'} renamed to "${plan.value ?? label ?? ''}" successfully.`;
      case 'connect':
        return `${plan.target ?? 'Component'} connected to ${plan.value ?? 'component'} successfully.`;
      case 'disconnect':
        return plan.value
          ? `${plan.target ?? 'Component'} disconnected from ${plan.value} successfully.`
          : `${plan.target ?? 'Component'} disconnected successfully.`;
      default:
        return 'Edit applied successfully.';
    }
  }
}

/** Shared instance — backed by the same existing `editApplier`
 *  (itself backed by `circuitToolBridge`) that `EditValidator.ts`'s own
 *  singleton reads through, so validation, execution, and read-back all
 *  agree on one live circuit rather than three separate sources of
 *  truth. Mirrors `Brain/ToolExecutor.ts`'s `toolExecutor` singleton. */
export const editExecutor = new EditExecutor(editApplier, circuitToolBridge);
