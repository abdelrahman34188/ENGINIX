/**
 * HORUS AI — Auto Arrange Executor (Tools) — Phase 4 (Auto Arrange).
 *
 * Repositions the components a `CircuitPlanExecutor` run just created
 * so they don't overlap/stack, before `WiringExecutor` runs. This file
 * does not implement layout itself — it calls straight through
 * `ICircuitToolMutator.autoArrange()` (`CircuitToolBridge`), which is
 * itself a thin pass-through to the Simulator's own, already-existing
 * `CircuitEditor.autoArrangeCircuit()` (role-clustered: controllers
 * center, power sources to one side, sensors/actuators above/below,
 * everything else to the other side; grid-packed per cluster sized to
 * each component's own real terminal extents so bounding boxes can't
 * touch). Nothing here invents a coordinate scheme, a component size
 * table, or a scenario-specific arrangement — every component type is
 * handled the same way, generically, by that existing method.
 *
 * What this executor adds on top, per the Phase 4 spec:
 *  - Never trusts the mutator's own `{ moved }` count as proof of
 *    anything: after calling it, this independently re-reads
 *    `tool.getComponents()` — live simulator state — and checks the
 *    newly created components no longer share a position and that
 *    every position is a real, finite grid coordinate (the Simulator
 *    has no fixed min/max canvas bounds — it's an infinite pannable
 *    grid — so "within the valid workspace" is verified as "a real
 *    number the grid actually placed a component at", not against an
 *    invented box).
 *  - If arranging still leaves an overlap (e.g. no editor open, so
 *    `autoArrange()` was a no-op), that's reported with the exact
 *    reason rather than silently proceeding to wiring anyway.
 */
import type { CreatedComponentInstance } from './CircuitPlanExecutor';
import type { ICircuitTool } from './CircuitContextBuilder';
import type { ICircuitToolMutator } from './CircuitToolBridge';
import { circuitToolBridge } from './CircuitToolBridge';

export interface ArrangedComponentPosition {
  componentId: number;
  type: string;
  x: number;
  y: number;
}

export type ArrangeExecutionStatus = 'completed' | 'failed' | 'nothing_to_do';

export interface ArrangeExecutionResult {
  status: ArrangeExecutionStatus;
  moved: number;
  positions: ArrangedComponentPosition[];
  /** Non-empty only when independent verification found components
   *  still overlapping (or off-grid) after arranging — each with the
   *  exact pair/reason, never a generic "arrange failed". */
  issues: string[];
  message: string;
}

export interface IAutoArrangeExecutor {
  /** Arranges — and independently verifies — the real positions of
   *  `created` (the components `CircuitPlanExecutor` just made). */
  execute(created: CreatedComponentInstance[]): ArrangeExecutionResult;
}

export class AutoArrangeExecutor implements IAutoArrangeExecutor {
  private readonly tool: ICircuitTool & ICircuitToolMutator;

  constructor(tool: ICircuitTool & ICircuitToolMutator) {
    this.tool = tool;
  }

  execute(created: CreatedComponentInstance[]): ArrangeExecutionResult {
    if (created.length === 0) {
      return { status: 'nothing_to_do', moved: 0, positions: [], issues: [], message: 'No components to arrange.' };
    }

    const { moved } = this.tool.autoArrange();

    // Verification, not trust: re-read live component state after the
    // call and confirm what actually happened, the same discipline
    // WiringExecutor uses for wires.
    const createdIds = new Set(created.map((c) => c.componentId));
    const live = this.tool.getComponents().filter((c) => createdIds.has(c.id));

    const positions: ArrangedComponentPosition[] = live.map((c) => ({
      componentId: c.id,
      type: c.type,
      x: c.x ?? NaN,
      y: c.y ?? NaN,
    }));

    const issues: string[] = [];

    for (const p of positions) {
      if (!Number.isFinite(p.x) || !Number.isFinite(p.y)) {
        issues.push(`${p.type} #${p.componentId} has no valid position after arranging (x=${p.x}, y=${p.y}).`);
      }
    }

    for (let i = 0; i < positions.length; i++) {
      for (let j = i + 1; j < positions.length; j++) {
        const a = positions[i];
        const b = positions[j];
        if (a.x === b.x && a.y === b.y) {
          issues.push(`${a.type} #${a.componentId} and ${b.type} #${b.componentId} still occupy the same position (${a.x}, ${a.y}) after arranging.`);
        }
      }
    }

    const status: ArrangeExecutionStatus = issues.length === 0 ? 'completed' : 'failed';
    const message =
      issues.length === 0
        ? `Arranged and confirmed ${positions.length} component${positions.length === 1 ? '' : 's'} with no overlaps.`
        : `Arrange verification failed: ${issues.join(' ')}`;

    return { status, moved, positions, issues, message };
  }
}

/** Shared instance backed by `circuitToolBridge`, matching every other
 *  execution-stage singleton in this directory. */
export const autoArrangeExecutor = new AutoArrangeExecutor(circuitToolBridge);
