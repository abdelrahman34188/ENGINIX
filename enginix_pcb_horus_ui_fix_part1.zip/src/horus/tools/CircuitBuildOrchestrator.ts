/**
 * HORUS AI — Circuit Build Orchestrator (Tools) — Phase 4 (Auto Arrange).
 *
 * Runs a `CircuitPlan` end to end, three stages, each depending only
 * on what the previous one actually confirmed live (never on the
 * plan's stated intent):
 *  1. `CircuitPlanExecutor` (Phase 2, unmodified) creates and verifies
 *     every planned component.
 *  2. `AutoArrangeExecutor` (Phase 4) repositions exactly those
 *     created components into a non-overlapping layout and
 *     independently re-verifies their live positions — *before* any
 *     wiring, per the Phase 4 spec, so wires route between components
 *     that are actually visibly separated rather than stacked.
 *  3. `WiringExecutor` (Phase 3, unmodified) creates and verifies the
 *     planned connections between them.
 *
 * None of the three stages is changed by this file; it only sequences
 * them and reports their combined, live-confirmed outcome. Wiring
 * still runs even if arranging reports issues (e.g. no editor open) —
 * same principle as Phase 3's "wiring still runs after a partial
 * build": each stage reports its own exact failure rather than one
 * stage's trouble silently cancelling the next.
 */
import type { CircuitPlan } from '../core/Brain/CircuitPlanner';
import type { CircuitPlanExecutionResult, ICircuitPlanExecutor } from './CircuitPlanExecutor';
import { circuitPlanExecutor } from './CircuitPlanExecutor';
import type { IAutoArrangeExecutor, ArrangeExecutionResult } from './AutoArrangeExecutor';
import { autoArrangeExecutor } from './AutoArrangeExecutor';
import type { IWiringExecutor, WiringExecutionResult } from './WiringExecutor';
import { wiringExecutor } from './WiringExecutor';

export interface CircuitBuildResult {
  planExecution: CircuitPlanExecutionResult;
  arrangeExecution: ArrangeExecutionResult;
  wiringExecution: WiringExecutionResult;
  /** Combined, human-readable summary of all three stages' verified
   *  outcomes — built only from what each stage actually confirmed. */
  message: string;
}

export class CircuitBuildOrchestrator {
  constructor(
    private readonly planExecutor: ICircuitPlanExecutor,
    private readonly arrangeExecutor: IAutoArrangeExecutor,
    private readonly wireExecutor: IWiringExecutor
  ) {}

  build(plan: CircuitPlan): CircuitBuildResult {
    const planExecution = this.planExecutor.execute(plan);
    const arrangeExecution = this.arrangeExecutor.execute(planExecution.created);
    const wiringExecution = this.wireExecutor.execute(plan, planExecution.created);

    const parts = [planExecution.message];
    if (arrangeExecution.status !== 'nothing_to_do') parts.push(arrangeExecution.message);
    if (wiringExecution.status !== 'nothing_to_do') parts.push(wiringExecution.message);

    return { planExecution, arrangeExecution, wiringExecution, message: parts.join(' ').trim() };
  }
}

/** Shared instance wired to the same shared singletons every other
 *  execution-stage consumer in this directory already uses. */
export const circuitBuildOrchestrator = new CircuitBuildOrchestrator(
  circuitPlanExecutor,
  autoArrangeExecutor,
  wiringExecutor
);
