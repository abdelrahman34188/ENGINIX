/**
 * HORUS AI — Component Roles (Tools) — Phase 3 (Auto Wiring).
 *
 * Classifies a real `ComponentType` into the handful of electrical
 * roles `ConnectionPlanner` needs to synthesize a topology generically
 * — never per named scenario ("LED circuit", "traffic light"). Every
 * type/role pair here is either a direct read of `TerminalRoles`
 * (itself sourced from the simulator's own `defaultTerminals`) or, for
 * Arduino-family boards, resolved dynamically against the live
 * component's own terminals — nothing is invented.
 */
import type { ComponentType } from '../../circuit/types';

export type ComponentRole = 'powerSource' | 'controller' | 'passthrough' | 'load' | 'unknown';

const POWER_SOURCES = new Set<ComponentType>(['battery', 'dcCurrentSource']);
const CONTROLLERS = new Set<ComponentType>(['arduino', 'arduinoMega', 'arduinoNano']);
const PASSTHROUGH = new Set<ComponentType>([
  'resistor', 'capacitor', 'inductor', 'fuse', 'polyfuse', 'switch', 'pushButton', 'ammeter', 'bulb',
]);
const LOADS = new Set<ComponentType>([
  'led', 'diode', 'zenerDiode',
  'buzzer', 'activeBuzzer', 'passiveBuzzer',
  'dcMotor', 'waterPump', 'solenoidValve',
]);

export function roleOf(type: string): ComponentRole {
  const t = type as ComponentType;
  if (POWER_SOURCES.has(t)) return 'powerSource';
  if (CONTROLLERS.has(t)) return 'controller';
  if (PASSTHROUGH.has(t)) return 'passthrough';
  if (LOADS.has(t)) return 'load';
  return 'unknown';
}

export function isController(type: string): boolean {
  return CONTROLLERS.has(type as ComponentType);
}

/** For a power source: which terminal role feeds the rest of the
 *  circuit, and which is the return/GND side that closes the loop. */
export function powerSourceIo(type: string): { out: string; return: string } | null {
  if (!POWER_SOURCES.has(type as ComponentType)) return null;
  return { out: 'positive', return: 'negative' };
}

/** For a passthrough or load component: which terminal role is the
 *  "in" side (current enters here) and which is "out" (continues the
 *  chain). Non-polarized passthrough parts have no real electrical
 *  "direction", but the chain still needs two distinct terminal names
 *  to wire "the other side" of the part — `pin1`/`pin2` from
 *  `TerminalRoles` serve that purpose without claiming any polarity. */
export function inlineIo(type: string): { in: string; out: string } | null {
  const t = type as ComponentType;
  if (PASSTHROUGH.has(t)) return { in: 'pin1', out: 'pin2' };
  if (t === 'led' || t === 'diode' || t === 'zenerDiode') return { in: 'anode', out: 'cathode' };
  if (LOADS.has(t)) return { in: 'positive', out: 'negative' };
  return null;
}

/** Arduino-family board terminal-label prefixes/names this planner is
 *  willing to allocate — used only to pick candidate pin labels to
 *  *try*; whether a given label actually exists on the live board is
 *  always confirmed independently by `WiringExecutor` against the
 *  real component's terminals before any wire is attempted. */
export const ARDUINO_GND_LABEL = 'GND';

/** Candidate digital-pin labels in allocation order, skipping D0/D1
 *  (reserved for serial Rx/Tx on every AVR Arduino board, so wiring a
 *  load there would silently break USB programming/serial output).
 *  Deliberately generates more than any single board exposes —
 *  `WiringExecutor`'s live-terminal check is what actually bounds
 *  this per board, and reports the exact missing pin rather than this
 *  list ever being trusted as "valid for this board". */
export function candidateDigitalPinLabels(count: number): string[] {
  const labels: string[] = [];
  for (let i = 2; labels.length < count; i++) {
    labels.push(`D${i}`);
  }
  return labels;
}
