/**
 * HORUS AI — Circuit Context Builder (Tools).
 *
 * Responsible for reading the current circuit state from `CircuitTool`
 * (see `core/Tools/ToolRegistry.ts`'s `'CircuitTool'` entry) and
 * returning it as a single, structured JSON object: components, wires,
 * and the currently selected component. Nothing else.
 *
 * Deliberately narrow, matching every other module at this stage:
 *  - No analysis. This builder does not interpret, summarize, validate,
 *    or reason about the circuit — it only reshapes whatever
 *    `CircuitTool` reports into one snapshot object.
 *  - No AI. Never touches `AIGateway`, a provider, or any prompt.
 *  - No fixing. Never mutates the circuit, `CircuitTool`, or anything
 *    it reads.
 *  - No direct dependency on `src/circuit`. Like every context provider
 *    under `horus/context/providers/`, this builder only knows the
 *    `ICircuitTool` read contract below — not the Simulator/Circuit
 *    Editor's internals — so `src/circuit` stays untouched and
 *    `CircuitTool`'s eventual real implementation is free to source
 *    that data however it needs to.
 *
 * Interface + skeleton only — `CircuitTool` itself is still just a
 * placeholder name in `ToolRegistry` (no implementation exists yet), so
 * `build()` has nothing real to read from until a concrete
 * `ICircuitTool` is wired in.
 */

/** A single component as CircuitTool currently reports it.
 *
 *  `x`/`y`/`color`/`value` are optional, best-effort read-only fields
 *  added for `SmartComponentResolver` to disambiguate natural-language
 *  references ("the LED on the right", "the green LED", "the 220Ω
 *  resistor") against real component data — never guessed, never
 *  mutated. All four are omitted (`undefined`) when the underlying
 *  `ICircuitTool` implementation has nothing to report (e.g. the
 *  placeholder `EmptyCircuitTool`, or a component type with no
 *  matching property):
 *   - `x`/`y`: the component's grid position, for "on the right/left/
 *     top/bottom" references.
 *   - `color`: the component's own `color` property, read back as the
 *     human label of whichever option is selected (e.g. "Red"), only
 *     for component types that actually define one (e.g. `led`,
 *     `rgbLed`) — never inferred for types without it.
 *   - `value`: the component's primary editable property, formatted
 *     with its unit (e.g. "220Ω", "9V") — the same "first property in
 *     `defaultProperties[type]`" convention `EditApplier` already uses
 *     for `change_value`/`replace`. */
export interface CircuitToolComponent {
  id: number;
  type: string;
  label: string;
  x?: number;
  y?: number;
  color?: string;
  value?: string;
}

/** A single wire as CircuitTool currently reports it. */
export interface CircuitToolWire {
  id: number;
  fromComponentId: number;
  toComponentId: number;
}

/** The currently selected component, or null if nothing is selected. */
export type CircuitToolSelectedComponent = CircuitToolComponent | null;

/**
 * Read-only contract `CircuitContextBuilder` depends on. `CircuitTool`
 * (registered by name in `ToolRegistry`) is expected to satisfy this
 * once implemented — this builder never reaches past it.
 */
export interface ICircuitTool {
  getComponents(): CircuitToolComponent[];
  getWires(): CircuitToolWire[];
  getSelectedComponent(): CircuitToolSelectedComponent;
  /** The *real*, unformatted `props` map for one component (e.g.
   *  `{ resistance: 220 }`, `{ color: '#00ff00', forwardVoltage: 2 }`),
   *  read straight off the live component — never a guessed/derived
   *  shape. Null when the component doesn't exist (or no editor is
   *  registered). Optional so pre-existing `ICircuitTool`
   *  implementations (e.g. a test double, `EmptyCircuitTool`) don't
   *  need to grow it just to keep compiling; `PropertyEngine` is the
   *  one real caller, and it requires an implementation because this
   *  is exactly the read-back it uses to verify a write actually
   *  landed, instead of trusting a mutator's boolean return alone. */
  getComponentProperties?(componentId: number): Record<string, number | string | boolean> | null;
  /** Terminal labels available on a component (e.g. `['A', 'K']` for an
   *  LED), in the same order the component defines them. Empty array
   *  when the component doesn't exist or has no terminals. Used by
   *  connection-resolving callers (e.g. `EditApplier`) to turn a named
   *  pin ("anode") into the real label `connectComponents` needs —
   *  never used to mutate anything. */
  getComponentTerminalLabels(componentId: number): string[];
}

/** The single JSON object `build()` returns — structured data only. */
export interface CircuitContextSnapshot {
  components: CircuitToolComponent[];
  wires: CircuitToolWire[];
  selectedComponent: CircuitToolSelectedComponent;
}

export interface ICircuitContextBuilder {
  /** Read CircuitTool's current state and return it as one JSON object. */
  build(): CircuitContextSnapshot;
}

export class CircuitContextBuilder implements ICircuitContextBuilder {
  private readonly circuitTool: ICircuitTool;

  constructor(circuitTool: ICircuitTool) {
    this.circuitTool = circuitTool;
  }

  build(): CircuitContextSnapshot {
    return {
      components: this.circuitTool.getComponents(),
      wires: this.circuitTool.getWires(),
      selectedComponent: this.circuitTool.getSelectedComponent(),
    };
  }
}

/**
 * Placeholder `ICircuitTool` returning an always-empty circuit — used
 * wherever the runtime needs *a* `CircuitTool` to read from before a
 * real implementation exists (`CircuitTool` is still just a name in
 * `ToolRegistry`). Swapping this for the real thing later is a one-line
 * change at the call site; `CircuitContextBuilder` itself never changes.
 */
export class EmptyCircuitTool implements ICircuitTool {
  getComponents(): CircuitToolComponent[] {
    return [];
  }

  getWires(): CircuitToolWire[] {
    return [];
  }

  getSelectedComponent(): CircuitToolSelectedComponent {
    return null;
  }

  getComponentTerminalLabels(): string[] {
    return [];
  }
}
