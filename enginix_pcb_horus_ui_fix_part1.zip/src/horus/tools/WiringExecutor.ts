/**
 * HORUS AI — Wiring Executor (Tools) — Phase 3 (Auto Wiring).
 *
 * Executes a `CircuitPlan.plannedConnections` (Phase 1's
 * `CircuitPlanner`, extended) against the real simulator, resolving
 * each planned, role-based endpoint ("battery positive", "LED anode")
 * to the real component id `CircuitPlanExecutor` (Phase 2) just
 * created and verified, and the real terminal label that role means
 * for that component's type (`TerminalRoles`) — then creates the wire
 * through the exact same mutation path every other tool uses
 * (`CircuitToolBridge`'s `ICircuitToolMutator.connectComponents`).
 *
 * Scope, per the Phase 3 spec:
 *  - Reads `plan.plannedConnections` (never re-derives connections
 *    from `circuitRequirements` prose or invents a topology of its
 *    own) and needs `CircuitPlanExecutor`'s already-verified `created`
 *    list to know which real component id/instance each planned
 *    component became.
 *  - Resolves names to ids: an endpoint is looked up by
 *    (`componentType`, `instanceIndex`) against `created`, in the
 *    exact order those instances were created — never by guessing
 *    which instance was meant.
 *  - Resolves terminals automatically via `TerminalRoles`, restricted
 *    to that component's own real, live terminal labels
 *    (`tool.getComponentTerminalLabels`) — never assumes a label
 *    exists just because the role table has an entry for the type.
 *  - Never assumes a connection succeeded: `connectComponents`'s
 *    return value alone is not the verification. After every attempt
 *    (success or not), this reads `tool.getWires()` back and only
 *    counts a connection as made when a wire between those exact two
 *    components is actually present there.
 *  - Reports, never invents: a missing component instance, an
 *    unresolvable role, or a terminal absent from the live component
 *    all become a specific `FailedConnection`/`UnavailableConnection`
 *    entry with the exact reason — nothing is silently skipped or
 *    substituted.
 *  - Does not touch component values/colors/properties (that's
 *    `CircuitPlanExecutor`'s job, already done before this runs), and
 *    does not re-plan, optimize, or remember anything across calls.
 */
import type { CircuitPlan, PlannedConnection, PlannedConnectionEndpoint } from '../core/Brain/CircuitPlanner';
import type { CreatedComponentInstance } from './CircuitPlanExecutor';
import type { ICircuitTool } from './CircuitContextBuilder';
import type { ICircuitToolMutator } from './CircuitToolBridge';
import { circuitToolBridge } from './CircuitToolBridge';
import { resolveTerminalLabel, hasKnownRoles } from './TerminalRoles';

/** One connection actually created *and* independently confirmed
 *  present in the live simulator's wire list. */
export interface ConnectedWireInstance {
  wireId: number;
  fromComponentId: number;
  fromTerminal: string;
  toComponentId: number;
  toTerminal: string;
  description: string;
}

/** One planned connection this executor could not make — the exact,
 *  specific reason, never a generic "failed". */
export interface FailedConnection {
  description: string;
  reason: string;
}

export type WiringExecutionStatus = 'completed' | 'partial' | 'failed' | 'nothing_to_do';

export interface WiringExecutionResult {
  status: WiringExecutionStatus;
  /** Every wire actually created *and* confirmed present in the live
   *  simulator — never a claim based on the plan or a mutator's
   *  return value alone. */
  connected: ConnectedWireInstance[];
  /** Planned connections attempted but the simulator/terminal
   *  resolution refused, each with its exact reason. */
  failed: FailedConnection[];
  message: string;
}

export interface IWiringExecutor {
  /** Executes `plan.plannedConnections` against the live simulator,
   *  using `created` (from `CircuitPlanExecutor.execute(plan)`) to
   *  resolve each endpoint's real component id. */
  execute(plan: CircuitPlan, created: CreatedComponentInstance[]): WiringExecutionResult;
}

export class WiringExecutor implements IWiringExecutor {
  private readonly tool: ICircuitTool & ICircuitToolMutator;

  constructor(tool: ICircuitTool & ICircuitToolMutator) {
    this.tool = tool;
  }

  execute(plan: CircuitPlan, created: CreatedComponentInstance[]): WiringExecutionResult {
    if (plan.plannedConnections.length === 0) {
      return {
        status: 'nothing_to_do',
        connected: [],
        failed: [],
        message: 'No planned connections for this circuit yet.',
      };
    }

    // Real instances actually created, grouped by type, in creation
    // order — this is what `instanceIndex` on a planned endpoint
    // indexes into. Never re-reads the plan's *requested* quantity;
    // if fewer were created than planned (a Phase 2 failure), later
    // instanceIndex lookups simply come back missing and are reported
    // as such, not padded.
    const byType = new Map<string, CreatedComponentInstance[]>();
    for (const instance of created) {
      const list = byType.get(instance.type) ?? [];
      list.push(instance);
      byType.set(instance.type, list);
    }

    const connected: ConnectedWireInstance[] = [];
    const failed: FailedConnection[] = [];

    for (const planned of plan.plannedConnections) {
      const outcome = this.connectAndVerify(planned, byType);
      if (outcome.ok) {
        connected.push(outcome.wire);
      } else {
        failed.push({ description: planned.description, reason: outcome.reason });
      }
    }

    const status: WiringExecutionStatus =
      failed.length === 0 ? 'completed' : connected.length > 0 ? 'partial' : 'failed';

    return { status, connected, failed, message: this.buildMessage(connected, failed) };
  }

  private connectAndVerify(
    planned: PlannedConnection,
    byType: Map<string, CreatedComponentInstance[]>
  ): { ok: true; wire: ConnectedWireInstance } | { ok: false; reason: string } {
    const from = this.resolveEndpoint(planned.from, byType);
    if (!from.ok) return { ok: false, reason: `${planned.description} — ${from.reason}` };

    const to = this.resolveEndpoint(planned.to, byType);
    if (!to.ok) return { ok: false, reason: `${planned.description} — ${to.reason}` };

    const wire = this.tool.connectComponents(
      from.componentId,
      from.terminalLabel,
      to.componentId,
      to.terminalLabel
    );
    if (!wire) {
      return {
        ok: false,
        reason: `${planned.description} — the simulator did not create the wire (already connected, or the connection was refused).`,
      };
    }

    // Verification, not trust: `connectComponents` already checks
    // this internally before returning, but this executor never
    // reports success off a mutator's return value alone — it reads
    // live wire state back independently, same discipline
    // `CircuitPlanExecutor` uses for component creation.
    const stillWired = this.tool
      .getWires()
      .some(
        (w) =>
          w.id === wire.id &&
          ((w.fromComponentId === from.componentId && w.toComponentId === to.componentId) ||
            (w.fromComponentId === to.componentId && w.toComponentId === from.componentId))
      );
    if (!stillWired) {
      return {
        ok: false,
        reason: `${planned.description} — wire reported created but not found in the simulator's live wire list.`,
      };
    }

    return {
      ok: true,
      wire: {
        wireId: wire.id,
        fromComponentId: from.componentId,
        fromTerminal: from.terminalLabel,
        toComponentId: to.componentId,
        toTerminal: to.terminalLabel,
        description: planned.description,
      },
    };
  }

  private resolveEndpoint(
    endpoint: PlannedConnectionEndpoint,
    byType: Map<string, CreatedComponentInstance[]>
  ): { ok: true; componentId: number; terminalLabel: string } | { ok: false; reason: string } {
    const instances = byType.get(endpoint.componentType) ?? [];
    const instance = instances[endpoint.instanceIndex];
    if (!instance) {
      return {
        ok: false,
        reason: `${endpoint.componentType} #${endpoint.instanceIndex + 1} was never created, so it can't be wired.`,
      };
    }

    if (!hasKnownRoles(endpoint.componentType)) {
      return {
        ok: false,
        reason: `No known terminal roles for component type "${endpoint.componentType}".`,
      };
    }

    const terminalLabel = resolveTerminalLabel(endpoint.componentType, endpoint.role);
    if (!terminalLabel) {
      return {
        ok: false,
        reason: `"${endpoint.role}" is not a known terminal role on ${instance.name}.`,
      };
    }

    // Final check against the *live* component, not just the role
    // table — a role table entry alone is never treated as proof the
    // terminal actually exists on this real instance.
    const liveLabels = this.tool.getComponentTerminalLabels(instance.componentId);
    if (!liveLabels.includes(terminalLabel)) {
      return {
        ok: false,
        reason: `${instance.name} has no live terminal labeled "${terminalLabel}" for role "${endpoint.role}".`,
      };
    }

    return { ok: true, componentId: instance.componentId, terminalLabel };
  }

  private buildMessage(connected: ConnectedWireInstance[], failed: FailedConnection[]): string {
    const parts: string[] = [];
    if (connected.length > 0) {
      parts.push(`Wired and confirmed in the simulator: ${connected.length} connection${connected.length === 1 ? '' : 's'}.`);
    }
    if (failed.length > 0) {
      parts.push(`Could not wire: ${failed.map((f) => f.reason).join(' ')}`);
    }
    if (parts.length === 0) {
      parts.push('No connections to make.');
    }
    return parts.join(' ');
  }
}

/** Shared instance backed by `circuitToolBridge`, matching every other
 *  execution-stage singleton in this directory. */
export const wiringExecutor = new WiringExecutor(circuitToolBridge);
