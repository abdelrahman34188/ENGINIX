/**
 * HORUS AI — Tool Manager.
 *
 * Responsible (once implemented) for registering callable tools/functions
 * HORUS can invoke (e.g. "place a component", "run simulation") and
 * dispatching provider-requested tool calls to them. Tools are registered
 * here, not hardcoded into AI Core, so new capabilities can be added
 * without modifying the core orchestration (Open/Closed Principle).
 *
 * Interface + skeleton only — no logic implemented yet.
 */

export interface HorusToolDefinition {
  name: string;
  description: string;
  /** JSON-schema-shaped parameter description; kept opaque at this stage. */
  parameters: unknown;
}

export interface HorusToolInvocation {
  toolName: string;
  arguments: unknown;
}

export interface HorusToolResult {
  toolName: string;
  ok: boolean;
  output: unknown;
}

export interface IToolManager {
  /** Register a tool so it becomes available for HORUS to call. */
  registerTool(definition: HorusToolDefinition, handler: (invocation: HorusToolInvocation) => Promise<HorusToolResult>): void;

  /** List all currently registered tool definitions. */
  listTools(): HorusToolDefinition[];

  /** Execute a registered tool by name. */
  invokeTool(invocation: HorusToolInvocation): Promise<HorusToolResult>;
}

export class ToolManager implements IToolManager {
  registerTool(
    _definition: HorusToolDefinition,
    _handler: (invocation: HorusToolInvocation) => Promise<HorusToolResult>
  ): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  listTools(): HorusToolDefinition[] {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  invokeTool(_invocation: HorusToolInvocation): Promise<HorusToolResult> {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
