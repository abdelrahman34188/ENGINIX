/**
 * HORUS AI — Smart Component Resolver (Tools).
 *
 * Sits between `EditValidator` and `EditExecutor` in the edit pipeline:
 *
 *   HORUS request -> CircuitEditPlanner -> EditValidator ->
 *     SmartComponentResolver -> EditExecutor -> CircuitToolBridge
 *
 * Two jobs, both read-only against data `CircuitContextBuilder`/
 * `CircuitToolBridge` already report — this module never calls a
 * mutator, never touches `CircuitEditor`, and never invents a
 * component id or a component type the simulator doesn't actually
 * support:
 *
 *  - `resolve()` — disambiguates a reference to an *existing*
 *    component ("the LED", "the green LED", "the resistor on the
 *    right", "the last LED I added"). `EditValidator`'s own
 *    `resolveComponent()` (`EditValidator.ts`) already checks that
 *    *some* component matches a plan's target text, but just takes the
 *    first match. This re-checks the same reference and, when more
 *    than one real component could be meant, first tries to narrow
 *    using whatever real data is available (color, primary value,
 *    grid position, recency) and only reports `ambiguous` — asking the
 *    user rather than guessing — when that still leaves more than one.
 *  - `resolveComponentType()` — for requests that name a component
 *    *type* to add rather than an existing instance (e.g. "add a
 *    lamp"). Maps common aliases/synonyms ("light", "lamp", "knob", …)
 *    onto the simulator's real, supported `ComponentType`s (the same
 *    catalog `EditApplier`'s `KNOWN_COMPONENT_TYPES` is built from) and
 *    reports `unavailable` — never a guessed/invented type — when
 *    nothing in that catalog matches.
 *
 * Scope, deliberately narrow, matching every other module at this
 * pipeline stage:
 *  - No new component data beyond what `CircuitToolComponent` already
 *    carries (`id`, `type`, `label`, and the optional best-effort
 *    `x`/`y`/`color`/`value` `CircuitToolBridge` now populates from the
 *    real component's own props/schema) — a qualifier this module
 *    can't verify against real data is simply left unable to narrow
 *    anything, never guessed.
 *  - No mutation, no AI call, no UI.
 *  - `EditExecutor`/`EditApplier` are untouched — this module only
 *    changes what `runtime.ts` decides to hand them.
 */

import type { CircuitToolComponent } from './CircuitContextBuilder';
import { defaultProperties, componentNames } from '../../circuit/componentDefs';

export type SmartResolutionStatus = 'resolved' | 'ambiguous' | 'not_found' | 'unavailable';

export interface SmartResolutionResult {
  status: SmartResolutionStatus;
  /** The single matching component, only when `status === 'resolved'`. */
  component: CircuitToolComponent | null;
  /** Every component that could plausibly be meant. Empty for
   *  `not_found`/`unavailable`; one element for `resolved`; two or
   *  more for `ambiguous`. */
  candidates: CircuitToolComponent[];
  /** User-facing text: the clarifying question for `ambiguous`, or the
   *  fixed "not available" notice for `unavailable`. Null for
   *  `resolved`/`not_found` (those get a plain, existing message from
   *  whichever caller already handles that case, e.g. `EditValidator`). */
  message: string | null;
}

export type TypeResolutionStatus = 'resolved' | 'ambiguous' | 'unavailable';

export interface SmartTypeResolutionResult {
  status: TypeResolutionStatus;
  /** The single supported `ComponentType`, only when `status ===
   *  'resolved'`. */
  type: string | null;
  /** Every supported type the phrase could plausibly mean — one
   *  element for `resolved`, two or more for `ambiguous`, empty for
   *  `unavailable`. */
  candidateTypes: string[];
  message: string | null;
}

/** The fixed notice required whenever a requested component type has
 *  no real match in the simulator's catalog — never a guess, never a
 *  partial/best-effort type substituted in its place. */
export const COMPONENT_UNAVAILABLE_MESSAGE = 'This component is not available in the current simulator.';

/** Every real, supported `ComponentType` — built the same way
 *  `EditApplier`'s own `KNOWN_COMPONENT_TYPES` is (straight from
 *  `defaultProperties`'s keys), so this never drifts out of sync with
 *  what the simulator can actually place. */
const KNOWN_COMPONENT_TYPES = new Set(Object.keys(defaultProperties));

/** Lowercases and collapses `s` down to space-separated alphanumeric
 *  tokens (e.g. "MQ-2 Gas Sensor" -> "mq 2 gas sensor"), so a display
 *  name and a free-typed phrase can be compared word-for-word
 *  regardless of punctuation/casing differences. */
function normalizeName(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

/** True when `needle` appears in `haystack` as a contiguous run of
 *  whole words (not just a raw substring) — both must already be
 *  `normalizeName()`d. */
function tokenPhraseIncludes(haystack: string, needle: string): boolean {
  if (!needle) return false;
  return ` ${haystack} `.includes(` ${needle} `);
}

/** Every real, supported `ComponentType` -> its normalized display
 *  name, straight from `componentNames` (`componentDefs.ts`) — the
 *  simulator's own catalog of human-readable part names (\"IR Obstacle
 *  Sensor\", \"MQ-2 Gas Sensor\", ...), so a natural name resolves to a
 *  real type without needing a hand-maintained alias entry for every
 *  part. Filtered against `KNOWN_COMPONENT_TYPES` for the same reason
 *  every other lookup here is: never offer a type that isn't (or is no
 *  longer) actually placeable. */
const TYPE_NAMES_NORMALIZED: ReadonlyMap<string, string> = new Map(
  Object.entries(componentNames)
    .filter(([type]) => KNOWN_COMPONENT_TYPES.has(type))
    .map(([type, name]) => [type, normalizeName(name)] as const),
);

/** Alias-expands `lower` against the simulator's own display names
 *  (rather than the hand-curated `TYPE_ALIASES` map) — a whole-word
 *  match either direction: the phrase typed is (part of) the real
 *  name (\"gas sensor\" -> \"MQ-2 Gas Sensor\"), or the real name is
 *  (part of) the phrase typed (\"green led\" -> \"LED\"). This is what
 *  lets every component the simulator can create be found by its own
 *  real name, not just the ones someone thought to add a colloquial
 *  alias for. */
function nameTypeHints(lower: string): string[] {
  const normLower = normalizeName(lower);
  const hints: string[] = [];
  for (const [type, normName] of TYPE_NAMES_NORMALIZED) {
    if (
      normName === normLower ||
      tokenPhraseIncludes(normName, normLower) ||
      tokenPhraseIncludes(normLower, normName)
    ) {
      hints.push(type);
    }
  }
  return hints;
}

/**
 * Common colloquial words/phrases -> the real `ComponentType`(s) they
 * could mean, most-likely-first. Every value here is checked against
 * `KNOWN_COMPONENT_TYPES` before ever being offered as a match — an
 * alias whose target isn't (or is no longer) part of the catalog is
 * simply dropped, never surfaced. Not exhaustive by design: an
 * unrecognized word just falls through to `unavailable` rather than a
 * wrong guess.
 */
const TYPE_ALIASES: Readonly<Record<string, readonly string[]>> = {
  light: ['led', 'bulb'],
  lamp: ['bulb'],
  bulb: ['bulb'],
  led: ['led'],
  'rgb light': ['rgbLed'],
  'rgb led': ['rgbLed'],
  pot: ['potentiometer'],
  potmeter: ['potentiometer'],
  'pot meter': ['potentiometer'],
  knob: ['potentiometer'],
  dial: ['potentiometer'],
  button: ['pushButton'],
  'push button': ['pushButton'],
  switch: ['switch'],
  battery: ['battery'],
  cell: ['battery'],
  'power source': ['battery'],
  'voltage source': ['battery'],
  resistor: ['resistor'],
  res: ['resistor'],
  cap: ['capacitor'],
  capacitor: ['capacitor'],
  coil: ['inductor'],
  inductor: ['inductor'],
  transistor: ['transistorNpn', 'transistorPnp'],
  npn: ['transistorNpn'],
  pnp: ['transistorPnp'],
  mosfet: ['irf520', 'irf540', 'irlz44n'],
  motor: ['dcMotor'],
  'dc motor': ['dcMotor'],
  servo: ['servoMotor'],
  stepper: ['stepperMotor'],
  pump: ['waterPump'],
  buzzer: ['buzzer', 'activeBuzzer', 'passiveBuzzer'],
  speaker: ['buzzer', 'passiveBuzzer'],
  screen: ['lcd16x2', 'oledSsd1306'],
  display: ['lcd16x2', 'oledSsd1306', 'sevenSegment', 'sevenSegment4'],
  relay: ['relay', 'relayModule'],
  fuse: ['fuse'],
  diode: ['diode'],
  zener: ['zenerDiode'],
  ground: ['ground'],
  gnd: ['ground'],
  voltmeter: ['voltmeter'],
  ammeter: ['ammeter'],
  wifi: ['esp8266', 'esp32'],
  'wifi module': ['esp8266', 'esp32'],
  bluetooth: ['hc05', 'hc06'],
};

const COLOR_WORDS = ['red', 'green', 'blue', 'yellow', 'white', 'black', 'orange', 'purple'];
const RIGHT_WORDS = ['right'];
const LEFT_WORDS = ['left'];
const TOP_WORDS = ['top', 'upper'];
const BOTTOM_WORDS = ['bottom', 'lower'];

function containsWord(lower: string, words: readonly string[]): boolean {
  return words.some((w) => new RegExp(`\\b${w}\\b`).test(lower));
}

/** True when `text` names `component` — same loose rule
 *  `EditValidator.resolveComponent()` uses (exact or substring, either
 *  direction, against label or type) — but used here to *collect
 *  every* match rather than stop at the first. */
function matchesText(component: CircuitToolComponent, lower: string): boolean {
  const label = component.label.toLowerCase();
  const type = component.type.toLowerCase();
  return (
    label === lower ||
    type === lower ||
    label.includes(lower) ||
    lower.includes(label) ||
    type.includes(lower) ||
    lower.includes(type)
  );
}

/** Matches "last/latest/most recent/newest <type> [I added/placed]",
 *  e.g. "the last LED I added" (the planner already strips the leading
 *  "the"). Returns the bare type phrase ("led") or null if `raw`
 *  doesn't read as a recency reference. */
function parseRecencyReference(lower: string): string | null {
  const match = lower.match(
    /^(?:last|latest|most recent|newest)\s+(.+?)(?:\s+(?:i|we|you)\s+(?:added|placed|put in|inserted)|\s+added|\s+placed)?$/,
  );
  return match ? match[1].trim() : null;
}

/** Alias-expands `lower` into every real, supported `ComponentType` it
 *  could plausibly refer to: a direct type/alias hit, or (for
 *  multi-word phrases) an alias found as a whole word inside `lower`.
 *  Always filtered against `KNOWN_COMPONENT_TYPES` — an alias entry
 *  that isn't currently a real type is silently skipped rather than
 *  offered. */
function aliasTypeHints(lower: string): string[] {
  const hints = new Set<string>();
  if (KNOWN_COMPONENT_TYPES.has(lower)) hints.add(lower);

  for (const [alias, types] of Object.entries(TYPE_ALIASES)) {
    const hit = alias.includes(' ') ? lower.includes(alias) : containsWord(lower, [alias]);
    if (!hit) continue;
    for (const type of types) {
      if (KNOWN_COMPONENT_TYPES.has(type)) hints.add(type);
    }
  }

  // The simulator's own real display names — this is what discovers
  // components like "IR Obstacle Sensor" / "Flame Sensor" / "Gas
  // Sensor" that have no hand-written alias above, without ever
  // hardcoding those (or any other) individual component types here.
  for (const type of nameTypeHints(lower)) hints.add(type);

  return Array.from(hints);
}

/** Given the free-typed phrase that named a component *type* to add
 *  (e.g. \"Green LED\") and the real `type` it was resolved to (e.g.
 *  `led`), returns whatever's left over once the words that actually
 *  named the type are removed (e.g. \"green\") — or null when nothing's
 *  left (the phrase was just the type's own name/alias, no extra
 *  qualifier). Purely textual; this never checks the leftover against
 *  a real property itself — that's `EditApplier`'s job, against the
 *  type's own real `defaultProperties`, so an unsupported qualifier is
 *  reported clearly rather than silently dropped or guessed at. */
export function extractPropertyQualifier(raw: string, type: string): string | null {
  const normInput = normalizeName(raw);
  if (!normInput) return null;

  const tokens = normInput.split(' ');
  const nameTokens = (TYPE_NAMES_NORMALIZED.get(type) ?? normalizeName(type)).split(' ');
  for (const tok of nameTokens) {
    const idx = tokens.indexOf(tok);
    if (idx !== -1) tokens.splice(idx, 1);
  }

  // Also strip single-word colloquial aliases for this type (e.g.
  // "knob" for potentiometer) so e.g. "Add a knob" doesn't leave
  // "knob" behind as a bogus, unmatchable qualifier.
  for (const [alias, types] of Object.entries(TYPE_ALIASES)) {
    if (alias.includes(' ') || !types.includes(type)) continue;
    const idx = tokens.indexOf(alias);
    if (idx !== -1) tokens.splice(idx, 1);
  }

  const leftover = tokens.join(' ').trim();
  return leftover.length > 0 ? leftover : null;
}

/** Parses a leading "<number>" off a value phrase like "220 ohm
 *  resistor" or "220Ω", to compare against a candidate's own `value`
 *  field (e.g. "220Ω"). Returns null when no leading number is
 *  present. */
function leadingNumber(lower: string): string | null {
  const match = lower.match(/^([\d.]+)/);
  return match ? match[1] : null;
}

/** Narrows `candidates` by a color word present in `lower`, only when
 *  doing so actually leaves a smaller, non-empty set — an unmatched or
 *  unrecognized color word never empties the candidate list outright,
 *  since that would turn "narrow, please" into "give up". */
function narrowByColor(candidates: CircuitToolComponent[], lower: string): CircuitToolComponent[] {
  const colorWord = COLOR_WORDS.find((c) => containsWord(lower, [c]));
  if (!colorWord) return candidates;
  const narrowed = candidates.filter((c) => c.color?.toLowerCase() === colorWord);
  return narrowed.length > 0 ? narrowed : candidates;
}

/** Narrows `candidates` by a leading numeric value in `lower` (e.g.
 *  "220" in "the 220 ohm resistor") against each candidate's own
 *  `value` field. */
function narrowByValue(candidates: CircuitToolComponent[], lower: string): CircuitToolComponent[] {
  const num = leadingNumber(lower);
  if (!num) return candidates;
  const narrowed = candidates.filter((c) => c.value?.startsWith(num));
  return narrowed.length > 0 ? narrowed : candidates;
}

/** Narrows `candidates` by a left/right/top/bottom reference in
 *  `lower`, picking whichever candidate is furthest in that direction
 *  — only when `x`/`y` is actually known for every candidate and the
 *  extremum is unique (a tie stays ambiguous rather than picking
 *  arbitrarily). */
function narrowByPosition(candidates: CircuitToolComponent[], lower: string): CircuitToolComponent[] {
  const withPos = candidates.filter((c) => c.x !== undefined && c.y !== undefined);
  if (withPos.length !== candidates.length || withPos.length === 0) return candidates;

  let axis: 'x' | 'y' | null = null;
  let pickMax = true;
  if (containsWord(lower, RIGHT_WORDS)) {
    axis = 'x';
    pickMax = true;
  } else if (containsWord(lower, LEFT_WORDS)) {
    axis = 'x';
    pickMax = false;
  } else if (containsWord(lower, BOTTOM_WORDS)) {
    axis = 'y';
    pickMax = true;
  } else if (containsWord(lower, TOP_WORDS)) {
    axis = 'y';
    pickMax = false;
  }
  if (!axis) return candidates;

  const values = withPos.map((c) => (axis === 'x' ? c.x! : c.y!));
  const extremum = pickMax ? Math.max(...values) : Math.min(...values);
  const winners = withPos.filter((c) => (axis === 'x' ? c.x : c.y) === extremum);
  return winners.length === 1 ? winners : candidates;
}

function ambiguousResult(raw: string, candidates: CircuitToolComponent[]): SmartResolutionResult {
  const names = candidates.map((c) => c.label).join(', ');
  return {
    status: 'ambiguous',
    component: null,
    candidates,
    message: `Which one did you mean by "${raw}" — ${names}?`,
  };
}

function resolvedResult(component: CircuitToolComponent): SmartResolutionResult {
  return { status: 'resolved', component, candidates: [component], message: null };
}

const NOT_FOUND: SmartResolutionResult = { status: 'not_found', component: null, candidates: [], message: null };
const UNAVAILABLE: SmartResolutionResult = {
  status: 'unavailable',
  component: null,
  candidates: [],
  message: COMPONENT_UNAVAILABLE_MESSAGE,
};

export interface ISmartComponentResolver {
  /** Resolve one natural-language reference to an *existing*
   *  component (e.g. "the LED", "the green LED", "the last LED I
   *  added") against the current component list. Read-only. */
  resolve(raw: string, components: readonly CircuitToolComponent[]): SmartResolutionResult;

  /** Resolve a component *type* phrase (e.g. "lamp", "a resistor") to
   *  the real `ComponentType`(s) it names, for requests that add a new
   *  component rather than reference an existing one. Read-only —
   *  never touches the circuit; just checks the phrase against the
   *  simulator's own catalog. */
  resolveComponentType(raw: string): SmartTypeResolutionResult;

  /** Leftover qualifier text once `type`'s own name/alias words are
   *  stripped out of `raw` (see `extractPropertyQualifier()` above) —
   *  null when there's nothing left over. Read-only text processing,
   *  same as `resolveComponentType`. */
  extractQualifier(raw: string, type: string): string | null;
}

class SmartComponentResolver implements ISmartComponentResolver {
  resolve(raw: string, components: readonly CircuitToolComponent[]): SmartResolutionResult {
    const trimmed = raw.trim();
    if (trimmed.length === 0 || components.length === 0) return NOT_FOUND;
    const lower = trimmed.toLowerCase();

    // Numeric id / exact label — both unique identifiers, never
    // ambiguous once they match.
    if (/^\d+$/.test(trimmed)) {
      const byId = components.find((c) => c.id === Number(trimmed));
      return byId ? resolvedResult(byId) : NOT_FOUND;
    }
    const byLabel = components.find((c) => c.label.toLowerCase() === lower);
    if (byLabel) return resolvedResult(byLabel);

    // "the last LED I added" — recency against the component list's
    // own (append) order, alias-aware so "the last light I added"
    // also works.
    const recencyPhrase = parseRecencyReference(lower);
    if (recencyPhrase) {
      const hints = aliasTypeHints(recencyPhrase);
      const recencyCandidates = components.filter(
        (c) => matchesText(c, recencyPhrase) || hints.includes(c.type),
      );
      if (recencyCandidates.length === 0) return NOT_FOUND;
      return resolvedResult(recencyCandidates[recencyCandidates.length - 1]);
    }

    // General case: collect every component the reference could
    // plausibly mean — direct label/type matching, broadened by any
    // alias hints ("light"/"lamp" -> led/bulb) so a synonym matches
    // components a literal substring check would miss.
    const hints = aliasTypeHints(lower);
    let candidates = components.filter((c) => matchesText(c, lower) || hints.includes(c.type));

    if (candidates.length === 0) {
      // Nothing on the circuit matches — but is this even a type the
      // simulator supports? If not, that's a clearer answer than a
      // generic "not found".
      const supported = hints.length > 0 || KNOWN_COMPONENT_TYPES.has(lower);
      return supported ? NOT_FOUND : UNAVAILABLE;
    }
    if (candidates.length === 1) return resolvedResult(candidates[0]);

    // More than one real match — try to narrow using whatever real
    // data (color, value, position) the reference itself carries,
    // before falling back to asking.
    candidates = narrowByColor(candidates, lower);
    candidates = narrowByValue(candidates, lower);
    candidates = narrowByPosition(candidates, lower);

    return candidates.length === 1 ? resolvedResult(candidates[0]) : ambiguousResult(trimmed, candidates);
  }

  resolveComponentType(raw: string): SmartTypeResolutionResult {
    const trimmed = raw.trim();
    if (trimmed.length === 0) {
      return { status: 'unavailable', type: null, candidateTypes: [], message: COMPONENT_UNAVAILABLE_MESSAGE };
    }
    const lower = trimmed.toLowerCase();
    const hints = aliasTypeHints(lower);

    if (hints.length === 0) {
      return { status: 'unavailable', type: null, candidateTypes: [], message: COMPONENT_UNAVAILABLE_MESSAGE };
    }
    if (hints.length === 1) {
      return { status: 'resolved', type: hints[0], candidateTypes: hints, message: null };
    }
    const names = hints.join(', ');
    return {
      status: 'ambiguous',
      type: null,
      candidateTypes: hints,
      message: `Which one did you mean by "${trimmed}" — ${names}?`,
    };
  }

  extractQualifier(raw: string, type: string): string | null {
    return extractPropertyQualifier(raw, type);
  }
}

/** Shared instance, mirroring every other stage's singleton export
 *  (`editValidator`, `editApplier`, `editExecutor`, ...). */
export const smartComponentResolver = new SmartComponentResolver();
