/**
 * HORUS AI — Circuit Plan Executor (Tools) — Phase 2.
 *
 * Executes a `CircuitPlan` (`core/Brain/CircuitPlanner.ts`'s pure,
 * offline reasoning about what a goal like "create a simple LED
 * circuit" requires) against the real simulator, through the exact
 * same mutation path the existing Add/Remove edit pipeline already
 * uses (`CircuitToolBridge`'s `ICircuitToolMutator`) — never a second
 * implementation of component creation or property writes.
 *
 * Pipeline this completes:
 *   goal -> CircuitPlanner (Phase 1, unmodified) -> CircuitPlanExecutor -> CircuitToolBridge -> CircuitTool (CircuitEditor)
 *
 * Scope, per the Phase 2 spec:
 *  - Add-only. This executes each planned component's *creation* and
 *    its planned property values. It does not wire/connect
 *    components (`circuitRequirements` stays descriptive — automatic
 *    wiring is explicitly a later phase), does not re-plan or
 *    optimize anything `CircuitPlanner` proposed, and keeps no memory
 *    of past runs (each call is independent).
 *  - Source of truth: the simulator's component registry, via the
 *    same `CircuitToolBridge` every other tool already reads/writes
 *    through. Every component type this executes already passed
 *    `CircuitPlanner`'s own registry check
 *    (`SmartComponentResolver.resolveComponentType`), so nothing here
 *    invents a type; `plan.unavailableComponents` is carried straight
 *    through as reported (never attempted) failures.
 *  - Safe order: components are created in the exact order
 *    `CircuitPlan.components` lists them (the planner's own
 *    power-source-then-load ordering), one fully created and verified
 *    before the next is even attempted. If the simulator refuses one
 *    creation, execution stops immediately rather than attempting the
 *    rest — a later mutator call would fail the same way (e.g. no
 *    circuit is open), so continuing would only produce repeats of
 *    the same failure instead of a clearer report.
 *  - Real verification only, never a claim based on the plan or a
 *    mutator's boolean return alone:
 *      - After `addComponent`, the new id is read back through
 *        `getComponents()`/`getComponentProperties()` before it
 *        counts as "created".
 *      - After every `changeComponentValue` call, the property is
 *        read back and compared to the requested value; only a match
 *        counts as "applied".
 *  - No UI changes, and no changes to the existing Add/Remove
 *    edit-request pipeline (`CircuitEditPlanner`/`EditValidator`/
 *    `EditApplier`/`EditExecutor`) — this is a new, separate consumer
 *    of the same `CircuitToolBridge`, not a replacement for anything.
 */

import type { CircuitPlan, PlannedComponent, UnavailableComponent } from '../core/Brain/CircuitPlanner';
import type { ICircuitTool } from './CircuitContextBuilder';
import type { ICircuitToolMutator } from './CircuitToolBridge';
import { circuitToolBridge } from './CircuitToolBridge';
import type { ComponentType } from '../../circuit/types';

/** One property write attempted for one created component instance. */
export interface AppliedProperty {
  key: string;
  name: string;
  requestedValue: number | string | boolean;
  /** What the live simulator actually reports after the write — the
   *  only thing `applied` is judged against. */
  actualValue: number | string | boolean | undefined;
  applied: boolean;
  /** Present only when `applied` is false. */
  reason?: string;
}

/** One real, created-and-verified component instance. */
export interface CreatedComponentInstance {
  type: string;
  name: string;
  componentId: number;
  label: string;
  properties: AppliedProperty[];
}

/** One planned component this executor could not create — the
 *  simulator itself refused (e.g. no circuit open), not a registry
 *  problem (those are `plan.unavailableComponents` and never reach
 *  this executor at all). */
export interface FailedComponentCreation {
  type: string;
  name: string;
  requestedQuantity: number;
  createdBeforeFailure: number;
  reason: string;
}

export type CircuitPlanExecutionStatus = 'completed' | 'partial' | 'failed' | 'nothing_to_do';

export interface CircuitPlanExecutionResult {
  status: CircuitPlanExecutionStatus;
  /** Every component instance actually created *and* confirmed present
   *  in the live simulator — never a claim based on the plan alone. */
  created: CreatedComponentInstance[];
  /** Requested parts `CircuitPlanner` itself couldn't resolve against
   *  the registry — carried straight through, never attempted here. */
  unavailable: UnavailableComponent[];
  /** Component types this executor tried to create but the simulator
   *  rejected — execution stops the moment this happens. */
  failed: FailedComponentCreation[];
  /** Human-readable summary of what was actually confirmed built, for
   *  a caller to show as-is — built only from `created`/`failed`/
   *  `unavailable` above (i.e. from the verified outcome), never from
   *  the plan's own stated intent. */
  message: string;
}

export interface ICircuitPlanExecutor {
  /** Executes `plan` against the live simulator and returns only what
   *  was actually confirmed to happen there. */
  execute(plan: CircuitPlan): CircuitPlanExecutionResult;
}

export class CircuitPlanExecutor implements ICircuitPlanExecutor {
  private readonly tool: ICircuitTool & ICircuitToolMutator;

  constructor(tool: ICircuitTool & ICircuitToolMutator) {
    this.tool = tool;
  }

  execute(plan: CircuitPlan): CircuitPlanExecutionResult {
    const created: CreatedComponentInstance[] = [];
    const failed: FailedComponentCreation[] = [];

    for (const planned of plan.components) {
      let createdForThisType = 0;
      let stop = false;

      for (let i = 0; i < planned.quantity; i++) {
        const outcome = this.createAndVerify(planned);
        if (!outcome.ok) {
          failed.push({
            type: planned.type,
            name: planned.name,
            requestedQuantity: planned.quantity,
            createdBeforeFailure: createdForThisType,
            reason: outcome.reason,
          });
          stop = true;
          break;
        }
        created.push(outcome.instance);
        createdForThisType++;
      }

      // Stop the whole run, not just this component type: once the
      // simulator refuses a creation it's virtually always because
      // there's no live circuit to add to at all, so every remaining
      // planned component would fail identically.
      if (stop) break;
    }

    const message = this.buildMessage(plan, created, failed);
    const status: CircuitPlanExecutionStatus =
      plan.components.length === 0
        ? 'nothing_to_do'
        : failed.length > 0
        ? created.length > 0
          ? 'partial'
          : 'failed'
        : 'completed';

    return { status, created, unavailable: plan.unavailableComponents, failed, message };
  }

  private createAndVerify(
    planned: PlannedComponent
  ): { ok: true; instance: CreatedComponentInstance } | { ok: false; reason: string } {
    const createdComponent = this.tool.addComponent(planned.type as ComponentType);
    if (!createdComponent) {
      return { ok: false, reason: 'No circuit is currently open in the simulator.' };
    }

    // Verification, not trust: confirm the component the bridge just
    // reported creating is actually readable back from live simulator
    // state before counting it as created at all.
    const liveProps = this.readLiveProperties(createdComponent.id);
    if (liveProps === null) {
      return { ok: false, reason: `${planned.name} did not appear in the simulator after creation.` };
    }

    const properties: AppliedProperty[] = planned.properties.map((prop) =>
      this.applyAndVerifyProperty(createdComponent.id, planned.name, prop.key, prop.name, prop.value, liveProps)
    );

    return {
      ok: true,
      instance: {
        type: planned.type,
        name: planned.name,
        componentId: createdComponent.id,
        label: createdComponent.label,
        properties,
      },
    };
  }

  private applyAndVerifyProperty(
    componentId: number,
    componentName: string,
    key: string,
    propertyName: string,
    requestedValue: number | string | boolean,
    liveProps: Record<string, number | string | boolean>
  ): AppliedProperty {
    // Already at the requested value (e.g. it matched the type's
    // default) — nothing to write, and the live read already confirms
    // it, so report it applied without a redundant mutator call.
    if (this.valuesEqual(liveProps[key], requestedValue)) {
      return { key, name: propertyName, requestedValue, actualValue: liveProps[key], applied: true };
    }

    const wrote = this.tool.changeComponentValue(componentId, key, requestedValue);
    const readBack = this.readLiveProperties(componentId);
    const actualValue = readBack ? readBack[key] : undefined;
    const verified = wrote && this.valuesEqual(actualValue, requestedValue);

    return {
      key,
      name: propertyName,
      requestedValue,
      actualValue,
      applied: verified,
      reason: verified
        ? undefined
        : `${propertyName} could not be set to ${String(requestedValue)} on this ${componentName}.`,
    };
  }

  /** Reads a component's live property map back from the simulator,
   *  confirming the component still exists there at all. Null means
   *  "not found" — the caller treats that as verification failure,
   *  never as an empty-but-present component. */
  private readLiveProperties(componentId: number): Record<string, number | string | boolean> | null {
    const stillPresent = this.tool.getComponents().some((c) => c.id === componentId);
    if (!stillPresent) return null;
    return this.tool.getComponentProperties?.(componentId) ?? null;
  }

  private valuesEqual(a: number | string | boolean | undefined, b: number | string | boolean): boolean {
    if (a === undefined) return false;
    if (typeof a === 'number' && typeof b === 'number') return Math.abs(a - b) < 1e-9;
    return a === b;
  }

  private buildMessage(
    plan: CircuitPlan,
    created: CreatedComponentInstance[],
    failed: FailedComponentCreation[]
  ): string {
    const parts: string[] = [];

    if (created.length > 0) {
      const byName = new Map<string, number>();
      for (const c of created) byName.set(c.name, (byName.get(c.name) ?? 0) + 1);
      const summary = Array.from(byName.entries())
        .map(([name, count]) => `${count}x ${name}`)
        .join(', ');
      const unverifiedProps = created.flatMap((c) => c.properties.filter((p) => !p.applied));
      const propNote =
        unverifiedProps.length > 0
          ? ` Note: ${unverifiedProps.map((p) => p.reason).join(' ')}`
          : '';
      parts.push(`Added to the simulator and confirmed present: ${summary}.${propNote}`);
    }

    if (plan.unavailableComponents.length > 0) {
      const names = plan.unavailableComponents.map((u) => u.requested).join(', ');
      parts.push(`Not available in the simulator's component registry, so not added: ${names}.`);
    }

    if (failed.length > 0) {
      const names = failed.map((f) => `${f.name} — ${f.reason}`).join('; ');
      parts.push(`Stopped before finishing: ${names}.`);
    }

    if (parts.length === 0) {
      parts.push('Nothing to build — the plan had no components to create.');
    }

    return parts.join(' ');
  }
}

/** Shared instance backed by `circuitToolBridge` — the same existing,
 *  live `ICircuitTool & ICircuitToolMutator` instance every other
 *  execution-stage singleton in this directory (`editApplier`,
 *  `editValidator`, ...) already wires in. */
export const circuitPlanExecutor = new CircuitPlanExecutor(circuitToolBridge);
