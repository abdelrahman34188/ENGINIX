/**
 * HORUS AI — Edit Applier (Tools).
 *
 * The execution stage `EditExecutor.ts` explicitly reserves for later
 * ("A later stage (once the concrete `CircuitTool` mutators exist) is
 * expected to drain `queue()` ... and actually apply each queued plan —
 * that stage does not exist yet"). The mutators now exist
 * (`CircuitToolBridge`'s `ICircuitToolMutator` side), so this module is
 * that stage: it takes a `ValidatedEditPlan` (`EditValidator.ts`) and
 * calls straight through to the matching `CircuitToolBridge` mutator —
 * the same bridge instance `EditValidator`/`CircuitContextBuilder`
 * already read through.
 *
 * Pipeline this completes:
 *   HORUS request -> CircuitEditPlanner -> EditValidator -> EditApplier -> CircuitToolBridge -> CircuitTool (CircuitEditor)
 *
 * Scope:
 *  - No re-validation of things `EditValidator` already checked (target
 *    existence, value shape, connection possibility) — an invalid plan
 *    is rejected immediately with the same issue `EditValidator` found,
 *    never attempted.
 *  - No parsing beyond turning the compact string values `EditPlanJSON`
 *    already carries into the numeric/typed values the bridge methods
 *    need (e.g. "220Ω" -> `220`). No new circuit-editing logic — every
 *    actual mutation is one call to an existing `ICircuitToolMutator`
 *    method, which itself is a call-through to an existing
 *    `CircuitEditor` method. Nothing here touches `CircuitEditor` or
 *    simulator state directly.
 *  - No UI. Doesn't refresh, re-render, or rebuild anything itself —
 *    that's the bridge/`CircuitEditor`'s job (unchanged), and they only
 *    ever mutate in place (`updateComponentProperty`, etc.), never
 *    reload or recreate the editor.
 *  - Structured results only. A missing component, an unparsable
 *    value, or an unsupported action all come back as
 *    `{ status: 'error', field, message }` — never a thrown exception,
 *    never a silently-ignored no-op reported as success.
 */

import type { ComponentType } from '../../circuit/types';
import { defaultProperties, componentNames } from '../../circuit/componentDefs';
import type { ICircuitTool, CircuitToolComponent } from './CircuitContextBuilder';
import type { ICircuitToolMutator } from './CircuitToolBridge';
import { circuitToolBridge } from './CircuitToolBridge';
import { resolveComponent } from './EditValidator';
import type { ValidatedEditPlan, EditPlanValidationField } from './EditValidator';
import type { EditPlanJSON } from '../core/Brain/CircuitEditPlanner';
import { propertyEngine } from './PropertyEngine';
import type { PropertyEngineField } from './PropertyEngine';

/** Synonyms for common terminal names -> the real terminal label(s) to
 *  try, in priority order, against the target component's actual
 *  terminal list (see `defaultTerminals` in `componentDefs.ts`). Not
 *  every synonym applies to every component type — `pickTerminalLabel`
 *  below only accepts a candidate that's actually present on the
 *  resolved component, so an "anode" hint against a resistor simply
 *  fails to resolve rather than picking something wrong. */
const TERMINAL_SYNONYMS: Readonly<Record<string, readonly string[]>> = {
  anode: ['A'],
  cathode: ['K'],
  base: ['B'],
  collector: ['C'],
  emitter: ['E'],
  gate: ['G'],
  drain: ['D'],
  source: ['S'],
  positive: ['+', 'A', '1'],
  plus: ['+', 'A', '1'],
  pos: ['+', 'A', '1'],
  negative: ['-', 'K', '2'],
  minus: ['-', 'K', '2'],
  neg: ['-', 'K', '2'],
  vcc: ['VCC'],
  power: ['VCC'],
  gnd: ['GND'],
  ground: ['GND'],
  wiper: ['W'],
  common: ['COM'],
  com: ['COM'],
  pin1: ['1'],
  pin2: ['2'],
  leg1: ['1'],
  leg2: ['2'],
};

/** Splits a connect-target phrase like "LED anode" or "anode of LED"
 *  into the component reference ("LED") and the terminal hint word
 *  ("anode"), by checking whether the last or first word is a known
 *  terminal synonym. Falls back to treating the whole phrase as just
 *  the component reference (no hint) when neither end matches. */
function splitComponentAndTerminal(raw: string): { componentText: string; hint: string | null } {
  const trimmed = raw.trim();
  const words = trimmed.split(/\s+/);
  if (words.length < 2) return { componentText: trimmed, hint: null };

  const last = words[words.length - 1].toLowerCase().replace(/[^\w+-]/g, '');
  if (TERMINAL_SYNONYMS[last]) {
    return { componentText: words.slice(0, -1).join(' '), hint: last };
  }

  const first = words[0].toLowerCase().replace(/[^\w+-]/g, '');
  if (TERMINAL_SYNONYMS[first]) {
    const rest = words.slice(1).join(' ').replace(/^of\s+/i, '');
    return { componentText: rest, hint: first };
  }

  return { componentText: trimmed, hint: null };
}

/** Picks the real terminal label to use: the first synonym candidate
 *  that actually exists on `terminals` when a hint was given, or the
 *  component's first terminal (its "default" pin) when it wasn't.
 *  Returns null when a hint was given but nothing on the component
 *  matches it, or the component has no terminals at all. */
function pickTerminalLabel(hint: string | null, terminals: readonly string[]): string | null {
  if (terminals.length === 0) return null;
  if (!hint) return terminals[0];
  const candidates = TERMINAL_SYNONYMS[hint] ?? [];
  for (const candidate of candidates) {
    const found = terminals.find((t) => t.toLowerCase() === candidate.toLowerCase());
    if (found) return found;
  }
  return null;
}

/** Maps `PropertyEngine`'s result field vocabulary onto the
 *  `EditApplyResult` field vocabulary this class already reports —
 *  `'property'` (no such property on this component) and
 *  `'verification'` (write didn't read back as applied) both surface
 *  as a `'value'` problem here, the closest existing category, rather
 *  than growing `EditApplyResult`'s own field union for this one
 *  caller. */
function engineFieldToEditField(field: PropertyEngineField | undefined): EditPlanValidationField {
  if (field === 'target') return 'target';
  return 'value';
}

export type EditApplyStatus = 'applied' | 'error';

export interface EditApplyResult {
  status: EditApplyStatus;
  /** The plan this result concerns, passed through unchanged. */
  plan: EditPlanJSON;
  /** Id of the component the edit landed on (or was created as), when
   *  applicable and successful. */
  componentId?: number;
  /** Id of the wire created, for a successful `connect`. */
  wireId?: number;
  /** Which field the error concerns, mirroring `EditValidator`'s issue
   *  shape, so a caller can handle "target missing" distinctly from
   *  "bad value" etc. Present only when `status === 'error'`. */
  field?: EditPlanValidationField | 'action';
  /** Human-readable reason. Present only when `status === 'error'`. */
  message?: string;
}

/** Only known, valid `ComponentType` keys can be created/swapped to —
 *  built from `defaultProperties`' own keys so this never drifts out
 *  of sync with the component catalog `addComponent`/`replaceComponent`
 *  can actually place. */
const KNOWN_COMPONENT_TYPES = new Set(Object.keys(defaultProperties));

/** Case-insensitive lookup onto the real, camelCase `ComponentType` key
 *  (e.g. `pushButton`, `dcMotor`, `rgbLed`) — built once from
 *  `KNOWN_COMPONENT_TYPES` so a lowercased match still resolves to the
 *  simulator's actual type string rather than the lowercased guess. */
const KNOWN_COMPONENT_TYPES_BY_LOWER = new Map(
  Array.from(KNOWN_COMPONENT_TYPES, (t) => [t.toLowerCase(), t] as const),
);

function asComponentType(raw: string | null): ComponentType | null {
  if (!raw) return null;
  const normalized = raw.trim().toLowerCase();
  return (KNOWN_COMPONENT_TYPES_BY_LOWER.get(normalized) as ComponentType | undefined) ?? null;
}

/** The primary editable property for a component type — e.g.
 *  `resistance` for a resistor, `voltage` for a battery — taken as the
 *  first entry in that type's own `defaultProperties` list (the same
 *  list the Property Panel builds its fields from), not a separately
 *  maintained mapping. */
function primaryPropertyKey(type: string): string | null {
  return defaultProperties[type]?.[0]?.key ?? null;
}

/** Matches free text (e.g. \"green\", \"Blue\") against the *options* of
 *  any `select` property that `type` really has (per its own
 *  `defaultProperties` entry — never a separately maintained mapping),
 *  case-insensitively against each option's label. Returns the
 *  property's key and the option's real underlying value on a match
 *  (e.g. `{ key: 'color', value: '#00ff00' }` for LED + \"green\"), or
 *  null when no property of this type has a matching option — a
 *  qualifier that doesn't match anything is never guessed at or
 *  silently dropped onto the wrong property. */
function matchPropertyOption(
  type: string,
  text: string,
): { key: string; value: string | number | boolean } | null {
  const wanted = text.trim().toLowerCase();
  if (!wanted) return null;
  const props = defaultProperties[type] ?? [];
  for (const prop of props) {
    if (prop.type !== 'select' || !prop.options) continue;
    const option = prop.options.find((o) => o.label.toLowerCase() === wanted);
    if (option) return { key: prop.key, value: option.value };
  }
  return null;
}

/** Pulls a leading "<number><unit>" off free text like "220Ω resistor"
 *  or "220Ω", reusing `CircuitEditPlanner`'s own value-parsing regex so
 *  a bare property change and the value embedded in a replace/add
 *  phrase are parsed identically. Returns null when no leading number
 *  is present (e.g. "a capacitor"). */
function leadingNumericValue(text: string): number | null {
  const match = text.trim().match(/^([\d.]+)\s*[a-zA-ZΩµμ]*/);
  if (!match) return null;
  const n = Number(match[1]);
  return Number.isFinite(n) ? n : null;
}

export interface IEditApplier {
  /** Apply an already-validated plan to the live circuit. Rejects
   *  immediately (no bridge call at all) when `validated.valid` is
   *  false. */
  apply(validated: ValidatedEditPlan): EditApplyResult;
}

export class EditApplier implements IEditApplier {
  private readonly tool: ICircuitTool & ICircuitToolMutator;

  constructor(tool: ICircuitTool & ICircuitToolMutator) {
    this.tool = tool;
  }

  apply(validated: ValidatedEditPlan): EditApplyResult {
    const { plan } = validated;

    if (!validated.valid) {
      const issue = validated.issues[0];
      return {
        status: 'error',
        plan,
        field: issue?.field ?? 'target',
        message: issue?.message ?? 'Plan failed validation.',
      };
    }

    switch (plan.action) {
      case 'change_value':
        return this.applyChangeValue(plan);
      case 'replace':
        return this.applyReplace(plan);
      case 'remove':
        return this.applyRemove(plan);
      case 'add':
        return this.applyAdd(plan);
      case 'disconnect':
        return this.applyDisconnect(plan);
      case 'connect':
        return this.applyConnect(plan);
      case 'rename':
        // No rename mutator exists on ICircuitToolMutator (out of scope
        // for this bridge) — report honestly instead of silently no-op.
        return {
          status: 'error',
          plan,
          field: 'action',
          message: 'CircuitToolBridge has no rename mutator.',
        };
      default:
        return { status: 'error', plan, field: 'action', message: `Unknown action "${plan.action}".` };
    }
  }

  private resolveTarget(plan: EditPlanJSON): CircuitToolComponent | null {
    return resolveComponent(this.tool.getComponents(), {
      raw: plan.target ?? '',
      kind: 'unknown',
      componentType: null,
    });
  }

  /**
   * Resolves and applies a "change_value" plan through `PropertyEngine`
   * (`PropertyEngine.ts`) — the generic component -> property -> value
   * engine that walks a component's *entire* real property schema
   * (every `select`/`number`/`boolean`/`string`/`presetNumber` entry in
   * `defaultProperties[type]`, not just "the first property" plus
   * `select` options), coerces `valueText` into that property's real
   * type, applies it through the same `ICircuitToolMutator.changeComponentValue`
   * this class already used directly, and — critically — re-reads the
   * component's real props afterward to confirm the write actually
   * landed before this ever returns `status: 'applied'`. A property
   * name/value this component genuinely doesn't support is reported
   * back naming what it *does* support, never silently dropped or
   * misapplied to the wrong field.
   */
  private applyChangeValue(plan: EditPlanJSON): EditApplyResult {
    const target = this.resolveTarget(plan);
    if (!target) {
      return { status: 'error', plan, field: 'target', message: `Component "${plan.target}" not found.` };
    }
    const valueText = plan.value ?? '';

    const result = propertyEngine.applyFromText(target.id, valueText);
    if (result.status === 'error') {
      return {
        status: 'error',
        plan,
        field: engineFieldToEditField(result.field),
        message: result.message ?? `"${plan.value}" isn't a recognizable value.`,
      };
    }
    return { status: 'applied', plan, componentId: target.id };
  }

  /**
   * "Replace X with <value><unit> [type]" (e.g. "Replace R1 with
   * 220Ω resistor") is ambiguous between two real operations:
   *  - a value edit on the existing component, when a numeric value is
   *    present and the named type (if any) matches what's already
   *    there — this is what "replace R1 with 220Ω" means in normal
   *    engineering speech, and it must land as an in-place value
   *    change (`changeComponentValue`), not a delete+recreate: R1
   *    keeps its id, its wires, everything.
   *  - an actual component swap, when a different component type is
   *    named and there's no value that could apply to the existing
   *    part — that really is `removeComponent` + `addComponent` (no
   *    single primitive exists for it, see `CircuitToolBridge`).
   * Both branches call only existing `ICircuitToolMutator` methods.
   */
  private applyReplace(plan: EditPlanJSON): EditApplyResult {
    const target = this.resolveTarget(plan);
    if (!target) {
      return { status: 'error', plan, field: 'target', message: `Component "${plan.target}" not found.` };
    }
    const replacementText = plan.value ?? '';
    const numeric = leadingNumericValue(replacementText);
    const namedType = asComponentType(
      replacementText
        .trim()
        .split(/\s+/)
        .pop() ?? null
    );

    const sameTypeOrUnspecified = namedType === null || namedType === target.type;

    if (numeric !== null && sameTypeOrUnspecified) {
      const key = primaryPropertyKey(target.type);
      if (!key) {
        return { status: 'error', plan, field: 'value', message: `${target.type} has no editable value property.` };
      }
      const ok = this.tool.changeComponentValue(target.id, key, numeric);
      if (!ok) {
        return { status: 'error', plan, field: 'target', message: `Component "${plan.target}" not found.` };
      }
      return { status: 'applied', plan, componentId: target.id };
    }

    // Genuine type swap.
    if (!namedType) {
      return {
        status: 'error',
        plan,
        field: 'value',
        message: `"${replacementText}" doesn't name a recognized component type.`,
      };
    }
    const created = this.tool.replaceComponent(target.id, namedType);
    if (!created) {
      return { status: 'error', plan, field: 'target', message: `Component "${plan.target}" not found.` };
    }
    if (numeric !== null) {
      const key = primaryPropertyKey(created.type);
      if (key) this.tool.changeComponentValue(created.id, key, numeric);
    }
    return { status: 'applied', plan, componentId: created.id };
  }

  /**
   * "Connect X to Y" plans carry only component references
   * (`plan.target`/`plan.value`), with any pin name folded into the
   * same phrase (e.g. "LED anode") — `EditPlanJSON` has no separate
   * terminal field. This resolves each side in two steps, both against
   * real data: split off a trailing/leading terminal-name word if one
   * is present (`splitComponentAndTerminal`), resolve the remaining
   * text to a real component, then resolve the hint (or the
   * component's first pin, when no hint was given) against that
   * component's *actual* terminal labels (`getComponentTerminalLabels`)
   * — never a guessed label. Only once both sides resolve to a real
   * terminal does this call `connectComponents`, so a "success" here
   * always means `CircuitTool` already created the wire.
   */
  private applyConnect(plan: EditPlanJSON): EditApplyResult {
    if (!plan.target || !plan.value) {
      return { status: 'error', plan, field: 'target', message: 'Both components to connect must be named.' };
    }

    const a = splitComponentAndTerminal(plan.target);
    const b = splitComponentAndTerminal(plan.value);

    const components = this.tool.getComponents();
    const compA = resolveComponent(components, { raw: a.componentText, kind: 'unknown', componentType: null });
    if (!compA) {
      return { status: 'error', plan, field: 'target', message: `Component "${a.componentText}" not found.` };
    }
    const compB = resolveComponent(components, { raw: b.componentText, kind: 'unknown', componentType: null });
    if (!compB) {
      return { status: 'error', plan, field: 'secondaryTarget', message: `Component "${b.componentText}" not found.` };
    }

    const labelA = pickTerminalLabel(a.hint, this.tool.getComponentTerminalLabels(compA.id));
    if (!labelA) {
      return {
        status: 'error',
        plan,
        field: 'target',
        message: a.hint ? `${compA.label} has no "${a.hint}" terminal.` : `${compA.label} has no terminals.`,
      };
    }
    const labelB = pickTerminalLabel(b.hint, this.tool.getComponentTerminalLabels(compB.id));
    if (!labelB) {
      return {
        status: 'error',
        plan,
        field: 'secondaryTarget',
        message: b.hint ? `${compB.label} has no "${b.hint}" terminal.` : `${compB.label} has no terminals.`,
      };
    }

    const wire = this.tool.connectComponents(compA.id, labelA, compB.id, labelB);
    if (!wire) {
      return {
        status: 'error',
        plan,
        field: 'connection',
        message: `Could not connect ${compA.label}.${labelA} to ${compB.label}.${labelB}.`,
      };
    }
    // The wire is already in CircuitTool's real state by this point —
    // connectComponents/connectByLabel push it synchronously.
    return { status: 'applied', plan, componentId: compA.id, wireId: wire.id };
  }

  private applyRemove(plan: EditPlanJSON): EditApplyResult {
    const target = this.resolveTarget(plan);
    if (!target) {
      return { status: 'error', plan, field: 'target', message: `Component "${plan.target}" not found.` };
    }
    const ok = this.tool.removeComponent(target.id);
    if (!ok) {
      return { status: 'error', plan, field: 'target', message: `Component "${plan.target}" not found.` };
    }
    return { status: 'applied', plan, componentId: target.id };
  }

  private applyAdd(plan: EditPlanJSON): EditApplyResult {
    const type = asComponentType(plan.target);
    if (!type) {
      return {
        status: 'error',
        plan,
        field: 'target',
        message: `"${plan.target}" doesn't name a recognized component type.`,
      };
    }

    // `plan.value`, for `add`, carries whatever's left of the typed
    // phrase once the type's own name/alias is accounted for (e.g.
    // "green" out of "Green LED" — see `SmartComponentResolver`'s
    // `extractPropertyQualifier`/`runtime.ts`). Resolve — and validate
    // — that *before* creating anything: an unsupported qualifier is
    // reported clearly, never silently dropped in favor of the
    // default the component would otherwise get.
    let propertyToApply: { key: string; value: string | number | boolean } | null = null;
    if (plan.value) {
      const match = matchPropertyOption(type, plan.value);
      if (!match) {
        const name = componentNames[type] ?? type;
        return {
          status: 'error',
          plan,
          field: 'value',
          message: `"${plan.value}" isn't a supported property for ${name}.`,
        };
      }
      propertyToApply = match;
    }

    const created = this.tool.addComponent(type);
    if (!created) {
      return { status: 'error', plan, field: 'target', message: 'No circuit is currently open.' };
    }
    if (propertyToApply) {
      this.tool.changeComponentValue(created.id, propertyToApply.key, propertyToApply.value);
    }
    return { status: 'applied', plan, componentId: created.id };
  }

  /**
   * "Disconnect X" (no second component named) is a real, supported
   * request — `EditValidator` already treats it as valid whenever `X`
   * has any wire at all (`hasAnyWire`). This mirrors that: with a
   * named second component, one `disconnectComponents(A, B)` call, same
   * as before; without one, every neighbor `X` is currently wired to
   * (read via `getWires()`, the same read-only data `EditValidator`
   * used to decide this plan was valid) is disconnected in turn, each
   * through the same existing `disconnectComponents` mutator — no new
   * bridge/`CircuitEditor` primitive, just calling the pairwise one
   * once per real connection instead of once.
   */
  private applyDisconnect(plan: EditPlanJSON): EditApplyResult {
    const target = this.resolveTarget(plan);
    if (!target) {
      return { status: 'error', plan, field: 'target', message: `Component "${plan.target}" not found.` };
    }

    if (plan.value) {
      const secondary = resolveComponent(this.tool.getComponents(), {
        raw: plan.value,
        kind: 'unknown',
        componentType: null,
      });
      if (!secondary) {
        return { status: 'error', plan, field: 'secondaryTarget', message: `Component "${plan.value}" not found.` };
      }
      const ok = this.tool.disconnectComponents(target.id, secondary.id);
      if (!ok) {
        return { status: 'error', plan, field: 'connection', message: `${target.label} and ${secondary.label} aren't connected.` };
      }
      return { status: 'applied', plan, componentId: target.id };
    }

    const neighborIds = Array.from(
      new Set(
        this.tool
          .getWires()
          .filter((w) => w.fromComponentId === target.id || w.toComponentId === target.id)
          .map((w) => (w.fromComponentId === target.id ? w.toComponentId : w.fromComponentId))
      )
    );
    if (neighborIds.length === 0) {
      return { status: 'error', plan, field: 'connection', message: `${target.label} has no connections to remove.` };
    }

    const allDisconnected = neighborIds.every((neighborId) => this.tool.disconnectComponents(target.id, neighborId));
    if (!allDisconnected) {
      return { status: 'error', plan, field: 'connection', message: `Could not fully disconnect ${target.label}.` };
    }
    return { status: 'applied', plan, componentId: target.id };
  }
}

/** Shared instance backed by `circuitToolBridge` — the same existing,
 *  live `ICircuitTool & ICircuitToolMutator` instance `EditValidator`'s
 *  own `editValidator` singleton and `runtime.ts` already wire in.
 *  Mirrors that wiring rather than creating a second source of circuit
 *  truth (see `EditValidator.ts`'s `editValidator` export). */
export const editApplier = new EditApplier(circuitToolBridge);
