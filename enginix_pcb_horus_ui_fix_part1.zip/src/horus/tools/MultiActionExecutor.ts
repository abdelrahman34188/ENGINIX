/**
 * HORUS AI — Multi-Action Executor (Tools).
 *
 * Runs a request that describes several circuit-edit actions
 * back-to-back (e.g. "Replace R1 with 220Ω. Add LED. Connect LED to
 * R1.") through the real pipeline — one action at a time, in the order
 * the user wrote them:
 *
 *   request -> CircuitEditPlanner.splitActionRequests()/planEdit()
 *           -> EditValidator.validate()
 *           -> EditApplier.apply()
 *           -> CircuitToolBridge -> CircuitTool (CircuitEditor)
 *
 * This is the sequencing/stop-on-failure stage `CircuitEditPlanner`'s
 * own multi-action support (`planEdits()`) deliberately leaves to a
 * "future executor" — this module is that executor, applied to
 * `EditApplier`'s real-mutation path (the same path
 * `devPipelineReplaceComponent.test.ts` and friends already exercise
 * for a single action).
 *
 * Behavior, per spec:
 *  - Actions run strictly in order, one fully applied before the next
 *    is even planned.
 *  - The moment one action fails — the clause doesn't parse as an edit,
 *    it fails validation, or `EditApplier` reports an error — execution
 *    stops immediately. No later action is planned, validated, or
 *    applied, even though the request describes it.
 *  - The result always reports `completedActions` (every action that
 *    was actually applied to the circuit, in order, real
 *    `EditApplyResult`s — not a preview) and, when something stopped
 *    the run early, `failedAction` (which clause, at what position) and
 *    `reason` (a human-readable message for why). Both are null when
 *    every action succeeded.
 *
 * Scope:
 *  - No new circuit-editing logic. Every mutation is exactly the
 *    `EditApplier.apply()` call a single-action request would already
 *    make — this module only decides *whether* to make the next one.
 *  - No re-parsing/re-validating beyond what `CircuitEditPlanner` and
 *    `EditValidator` already do per clause — this module is glue, not
 *    a second implementation of either.
 *  - No partial rollback. A stopped run's completed actions stay
 *    applied — this module reports what happened, it doesn't undo it.
 */

import type { ICircuitEditPlanner, MultiEditPlanEntry } from '../core/Brain/CircuitEditPlanner';
import { circuitEditPlanner } from '../core/Brain/CircuitEditPlanner';
import type { IEditValidator, EditPlanValidationField } from './EditValidator';
import { editValidator } from './EditValidator';
import type { IEditApplier, EditApplyResult } from './EditApplier';
import { editApplier } from './EditApplier';
import type { EditPlanJSON } from '../core/Brain/CircuitEditPlanner';

/** Identifies which action in the request stopped the run, and why. */
export interface FailedMultiAction {
  /** Position of this action in the original request, 0-based —
   *  matches `MultiEditPlanEntry.index` for the same clause. */
  index: number;
  /** The action's clause exactly as split out of the request. */
  requestText: string;
  /** The compact plan for this action, when one could be built at all.
   *  Null when the clause didn't parse as a recognizable edit action in
   *  the first place (nothing ever reached validation). */
  plan: EditPlanJSON | null;
  /** Which stage stopped the run: the clause never parsed into a plan,
   *  it failed `EditValidator`, or `EditApplier` reported an error
   *  while actually applying it. */
  stage: 'plan' | 'validate' | 'apply';
  /** Mirrors `EditValidator`/`EditApplier`'s own issue field, when the
   *  failing stage produced one. Absent when `stage === 'plan'`. */
  field?: EditPlanValidationField | 'action';
}

export interface MultiActionExecutionResult {
  /** Every action that was actually applied to the circuit, in order —
   *  real `EditApplyResult`s from `EditApplier`, not a dry run. Empty
   *  when the very first action failed, or the request had none. */
  completedActions: EditApplyResult[];
  /** The action that stopped the run, or null when every action in the
   *  request completed successfully. */
  failedAction: FailedMultiAction | null;
  /** Human-readable reason the run stopped, or null when nothing did. */
  reason: string | null;
}

export interface IMultiActionExecutor {
  /**
   * Splits `request` into its individual action clauses and runs each
   * one — plan, validate, apply — strictly in order, stopping at the
   * first failure. Never throws: every outcome, including "the request
   * had no actions at all", comes back as a structured
   * `MultiActionExecutionResult`.
   */
  executeAll(request: string): MultiActionExecutionResult;
}

export class MultiActionExecutor implements IMultiActionExecutor {
  private readonly planner: ICircuitEditPlanner;
  private readonly validator: IEditValidator;
  private readonly applier: IEditApplier;

  constructor(
    planner: ICircuitEditPlanner = circuitEditPlanner,
    validator: IEditValidator = editValidator,
    applier: IEditApplier = editApplier,
  ) {
    this.planner = planner;
    this.validator = validator;
    this.applier = applier;
  }

  executeAll(request: string): MultiActionExecutionResult {
    const entries: MultiEditPlanEntry[] = this.planner.planEdits({ request });
    const completedActions: EditApplyResult[] = [];

    for (const entry of entries) {
      if (!entry.plan) {
        return {
          completedActions,
          failedAction: {
            index: entry.index,
            requestText: entry.requestText,
            plan: null,
            stage: 'plan',
          },
          reason: `Action ${entry.index + 1} ("${entry.requestText}") isn't a recognizable circuit edit.`,
        };
      }

      const validated = this.validator.validate(entry.plan);
      if (!validated.valid) {
        const issue = validated.issues[0];
        return {
          completedActions,
          failedAction: {
            index: entry.index,
            requestText: entry.requestText,
            plan: validated.plan,
            stage: 'validate',
            field: issue?.field,
          },
          reason: issue?.message ?? `Action ${entry.index + 1} ("${entry.requestText}") failed validation.`,
        };
      }

      const applied = this.applier.apply(validated);
      if (applied.status === 'error') {
        return {
          completedActions,
          failedAction: {
            index: entry.index,
            requestText: entry.requestText,
            plan: applied.plan,
            stage: 'apply',
            field: applied.field,
          },
          reason: applied.message ?? `Action ${entry.index + 1} ("${entry.requestText}") failed to apply.`,
        };
      }

      completedActions.push(applied);
    }

    return { completedActions, failedAction: null, reason: null };
  }
}

/** Shared instance — stateless, backed by the same shared
 *  `circuitEditPlanner` / `editValidator` / `editApplier` singletons
 *  every other pipeline module already uses. */
export const multiActionExecutor = new MultiActionExecutor();
