/**
 * HORUS AI — Edit Validator (Tools).
 *
 * Takes a `CircuitEditPlan` (see `core/Brain/CircuitEditPlanner.ts`) and
 * checks it against the current circuit — read through the existing
 * `ICircuitTool` contract (`CircuitContextBuilder.ts`), the same
 * read-only interface `CircuitContextBuilder` and `CircuitToolBridge`
 * already use — before anything would be allowed to execute it.
 *
 * Verifies exactly three things, no more:
 *  - target exists: the named component is actually on the circuit
 *    (skipped for `add`, whose target is the *new* component's
 *    name/type and isn't expected to exist yet).
 *  - value is valid: a new property value parsed to a real number
 *    (`change_value`), a non-empty new name (`rename`), a non-empty
 *    component name/type to add (`add`), or a non-empty replacement
 *    component that isn't the same component being replaced
 *    (`replace`).
 *  - connection is possible: for `connect`, both components exist,
 *    aren't the same component, and aren't already wired together; for
 *    `disconnect`, the named component(s) currently have a connection
 *    to remove. `null` (not applicable) for every other action.
 *
 * Scope, deliberately narrow, matching `CircuitContextBuilder.ts`:
 *  - No execution. This module never calls `CircuitTool`,
 *    `CircuitToolBridge`'s mutators (it has none), `CircuitEditor`, or
 *    anything that changes the circuit — it only reads, via
 *    `ICircuitTool`, and returns a verdict.
 *  - No AI logic, no prompt building, no provider calls.
 *  - Returns a validated `EditPlan` (the compact `EditPlanJSON` shape,
 *    annotated with what was and wasn't verified) — never mutates the
 *    plan it was given, the circuit, or anything else.
 */

import type { ICircuitTool, CircuitToolComponent, CircuitToolWire } from './CircuitContextBuilder';
import {
  toEditPlanJSON,
  type CircuitEditPlan,
  type CircuitEditTargetRef,
  type EditPlanJSON,
} from '../core/Brain/CircuitEditPlanner';
import { circuitToolBridge } from './CircuitToolBridge';

/** Which field a validation problem applies to. */
export type EditPlanValidationField = 'target' | 'secondaryTarget' | 'value' | 'connection';

export interface EditPlanValidationIssue {
  field: EditPlanValidationField;
  message: string;
}

/**
 * The validated `EditPlan` this module returns: the same compact
 * `EditPlanJSON` shape `CircuitEditPlanner` produces, plus the three
 * verification results and an overall `valid` flag. Still just a
 * description — nothing here has executed the edit.
 */
export interface ValidatedEditPlan {
  plan: EditPlanJSON;
  /** True when the named target was found on the current circuit.
   *  Always true for `add`, whose target doesn't exist yet by design. */
  targetExists: boolean;
  /** True when the plan's value (new property value / new name /
   *  new-component name) is well-formed. */
  valueValid: boolean;
  /** True/false for `connect`/`disconnect`; null (not applicable) for
   *  every other action. */
  connectionPossible: boolean | null;
  /** `targetExists && valueValid &&` (`connectionPossible` is either
   *  not applicable or true). */
  valid: boolean;
  /** Every problem found, empty when `valid` is true. */
  issues: EditPlanValidationIssue[];
}

export interface IEditValidator {
  /** Verify a plan against the current circuit and return the
   *  validated `EditPlan`. Never executes anything. */
  validate(plan: CircuitEditPlan): ValidatedEditPlan;
}

/** Resolves a target reference (e.g. "R1", "resistor", "the LED") to a
 *  real component on the circuit, or null if none matches. Tries, in
 *  order: numeric id, exact label, exact type, then a loose
 *  label/type substring match. */
export function resolveComponent(
  components: readonly CircuitToolComponent[],
  ref: CircuitEditTargetRef | null,
): CircuitToolComponent | null {
  if (!ref) return null;
  const raw = ref.raw.trim();
  if (raw.length === 0) return null;
  const lower = raw.toLowerCase();

  if (/^\d+$/.test(raw)) {
    const byId = components.find((c) => c.id === Number(raw));
    if (byId) return byId;
  }

  const byLabel = components.find((c) => c.label.toLowerCase() === lower);
  if (byLabel) return byLabel;

  const byType = components.find((c) => c.type.toLowerCase() === lower);
  if (byType) return byType;

  const byPartial = components.find(
    (c) =>
      c.label.toLowerCase().includes(lower) ||
      lower.includes(c.label.toLowerCase()) ||
      c.type.toLowerCase().includes(lower) ||
      lower.includes(c.type.toLowerCase()),
  );
  return byPartial ?? null;
}

function wiresConnect(wires: readonly CircuitToolWire[], aId: number, bId: number): boolean {
  return wires.some(
    (w) =>
      (w.fromComponentId === aId && w.toComponentId === bId) ||
      (w.fromComponentId === bId && w.toComponentId === aId),
  );
}

function hasAnyWire(wires: readonly CircuitToolWire[], id: number): boolean {
  return wires.some((w) => w.fromComponentId === id || w.toComponentId === id);
}

export class EditValidator implements IEditValidator {
  private readonly circuitTool: ICircuitTool;

  constructor(circuitTool: ICircuitTool) {
    this.circuitTool = circuitTool;
  }

  validate(plan: CircuitEditPlan): ValidatedEditPlan {
    const components = this.circuitTool.getComponents();
    const wires = this.circuitTool.getWires();
    const issues: EditPlanValidationIssue[] = [];

    // --- target exists ---------------------------------------------
    let resolvedTarget: CircuitToolComponent | null = null;
    let targetExists: boolean;
    if (plan.action === 'add_component') {
      // The target here is the component being created — it isn't
      // expected to exist on the circuit yet.
      targetExists = true;
    } else {
      resolvedTarget = resolveComponent(components, plan.target);
      targetExists = resolvedTarget !== null;
      if (!targetExists) {
        issues.push({
          field: 'target',
          message: plan.target
            ? `No component matching "${plan.target.raw}" was found on the circuit.`
            : 'No target component was named in the request.',
        });
      }
    }

    // --- value is valid ----------------------------------------------
    let valueValid: boolean;
    switch (plan.action) {
      case 'change_property':
        // Only checks that *some* new value text was given — not that
        // it parses as a number. Which values are actually acceptable
        // depends on the target component's real property schema
        // (numeric, select/color, boolean, string, ...), which isn't
        // known until the target resolves; that per-property check is
        // `PropertyEngine`'s job (`EditApplier.applyChangeValue` ->
        // `propertyEngine.applyFromText`), not this shape-only gate.
        // Rejecting here on `propertyChange.value === null` (the
        // numeric-only leading-number parse) would wrongly block every
        // non-numeric edit — e.g. "change LED_2 color to green" — from
        // ever reaching that real check.
        valueValid = plan.propertyChange !== null && plan.propertyChange.raw.trim().length > 0;
        if (!valueValid) {
          issues.push({ field: 'value', message: 'No new value was given.' });
        }
        break;
      case 'rename_component':
        valueValid = !!plan.newName && plan.newName.trim().length > 0;
        if (!valueValid) {
          issues.push({ field: 'value', message: 'No new name was given.' });
        }
        break;
      case 'add_component':
        valueValid = !!plan.target && plan.target.raw.trim().length > 0;
        if (!valueValid) {
          issues.push({ field: 'value', message: 'No component name/type was given to add.' });
        }
        break;
      case 'replace_component':
        valueValid = !!plan.replacement && plan.replacement.raw.trim().length > 0;
        if (!valueValid) {
          issues.push({ field: 'value', message: 'No replacement component was given.' });
        } else if (targetExists && plan.replacement && plan.replacement.kind === 'designator') {
          // If the replacement itself names an existing component *by
          // instance designator* (e.g. "Replace R1 with R1"), replacing
          // a component with itself is a no-op, not a real edit.
          // Restricted to `kind === 'designator'` (as opposed to
          // resolving any type/value phrase against the component
          // list) because a phrase like "220Ω resistor" would
          // otherwise partial-match R1 itself whenever R1 happens to
          // be a resistor — that's a same-type value change, not a
          // self-replacement, and must not be blocked here.
          const resolvedReplacement = resolveComponent(components, plan.replacement);
          if (resolvedReplacement && resolvedTarget && resolvedReplacement.id === resolvedTarget.id) {
            valueValid = false;
            issues.push({
              field: 'value',
              message: `${resolvedTarget.label} is already "${plan.replacement.raw}" — nothing to replace it with.`,
            });
          }
        }
        break;
      default:
        // remove / connect / disconnect carry no separate value to check.
        valueValid = true;
    }

    // --- connection is possible ---------------------------------------
    let connectionPossible: boolean | null = null;
    if (plan.action === 'connect_components') {
      const resolvedSecondary = resolveComponent(components, plan.secondaryTarget);
      const secondaryExists = resolvedSecondary !== null;
      if (!secondaryExists) {
        issues.push({
          field: 'secondaryTarget',
          message: plan.secondaryTarget
            ? `No component matching "${plan.secondaryTarget.raw}" was found on the circuit.`
            : 'No second component was named to connect to.',
        });
      }

      if (!targetExists || !secondaryExists) {
        connectionPossible = false;
      } else if (resolvedTarget!.id === resolvedSecondary!.id) {
        connectionPossible = false;
        issues.push({ field: 'connection', message: 'Cannot connect a component to itself.' });
      } else if (wiresConnect(wires, resolvedTarget!.id, resolvedSecondary!.id)) {
        connectionPossible = false;
        issues.push({
          field: 'connection',
          message: `${resolvedTarget!.label} and ${resolvedSecondary!.label} are already connected.`,
        });
      } else {
        connectionPossible = true;
      }
    } else if (plan.action === 'disconnect_components') {
      if (plan.secondaryTarget) {
        const resolvedSecondary = resolveComponent(components, plan.secondaryTarget);
        const secondaryExists = resolvedSecondary !== null;
        if (!secondaryExists) {
          issues.push({
            field: 'secondaryTarget',
            message: `No component matching "${plan.secondaryTarget.raw}" was found on the circuit.`,
          });
        }
        if (targetExists && secondaryExists) {
          connectionPossible = wiresConnect(wires, resolvedTarget!.id, resolvedSecondary!.id);
          if (!connectionPossible) {
            issues.push({
              field: 'connection',
              message: `${resolvedTarget!.label} and ${resolvedSecondary!.label} aren't currently connected.`,
            });
          }
        } else {
          connectionPossible = false;
        }
      } else if (targetExists) {
        connectionPossible = hasAnyWire(wires, resolvedTarget!.id);
        if (!connectionPossible) {
          issues.push({ field: 'connection', message: `${resolvedTarget!.label} has no connections to remove.` });
        }
      } else {
        connectionPossible = false;
      }
    }

    const valid = targetExists && valueValid && (connectionPossible === null || connectionPossible === true);

    return {
      plan: toEditPlanJSON(plan),
      targetExists,
      valueValid,
      connectionPossible,
      valid,
      issues,
    };
  }
}

/** Shared instance backed by `circuitToolBridge` — the same existing,
 *  live `ICircuitTool` instance `runtime.ts` already wires
 *  `CircuitContextBuilder` to. Mirrors that wiring rather than creating
 *  a second source of circuit truth. */
export const editValidator = new EditValidator(circuitToolBridge);
