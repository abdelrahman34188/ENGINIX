/**
 * HORUS AI — Property Engine (Tools).
 *
 * A generic component -> property -> value resolver and executor. This
 * is the one place that decides which property of a component a piece
 * of natural language refers to, coerces the text into that property's
 * real type, applies it through the existing `CircuitToolBridge`
 * mutator, and verifies the change against the simulator's own
 * post-write state before ever reporting success.
 *
 * Why this exists: `EditApplier`'s previous property handling only
 * ever considered two things — the *first* entry in a type's
 * `defaultProperties` list ("the primary property", e.g. `resistance`
 * for a resistor) for numeric edits, and `select`-typed options for
 * anything else (e.g. LED `color`). That covers the two components the
 * feature was originally built against (LED, Resistor) but silently
 * can't reach a `boolean` property (e.g. HC-05's `Powered`), a
 * *second* `select` on the same type (e.g. HC-05 has both `Role` and
 * `Baud Rate`), or a *second* `number` (e.g. HC-05's `Logic Level`
 * alongside `Baud Rate`). This module replaces that narrow lookup with
 * one that walks the component's *entire* real property list — the
 * same `defaultProperties[type]` schema `CircuitToolBridge`'s own
 * `isValidPropertyValue` and the Property Panel already read from —
 * so any component already gets full property coverage automatically,
 * and any component added to `componentDefs.ts` later does too, with
 * no change needed here.
 *
 * Scope:
 *  - Discovery only reads `defaultProperties` (`componentDefs.ts`) and,
 *    for current values, `CircuitToolBridge.getComponentProperties` —
 *    never a separately maintained property list, never a hardcoded
 *    per-type table.
 *  - No new mutation primitive. Every write is one call to the
 *    existing `ICircuitToolMutator.changeComponentValue`, which itself
 *    already validates the value against the same schema and calls
 *    through to `CircuitEditor.updateComponentProperty` — this module
 *    adds resolution and *verification* around that call, not a new
 *    way of mutating the circuit.
 *  - Verification is mandatory. A `changeComponentValue` call
 *    returning `true` is necessary but not sufficient — this module
 *    always re-reads the component's real `props` afterward
 *    (`getComponentProperties`) and only reports `status: 'applied'`
 *    once the stored value actually matches what was requested. A
 *    component with no matching property, or a value that doesn't
 *    parse for the property's real type, is reported back clearly
 *    (which property, which choices/range), never silently dropped or
 *    guessed at.
 */

import type { ComponentType, PropertyDef } from '../../circuit/types';
import { defaultProperties, componentNames } from '../../circuit/componentDefs';
import type { ICircuitTool } from './CircuitContextBuilder';
import type { ICircuitToolMutator } from './CircuitToolBridge';
import { circuitToolBridge } from './CircuitToolBridge';

// ---------------------------------------------------------------------
// Discovery
// ---------------------------------------------------------------------

export interface PropertySnapshotEntry {
  def: PropertyDef;
  /** The component's real current value for this property, read via
   *  `getComponentProperties` — `undefined` only when the read-back
   *  isn't available (no `getComponentProperties` on this tool) or the
   *  component genuinely has no stored value for this key yet. */
  currentValue: number | string | boolean | undefined;
}

export interface PropertySnapshot {
  componentId: number;
  type: ComponentType;
  label: string;
  /** Every property this component type really defines, in schema
   *  order — empty for a type with no editable properties (e.g. a bare
   *  connector like `screwTerminal2pin`), never padded with guesses. */
  properties: PropertySnapshotEntry[];
}

/** The component's real editable property schema — exactly
 *  `defaultProperties[type]`, so this is automatically correct for any
 *  component type present in `componentDefs.ts`, including ones added
 *  after this module was written. Empty array (not an error) for a
 *  type with no editable properties. */
export function listProperties(type: string): PropertyDef[] {
  return defaultProperties[type] ?? [];
}

/** Read-only snapshot of one component: its type's full property
 *  schema paired with the component's real current values. Null when
 *  the component doesn't exist. */
export function getPropertySnapshot(
  tool: ICircuitTool,
  componentId: number,
): PropertySnapshot | null {
  const comp = tool.getComponents().find((c) => c.id === componentId);
  if (!comp) return null;
  const defs = listProperties(comp.type);
  const raw = tool.getComponentProperties?.(componentId) ?? null;
  return {
    componentId,
    type: comp.type as ComponentType,
    label: comp.label,
    properties: defs.map((def) => ({ def, currentValue: raw ? raw[def.key] : undefined })),
  };
}

// ---------------------------------------------------------------------
// Natural-language resolution
// ---------------------------------------------------------------------

function normalizeName(s: string): string {
  return s.trim().toLowerCase().replace(/[_\s-]+/g, '');
}

/** Matches free text (e.g. "baud rate", "Role", "resistance") against
 *  one property's real display `name` or `key`, for the given
 *  component type. Exact match first, then a loose substring match
 *  (guards against near-misses like "colour" vs "color" or minor
 *  phrasing differences) — never matched against a *different* type's
 *  properties. */
export function matchPropertyByName(type: string, text: string): PropertyDef | null {
  const wanted = normalizeName(text);
  if (!wanted) return null;
  const defs = listProperties(type);
  return (
    defs.find((d) => normalizeName(d.name) === wanted) ??
    defs.find((d) => normalizeName(d.key) === wanted) ??
    defs.find((d) => {
      const n = normalizeName(d.name);
      return n.length > 2 && (n.includes(wanted) || wanted.includes(n));
    }) ??
    null
  );
}

/** Matches free text against a select option's label or raw value,
 *  across *every* `select` property this type actually has — not just
 *  the first one — so e.g. a Baud Rate option and a Role option on the
 *  same component type are each still individually reachable. */
export function matchPropertyOptionByValue(
  type: string,
  text: string,
): { def: PropertyDef; value: string } | null {
  const wanted = text.trim().toLowerCase();
  if (!wanted) return null;
  for (const def of listProperties(type)) {
    if (def.type !== 'select' || !def.options) continue;
    const option = def.options.find(
      (o) => o.label.toLowerCase() === wanted || String(o.value).toLowerCase() === wanted,
    );
    if (option) return { def, value: option.value };
  }
  return null;
}

const BOOLEAN_WORDS: Readonly<Record<string, boolean>> = {
  true: true, on: true, yes: true, enable: true, enabled: true, active: true,
  false: false, off: false, no: false, disable: false, disabled: false, inactive: false,
};

/** Matches an on/off-style word against this type's boolean
 *  properties. Only resolves when exactly one boolean property exists
 *  on the type — with two or more (ambiguous which one "on" refers
 *  to) this deliberately returns null rather than guessing; the
 *  property must be named explicitly in that case. */
export function matchPropertyBooleanByValue(type: string, text: string): { def: PropertyDef; value: boolean } | null {
  const wanted = text.trim().toLowerCase();
  if (!(wanted in BOOLEAN_WORDS)) return null;
  const boolDefs = listProperties(type).filter((d) => d.type === 'boolean');
  if (boolDefs.length !== 1) return null;
  return { def: boolDefs[0], value: BOOLEAN_WORDS[wanted] };
}

/** The first `number`/`presetNumber` property a type defines — the
 *  same "primary value" convention the rest of HORUS already uses
 *  (`EditApplier`'s old `primaryPropertyKey`, `CircuitToolBridge`'s
 *  read-side `value` field) for a bare numeric edit with no property
 *  named (e.g. "set R1 to 220"). */
export function primaryNumericProperty(type: string): PropertyDef | null {
  return listProperties(type).find((d) => d.type === 'number' || d.type === 'presetNumber') ?? null;
}

export type PropertyCoercion =
  | { ok: true; value: number | string | boolean }
  | { ok: false; message: string };

/** Turns free text into the real typed value `def` expects, with a
 *  clear, property-specific message on failure (bad number, out of
 *  range, unrecognized option/boolean word) — generic over every
 *  `PropertyDef['type']`, never a per-component special case. */
export function coercePropertyValue(def: PropertyDef, rawText: string): PropertyCoercion {
  const text = rawText.trim();
  switch (def.type) {
    case 'number':
    case 'presetNumber': {
      // Anchored at the start: a leading number only, same convention
      // `CircuitEditPlanner.parsePropertyValue` already uses (e.g.
      // "220Ω" -> 220). Deliberately NOT a bare digit search anywhere
      // in the text — "frequency to 5" must not be read as "5" once
      // "frequency" fails to match any real property; that case should
      // report "no such property", not silently fall back to whichever
      // numeric property happens to be primary.
      const match = text.match(/^-?[\d.]+/);
      const n = match ? Number(match[0]) : NaN;
      if (!Number.isFinite(n)) {
        return { ok: false, message: `"${rawText}" isn't a recognizable number for ${def.name}.` };
      }
      if (def.min !== undefined && n < def.min) {
        return { ok: false, message: `${def.name} must be at least ${def.min}${def.unit ?? ''} (got ${n}${def.unit ?? ''}).` };
      }
      if (def.max !== undefined && n > def.max) {
        return { ok: false, message: `${def.name} must be at most ${def.max}${def.unit ?? ''} (got ${n}${def.unit ?? ''}).` };
      }
      return { ok: true, value: n };
    }
    case 'boolean': {
      const wanted = text.toLowerCase();
      if (!(wanted in BOOLEAN_WORDS)) {
        return { ok: false, message: `"${rawText}" isn't recognizable as on/off for ${def.name}.` };
      }
      return { ok: true, value: BOOLEAN_WORDS[wanted] };
    }
    case 'select': {
      const wanted = text.toLowerCase();
      const option = def.options?.find(
        (o) => o.label.toLowerCase() === wanted || String(o.value).toLowerCase() === wanted,
      );
      if (!option) {
        const choices = (def.options ?? []).map((o) => o.label).join(', ') || '(no options defined)';
        return { ok: false, message: `"${rawText}" isn't a valid ${def.name}. Choices: ${choices}.` };
      }
      return { ok: true, value: option.value };
    }
    case 'string':
      if (text.length === 0) return { ok: false, message: `${def.name} can't be empty.` };
      return { ok: true, value: text };
    default:
      return { ok: false, message: `${def.name} has an unrecognized property type.` };
  }
}

interface PropertyValueResolution {
  key: string;
  def: PropertyDef;
  value: number | string | boolean;
}

type PropertyResolutionField = 'property' | 'value';

/**
 * Resolves free text like "Baud Rate to 19200", "resistance: 220",
 * "color = green", or a bare "220"/"green"/"on" into a real
 * `{ key, value }` pair, checked against `type`'s *entire* property
 * schema — never just the first entry.
 *
 * Two shapes:
 *  1. "<property> <to|:|=> <value>" — the property is named
 *     explicitly, resolved by `matchPropertyByName`, then its value
 *     coerced by that property's own type. This is what lets a
 *     multi-property component (e.g. HC-05: Role, Baud Rate, Logic
 *     Level, Powered, Connected) have any one of its properties
 *     targeted individually.
 *  2. A bare value with no property named — tried, in order, against
 *     every `select` option across all of the type's select
 *     properties, then an unambiguous boolean property, then the
 *     primary numeric property. This preserves exactly the shape of
 *     requests HORUS already supported ("change LED to green", "set
 *     R1 to 220Ω") while now checking the *real*, full property list
 *     instead of a two-case special path.
 */
export function resolvePropertyAndValue(
  type: string,
  text: string,
): { ok: true; resolution: PropertyValueResolution } | { ok: false; field: PropertyResolutionField; message: string } {
  const trimmed = text.trim();
  if (!trimmed) {
    return { ok: false, field: 'value', message: 'No new value was given.' };
  }

  const named = trimmed.match(/^(.+?)\s*(?:\bto\b|[:=])\s*(.+)$/i);
  if (named) {
    const def = matchPropertyByName(type, named[1]);
    if (def) {
      const coerced = coercePropertyValue(def, named[2]);
      if (!coerced.ok) return { ok: false, field: 'value', message: coerced.message };
      return { ok: true, resolution: { key: def.key, def, value: coerced.value } };
    }
    // Falls through — the text before "to"/":"/"=" didn't name a real
    // property of this type, so try the whole phrase as a bare value
    // below rather than failing immediately (handles cases like a
    // select option whose label itself contains "to"/"=").
  }

  const optionMatch = matchPropertyOptionByValue(type, trimmed);
  if (optionMatch) {
    return { ok: true, resolution: { key: optionMatch.def.key, def: optionMatch.def, value: optionMatch.value } };
  }

  const boolMatch = matchPropertyBooleanByValue(type, trimmed);
  if (boolMatch) {
    return { ok: true, resolution: { key: boolMatch.def.key, def: boolMatch.def, value: boolMatch.value } };
  }

  const numDef = primaryNumericProperty(type);
  if (numDef) {
    const coerced = coercePropertyValue(numDef, trimmed);
    if (coerced.ok) return { ok: true, resolution: { key: numDef.key, def: numDef, value: coerced.value } };
  }

  return { ok: false, field: 'value', message: `"${text}" isn't a recognizable property or value.` };
}

function valuesMatch(a: number | string | boolean | undefined, b: number | string | boolean): boolean {
  if (a === undefined) return false;
  if (typeof a === 'number' && typeof b === 'number') {
    return Math.abs(a - b) < 1e-9;
  }
  return a === b;
}

// ---------------------------------------------------------------------
// Execution + verification
// ---------------------------------------------------------------------

export type PropertyEngineStatus = 'applied' | 'error';
export type PropertyEngineField = 'target' | 'property' | 'value' | 'verification';

export interface PropertyEngineResult {
  status: PropertyEngineStatus;
  componentId?: number;
  /** The real `PropertyDef.key` that was targeted, once resolved. */
  key?: string;
  /** The coerced value that was requested. */
  value?: number | string | boolean;
  /** True only once the post-write read-back confirmed the value —
   *  present only on `status: 'applied'`. Success is never reported
   *  without this. */
  verified?: boolean;
  field?: PropertyEngineField;
  message?: string;
}

/** Tool contract the engine needs: the existing read/write bridge,
 *  plus the read-back `getComponentProperties` gives it to verify a
 *  write actually landed. `circuitToolBridge` (below) is the one real
 *  implementation. */
export type IPropertyEngineTool = ICircuitTool &
  ICircuitToolMutator & {
    getComponentProperties(componentId: number): Record<string, number | string | boolean> | null;
  };

export class PropertyEngine {
  private readonly tool: IPropertyEngineTool;

  constructor(tool: IPropertyEngineTool) {
    this.tool = tool;
  }

  /** Every real editable property of `componentId`, with current
   *  values — the "discover what this component supports" entry
   *  point. Null when the component doesn't exist. */
  discover(componentId: number): PropertySnapshot | null {
    return getPropertySnapshot(this.tool, componentId);
  }

  /**
   * Resolves free text (naming a property explicitly, or a bare
   * value) against `componentId`'s real, full property schema,
   * applies it, and verifies it. This is the generic replacement for
   * "primary numeric property + select options only" — any property
   * of any component type is reachable, and a component with nothing
   * matching the text is reported clearly rather than silently
   * defaulting to the wrong property.
   */
  applyFromText(componentId: number, text: string): PropertyEngineResult {
    const snapshot = this.discover(componentId);
    if (!snapshot) {
      return { status: 'error', field: 'target', message: `Component ${componentId} not found.` };
    }
    if (snapshot.properties.length === 0) {
      const name = componentNames[snapshot.type] ?? snapshot.type;
      return {
        status: 'error',
        componentId,
        field: 'property',
        message: `${snapshot.label} (${name}) has no editable properties.`,
      };
    }

    const resolved = resolvePropertyAndValue(snapshot.type, text);
    if (!resolved.ok) {
      const available = snapshot.properties.map((p) => p.def.name).join(', ');
      return {
        status: 'error',
        componentId,
        field: resolved.field,
        message: `${resolved.message} ${snapshot.label} supports: ${available}.`,
      };
    }
    return this.writeAndVerify(componentId, resolved.resolution.key, resolved.resolution.value);
  }

  /**
   * Sets a property named explicitly by key or display name (e.g.
   * `"resistance"` or `"Resistance"`, `"baudRate"` or `"Baud Rate"`)
   * to a raw text value. For callers (a future explicit
   * component→property→value UI path, or tests) that already know
   * which property they mean rather than needing it inferred from a
   * full sentence.
   */
  setPropertyFromText(componentId: number, propertyNameOrKey: string, rawValueText: string): PropertyEngineResult {
    const snapshot = this.discover(componentId);
    if (!snapshot) {
      return { status: 'error', field: 'target', message: `Component ${componentId} not found.` };
    }
    const entry = snapshot.properties.find((p) => p.def.key === propertyNameOrKey);
    const def = entry?.def ?? matchPropertyByName(snapshot.type, propertyNameOrKey);
    if (!def) {
      const available = snapshot.properties.map((p) => p.def.name).join(', ') || 'none';
      return {
        status: 'error',
        componentId,
        field: 'property',
        message: `${snapshot.label} has no "${propertyNameOrKey}" property. Editable properties: ${available}.`,
      };
    }
    const coerced = coercePropertyValue(def, rawValueText);
    if (!coerced.ok) {
      return { status: 'error', componentId, field: 'value', message: coerced.message };
    }
    return this.writeAndVerify(componentId, def.key, coerced.value);
  }

  /**
   * Executes the real write through `ICircuitToolMutator.changeComponentValue`
   * (which already validates the value against the same schema) and
   * then re-reads the component's real `props` to confirm the value
   * actually took — success is reported only once that read-back
   * matches. A `changeComponentValue` rejection, or a read-back
   * mismatch, both come back as `status: 'error'`, never a thrown
   * exception and never a claimed success the simulator doesn't
   * actually reflect.
   */
  private writeAndVerify(
    componentId: number,
    key: string,
    value: number | string | boolean,
  ): PropertyEngineResult {
    const applied = this.tool.changeComponentValue(componentId, key, value);
    if (!applied) {
      return {
        status: 'error',
        componentId,
        key,
        value,
        field: 'value',
        message: `The simulator rejected setting "${key}" to "${value}".`,
      };
    }

    const after = this.tool.getComponentProperties(componentId);
    const verified = valuesMatch(after ? after[key] : undefined, value);
    if (!verified) {
      return {
        status: 'error',
        componentId,
        key,
        value,
        verified: false,
        field: 'verification',
        message: `"${key}" could not be verified in the simulator after the update.`,
      };
    }

    return { status: 'applied', componentId, key, value, verified: true };
  }
}

/** Shared instance backed by `circuitToolBridge` — the same live
 *  circuit `EditApplier`/`EditValidator` already read and write
 *  through, so this never becomes a second source of circuit truth. */
export const propertyEngine = new PropertyEngine(circuitToolBridge);
