/**
 * HORUS AI — Terminal Roles (Tools) — Phase 3 (Auto Wiring).
 *
 * A `CircuitPlan`'s connections are described in engineering terms
 * ("battery positive", "LED anode") rather than raw terminal labels,
 * because the same role can map to a different literal label per
 * component type (`'+' ` on a battery, `'A'` on an LED, `'1'` on a
 * plain two-pin part with no polarity). This table is the single
 * place that mapping lives, sourced directly from the simulator's own
 * `defaultTerminals` (`componentDefs.ts`) labels — never invented.
 *
 * Deliberately small: only the component types Phase 3's planned
 * scenarios currently reference. A type/role pair with no entry here
 * is reported by `WiringExecutor` as unavailable rather than guessed.
 */
import type { ComponentType } from '../../circuit/types';

/** A connection endpoint's role name, e.g. `'positive'`, `'anode'`,
 *  `'pin1'` — resolved to a real terminal label via this table. */
export type TerminalRole = string;

const ROLES: Partial<Record<ComponentType, Record<TerminalRole, string>>> = {
  battery: { positive: '+', negative: '-' },
  dcCurrentSource: { positive: '+', negative: '-' },
  solenoidValve: { positive: '+', negative: '-' },
  dcMotor: { positive: '+', negative: '-' },
  waterPump: { positive: '+', negative: '-' },
  buzzer: { positive: '+', negative: '-' },
  activeBuzzer: { positive: '+', negative: '-' },
  passiveBuzzer: { positive: '+', negative: '-' },
  voltmeter: { positive: '+', negative: '-' },

  led: { anode: 'A', cathode: 'K' },
  diode: { anode: 'A', cathode: 'K' },
  zenerDiode: { anode: 'A', cathode: 'K' },

  // Non-polarized two-pin parts: either terminal is electrically
  // equivalent, so both roles are exposed under generic names — a
  // caller in a series chain still needs two distinct terminal labels
  // to wire "the other side" of the part.
  resistor: { pin1: '1', pin2: '2' },
  capacitor: { pin1: '1', pin2: '2' },
  inductor: { pin1: '1', pin2: '2' },
  fuse: { pin1: '1', pin2: '2' },
  polyfuse: { pin1: '1', pin2: '2' },
  switch: { pin1: '1', pin2: '2' },
  pushButton: { pin1: '1', pin2: '2' },
  ammeter: { pin1: '1', pin2: '2' },
  bulb: { pin1: '1', pin2: '2' },
};

/** Arduino-family boards: `defaultTerminals` gives every board its own
 *  large, board-specific set of real labels (`D0`..`D13`/`D53`,
 *  `A0`..`A15`, `GND`, `5V`, `3V3`, `VIN`, `RESET`, `AREF`, the ICSP
 *  header). Those labels are already the engineering-level name (a
 *  role of `'GND'` or `'D2'` *is* the terminal label), so a controller
 *  board resolves any role identically to itself rather than through
 *  a fixed table — `WiringExecutor`'s live-terminal check (against
 *  that specific board instance's real terminals) is what actually
 *  confirms a given pin exists, never this function. */
const CONTROLLER_TYPES = new Set<ComponentType>(['arduino', 'arduinoMega', 'arduinoNano']);

/**
 * Resolves `role` for `type` to a real terminal label — from the
 * table above (or, for Arduino-family boards, identity) only, never
 * derived or guessed. `null` means this component type has no such
 * role, which the caller (`WiringExecutor`) reports as an unavailable
 * terminal rather than picking anything else.
 */
export function resolveTerminalLabel(type: string, role: TerminalRole): string | null {
  if (CONTROLLER_TYPES.has(type as ComponentType)) return role;
  const roles = ROLES[type as ComponentType];
  if (!roles) return null;
  return roles[role] ?? null;
}

/** True when `type` has any known roles at all — lets a caller
 *  distinguish "unknown component type" from "known type, unknown
 *  role" when building a failure reason. */
export function hasKnownRoles(type: string): boolean {
  return CONTROLLER_TYPES.has(type as ComponentType) || Boolean(ROLES[type as ComponentType]);
}
