/**
 * HORUS AI — Circuit Tool Bridge.
 *
 * `CircuitTool` (see `core/Tools/ToolRegistry.ts`) has always been just a
 * placeholder name — no implementation existed, so `runtime.ts` fell back
 * to `EmptyCircuitTool` and every AI prompt carried an always-empty
 * circuit ("Circuit context: Selected: none"), regardless of what was
 * actually open in the Electrical Lab.
 *
 * This file does NOT create a new CircuitTool. It is a thin adapter that
 * reads and writes through the same, single `CircuitEditor` instance
 * `ElectricalLab.tsx` already owns via `editorRef`. `ElectricalLab`
 * registers/unregisters that exact instance with this bridge on
 * mount/unmount; nothing here constructs a `CircuitEditor`, duplicates
 * its state, or reimplements the Simulator's mutation logic.
 *
 * Two halves:
 *  - Read side (`getComponents`/`getWires`/`getSelectedComponent`):
 *    satisfies the existing `ICircuitTool` read contract
 *    (`CircuitContextBuilder.ts`) unchanged, same as before.
 *  - Mutation side (`addComponent`/`removeComponent`/`replaceComponent`/
 *    `connectComponents`/`disconnectComponents`/`changeComponentValue`):
 *    each one maps straight onto the Simulator's own existing
 *    `CircuitEditor` methods (`addComponentAt`, `connectByLabel`,
 *    `deleteSelected`, `updateComponentProperty`, `buildCircuit`) — the
 *    same methods the Simulator/AI Electrical Engineer already calls.
 *    Nothing here talks to `state.components`/`state.wires` directly
 *    except to look ids up; every actual mutation goes through a
 *    `CircuitEditor` method that already exists, so history/undo,
 *    re-render, terminal-position recompute, and junction cleanup all
 *    keep working exactly as they do for every other caller of those
 *    methods. `CircuitEditor` itself is untouched.
 */

import type { CircuitEditor } from '../../circuit/CircuitEditor';
import type { Component, ComponentType } from '../../circuit/types';
import { defaultProperties } from '../../circuit/componentDefs';
import type {
  ICircuitTool,
  CircuitToolComponent,
  CircuitToolWire,
  CircuitToolSelectedComponent,
} from './CircuitContextBuilder';

/**
 * Write contract the mutation side of `CircuitToolBridge` satisfies.
 * Split out from `ICircuitTool` (the pre-existing read contract) the
 * same way `ICircuitTool` itself is split from `CircuitContextBuilder` —
 * a caller that only needs to apply edits (e.g. an executor stage)
 * depends on this interface, not the concrete `CircuitToolBridge`
 * class or `CircuitEditor`.
 */
export interface ICircuitToolMutator {
  addComponent(type: ComponentType, x?: number, y?: number): CircuitToolComponent | null;
  removeComponent(componentId: number): boolean;
  replaceComponent(componentId: number, newType: ComponentType): CircuitToolComponent | null;
  connectComponents(
    componentIdA: number,
    terminalLabelA: string,
    componentIdB: number,
    terminalLabelB: string
  ): CircuitToolWire | null;
  disconnectComponents(componentIdA: number, componentIdB: number): boolean;
  changeComponentValue(componentId: number, key: string, value: number | string | boolean): boolean;
  /** Repositions every real component into a non-overlapping layout.
   *  A thin pass-through to `CircuitEditor.autoArrangeCircuit()` — see
   *  that method's own doc comment for the layout it produces. Returns
   *  how many components it moved (`0` when no editor is open or
   *  there's nothing to arrange). */
  autoArrange(): { moved: number };
}

class CircuitToolBridge implements ICircuitTool, ICircuitToolMutator {
  private editor: CircuitEditor | null = null;

  /** Called by ElectricalLab once its CircuitEditor instance exists. */
  register(editor: CircuitEditor): void {
    this.editor = editor;
  }

  /** Called by ElectricalLab on unmount, so a stale editor is never read. */
  unregister(editor: CircuitEditor): void {
    if (this.editor === editor) this.editor = null;
  }

  getComponents(): CircuitToolComponent[] {
    if (!this.editor) return [];
    return this.editor.state.components.map((c) => this.toCircuitToolComponent(c));
  }

  getWires(): CircuitToolWire[] {
    if (!this.editor) return [];
    return this.editor.state.wires.map((w) => ({
      id: w.id,
      fromComponentId: w.fromCompId,
      toComponentId: w.toCompId,
    }));
  }

  getSelectedComponent(): CircuitToolSelectedComponent {
    if (!this.editor) return null;
    const selectedId = this.editor.state.selectedComponentIds[0];
    if (selectedId === undefined) return null;
    const comp = this.editor.state.components.find((c) => c.id === selectedId);
    if (!comp) return null;
    return this.toCircuitToolComponent(comp);
  }

  /**
   * Read-only access to the real, unreshaped `Component[]`/`Wire[]` the
   * live `CircuitEditor` holds (terminals, props, rotation, etc. intact) —
   * for callers that need to run existing engines that operate on these
   * types directly (`errorDetector.detectCircuitErrors`, `simulateDC`,
   * `convertCircuitToPCB`), rather than the simplified `CircuitToolComponent`/
   * `CircuitToolWire` shapes above. Never mutates anything; returns empty
   * arrays when no editor is registered, exactly like the read side above.
   */
  getRawComponents(): Component[] {
    if (!this.editor) return [];
    return this.editor.state.components;
  }

  getRawWires(): import('../../circuit/types').Wire[] {
    if (!this.editor) return [];
    return this.editor.state.wires;
  }

  /** The real, unreshaped selected `Component`, or `null` — same
   *  read-only rationale as `getRawComponents`/`getRawWires` above. */
  getRawSelectedComponent(): Component | null {
    if (!this.editor) return null;
    const selectedId = this.editor.state.selectedComponentIds[0];
    if (selectedId === undefined) return null;
    return this.editor.state.components.find((c) => c.id === selectedId) ?? null;
  }

  /**
   * Reshapes a real `Component` into the `CircuitToolComponent` read
   * shape, adding position/color/value best-effort from that
   * component's own `props` and `defaultProperties[type]` schema — the
   * same schema `isValidPropertyValue` (below) and `EditApplier`'s
   * `primaryPropertyKey` already read from. Read-only: never touches
   * `props` or anything else on the real component.
   */
  private toCircuitToolComponent(c: Component): CircuitToolComponent {
    const propDefs = defaultProperties[c.type] ?? [];

    const colorDef = propDefs.find((p) => p.key === 'color');
    let color: string | undefined;
    if (colorDef) {
      const raw = c.props[colorDef.key];
      if (colorDef.type === 'select' && colorDef.options) {
        color = colorDef.options.find((opt) => opt.value === raw)?.label;
      } else if (typeof raw === 'string') {
        color = raw;
      }
    }

    const valueDef = propDefs[0];
    let value: string | undefined;
    if (valueDef) {
      const raw = c.props[valueDef.key];
      if (typeof raw === 'number') {
        value = valueDef.unit ? `${raw}${valueDef.unit}` : String(raw);
      } else if (typeof raw === 'string' || typeof raw === 'boolean') {
        value = String(raw);
      }
    }

    return { id: c.id, type: c.type, label: c.label, x: c.x, y: c.y, color, value };
  }

  /**
   * Real, unformatted `props` map for `componentId` (e.g.
   * `{ resistance: 220 }`), read straight from the live `Component` —
   * a shallow copy, never a reference into editor state, so a caller
   * can't mutate the circuit by touching the returned object. This is
   * the read-back `PropertyEngine` uses to verify a `changeComponentValue`
   * write actually landed in the simulator, rather than trusting that
   * call's boolean return alone. Null when the component doesn't exist
   * or no editor is registered.
   */
  getComponentProperties(componentId: number): Record<string, number | string | boolean> | null {
    if (!this.editor) return null;
    const comp = this.editor.state.components.find((c) => c.id === componentId);
    if (!comp) return null;
    return { ...comp.props };
  }

  getComponentTerminalLabels(componentId: number): string[] {
    if (!this.editor) return [];
    const comp = this.editor.state.components.find((c) => c.id === componentId);
    if (!comp) return [];
    return comp.terminals.map((t) => t.label);
  }

  // ---------------------------------------------------------------------
  // Mutators. Each of these is a thin call-through to an existing
  // `CircuitEditor` method — see file header. All of them are no-ops
  // (returning null/false) when no editor is registered, same as the
  // read side returning empty data.
  // ---------------------------------------------------------------------

  /**
   * Adds a component of `type` at grid position (`x`, `y`) (default
   * origin when omitted). Calls through to `CircuitEditor.addComponentAt`
   * — the same primitive the AI Electrical Engineer's circuit builder
   * already uses — wrapped in `buildCircuit` so it gets one undo step,
   * a terminal-position recompute, and a single re-render, exactly like
   * every other `buildCircuit` caller.
   */
  addComponent(type: ComponentType, x = 0, y = 0): CircuitToolComponent | null {
    if (!this.editor) return null;
    const editor = this.editor;
    let created: ReturnType<CircuitEditor['addComponentAt']> | null = null;
    editor.buildCircuit((e) => {
      created = e.addComponentAt(type, x, y);
    });
    if (!created) return null;
    return { id: created.id, type: created.type, label: created.label };
  }

  /**
   * Removes the component identified by `componentId`, along with any
   * wires attached to it. Calls through to `CircuitEditor.deleteSelected`
   * — the same method the Simulator UI uses for Delete/Backspace — by
   * selecting just that component first. The caller's prior selection is
   * restored afterward (filtered to ids that still exist), so this never
   * clobbers whatever the user had selected in the Electrical Lab.
   */
  removeComponent(componentId: number): boolean {
    if (!this.editor) return false;
    const editor = this.editor;
    if (!editor.state.components.some((c) => c.id === componentId)) return false;

    const prevComponents = editor.state.selectedComponentIds;
    const prevWires = editor.state.selectedWireIds;

    editor.state.selectedComponentIds = [componentId];
    editor.state.selectedWireIds = [];
    editor.deleteSelected();

    editor.state.selectedComponentIds = prevComponents.filter(
      (id) => id !== componentId && editor.state.components.some((c) => c.id === id)
    );
    editor.state.selectedWireIds = prevWires.filter((id) =>
      editor.state.wires.some((w) => w.id === id)
    );
    return true;
  }

  /**
   * Replaces the component at `componentId` with a new component of
   * `newType` in the same grid position. Composed entirely from existing
   * primitives — `removeComponent` (above, itself `deleteSelected`) then
   * `addComponentAt` via `buildCircuit` — since `CircuitEditor` has no
   * single "replace" method. Any wires the old component had are not
   * carried over (removal drops them, same as deleting it by hand would);
   * the caller is expected to reconnect via `connectComponents`.
   */
  replaceComponent(componentId: number, newType: ComponentType): CircuitToolComponent | null {
    if (!this.editor) return null;
    const editor = this.editor;
    const old = editor.state.components.find((c) => c.id === componentId);
    if (!old) return null;
    const { x, y } = old;

    if (!this.removeComponent(componentId)) return null;
    return this.addComponent(newType, x, y);
  }

  /**
   * Connects terminal `terminalLabelA` on component `componentIdA` to
   * terminal `terminalLabelB` on component `componentIdB`. Calls through
   * to `CircuitEditor.connectByLabel` — the same primitive the AI
   * Electrical Engineer's circuit builder already uses to wire generated
   * circuits — wrapped in `buildCircuit` for one undo step + re-render.
   *
   * Before entering `buildCircuit` (so a bad call never even creates an
   * undo step), both terminal labels are resolved against the real
   * `Component.terminals` — the same lookup `connectByLabel` itself does
   * — and rejected if either is missing. The two *terminals* (not just
   * the two components — a multi-pin component can legitimately have
   * several separate wires to another) are then checked against the
   * existing wire list; if that exact terminal pair is already wired,
   * this is a no-op rather than a second, duplicate wire. Finally, the
   * wire `connectByLabel` returns is confirmed present in
   * `editor.state.wires` before being reported as created — success is
   * only ever reported once the wire actually exists on the circuit.
   */
  connectComponents(
    componentIdA: number,
    terminalLabelA: string,
    componentIdB: number,
    terminalLabelB: string
  ): CircuitToolWire | null {
    if (!this.editor) return null;
    const editor = this.editor;
    const compA = editor.state.components.find((c) => c.id === componentIdA);
    const compB = editor.state.components.find((c) => c.id === componentIdB);
    if (!compA || !compB) return null;

    const termA = compA.terminals.find((t) => t.label === terminalLabelA);
    const termB = compB.terminals.find((t) => t.label === terminalLabelB);
    if (!termA || !termB) return null;

    const alreadyWired = editor.state.wires.some(
      (w) =>
        (w.fromTerminalId === termA.id && w.toTerminalId === termB.id) ||
        (w.fromTerminalId === termB.id && w.toTerminalId === termA.id)
    );
    if (alreadyWired) return null;

    let created: ReturnType<CircuitEditor['connectByLabel']> = null;
    editor.buildCircuit((e) => {
      created = e.connectByLabel(compA, terminalLabelA, compB, terminalLabelB);
    });
    if (!created) return null;

    const persisted = editor.state.wires.find((w) => w.id === created!.id);
    if (!persisted) return null;

    return {
      id: persisted.id,
      fromComponentId: persisted.fromCompId,
      toComponentId: persisted.toCompId,
    };
  }

  /**
   * Removes every wire directly connecting `componentIdA` and
   * `componentIdB`. Calls through to `CircuitEditor.deleteSelected` by
   * selecting just those wires, the same pattern `removeComponent` above
   * uses, restoring the caller's prior selection afterward. Returns false
   * (no-op) when the two components aren't directly wired together, and
   * only reports success once none of those wires remain in
   * `editor.state.wires`.
   */
  disconnectComponents(componentIdA: number, componentIdB: number): boolean {
    if (!this.editor) return false;
    const editor = this.editor;
    const matching = editor.state.wires.filter(
      (w) =>
        (w.fromCompId === componentIdA && w.toCompId === componentIdB) ||
        (w.fromCompId === componentIdB && w.toCompId === componentIdA)
    );
    if (matching.length === 0) return false;
    const matchingIds = new Set(matching.map((w) => w.id));

    const prevComponents = editor.state.selectedComponentIds;
    const prevWires = editor.state.selectedWireIds;

    editor.state.selectedComponentIds = [];
    editor.state.selectedWireIds = matching.map((w) => w.id);
    editor.deleteSelected();

    editor.state.selectedComponentIds = prevComponents.filter((id) =>
      editor.state.components.some((c) => c.id === id)
    );
    editor.state.selectedWireIds = prevWires.filter(
      (id) => !matchingIds.has(id) && editor.state.wires.some((w) => w.id === id)
    );

    return !editor.state.wires.some((w) => matchingIds.has(w.id));
  }

  /**
   * Auto Arrange (Phase 4): calls straight through to the Simulator's
   * own `CircuitEditor.autoArrangeCircuit()` — nothing here reimplements
   * layout, invents a coordinate scheme, or duplicates position state.
   * That method already guarantees non-overlap (grid-packed, sized to
   * each component's real terminal extents) and leaves every wire's
   * electrical endpoints untouched, so calling it before wiring (Phase
   * 3) or after is equally safe.
   */
  autoArrange(): { moved: number } {
    if (!this.editor) return { moved: 0 };
    return this.editor.autoArrangeCircuit();
  }

  /**
   * Sets property `key` (e.g. `'resistance'`, `'voltage'`) on component
   * `componentId` to `value`. Calls through to
   * `CircuitEditor.updateComponentProperty` — the same method the
   * Property Panel already uses on every keystroke — so history,
   * re-simulation (when running), and re-render (which refreshes the
   * Property Panel via `onSelectionChange`) all happen exactly as they
   * do for a manual edit.
   *
   * Before touching the real component, `value` is checked against that
   * component type's own `PropertyDef` (`defaultProperties` in
   * `componentDefs.ts` — the same schema the Property Panel's inputs
   * are built from): the property must exist for this component type,
   * and the value must be the right kind (a finite number in range for
   * `'number'`/`'presetNumber'`, one of the defined options for
   * `'select'`, a boolean for `'boolean'`). Nothing is applied and
   * `false` is returned when a check fails, so an invalid value from
   * the AI (or any other caller) never reaches the simulator.
   */
  changeComponentValue(componentId: number, key: string, value: number | string | boolean): boolean {
    if (!this.editor) return false;
    const comp = this.editor.state.components.find((c) => c.id === componentId);
    if (!comp) return false;
    if (!this.isValidPropertyValue(comp.type, key, value)) return false;

    this.editor.updateComponentProperty(componentId, key, value);
    return true;
  }

  /**
   * Validates `value` for property `key` on a component of `type`
   * against that type's `PropertyDef` (see `changeComponentValue`
   * above). Read-only — never touches the editor or the component.
   */
  private isValidPropertyValue(
    type: ComponentType,
    key: string,
    value: number | string | boolean
  ): boolean {
    const propDefs = defaultProperties[type];
    if (!propDefs) return false;
    const def = propDefs.find((p) => p.key === key);
    if (!def) return false;

    switch (def.type) {
      case 'number':
      case 'presetNumber': {
        if (typeof value !== 'number' || !Number.isFinite(value)) return false;
        if (def.min !== undefined && value < def.min) return false;
        if (def.max !== undefined && value > def.max) return false;
        return true;
      }
      case 'boolean':
        return typeof value === 'boolean';
      case 'select':
        if (typeof value !== 'string') return false;
        return !def.options || def.options.some((opt) => opt.value === value);
      case 'string':
        return typeof value === 'string';
      default:
        return true;
    }
  }
}

/** Single shared instance — the "existing instance" every caller reuses. */
export const circuitToolBridge = new CircuitToolBridge();

// Development-mode inspection only: expose the bridge as `window.CircuitTool`
// so it can be poked at from the console. Never referenced by app logic.
if (import.meta.env.DEV) {
  (window as unknown as { CircuitTool: ICircuitTool }).CircuitTool = circuitToolBridge;
}
