/**
 * HORUS AI — Action Registry (for a future chat "Tools" menu).
 *
 * This module does NOT implement any action logic. It only exposes the
 * five existing HORUS actions — previously shown as cards in
 * `components/horus-ai/HorusAIView.tsx`, and already wired end-to-end via
 * `router/IntentRouter.ts` -> `core/Brain/IntentToolBridge.ts` ->
 * `core/Brain/ToolExecutor.ts` -> `core/Tools/*` — as a single, clean,
 * lookup-able list so a future chat Tools menu can call them by id
 * without knowing about `IntentRouter`/`IntentToolBridge` internals.
 *
 * Explicitly out of scope / untouched by this module:
 *  - No action's internal logic is changed, reimplemented, or mocked.
 *  - No AI provider is called here (same as `IntentToolBridge`).
 *  - No UI component is modified — nothing here is imported or rendered
 *    anywhere yet. A future chat Tools menu opts in by importing
 *    `horusActionRegistry` itself, in a later step.
 *  - The simulator/backend are not touched.
 *
 * Every entry below is a thin pass-through to `intentToolBridge.runIntent`,
 * the exact same call path the removed action cards used to trigger.
 */

import { intentToolBridge, type IIntentToolBridge } from '../core/Brain/IntentToolBridge';
import { intentRouter, type IIntentRouter, type HorusButtonIntent } from '../router/IntentRouter';
import type { ToolExecutionResult } from '../core/Brain/ToolExecutor';

/** Stable id for a HORUS action, independent of its display label. */
export type HorusActionId =
  | 'explain_component'
  | 'analyze_circuit'
  | 'generate_arduino'
  | 'fix_errors'
  | 'convert_pcb';

/** One entry in the registry: display metadata plus its existing intent. */
export interface HorusActionDefinition {
  /** Stable id, safe to store/reference (e.g. from a Tools-menu item). */
  id: HorusActionId;
  /** Same label previously shown on the action card. */
  label: string;
  /** The existing `HorusButtonIntent` this action already routes to. */
  intent: HorusButtonIntent;
}

export interface IHorusActionRegistry {
  /** List every registered action definition, in a stable order. */
  listActions(): readonly HorusActionDefinition[];

  /** Look up an action definition by its stable id. */
  getAction(id: HorusActionId): HorusActionDefinition | undefined;

  /** Look up an action definition by its display label (e.g. from a
   *  menu item's text), mirroring `IntentRouter.routeByLabel`. */
  getActionByLabel(label: string): HorusActionDefinition | undefined;

  /** Invoke an action's existing handler by id. Not called from
   *  anywhere yet — this is the entry point a future Tools menu will
   *  use once actions are wired up (out of scope for this step). */
  invoke(id: HorusActionId, input: unknown): ToolExecutionResult | undefined;
}

/**
 * The five existing HORUS actions, reusing `IntentRouter.BUTTON_INTENT_MAP`
 * as the single source of truth for labels/intents so this registry can
 * never drift out of sync with it.
 */
const ACTION_DEFINITIONS: readonly HorusActionDefinition[] = intentRouter
  .listMappings()
  .map(({ label, intent }) => ({ id: intent, label, intent }));

export class HorusActionRegistry implements IHorusActionRegistry {
  private readonly actions: ReadonlyMap<HorusActionId, HorusActionDefinition>;
  private readonly byLabel: ReadonlyMap<string, HorusActionDefinition>;
  private readonly router: IIntentRouter;
  private readonly bridge: IIntentToolBridge;

  constructor(
    definitions: readonly HorusActionDefinition[] = ACTION_DEFINITIONS,
    router: IIntentRouter = intentRouter,
    bridge: IIntentToolBridge = intentToolBridge,
  ) {
    this.actions = new Map(definitions.map((action) => [action.id, action]));
    this.byLabel = new Map(definitions.map((action) => [action.label, action]));
    this.router = router;
    this.bridge = bridge;
  }

  listActions(): readonly HorusActionDefinition[] {
    return Array.from(this.actions.values());
  }

  getAction(id: HorusActionId): HorusActionDefinition | undefined {
    return this.actions.get(id);
  }

  getActionByLabel(label: string): HorusActionDefinition | undefined {
    return this.byLabel.get(label);
  }

  invoke(id: HorusActionId, input: unknown): ToolExecutionResult | undefined {
    const action = this.getAction(id);
    if (!action) {
      return undefined;
    }
    // Reuses the exact same routed call the removed action cards used:
    // IntentRouter.route(intent) -> IntentToolBridge.runRoutedIntent(...).
    return this.bridge.runRoutedIntent(this.router.route(action.intent), input);
  }
}

/** Shared instance — mirrors `intentRouter` / `intentToolBridge` singletons.
 *  Not imported anywhere yet; reserved for the future chat Tools menu. */
export const horusActionRegistry = new HorusActionRegistry();
