import { describe, it, expect } from 'vitest';
import { horusActionRegistry, HorusActionRegistry } from '../HorusActionRegistry';
import { intentRouter } from '../../router/IntentRouter';
import { intentToolBridge } from '../../core/Brain/IntentToolBridge';

describe('HorusActionRegistry', () => {
  it('lists exactly the five existing HORUS actions', () => {
    const actions = horusActionRegistry.listActions();
    expect(actions).toHaveLength(5);
    expect(actions.map((a) => a.label).sort()).toEqual(
      [
        'Analyze Circuit',
        'Convert Circuit to PCB',
        'Explain Component',
        'Fix Circuit Errors',
        'Generate Arduino Code',
      ].sort(),
    );
  });

  it('stays in sync with IntentRouter.BUTTON_INTENT_MAP (single source of truth)', () => {
    const fromRouter = intentRouter.listMappings();
    const fromRegistry = horusActionRegistry.listActions();
    expect(fromRegistry).toHaveLength(fromRouter.length);
    for (const { label, intent } of fromRouter) {
      const action = horusActionRegistry.getActionByLabel(label);
      expect(action).toBeDefined();
      expect(action?.intent).toBe(intent);
      expect(action?.id).toBe(intent);
    }
  });

  it('getAction resolves each of the five action ids', () => {
    const ids = [
      'explain_component',
      'analyze_circuit',
      'generate_arduino',
      'fix_errors',
      'convert_pcb',
    ] as const;
    for (const id of ids) {
      expect(horusActionRegistry.getAction(id)?.id).toBe(id);
    }
  });

  it('invoke() delegates to the existing IntentToolBridge path (no duplicated logic)', () => {
    const viaRegistry = horusActionRegistry.invoke('analyze_circuit', { foo: 'bar' });
    const viaExistingBridge = intentToolBridge.runIntent('analyze_circuit', { foo: 'bar' });
    expect(viaRegistry?.status).toBe(viaExistingBridge.status);
    expect(viaRegistry?.toolName).toBe(viaExistingBridge.toolName);
  });

  it('invoke() returns undefined for an unknown action id', () => {
    // @ts-expect-error deliberately invalid id for the negative case
    expect(horusActionRegistry.invoke('not_a_real_action', {})).toBeUndefined();
  });

  it('is constructible with injected collaborators (extensible for future tools)', () => {
    const custom = new HorusActionRegistry();
    expect(custom.listActions()).toHaveLength(5);
  });
});
