/**
 * HORUS AI — runtime composition root.
 *
 * Wires the minimal, functional HORUS Brain pipeline (see
 * `core/Brain/HORUSBrain.ts`) together: PromptBuilder + PromptValidator +
 * SystemPromptManager on the prompt side, AIGateway + CoreAIProviderManager
 * + ProviderRegistry + AIProviderManager + AIConfiguration on the provider
 * side, with GeminiProvider registered as (currently) the only, and
 * therefore active, provider. Also wires `CircuitContextBuilder` and
 * `PromptContextFormatter` in: both `runHorusPrompt()` and
 * `sendChatMessage()` build the current circuit context and format it
 * into readable text before every AI request, automatically — the
 * caller/user never has to say "this circuit" — and `sendChatMessage()`
 * additionally attaches the raw JSON snapshot to `ConversationManager`.
 * Building, formatting, and attaching are all storage/passthrough only;
 * no analysis of the circuit happens anywhere in this file.
 *
 * This is the single place outside Settings that constructs these
 * objects — callers (UI components, services) should go through
 * `runHorusPrompt()` (stateless, single-shot) or `sendChatMessage()`
 * (stateful, conversation-aware — see `core/Chat/ChatManager.ts`)
 * below rather than importing HORUS's internals directly, the same
 * way they'd only ever have called `GeminiService.generate()` before.
 */

import { HORUSBrain } from './core/Brain/HORUSBrain';
import { ChatManager } from './core/Chat/ChatManager';
import { conversationManager, type ConversationTurn } from './core/Chat/ConversationManager';
import { PromptBuilder } from './core/Prompt/PromptBuilder';
import { PromptValidator } from './core/Prompt/PromptValidator';
import { SystemPromptManager } from './core/Prompt/SystemPromptManager';
import { AIGateway } from './core/AI/AIGateway';
import { CoreAIProviderManager } from './core/AI/AIProviderManager';
import { ProviderRegistry } from './provider/ProviderRegistry';
import { AIProviderManager } from './provider/AIProviderManager';
import { AIConfiguration } from './core/AIConfiguration';
import { GeminiClient } from './provider/GeminiClient';
import { GeminiProvider } from './provider/GeminiProvider';
import { getProviderConfig } from '../lib/aiProviderSettings';
import type { AIResponse } from './core/AI/AIResponse';
import { CircuitContextBuilder, type CircuitContextSnapshot } from './tools/CircuitContextBuilder';
import { circuitToolBridge } from './tools/CircuitToolBridge';
import { promptContextFormatter } from './core/Prompt/PromptContextFormatter';
import { circuitEditPlanner } from './core/Brain/CircuitEditPlanner';
import { circuitPlanner } from './core/Brain/CircuitPlanner';
import type { CircuitPlan } from './core/Brain/CircuitPlanner';
import { intentResolver } from './core/Brain/IntentResolver';
import { editValidator, type ValidatedEditPlan } from './tools/EditValidator';
import { smartComponentResolver } from './tools/SmartComponentResolver';
import { editExecutor, type EditExecutionResult } from './tools/EditExecutor';
import type { CircuitPlanExecutionResult } from './tools/CircuitPlanExecutor';
import { circuitBuildOrchestrator } from './tools/CircuitBuildOrchestrator';
import type { WiringExecutionResult } from './tools/WiringExecutor';
import type { ArrangeExecutionResult } from './tools/AutoArrangeExecutor';
import type { CircuitEditPlan } from './core/Brain/CircuitEditPlanner';
import type { CircuitToolComponent } from './tools/CircuitContextBuilder';

/**
 * "Change LED_2 color to green" parses (`CircuitEditPlanner`) into
 * target = "LED_2 color", propertyChange.raw = "green" — the planner
 * has no live circuit to know "LED_2" is the real component reference
 * and "color" is a property name, not part of it (see
 * `CircuitEditPlanner.ts`'s own "no execution/no circuit access"
 * scope). Left as one phrase, "LED_2 color" then spuriously
 * substring-matches *every* LED's `type` ("led") in both
 * `EditValidator.resolveComponent()` and `SmartComponentResolver`,
 * turning an unambiguous request into a false "which one did you
 * mean?".
 *
 * This splits that phrase against the real, live component list —
 * the same kind of real-data check `EditApplier`'s
 * `splitComponentAndTerminal()` already does for connect/disconnect
 * pin hints — preferring the longest leading word-sequence that
 * exactly matches a real component id/label. Only an *exact* id/label
 * match is accepted (never a fuzzy/substring one, which is exactly
 * the ambiguity this exists to avoid); text that doesn't contain one
 * is returned unchanged, so ordinary single-word targets ("R1") are
 * untouched. The trailing words removed (e.g. "color") are the
 * property-name hint, folded into the property-change text so
 * `PropertyEngine`'s own real, dynamic property-schema lookup
 * (`matchPropertyByName`) still sees them — this never guesses which
 * property, it only stops a real component name from being cut off.
 */
function splitChangeTargetAndPropertyHint(
  raw: string,
  components: readonly Pick<CircuitToolComponent, 'id' | 'label'>[],
): { componentText: string; hint: string | null } {
  const trimmed = raw.trim();
  const words = trimmed.split(/\s+/);
  if (words.length < 2) return { componentText: trimmed, hint: null };

  const isExactComponentRef = (text: string): boolean =>
    components.some((c) => c.label.toLowerCase() === text.toLowerCase() || String(c.id) === text);

  for (let i = words.length - 1; i >= 1; i--) {
    const candidate = words.slice(0, i).join(' ');
    if (isExactComponentRef(candidate)) {
      return { componentText: candidate, hint: words.slice(i).join(' ') };
    }
  }
  return { componentText: trimmed, hint: null };
}

/** Applies `splitChangeTargetAndPropertyHint()` to a `change_property`
 *  plan in place (new object — `plan` itself, from `CircuitEditPlanner`,
 *  is never mutated), so every downstream reader — `EditValidator`,
 *  `SmartComponentResolver`, `EditApplier`/`PropertyEngine` — sees the
 *  same clean target and combined value text. A no-op (returns `plan`
 *  unchanged) for every other action, and for `change_property` plans
 *  where no split was needed/possible. */
function normalizeChangePropertyPlan(
  plan: CircuitEditPlan,
  components: readonly Pick<CircuitToolComponent, 'id' | 'label'>[],
): CircuitEditPlan {
  if (plan.action !== 'change_property' || !plan.target) return plan;
  const { componentText, hint } = splitChangeTargetAndPropertyHint(plan.target.raw, components);
  if (!hint) return plan;
  // The stripped words are only ever needed to disambiguate *which*
  // real component is meant — `PropertyEngine.applyFromText()` already
  // resolves which *property* to set from the value text alone (a
  // color word against `select` options, a leading number against the
  // primary numeric property, etc. — see `resolvePropertyAndValue()`),
  // so the hint is dropped rather than glued onto the value text,
  // where it would just as easily break that existing resolution
  // (e.g. turn a clean "100Ω" into "value 100Ω", which matches
  // nothing) as help it.
  return { ...plan, target: { ...plan.target, raw: componentText } };
}

// Provider-side wiring. AIConfiguration is the same kind of in-memory
// store SettingsDialog uses for its own GeminiProvider instance — kept
// separate here since Brain and Settings' "Test Connection" have
// different lifecycles, but refreshed from the same localStorage-backed
// settings (`lib/aiProviderSettings.ts`) every call, see below.
const aiConfiguration = new AIConfiguration();
const providerRegistry = new ProviderRegistry();
const providerManager = new AIProviderManager(providerRegistry, aiConfiguration);
const coreProviderManager = new CoreAIProviderManager(providerRegistry, providerManager);

const geminiProvider = new GeminiProvider(new GeminiClient(), aiConfiguration);
providerManager.registerProvider(geminiProvider);
providerManager.setActiveProvider('gemini');

// Prompt-side wiring.
const promptBuilder = new PromptBuilder();
const promptValidator = new PromptValidator();
const systemPromptManager = new SystemPromptManager();
const aiGateway = new AIGateway(coreProviderManager);

const horusBrain = new HORUSBrain(promptBuilder, promptValidator, systemPromptManager, aiGateway);

// Chat-side wiring: ChatManager drives the same `horusBrain` instance
// above through its plain `run()` entry point (Chat -> Brain ->
// AIGateway -> Gemini Provider -> Brain -> Chat) — no tool execution,
// text conversation only. Uses `Chat/ConversationManager.ts`'s shared
// singleton for per-conversation history, the same default
// `ChatManager`'s own constructor already falls back to.
const chatManager = new ChatManager(horusBrain);

// Circuit-side wiring: reads the current circuit from CircuitTool (via
// `CircuitContextBuilder`) and returns it as one JSON snapshot.
// `circuitToolBridge` is the existing `ICircuitTool` instance — it reads
// straight from whichever `CircuitEditor` `ElectricalLab.tsx` currently
// has mounted, falling back to an empty circuit when none is (e.g. the
// Electrical Lab hasn't been opened yet). No analysis happens here or
// anywhere downstream of it in this file — the snapshot is only attached
// and passed through, never inspected.
const circuitContextBuilder = new CircuitContextBuilder(circuitToolBridge);

/**
 * Per-conversation pending clarification context: when an `add`'s
 * component type (or an existing-component reference) comes back
 * `ambiguous` below and `sendChatMessage()` has to ask a clarifying
 * question ("Which Arduino?"), the edit-request text that produced
 * that question is kept here — keyed by conversation — so the next
 * message, which is normally just the answer alone ("Mega"), can be
 * merged back into it ("Add Arduino" + "Mega" -> "Add Arduino Mega")
 * and re-planned as one request, instead of "Mega" falling through to
 * the plain AI chat flow (which has no tool access and could only
 * ever *claim* success in text, never actually call
 * `CircuitToolBridge`). Consumed (deleted) as soon as it's used, or
 * dropped unused if the next message already reads as its own
 * complete edit request (the user moved on) — see `sendChatMessage()`.
 * Deliberately minimal/in-memory, scoped to this composition root the
 * same way `aiConfiguration` etc. above are — not
 * `ConversationManager`'s concern (that module's own docs are explicit
 * about staying out of simulator/edit-request territory).
 */
const pendingClarifications = new Map<string, string>();

/** True when `text` reads as an edit request either directly
 *  (`CircuitEditPlanner`'s own English keyword parsing) or through
 *  `IntentResolver` (Arabic phrasing normalized to that same English
 *  vocabulary — see `IntentResolver.ts`). Used only to decide whether
 *  a follow-up message already stands on its own as a fresh request,
 *  or should instead be merged with a pending clarification (see
 *  `pendingClarifications` above) — never used to plan or execute
 *  anything itself. */
function isRecognizedRequest(text: string): boolean {
  if (circuitEditPlanner.isEditRequest({ request: text })) return true;
  return intentResolver.resolve(text).status !== 'unrecognized';
}

/**
 * True when `text` reads as a *goal* request ("create a simple LED
 * circuit", "build a traffic light system") rather than a single
 * Add/Remove/Connect edit (`circuitEditPlanner.isEditRequest()` above
 * already owns that). Deliberately narrow/keyword-gated, the same
 * style `ACTION_KEYWORDS` in `CircuitEditPlanner.ts` already uses —
 * this only decides *which* pipeline a request goes through, never
 * plans or executes anything itself.
 */
const GOAL_REQUEST_PATTERN = /\b(create|build|design|make)\b[\s\S]*\b(circuit|system)\b/i;

function isGoalBuildRequest(text: string): boolean {
  return GOAL_REQUEST_PATTERN.test(text);
}

/**
 * Build the current circuit context and render it as the readable text
 * `PromptContextFormatter` produces (e.g. "LED D1", "Battery 9V"), so
 * every prompt HORUS sends already carries it — the caller/user never
 * has to say "this circuit" for HORUS to know what's on the canvas.
 * No analysis: this only builds and formats the snapshot.
 */
function buildFormattedCircuitContext(): { snapshot: CircuitContextSnapshot; text: string } {
  const snapshot = circuitContextBuilder.build();
  return { snapshot, text: promptContextFormatter.format(snapshot) };
}

/**
 * Send a single text prompt through HORUS Brain and get back its text
 * response (or a joined error message). This is the HORUS-routed
 * replacement for calling `GeminiService.generate()` / any AI provider
 * directly from a button handler — the button only ever talks to Brain;
 * Brain is what decides which provider handles it.
 */
export async function runHorusPrompt(
  prompt: string,
  context?: { conversationContext?: unknown; projectContext?: unknown; memory?: unknown },
): Promise<{ ok: true; text: string } | { ok: false; error: string }> {
  // Pull whatever API key is currently saved in Settings, the same
  // source SettingsDialog's own "Test Connection" reads — so Brain's
  // Gemini call always reflects the latest saved key without requiring
  // a page reload.
  const { apiKey } = getProviderConfig('gemini');
  aiConfiguration.setProviderConfiguration('gemini', { apiKey });

  // Every prompt automatically carries the current circuit context, in
  // readable text form — not just when the caller happens to ask about
  // "this circuit".
  const { text: formattedCircuitContext } = buildFormattedCircuitContext();
  const projectContext =
    context?.projectContext !== undefined
      ? `${JSON.stringify(context.projectContext)}\n\n${formattedCircuitContext}`
      : formattedCircuitContext;

  const response: AIResponse = await horusBrain.run({
    userRequest: prompt,
    conversationContext: context?.conversationContext,
    projectContext,
    memory: context?.memory,
  });

  if (response.errors.length > 0) {
    return { ok: false, error: response.errors.map((error) => error.message).join(' ') };
  }
  if (!response.text) {
    return { ok: false, error: 'HORUS returned no response.' };
  }
  return { ok: true, text: response.text };
}

/**
 * Send one message in an ongoing chat conversation: records it, runs
 * it through HORUS Brain -> AIGateway -> Gemini Provider -> Brain (via
 * `ChatManager`/`run()`, so no tool execution — text conversation
 * only), records the reply, and returns both the reply text and the
 * conversation's updated history. This is the first real, stateful
 * message flow — `runHorusPrompt()` above stays as the stateless,
 * single-shot alternative for callers that don't need history.
 *
 * Edit-request short-circuit: before any of that, `CircuitEditPlanner`
 * checks whether the message reads as a circuit-edit request ("add
 * LED", "change R1 to 220Ω", "connect battery to switch", ...). If it
 * does, HORUS Brain and the AI provider are never invoked for this
 * message — `CircuitEditPlanner` parses it into an `EditPlan` and
 * `EditValidator` checks that plan against the live circuit (target
 * exists, value is valid, connection is possible). The validated plan
 * is then re-checked by `SmartComponentResolver`, which lets users
 * refer to components without exact simulator ids ("the LED", "the
 * last LED I added") — a clear match passes through untouched, but a
 * reference that could mean more than one real component on the
 * circuit (e.g. "the LED" with three on the board) is stopped here and
 * turned into a clarifying question instead of guessing; `EditExecutor`
 * is never called for that turn, so nothing is mutated. Otherwise the
 * validated plan is handed to `EditExecutor`, which — for a valid plan
 * — executes it through `CircuitToolBridge` right away (the simulator
 * is updated for real before this function returns) and hands back a
 * short confirmation; for an invalid plan, `EditExecutor` rejects it
 * (no `CircuitToolBridge` call) and hands back why. Either way, `text`
 * below is that short confirmation/reason — never the raw `EditPlan`
 * JSON. Non-edit messages fall through to the AI flow exactly as
 * before.
 */
export async function sendChatMessage(
  conversationId: string,
  prompt: string,
  context?: { projectContext?: unknown; memory?: unknown },
): Promise<
  | {
      ok: true;
      text: string;
      execution: EditExecutionResult | null;
      planExecution?: CircuitPlanExecutionResult;
      arrangeExecution?: ArrangeExecutionResult;
      wiringExecution?: WiringExecutionResult;
      history: ConversationTurn[];
    }
  | { ok: false; error: string; history: ConversationTurn[] }
> {
  // Merge a pending clarification (if any) with this message before
  // deciding anything else. Only merges when `prompt` alone doesn't
  // already read as a complete edit request itself — an unrelated new
  // command ("Add resistor") means the user moved on, so the old
  // question is dropped rather than glued onto it. Otherwise, tries
  // "<pending> <prompt>" ("Add Arduino" + "Mega") as the request this
  // turn actually plans/executes; if that still doesn't read as an
  // edit request either, falls back to `prompt` alone unchanged (e.g.
  // the reply was small talk, not an answer).
  let effectiveRequest = prompt;
  const pendingRequest = pendingClarifications.get(conversationId);
  if (pendingRequest !== undefined) {
    pendingClarifications.delete(conversationId); // consumed either way
    if (!isRecognizedRequest(prompt)) {
      const merged = `${pendingRequest} ${prompt}`.trim();
      if (isRecognizedRequest(merged)) {
        effectiveRequest = merged;
      }
    }
  }

  // IntentResolver: a lightweight pre-processing step that recognizes
  // natural-language (currently Arabic) edit requests and normalizes
  // them into the plain-English text `CircuitEditPlanner` already
  // parses (see `IntentResolver.ts`) — e.g. "ضيف Arduino Mega" ->
  // "add Arduino Mega". Purely text-in/text-out: an `ambiguous` result
  // stops here with a clarifying question (kept pending the same way
  // as every other clarification below) without ever reaching
  // `CircuitEditPlanner`; a `resolved` result just substitutes the
  // normalized text before the *existing*, unmodified pipeline runs.
  // `unrecognized` (including every non-Arabic request) leaves
  // `effectiveRequest` untouched — English requests are unaffected.
  const intentResolution = intentResolver.resolve(effectiveRequest);
  if (intentResolution.status === 'ambiguous') {
    pendingClarifications.set(conversationId, effectiveRequest);
    conversationManager.receiveUserMessage(conversationId, prompt);
    conversationManager.appendAssistantReply(conversationId, intentResolution.message);
    const history = conversationManager.getHistory(conversationId);
    return { ok: false, error: intentResolution.message, history };
  }
  if (intentResolution.status === 'resolved') {
    effectiveRequest = intentResolution.normalizedRequest;
  }

  if (circuitEditPlanner.isEditRequest({ request: effectiveRequest })) {
    let plan = circuitEditPlanner.planEdit({ request: effectiveRequest });

    if (!plan) {
      conversationManager.receiveUserMessage(conversationId, prompt);
      const history = conversationManager.getHistory(conversationId);
      return { ok: false, error: 'Could not build an edit plan from that request.', history };
    }

    if (plan.action === 'change_property' && plan.target) {
      const { snapshot: circuitForSplit } = buildFormattedCircuitContext();
      plan = normalizeChangePropertyPlan(plan, circuitForSplit.components);
    }

    let validated: ValidatedEditPlan = editValidator.validate(plan);

    // SmartComponentResolver, in two parts, both before EditExecutor
    // ever sees the plan and both read-only (no CircuitToolBridge
    // mutator is called here):
    //
    //  1. `add` plans name a component *type* to create, not an
    //     existing one — `resolveComponentType()` maps colloquial
    //     words ("lamp", "knob", ...) onto the simulator's real
    //     catalog. `unavailable` (nothing in the catalog matches) and
    //     `ambiguous` (more than one real type could be meant) both
    //     stop here with a clear message instead of reaching
    //     `EditApplier`'s stricter, literal type check. A single
    //     resolved type is substituted into the plan `EditExecutor`
    //     receives (e.g. "lamp" -> "bulb") so aliasing actually works
    //     end to end — `EditExecutor`/`EditApplier` themselves are
    //     untouched; they just see a plan already in the vocabulary
    //     they understand.
    //  2. Every other action's *existing*-component reference (the
    //     primary target, plus the secondary target for
    //     `connect`/`disconnect`) is re-checked for ambiguity.
    //     `EditValidator` already confirmed *a* match exists for each;
    //     this asks whether more than one real component could be
    //     meant, narrowing first by color/value/position (see
    //     `SmartComponentResolver.ts`) before giving up and asking.
    if (validated.valid && validated.plan.action === 'add' && validated.plan.target) {
      const originalTarget = validated.plan.target;
      const typeResolution = smartComponentResolver.resolveComponentType(originalTarget);
      if (typeResolution.status !== 'resolved' || !typeResolution.type) {
        const message = typeResolution.message ?? 'Could not resolve that component type.';
        if (typeResolution.status === 'ambiguous') {
          // Keep this request live so the next message ("Mega") can
          // be merged into it ("Add Arduino" -> "Add Arduino Mega")
          // instead of being treated as an unrelated fresh message.
          pendingClarifications.set(conversationId, effectiveRequest);
        }
        conversationManager.receiveUserMessage(conversationId, prompt);
        conversationManager.appendAssistantReply(conversationId, message);
        const history = conversationManager.getHistory(conversationId);
        return { ok: false, error: message, history };
      }
      // Whatever's left of the typed phrase once the type's own
      // name/alias is accounted for (e.g. "green" out of "Green LED")
      // is a requested property for the new component — carried into
      // `value` (unused by `add` otherwise) so `EditApplier` can apply
      // it right as the component is created, or report clearly that
      // it isn't a real property of this type. See
      // `SmartComponentResolver.extractPropertyQualifier()`.
      const qualifier = smartComponentResolver.extractQualifier(originalTarget, typeResolution.type);
      validated = {
        ...validated,
        plan: { ...validated.plan, target: typeResolution.type, value: qualifier },
      };
    } else if (validated.valid) {
      const referencesToCheck: string[] = [];
      if (validated.plan.target) referencesToCheck.push(validated.plan.target);
      if (
        (validated.plan.action === 'connect' || validated.plan.action === 'disconnect') &&
        validated.plan.value
      ) {
        referencesToCheck.push(validated.plan.value);
      }

      const { snapshot: liveCircuit } = buildFormattedCircuitContext();
      for (const reference of referencesToCheck) {
        const resolution = smartComponentResolver.resolve(reference, liveCircuit.components);
        if (resolution.status === 'ambiguous' || resolution.status === 'unavailable') {
          const message = resolution.message ?? `Which component did you mean by "${reference}"?`;
          if (resolution.status === 'ambiguous') {
            pendingClarifications.set(conversationId, effectiveRequest);
          }
          conversationManager.receiveUserMessage(conversationId, prompt);
          conversationManager.appendAssistantReply(conversationId, message);
          const history = conversationManager.getHistory(conversationId);
          return { ok: false, error: message, history };
        }
      }
    }

    // EditExecutor checks `validated.valid` itself: a valid plan is
    // executed through CircuitToolBridge immediately; an invalid one is
    // rejected without ever reaching CircuitToolBridge. Either way the
    // simulator's state (or lack of a change) is settled by the time
    // this returns — `execution.message` is the short confirmation/
    // reason a caller shows, not the plan itself.
    const execution = editExecutor.receivePlan(validated);

    // Record this turn the same way a normal AI turn would be, so
    // conversation history stays coherent for any later AI message in
    // this same conversation — but no AI provider is called to produce
    // this reply. The confirmation message (not the EditPlan) is what's
    // recorded as HORUS's reply.
    conversationManager.receiveUserMessage(conversationId, prompt);
    conversationManager.appendAssistantReply(conversationId, execution.message);
    const history = conversationManager.getHistory(conversationId);

    if (execution.status !== 'applied') {
      return { ok: false, error: execution.message, history };
    }
    return { ok: true, text: execution.message, execution, history };
  }

  // Phase 2: goal requests ("create a simple LED circuit") are not a
  // single Add/Remove edit — `circuitEditPlanner.isEditRequest()`
  // above correctly leaves them alone. Recognized separately here and
  // routed through the read-only `circuitPlanner` (Phase 1, untouched)
  // to get a `CircuitPlan`, then `circuitPlanExecutor` actually builds
  // it against the live simulator via the same `CircuitToolBridge`
  // mutators the Add/Remove pipeline above uses — never a second
  // implementation of component creation. No wiring, optimization, or
  // memory of past plans happens here, per the Phase 2 spec; this
  // stage only creates the planned components and applies their
  // planned property values, each verified by reading it back from
  // the simulator afterward (`CircuitPlanExecutor`'s own doc covers
  // the verification contract in full).
  if (isGoalBuildRequest(effectiveRequest)) {
    const plan: CircuitPlan = circuitPlanner.planCircuit({ goal: effectiveRequest });

    if (plan.components.length === 0) {
      // Nothing this planner recognized enough to build — report why
      // plainly rather than pretending something was created.
      const reason =
        plan.unavailableComponents.length > 0
          ? `None of the requested parts are available in the simulator's component registry: ${plan.unavailableComponents
              .map((u) => u.requested)
              .join(', ')}.`
          : `Couldn't identify any buildable components in "${effectiveRequest}".`;
      conversationManager.receiveUserMessage(conversationId, prompt);
      conversationManager.appendAssistantReply(conversationId, reason);
      const history = conversationManager.getHistory(conversationId);
      return { ok: false, error: reason, history };
    }

    // The simulator's own post-execution state is what decides
    // success/failure below — `planExecution.status`/`.created` and
    // `wiringExecution.status`/`.connected` are all built entirely
    // from live read-backs (see `CircuitPlanExecutor`/`WiringExecutor`),
    // never from the plan's stated intent. `circuitBuildOrchestrator`
    // only sequences the two existing verifying executors — component
    // creation, then (only against what was actually created) wiring.
    const { planExecution, arrangeExecution, wiringExecution, message } = circuitBuildOrchestrator.build(plan);
    const reportedText = `${plan.summary} ${message}`.trim();

    conversationManager.receiveUserMessage(conversationId, prompt);
    conversationManager.appendAssistantReply(conversationId, reportedText);
    const history = conversationManager.getHistory(conversationId);

    if (planExecution.status === 'failed' || planExecution.status === 'nothing_to_do') {
      return { ok: false, error: reportedText, history };
    }
    return { ok: true, text: reportedText, execution: null, planExecution, arrangeExecution, wiringExecution, history };
  }

  // Same API-key refresh as `runHorusPrompt()` above, for the same
  // reason — Brain's Gemini call should reflect the latest saved key.
  const { apiKey } = getProviderConfig('gemini');
  aiConfiguration.setProviderConfiguration('gemini', { apiKey });

  // Before sending this AI request: build the current circuit context,
  // attach the JSON snapshot to ConversationManager (storage only), and
  // render it as the readable text `PromptContextFormatter` produces.
  // That text — not just the raw JSON — is what gets passed to Brain
  // below, so it reads as normal prompt text once AIGateway assembles
  // the final message, rather than a JSON blob. This happens on every
  // send, automatically — the user never has to say "this circuit".
  const { snapshot: circuitContext, text: formattedCircuitContext } = buildFormattedCircuitContext();
  conversationManager.attachCircuitContext(conversationId, circuitContext);

  const projectContext =
    context?.projectContext !== undefined
      ? `${JSON.stringify(context.projectContext)}\n\n${formattedCircuitContext}`
      : formattedCircuitContext;

  const { history, aiResponse } = await chatManager.sendMessage({
    conversationId,
    userRequest: prompt,
    projectContext,
    memory: context?.memory,
  });

  if (aiResponse.errors.length > 0) {
    return { ok: false, error: aiResponse.errors.map((error) => error.message).join(' '), history };
  }
  if (!aiResponse.text) {
    return { ok: false, error: 'HORUS returned no response.', history };
  }
  return { ok: true, text: aiResponse.text, execution: null, history };
}
