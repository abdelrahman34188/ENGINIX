/**
 * HORUS AI — Validation Engine.
 *
 * Responsible (once implemented) for checking AI-generated output against
 * structural/domain rules (e.g. a proposed circuit only uses supported
 * component types) before it's surfaced or acted on. Deliberately separate
 * from Auto Fix Engine: this module only *judges* validity, it never
 * mutates output.
 *
 * Interface + skeleton only — no logic implemented yet.
 */

export interface ValidationIssue {
  path: string;
  message: string;
  severity: 'error' | 'warning';
}

export interface ValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
}

export interface IValidationEngine {
  /** Validate an arbitrary AI-produced payload against HORUS's rules. */
  validate(payload: unknown): ValidationResult;
}

export class ValidationEngine implements IValidationEngine {
  validate(_payload: unknown): ValidationResult {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
