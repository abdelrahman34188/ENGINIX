/**
 * HORUS AI — Prompt Builder (Core/Prompt).
 *
 * Responsible (once implemented) for assembling one final prompt object
 * from all nine input parts:
 *  - System Prompt
 *  - HORUS Identity
 *  - User Request
 *  - Conversation Context
 *  - Memory Context
 *  - Circuit Context
 *  - PCB Context
 *  - Arduino Context
 *  - Simulation Context
 *
 * Distinct from src/horus/core/Managers/PromptManager.ts, which owns the
 * coarser system/user/context three-part prompt lifecycle (set/get/build/
 * validate/reset). PromptBuilder is the finer-grained assembly step that
 * would take the ReasoningPipeline's BuildReasoningInput output (and
 * ContextCollector's merged context) and produce the structured prompt
 * object PromptManager — or the AI provider layer — consumes. Does not
 * itself call any AI API.
 *
 * Implementation status: minimal but functional — collects the nine
 * parts (via the setters or directly via `build(input)`) and returns a
 * plain `StructuredPrompt` object stamped with an `assembledAt`
 * timestamp. No AI calls; assembly only.
 */

export interface SystemPromptPart {
  systemPrompt: unknown;
}

export interface HorusIdentityPart {
  identity: unknown;
}

export interface UserRequestPart {
  userRequest: unknown;
}

export interface ConversationContextPart {
  conversationContext: unknown;
}

export interface MemoryContextPart {
  memoryContext: unknown;
}

export interface CircuitContextPart {
  circuitContext: unknown;
}

export interface PCBContextPart {
  pcbContext: unknown;
}

export interface ArduinoContextPart {
  arduinoContext: unknown;
}

export interface SimulationContextPart {
  simulationContext: unknown;
}

/** All nine input parts PromptBuilder assembles from. */
export interface PromptBuilderInput {
  systemPrompt: SystemPromptPart;
  identity: HorusIdentityPart;
  userRequest: UserRequestPart;
  conversationContext: ConversationContextPart;
  memoryContext: MemoryContextPart;
  circuitContext: CircuitContextPart;
  pcbContext: PCBContextPart;
  arduinoContext: ArduinoContextPart;
  simulationContext: SimulationContextPart;
}

/** One structured prompt object assembled from all input parts. */
export interface StructuredPrompt {
  systemPrompt: SystemPromptPart;
  identity: HorusIdentityPart;
  userRequest: UserRequestPart;
  conversationContext: ConversationContextPart;
  memoryContext: MemoryContextPart;
  circuitContext: CircuitContextPart;
  pcbContext: PCBContextPart;
  arduinoContext: ArduinoContextPart;
  simulationContext: SimulationContextPart;
  assembledAt?: number;
}

export interface IPromptBuilder {
  /** Set the system prompt part. */
  setSystemPrompt(part: SystemPromptPart): void;

  /** Set the HORUS identity part. */
  setIdentity(part: HorusIdentityPart): void;

  /** Set the user request part. */
  setUserRequest(part: UserRequestPart): void;

  /** Set the conversation context part. */
  setConversationContext(part: ConversationContextPart): void;

  /** Set the memory context part. */
  setMemoryContext(part: MemoryContextPart): void;

  /** Set the circuit context part. */
  setCircuitContext(part: CircuitContextPart): void;

  /** Set the PCB context part. */
  setPCBContext(part: PCBContextPart): void;

  /** Set the Arduino context part. */
  setArduinoContext(part: ArduinoContextPart): void;

  /** Set the simulation context part. */
  setSimulationContext(part: SimulationContextPart): void;

  /** Assemble all nine parts into one structured prompt object. */
  build(input: PromptBuilderInput): StructuredPrompt;

  /** Clear all previously set parts. */
  reset(): void;
}

const EMPTY_PART = { value: undefined };

export class PromptBuilder implements IPromptBuilder {
  private parts: Partial<PromptBuilderInput> = {};

  setSystemPrompt(part: SystemPromptPart): void {
    this.parts.systemPrompt = part;
  }

  setIdentity(part: HorusIdentityPart): void {
    this.parts.identity = part;
  }

  setUserRequest(part: UserRequestPart): void {
    this.parts.userRequest = part;
  }

  setConversationContext(part: ConversationContextPart): void {
    this.parts.conversationContext = part;
  }

  setMemoryContext(part: MemoryContextPart): void {
    this.parts.memoryContext = part;
  }

  setCircuitContext(part: CircuitContextPart): void {
    this.parts.circuitContext = part;
  }

  setPCBContext(part: PCBContextPart): void {
    this.parts.pcbContext = part;
  }

  setArduinoContext(part: ArduinoContextPart): void {
    this.parts.arduinoContext = part;
  }

  setSimulationContext(part: SimulationContextPart): void {
    this.parts.simulationContext = part;
  }

  /**
   * Assemble all nine parts. Any part present on `input` is used as-is;
   * any part missing falls back to a previously-set part (via the
   * setters above), then to an empty placeholder — so callers that only
   * care about a subset of context (e.g. no PCB/Arduino context for a
   * circuit-only request) don't have to fabricate the rest.
   */
  build(input: PromptBuilderInput): StructuredPrompt {
    const merged: PromptBuilderInput = {
      systemPrompt: input.systemPrompt ?? this.parts.systemPrompt ?? { systemPrompt: EMPTY_PART },
      identity: input.identity ?? this.parts.identity ?? { identity: EMPTY_PART },
      userRequest: input.userRequest ?? this.parts.userRequest ?? { userRequest: EMPTY_PART },
      conversationContext:
        input.conversationContext ?? this.parts.conversationContext ?? { conversationContext: EMPTY_PART },
      memoryContext: input.memoryContext ?? this.parts.memoryContext ?? { memoryContext: EMPTY_PART },
      circuitContext: input.circuitContext ?? this.parts.circuitContext ?? { circuitContext: EMPTY_PART },
      pcbContext: input.pcbContext ?? this.parts.pcbContext ?? { pcbContext: EMPTY_PART },
      arduinoContext: input.arduinoContext ?? this.parts.arduinoContext ?? { arduinoContext: EMPTY_PART },
      simulationContext:
        input.simulationContext ?? this.parts.simulationContext ?? { simulationContext: EMPTY_PART },
    };

    return { ...merged, assembledAt: Date.now() };
  }

  reset(): void {
    this.parts = {};
  }
}
