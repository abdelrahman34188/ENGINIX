/**
 * HORUS AI — System Prompt Manager (Core/Prompt).
 *
 * Responsible (once implemented) for owning the HORUS base identity /
 * system prompt as its own isolated concern, kept strictly separate from
 * user prompts and other prompt parts:
 *  - Provide the HORUS base identity as the system prompt.
 *  - Allow that system prompt to be updated later without touching any
 *    user-facing prompt content.
 *
 * Distinct from PromptBuilder.ts (assembles all nine prompt parts,
 * system prompt included, into one structured prompt object) and from
 * core/Managers/PromptManager.ts (owns the broader system/user/context
 * prompt lifecycle). SystemPromptManager is the single source of truth
 * PromptBuilder's setSystemPrompt() would draw from once wired up. Does
 * not itself assemble prompts and does not call any AI API.
 *
 * Implementation status: minimal but functional — holds the HORUS base
 * identity/system prompt in memory (starting from `horus/identity.ts`)
 * and lets it be replaced. No persistence, no multi-provider variants.
 */

import type { SystemPromptPart } from './PromptBuilder';
import { HORUS_AI_NAME, HORUS_AI_ROLE } from '../../identity';

const DEFAULT_SYSTEM_PROMPT = `You are ${HORUS_AI_NAME}, an ${HORUS_AI_ROLE}. Answer precisely, follow the caller's requested output format exactly, and never invent data that wasn't given to you.`;

export interface ISystemPromptManager {
  /** Return the current HORUS system prompt (base identity). */
  getSystemPrompt(): SystemPromptPart;

  /** Update the HORUS system prompt, kept separate from user prompts. */
  updateSystemPrompt(prompt: SystemPromptPart): void;
}

export class SystemPromptManager implements ISystemPromptManager {
  private systemPrompt: SystemPromptPart = { systemPrompt: DEFAULT_SYSTEM_PROMPT };

  getSystemPrompt(): SystemPromptPart {
    return this.systemPrompt;
  }

  updateSystemPrompt(prompt: SystemPromptPart): void {
    this.systemPrompt = prompt;
  }
}
