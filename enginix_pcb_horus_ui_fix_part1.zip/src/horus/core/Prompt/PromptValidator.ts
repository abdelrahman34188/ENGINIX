/**
 * HORUS AI — Prompt Validator (Core/Prompt).
 *
 * Responsible (once implemented) for checking the final assembled
 * prompt before it is sent to any AI provider:
 *  - Empty fields      — required parts missing content.
 *  - Missing context   — expected context parts absent entirely.
 *  - Invalid structure  — assembled prompt does not match the expected
 *                         StructuredPrompt shape.
 *
 * Intended to run against PromptBuilder's StructuredPrompt output as
 * the last check before handoff to the AI provider layer — mirrors the
 * role PromptManager.validatePrompt() plays for its own three-part
 * prompt, but scoped to PromptBuilder's nine-part structured object.
 * Does not itself build or repair prompts and does not call any AI API.
 *
 * Implementation status: minimal but functional — `checkEmptyFields`
 * flags a part whose inner value is `undefined`/`null`/`''`;
 * `checkMissingContext` flags the four context parts (conversation,
 * memory, circuit, PCB/Arduino/simulation are optional — HORUS features
 * differ in which they need, so only conversation+memory are treated as
 * "expected" here); `checkInvalidStructure` checks the object has all
 * nine keys. `validate()` combines all three; a request is `isValid`
 * as long as there's no `InvalidStructure` issue and `userRequest`
 * (the one field every HORUS request must have) isn't empty — missing
 * optional context is reported but does not block sending the prompt.
 */

import type { StructuredPrompt } from './PromptBuilder';

export type PromptValidationIssueType =
  | 'EmptyField'
  | 'MissingContext'
  | 'InvalidStructure';

export interface PromptValidationIssue {
  type: PromptValidationIssueType;
  field?: string;
  message?: string;
}

export interface PromptValidationResult {
  isValid: boolean;
  issues: PromptValidationIssue[];
}

export interface IPromptValidator {
  /** Check the prompt for empty required fields. */
  checkEmptyFields(prompt: StructuredPrompt): PromptValidationIssue[];

  /** Check the prompt for missing expected context parts. */
  checkMissingContext(prompt: StructuredPrompt): PromptValidationIssue[];

  /** Check the prompt matches the expected structured shape. */
  checkInvalidStructure(prompt: StructuredPrompt): PromptValidationIssue[];

  /** Run all checks and return one combined validation result. */
  validate(prompt: StructuredPrompt): PromptValidationResult;
}

const REQUIRED_STRUCTURE_KEYS: Array<keyof StructuredPrompt> = [
  'systemPrompt',
  'identity',
  'userRequest',
  'conversationContext',
  'memoryContext',
  'circuitContext',
  'pcbContext',
  'arduinoContext',
  'simulationContext',
];

/** The single inner value of a one-key prompt part, e.g. `{ userRequest: x }.userRequest`. */
function innerValue(part: unknown): unknown {
  if (!part || typeof part !== 'object') return part;
  const values = Object.values(part as Record<string, unknown>);
  return values.length === 1 ? values[0] : part;
}

function isEmpty(value: unknown): boolean {
  return value === undefined || value === null || value === '';
}

export class PromptValidator implements IPromptValidator {
  checkEmptyFields(prompt: StructuredPrompt): PromptValidationIssue[] {
    const issues: PromptValidationIssue[] = [];
    for (const key of REQUIRED_STRUCTURE_KEYS) {
      if (isEmpty(innerValue(prompt[key]))) {
        issues.push({ type: 'EmptyField', field: key, message: `${key} is empty.` });
      }
    }
    return issues;
  }

  checkMissingContext(prompt: StructuredPrompt): PromptValidationIssue[] {
    const issues: PromptValidationIssue[] = [];
    if (isEmpty(innerValue(prompt.conversationContext))) {
      issues.push({ type: 'MissingContext', field: 'conversationContext', message: 'No conversation context provided.' });
    }
    if (isEmpty(innerValue(prompt.memoryContext))) {
      issues.push({ type: 'MissingContext', field: 'memoryContext', message: 'No memory context provided.' });
    }
    return issues;
  }

  checkInvalidStructure(prompt: StructuredPrompt): PromptValidationIssue[] {
    if (!prompt || typeof prompt !== 'object') {
      return [{ type: 'InvalidStructure', message: 'Prompt is not an object.' }];
    }
    const missingKeys = REQUIRED_STRUCTURE_KEYS.filter((key) => !(key in prompt));
    return missingKeys.length > 0
      ? [{ type: 'InvalidStructure', message: `Missing keys: ${missingKeys.join(', ')}.` }]
      : [];
  }

  validate(prompt: StructuredPrompt): PromptValidationResult {
    const structureIssues = this.checkInvalidStructure(prompt);
    const emptyFieldIssues = this.checkEmptyFields(prompt);
    const missingContextIssues = this.checkMissingContext(prompt);
    const issues = [...structureIssues, ...emptyFieldIssues, ...missingContextIssues];

    // Structure must be intact, and the user's actual request must not
    // be empty — everything else (conversation/memory/circuit/etc.
    // context) is reported but optional, since not every HORUS feature
    // needs all of it.
    const userRequestEmpty = emptyFieldIssues.some((issue) => issue.field === 'userRequest');
    const isValid = structureIssues.length === 0 && !userRequestEmpty;

    return { isValid, issues };
  }
}
