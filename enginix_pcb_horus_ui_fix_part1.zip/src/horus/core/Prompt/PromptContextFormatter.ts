/**
 * HORUS AI — Prompt Context Formatter (Core/Prompt).
 *
 * Converts a `CircuitContextSnapshot` (the JSON `CircuitContextBuilder`
 * produces) into clean, human-readable text — one line per component,
 * one line per wire, one line for the current selection — suitable for
 * dropping into a prompt's Circuit Context part.
 *
 *   Battery 9V
 *   LED D1
 *   220Ω resistor
 *   Switch open
 *   Arduino UNO
 *
 * Deliberately narrow, matching every other module at this stage:
 *  - No analysis. This formatter does not interpret the circuit, infer
 *    behavior, validate anything, or reason about what the components
 *    do — it only turns each JSON field it's given into a line of text.
 *  - No AI. Never touches `AIGateway`, a provider, or any prompt part
 *    other than producing this one block of text.
 *  - No fabrication. Only fields already present on
 *    `CircuitContextSnapshot` (component `type`/`label`, wire
 *    endpoints, the selected component) are formatted — nothing is
 *    invented for fields the current schema doesn't carry (e.g. a
 *    battery's voltage or a switch's open/closed state aren't on
 *    `CircuitToolComponent` yet, so they don't appear here either;
 *    once `CircuitTool` reports richer component data, the same
 *    line-per-component shape below picks it up without changing this
 *    file's responsibilities).
 *
 * Depends only on `CircuitContextSnapshot`'s shape (see
 * `tools/CircuitContextBuilder.ts`) — no import of `src/circuit` or
 * any AI module.
 */

import type {
  CircuitContextSnapshot,
  CircuitToolComponent,
} from '../../tools/CircuitContextBuilder';

export interface IPromptContextFormatter {
  /** Convert a circuit context snapshot into one readable text block. */
  format(circuitContext: CircuitContextSnapshot): string;
}

/** "led" -> "LED" is a fixed abbreviation exception; everything else is
 *  a plain capitalized-first-letter pass — no other component-specific
 *  knowledge lives here. */
const TYPE_ABBREVIATIONS: Record<string, string> = {
  led: 'LED',
  pcb: 'PCB',
  usb: 'USB',
};

function formatComponentType(type: string): string {
  const known = TYPE_ABBREVIATIONS[type.toLowerCase()];
  if (known) return known;
  if (!type) return type;
  return type.charAt(0).toUpperCase() + type.slice(1);
}

function formatComponentLine(component: CircuitToolComponent): string {
  const type = formatComponentType(component.type);
  const label = component.label?.trim();
  return label ? `${type} ${label}` : type;
}

export class PromptContextFormatter implements IPromptContextFormatter {
  format(circuitContext: CircuitContextSnapshot): string {
    const lines: string[] = [];

    for (const component of circuitContext.components) {
      lines.push(formatComponentLine(component));
    }

    for (const wire of circuitContext.wires) {
      lines.push(`Wire: ${wire.fromComponentId} -> ${wire.toComponentId}`);
    }

    lines.push(
      circuitContext.selectedComponent
        ? `Selected: ${formatComponentLine(circuitContext.selectedComponent)}`
        : 'Selected: none'
    );

    return lines.join('\n');
  }
}

/** Shared instance — mirrors the singleton pattern used elsewhere in
 *  HORUS (e.g. `conversationManager`, `toolRegistry`). */
export const promptContextFormatter = new PromptContextFormatter();
