/**
 * HORUS AI — AI Response (Core/AI).
 *
 * The single, standard response structure every HORUS module downstream
 * of an AI Provider (AI Core, Conversation Manager, Validation Engine,
 * Auto Fix Engine, UI layer, ...) consumes. Distinct from
 * `AIProviderResponse` in `provider/AIProvider.ts`, which is the narrower,
 * ok/error shape a vendor adapter returns for a single generation call.
 * `AIResponse` is the richer, normalized shape HORUS builds from that
 * (plus tool-call results, validation, timing, etc.) once a request has
 * been fully processed.
 *
 * Six standard fields:
 *  - text          Plain-text reply content.
 *  - markdown      Markdown-formatted reply content.
 *  - toolCalls     Tool/function invocations produced for this response.
 *  - errors        Normalized errors encountered while producing it.
 *  - confidence    Model/system confidence in the response.
 *  - processingTime How long the response took to produce.
 *
 * Implementation status: `AIResponseBuilder` is minimal but functional —
 * plain field accumulation plus a default `confidence`/`processingTime`
 * of 0 and empty `toolCalls`/`errors` arrays if never explicitly set.
 */

/** A single tool/function invocation requested as part of a response. */
export interface AIResponseToolCall {
  /** Name of the tool/function being invoked. */
  name: string;
  /** Arguments passed to the tool/function; shape is tool-specific. */
  arguments: unknown;
}

/** Normalized error categories an AIResponse may carry. */
export type AIResponseErrorCode =
  | 'missing_credentials'
  | 'invalid_credentials'
  | 'rate_limited'
  | 'network_error'
  | 'invalid_response'
  | 'validation_failed'
  | 'unknown';

/** A single normalized error attached to a response. */
export interface AIResponseError {
  code: AIResponseErrorCode;
  message: string;
}

/**
 * The standard, provider-agnostic AI response structure produced for a
 * fully processed HORUS request.
 */
export interface AIResponse {
  /** Plain-text reply content. */
  text: string;

  /** Markdown-formatted reply content. */
  markdown: string;

  /** Tool/function invocations produced for this response. */
  toolCalls: AIResponseToolCall[];

  /** Normalized errors encountered while producing this response. */
  errors: AIResponseError[];

  /** Model/system confidence in the response, expressed as 0–1. */
  confidence: number;

  /** Time taken to produce this response, in milliseconds. */
  processingTime: number;
}

/**
 * Builder contract for assembling an `AIResponse` incrementally across
 * HORUS's pipeline (provider call, tool execution, validation, timing).
 * Not implemented yet.
 */
export interface IAIResponseBuilder {
  /** Set the plain-text reply content. */
  setText(text: string): void;

  /** Set the markdown-formatted reply content. */
  setMarkdown(markdown: string): void;

  /** Attach a tool/function invocation to the response. */
  addToolCall(toolCall: AIResponseToolCall): void;

  /** Attach a normalized error to the response. */
  addError(error: AIResponseError): void;

  /** Set the confidence score for the response. */
  setConfidence(confidence: number): void;

  /** Set the processing time for the response, in milliseconds. */
  setProcessingTime(processingTime: number): void;

  /** Assemble everything set so far into a standard `AIResponse`. */
  build(): AIResponse;

  /** Clear all previously set fields. */
  reset(): void;
}

export class AIResponseBuilder implements IAIResponseBuilder {
  private text = '';
  private markdown = '';
  private toolCalls: AIResponseToolCall[] = [];
  private errors: AIResponseError[] = [];
  private confidence = 0;
  private processingTime = 0;

  setText(text: string): void {
    this.text = text;
  }

  setMarkdown(markdown: string): void {
    this.markdown = markdown;
  }

  addToolCall(toolCall: AIResponseToolCall): void {
    this.toolCalls.push(toolCall);
  }

  addError(error: AIResponseError): void {
    this.errors.push(error);
  }

  setConfidence(confidence: number): void {
    this.confidence = confidence;
  }

  setProcessingTime(processingTime: number): void {
    this.processingTime = processingTime;
  }

  build(): AIResponse {
    return {
      text: this.text,
      markdown: this.markdown,
      toolCalls: [...this.toolCalls],
      errors: [...this.errors],
      confidence: this.confidence,
      processingTime: this.processingTime,
    };
  }

  reset(): void {
    this.text = '';
    this.markdown = '';
    this.toolCalls = [];
    this.errors = [];
    this.confidence = 0;
    this.processingTime = 0;
  }
}
