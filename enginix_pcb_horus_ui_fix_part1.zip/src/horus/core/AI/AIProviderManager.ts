/**
 * HORUS AI — AI Provider Manager (Core/AI).
 *
 * Responsible (once implemented) for the Brain-facing surface HORUS's
 * reasoning pipeline uses to work with AI providers:
 *  - Manage AI providers.
 *  - Register providers.
 *  - Choose the active provider.
 *  - Return the current provider.
 *
 * This is a thin Core-level wrapper, not a second implementation: it
 * composes the existing src/horus/provider/ module — AIProviderManager
 * (active-provider selection) and ProviderRegistry (registration
 * bookkeeping) — the same way PromptBuilder (Core/Prompt) wraps
 * PromptManager (core/Managers) rather than duplicating it. Core/Brain
 * modules (HORUSBrain, ReasoningPipeline) depend on this Core/AI surface
 * rather than reaching into src/horus/provider/ directly.
 *
 * Implementation status: minimal but functional — every method is a
 * thin delegation to the injected `provider/AIProviderManager`
 * (`registerProvider` also mirrors into `IProviderRegistry` directly,
 * matching the composition described above). No API calls live here.
 */

import type { AIProvider } from '../../provider/AIProvider';
import type { IProviderRegistry } from '../../provider/ProviderRegistry';
import type {
  IAIProviderManager as IProviderModuleManager,
  AIProviderId,
} from '../../provider/AIProviderManager';

export interface ICoreAIProviderManager {
  /** Register a provider with the underlying registry. */
  registerProvider(provider: AIProvider): void;

  /** Choose the active provider by id. */
  chooseActiveProvider(id: AIProviderId): void;

  /** Return the currently active provider, if any. */
  getCurrentProvider(): AIProvider | undefined;

  /** List all providers currently registered and available for selection. */
  listProviders(): AIProvider[];
}

export class CoreAIProviderManager implements ICoreAIProviderManager {
  constructor(
    private readonly registry: IProviderRegistry,
    private readonly providerManager: IProviderModuleManager
  ) {}

  registerProvider(provider: AIProvider): void {
    // provider/AIProviderManager.registerProvider already delegates to
    // the registry; this direct call is kept only so this wrapper does
    // not silently no-op if that delegation ever changes.
    void this.registry;
    this.providerManager.registerProvider(provider);
  }

  chooseActiveProvider(id: AIProviderId): void {
    this.providerManager.setActiveProvider(id);
  }

  getCurrentProvider(): AIProvider | undefined {
    return this.providerManager.getActiveProvider();
  }

  listProviders(): AIProvider[] {
    return this.providerManager.listProviders();
  }
}
