/**
 * HORUS AI — AI Gateway (Core/AI).
 *
 * The single choke point between HORUS's prompt pipeline and the active
 * AI provider. Responsible (once implemented) for:
 *  - Receiving the final, validated prompt (PromptValidator's output
 *    for a PromptBuilder `StructuredPrompt`).
 *  - Requesting the current AI provider from Core/AI's
 *    `CoreAIProviderManager` (which itself wraps `provider/AIProviderManager`
 *    + `provider/ProviderRegistry` — never duplicated here).
 *  - Sending the prompt to that provider via the existing `AIProvider`
 *    interface (`generate`) — no vendor-specific code, no HTTP, no
 *    Gemini or any other concrete provider referenced.
 *  - Receiving the provider's `AIProviderResponse`.
 *  - Returning a standardized `AIResponse` (Core/AI's richer,
 *    normalized response shape) for the rest of HORUS to consume.
 *
 * AIGateway does not select a provider, does not build or validate
 * prompts, and does not implement any vendor protocol — it composes
 * `CoreAIProviderManager` and `AIProvider` and hands off to
 * `AIResponseBuilder` to assemble the standardized result. Reuses
 * existing modules only; nothing here duplicates provider selection,
 * prompt assembly/validation, or response shaping logic.
 *
 * Implementation status: minimal but functional. `send()` rejects an
 * invalid prompt without calling any provider, flattens the
 * `StructuredPrompt`'s nine parts into the provider-agnostic
 * `AIProviderMessage[]` shape `AIProvider.generate()` expects (system +
 * identity become one 'system' turn, every context part becomes
 * reference material folded into the 'user' turn, ahead of the actual
 * user request text), resolves the active provider via
 * `CoreAIProviderManager`, calls `generate()`, and uses
 * `AIResponseBuilder` to normalize the result — still no vendor-specific
 * code here (see `provider/GeminiProvider.ts` for that).
 */

import type { ICoreAIProviderManager } from './AIProviderManager';
import { AIResponseBuilder, type AIResponse } from './AIResponse';
import type { StructuredPrompt } from '../Prompt/PromptBuilder';
import type { PromptValidationResult } from '../Prompt/PromptValidator';
import type { AIProviderMessage } from '../../provider/AIProvider';

/** Unwrap a one-key prompt part, e.g. `{ userRequest: x }` -> `x`. */
function innerValue(part: unknown): unknown {
  if (!part || typeof part !== 'object') return part;
  const values = Object.values(part as Record<string, unknown>);
  return values.length === 1 ? values[0] : part;
}

/** Render any prompt-part value as text for inclusion in a chat message. */
function toText(value: unknown): string {
  if (value === undefined || value === null || value === '') return '';
  if (typeof value === 'string') return value;
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

/** Flatten a `StructuredPrompt`'s nine parts into the flat message list
 *  every `AIProvider` consumes. */
function toProviderMessages(prompt: StructuredPrompt): AIProviderMessage[] {
  const systemText = [toText(innerValue(prompt.systemPrompt)), toText(innerValue(prompt.identity))]
    .filter(Boolean)
    .join('\n\n');

  const contextText = (
    [
      ['Conversation context', prompt.conversationContext],
      ['Memory context', prompt.memoryContext],
      ['Circuit context', prompt.circuitContext],
      ['PCB context', prompt.pcbContext],
      ['Arduino context', prompt.arduinoContext],
      ['Simulation context', prompt.simulationContext],
    ] as const
  )
    .map(([label, part]) => {
      const text = toText(innerValue(part));
      return text ? `${label}:\n${text}` : '';
    })
    .filter(Boolean)
    .join('\n\n');

  const userText = [contextText, toText(innerValue(prompt.userRequest))].filter(Boolean).join('\n\n');

  const messages: AIProviderMessage[] = [];
  if (systemText) messages.push({ role: 'system', content: systemText });
  messages.push({ role: 'user', content: userText });
  return messages;
}

/**
 * The final, validated prompt AIGateway accepts — a `StructuredPrompt`
 * paired with the `PromptValidationResult` that cleared it for handoff.
 * AIGateway does not re-validate; validation is PromptValidator's job.
 */
export interface ValidatedPrompt {
  prompt: StructuredPrompt;
  validation: PromptValidationResult;
}

export interface IAIGateway {
  /**
   * Receive a final validated prompt, resolve the current AI provider
   * via `CoreAIProviderManager`, send the prompt to that provider, and
   * return a standardized `AIResponse`. Not implemented yet.
   */
  send(validatedPrompt: ValidatedPrompt): Promise<AIResponse>;
}

export class AIGateway implements IAIGateway {
  constructor(private readonly providerManager: ICoreAIProviderManager) {}

  async send(validatedPrompt: ValidatedPrompt): Promise<AIResponse> {
    const startedAt = Date.now();
    const builder = new AIResponseBuilder();

    if (!validatedPrompt.validation.isValid) {
      for (const issue of validatedPrompt.validation.issues) {
        builder.addError({ code: 'validation_failed', message: issue.message ?? issue.type });
      }
      builder.setProcessingTime(Date.now() - startedAt);
      return builder.build();
    }

    const provider = this.providerManager.getCurrentProvider();
    if (!provider) {
      builder.addError({ code: 'unknown', message: 'No active HORUS AI provider is configured.' });
      builder.setProcessingTime(Date.now() - startedAt);
      return builder.build();
    }

    const messages = toProviderMessages(validatedPrompt.prompt);
    const result = await provider.generate({ messages });

    if (result.ok) {
      builder.setText(result.text);
      builder.setMarkdown(result.text);
      builder.setConfidence(1);
    } else {
      builder.addError({ code: result.error.code, message: result.error.message });
    }
    builder.setProcessingTime(Date.now() - startedAt);
    return builder.build();
  }
}
