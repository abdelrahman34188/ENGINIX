/**
 * HORUS AI — Real action result builders (Core/Brain).
 *
 * `ToolExecutor` used to hand the *request input* straight back as the
 * *result* (e.g. `{ conversationId }`), so the chat rendered whatever the
 * caller passed in rather than anything the action actually did. This
 * module is what closes that gap: one function per existing HORUS action,
 * each reading the *real* live circuit (via `circuitToolBridge`, the same
 * bridge `EditExecutor`/`EditValidator`/`WiringExecutor` already read
 * from) and running it through the *existing* engines under `src/circuit`
 * and `src/pcb` — never re-implementing them, never inventing data.
 *
 * Explicitly out of scope here, same as everywhere else in `horus/core`:
 *  - No AI provider call of any kind.
 *  - No mutation of the circuit, the simulator, or the auto-wiring/
 *    auto-arrange system — every function below is read-only.
 *  - No fabricated output: where no real engine exists yet for part of
 *    an action (e.g. there is no automatic circuit-error *fixer*, only a
 *    detector), the result says so plainly instead of inventing one.
 */

import { circuitToolBridge } from '../../tools/CircuitToolBridge';
import { detectCircuitErrors, getBlockingErrors, type CircuitError } from '../../../circuit/errorDetector';
import { simulateDC } from '../../../circuit/simulator';
import { convertCircuitToPCB } from '../../../pcb/convertFromCircuit';
import { componentNames, defaultProperties, defaultTerminals } from '../../../circuit/componentDefs';
import type { Component } from '../../../circuit/types';

function summarizeComponents(components: Component[]) {
  return components.map((c) => ({ id: c.id, type: c.type, label: c.label, x: c.x, y: c.y }));
}

function summarizeConnections(wires: ReturnType<typeof circuitToolBridge.getRawWires>) {
  return wires.map((w) => ({ id: w.id, from: w.fromCompId, to: w.toCompId, netLabel: w.netLabel }));
}

function recommendationFor(error: CircuitError): string {
  switch (error.type) {
    case 'short_circuit':
      return `Remove or reroute the wiring shorting ${error.message.includes('across') ? 'this component' : 'these terminals'} together.`;
    case 'no_power_source':
      return 'Add a power source (e.g. a battery) to the circuit.';
    case 'no_ground':
      return 'Connect a ground/return path so current has a complete path back to the source.';
    case 'unconnected_component':
      return 'Wire this component into the circuit, or remove it if unused.';
    case 'open_connection':
      return 'Check for a broken/missing wire along this path.';
    case 'missing_led_resistor':
      return 'Add a current-limiting resistor in series with this LED.';
    case 'wrong_polarity':
      return 'Reverse this component so its polarity matches the rest of the circuit.';
    case 'overload':
      return 'Reduce the load or increase the source/component rating to stay within safe limits.';
    case 'blown_fuse':
    case 'polyfuse_tripped':
    case 'burned_component':
      return 'Fix the underlying fault, then replace/reset this component.';
    case 'unsafe_voltage':
      return 'Lower the applied voltage to a safe level for this component.';
    case 'convergence_failure':
      return 'Simplify or re-check the wiring — the simulator could not resolve a stable solution.';
    default:
      return 'Review this finding and adjust the circuit accordingly.';
  }
}

/** Analyze Circuit — real components/wires from the live editor, run
 *  through the existing `errorDetector`/`simulateDC` engines. */
export function buildAnalyzeCircuitResult(): unknown {
  const components = circuitToolBridge.getRawComponents();
  const wires = circuitToolBridge.getRawWires();

  if (components.length === 0) {
    return {
      components: [],
      connections: [],
      valid: false,
      problems: [],
      electricalCalculations: null,
      recommendations: ['The circuit is empty — add components to analyze it.'],
    };
  }

  const simulation = simulateDC(components, wires);
  const errors = detectCircuitErrors(components, wires, simulation);
  const blocking = getBlockingErrors(errors);

  return {
    components: summarizeComponents(components),
    connections: summarizeConnections(wires),
    valid: blocking.length === 0 && simulation.converged,
    problems: errors,
    electricalCalculations: {
      converged: simulation.converged,
      nodeVoltages: Object.fromEntries(simulation.nodeVoltages),
      branchCurrents: Object.fromEntries(simulation.branchCurrents),
      powers: Object.fromEntries(simulation.powers),
    },
    recommendations: errors.length > 0
      ? errors.map((e) => recommendationFor(e))
      : ['No issues detected — circuit looks electrically valid.'],
  };
}

/** Explain Component — the currently selected real component (falling
 *  back to the first component in the circuit), described from the
 *  existing, static `componentDefs` data. No prose is invented beyond
 *  presenting that real data. */
export function buildExplainComponentResult(): unknown {
  const components = circuitToolBridge.getRawComponents();
  const target = circuitToolBridge.getRawSelectedComponent() ?? components[0] ?? null;

  if (!target) {
    return { error: 'No component is selected and the circuit is empty — select or add a component first.' };
  }

  const propDefs = defaultProperties[target.type] ?? [];
  const terminalDefs = defaultTerminals[target.type] ?? [];

  return {
    id: target.id,
    label: target.label,
    type: target.type,
    name: componentNames[target.type] ?? target.type,
    function: `${componentNames[target.type] ?? target.type} — a ${target.type} component with ${terminalDefs.length} terminal(s): ${terminalDefs.map((t) => t.label).join(', ') || 'none'}.`,
    terminals: terminalDefs.map((t, i) => ({ index: i, label: t.label })),
    properties: propDefs.map((p) => ({
      name: p.name,
      key: p.key,
      unit: p.unit,
      currentValue: target.props[p.key] ?? p.defaultValue,
      defaultValue: p.defaultValue,
      min: p.min,
      max: p.max,
    })),
  };
}

/** Fix Circuit Errors — real detection via `errorDetector`. There is no
 *  existing automatic-fix engine wired to the live circuit yet, so this
 *  reports exactly that instead of claiming fixes it never made. */
export function buildFixErrorsResult(): unknown {
  const components = circuitToolBridge.getRawComponents();
  const wires = circuitToolBridge.getRawWires();

  if (components.length === 0) {
    return { errors: [], fixesApplied: [], status: 'empty', note: 'The circuit is empty — nothing to check.' };
  }

  const simulation = simulateDC(components, wires);
  const errors = detectCircuitErrors(components, wires, simulation);
  const blocking = getBlockingErrors(errors);

  return {
    errors,
    fixesApplied: [],
    status: blocking.length > 0 ? 'errors_found' : errors.length > 0 ? 'warnings_found' : 'ok',
    note: errors.length > 0
      ? 'Automatic fixing is not implemented yet — these are the detected issues; each includes the affected component ids so they can be fixed manually.'
      : 'No errors detected.',
  };
}

/** Convert Circuit to PCB — the real, existing `convertCircuitToPCB`
 *  engine, unmodified, run against the live circuit. */
export function buildConvertPcbResult(): unknown {
  const components = circuitToolBridge.getRawComponents();
  const wires = circuitToolBridge.getRawWires();

  if (components.length === 0) {
    return { components: [], netlist: [], unmapped: [], warnings: ['The circuit is empty — nothing to convert.'] };
  }

  const result = convertCircuitToPCB(components, wires);
  return {
    ...result,
    warnings: result.unmapped.length > 0
      ? [`${result.unmapped.length} component type(s) have no PCB footprint mapping and were skipped: ${result.unmapped.join(', ')}`]
      : [],
  };
}

/** Generate Arduino Code — checked against every existing engine under
 *  `src/arduino` (`lexer`/`parser`/`interpreter`/`ArduinoRuntime`) and
 *  `src/components/codeTemplates.ts`. All of it only *runs* or *edits*
 *  Arduino code a person already wrote (Coding Lab -> ArduinoRuntime) —
 *  none of it takes the live circuit as input and produces a sketch.
 *  So there is nothing real to "connect" HORUS to yet. `available: false`
 *  lets the UI mark this clearly as unavailable instead of rendering a
 *  fake success or dumping an ambiguous JSON blob. Structured this way
 *  (rather than as a generic `{ error }`) so a future real engine can be
 *  wired in by adding `available: true, language: 'arduino', code: ...`
 *  here without any change needed on the UI side. */
export function buildGenerateArduinoResult(): unknown {
  return {
    available: false,
    reason:
      'No existing HORUS engine generates a sketch from the live circuit. ' +
      'src/arduino only runs/interprets code already written by hand (Coding Lab), ' +
      'and src/components/codeTemplates.ts only holds static starter templates — ' +
      'neither reads circuit components/wiring to produce code.',
  };
}
