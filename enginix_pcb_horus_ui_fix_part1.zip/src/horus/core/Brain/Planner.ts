/**
 * HORUS AI — Planner (Core/Brain).
 *
 * Receives an already-detected intent (see `IntentAnalyzer.ts`), decides
 * which single tool that intent requires, and returns a structured
 * execution plan describing that decision.
 *
 * Scope, deliberately narrow:
 *  - Receive an intent. Decide the required tool. Return a plan.
 *  - No execution — this module never calls `ToolExecutor`, never
 *    invokes a tool, and never touches `ToolRegistry` beyond its
 *    `HorusToolName` type (a type-only import, not a call).
 *  - No AI call, no provider call (does not import/touch AIGateway,
 *    AIProviderManager, GeminiProvider/GeminiClient, or anything in
 *    `core/AI/`).
 *  - No frontend/UI changes — no consumer wired in yet.
 *  - No simulator involvement (does not import/touch anything under
 *    `simulator`/`circuit`).
 *
 * Deciding the tool here is a plain, deterministic intent -> tool
 * lookup — no model call, so the decision is fully inspectable and
 * testable offline. Intended (once wired in) to sit between
 * `IntentAnalyzer` and `ToolExecutor` in the reasoning pipeline,
 * alongside/instead of `DecisionEngine.ts`.
 */

import type { HorusIntentType } from './IntentAnalyzer';
import type { HorusToolName } from '../Tools/ToolRegistry';

/** The structured plan Planner hands off — describes what should
 *  happen, not the doing of it. */
export interface ExecutionPlan {
  intent: HorusIntentType;
  toolName: HorusToolName | undefined;
  /** True when `intent` has no tool mapping (e.g. plain `chat`) — the
   *  plan is still returned, just with `toolName: undefined`. */
  requiresTool: boolean;
}

export interface PlannerInput {
  intent: HorusIntentType;
}

export interface IPlanner {
  /** Decide the required tool for the given intent and return the plan. */
  createPlan(input: PlannerInput): ExecutionPlan;
}

/** Fixed intent -> tool map. Every `HorusIntentType` must appear
 *  exactly once, so this stays exhaustive as new intents are added.
 *  `chat` maps to `undefined` — general conversation needs no tool. */
const INTENT_TOOL_MAP: Readonly<Record<HorusIntentType, HorusToolName | undefined>> = {
  analyze_circuit: 'CircuitTool',
  fix_circuit: 'CircuitTool',
  generate_arduino: 'ArduinoTool',
  explain_component: 'ComponentTool',
  convert_to_pcb: 'PCBTool',
  chat: undefined,
};

export class Planner implements IPlanner {
  createPlan(input: PlannerInput): ExecutionPlan {
    const toolName = INTENT_TOOL_MAP[input.intent];
    return {
      intent: input.intent,
      toolName,
      requiresTool: toolName !== undefined,
    };
  }
}

/** Shared instance — stateless, mirrors `IntentAnalyzer.ts`'s exported
 *  `intentAnalyzer` singleton. */
export const planner = new Planner();
