/**
 * HORUS AI — Intent Resolver (Core/Brain).
 *
 * A lightweight pre-processing step in front of `CircuitEditPlanner`:
 * recognizes natural-language edit requests written with Arabic action
 * verbs / component nouns / colors —
 *   "شيل الليد الأخضر"    (remove the green LED)
 *   "ضيف Arduino Mega"    (add Arduino Mega)
 *   "خلي الليد أزرق"      (make the LED blue)
 *   "غير المقاومة لـ220Ω" (change the resistor to 220Ω)
 * — and rewrites each into the plain-English request text
 * `CircuitEditPlanner` already parses ("remove LED green",
 * "add Arduino Mega", "change LED to blue", "change resistor to
 * 220Ω") — then gets entirely out of the way.
 *
 * Deliberately narrow:
 *  - Text in, text (+ a coarse `HorusIntent` label) out. Never touches
 *    `CircuitToolBridge`, `EditExecutor`, or the live circuit —
 *    "resolving intent" here means recognizing *what* the user is
 *    asking for, not doing it. The normalized text is handed back to
 *    the existing, unmodified `CircuitEditPlanner` -> `EditValidator`
 *    -> `SmartComponentResolver` -> `EditExecutor` pipeline, which
 *    still does all real target/ambiguity resolution and all real
 *    execution exactly as before — this module changes none of them.
 *  - Only ever activates for text containing Arabic script
 *    (U+0600–U+06FF). Anything else resolves as `unrecognized`
 *    untouched, so every existing (English) flow is byte-for-byte
 *    unaffected.
 *  - A tiny, fixed word-for-word dictionary — just the vocabulary the
 *    brief's own examples use (component nouns + colors). Component
 *    *names* stay whatever the user typed (e.g. "Arduino"/"Mega" are
 *    already Latin script) — this module doesn't decide what's a real
 *    component; `SmartComponentResolver`, unchanged, still does.
 *  - No automatic wiring: no connect/disconnect vocabulary here at
 *    all, by design — only the three intents the brief asks for.
 *  - No execution: `ambiguous` returns a clarifying message rather
 *    than guessing; `resolved` returns text only, never mutates
 *    anything.
 */

export type HorusIntent = 'ADD_COMPONENT' | 'REMOVE_COMPONENT' | 'MODIFY_PROPERTY';

export type IntentResolution =
  | { status: 'resolved'; intent: HorusIntent; normalizedRequest: string }
  | { status: 'ambiguous'; message: string }
  | { status: 'unrecognized' };

export interface IIntentResolver {
  /** Recognize and normalize a natural-language edit request. Pure
   *  text processing — never touches the circuit or executes
   *  anything. */
  resolve(text: string): IntentResolution;
}

const ARABIC_SCRIPT = /[\u0600-\u06FF]/;

/** Leading action-verb triggers -> canonical English verb + intent.
 *  Anchored to the start of the (trimmed) text, followed by
 *  whitespace or end-of-string — not `\b`, which is defined over
 *  ASCII `\w` and doesn't reliably delimit Arabic script. */
const ACTION_TRIGGERS: ReadonlyArray<{ pattern: RegExp; verb: string; intent: HorusIntent }> = [
  { pattern: /^(?:شيل|احذف|امسح|ازل|إزالة)(?:\s|$)/, verb: 'remove', intent: 'REMOVE_COMPONENT' },
  { pattern: /^(?:ضيف|أضف|اضف|حط)(?:\s|$)/, verb: 'add', intent: 'ADD_COMPONENT' },
  { pattern: /^(?:خلي|خلّي|غير|غيّر|عدل|عدّل|اضبط|ضبط)(?:\s|$)/, verb: 'change', intent: 'MODIFY_PROPERTY' },
];

/** Component-noun dictionary (bare form, definite article stripped —
 *  see `stripArticle`). Not exhaustive by design: anything not here
 *  passes through untouched, which is exactly right for Latin
 *  component names ("Arduino", "Mega", ...) already in the request. */
const COMPONENT_NOUNS: Readonly<Record<string, string>> = {
  'ليد': 'LED',
  'مقاومة': 'resistor',
  'مكثف': 'capacitor',
  'بطارية': 'battery',
  'مفتاح': 'switch',
  'زر': 'button',
  'ديود': 'diode',
  'ترانزستور': 'transistor',
  'محرك': 'motor',
  'حساس': 'sensor',
  'مستشعر': 'sensor',
  'مصباح': 'lamp',
  'فيوز': 'fuse',
};

const COLOR_WORDS: Readonly<Record<string, string>> = {
  'أحمر': 'red', 'احمر': 'red',
  'أخضر': 'green', 'اخضر': 'green',
  'أزرق': 'blue', 'ازرق': 'blue',
  'أصفر': 'yellow', 'اصفر': 'yellow',
  'أبيض': 'white', 'ابيض': 'white',
  'أسود': 'black', 'اسود': 'black',
  'برتقالي': 'orange',
  'بنفسجي': 'purple',
};

/** Strips a leading Arabic definite article ("ال" / "the") so e.g.
 *  "الليد" ("the LED") and "ليد" ("LED") look up the same dictionary
 *  entry. */
function stripArticle(token: string): string {
  return token.startsWith('ال') && token.length > 2 ? token.slice(2) : token;
}

/** Strips a leading Arabic "to/for" connector ("لـ" / "ل") off a token
 *  that's otherwise a plain value (e.g. "لـ220Ω" -> "220Ω"), matching
 *  what `CircuitEditPlanner.parsePropertyValue()` already expects.
 *  Only strips when what's left looks like a numeric value — never
 *  off a word that's actually part of a name. */
function stripToConnector(token: string): string | null {
  const stripped = token.replace(/^لـ/, '').replace(/^ل/, '');
  return stripped !== token && /^[\d.]/.test(stripped) ? stripped : null;
}

/** Translates one whitespace-delimited token: an Arabic connector
 *  prefix off a value, an Arabic component noun, or an Arabic color —
 *  in that order — else returns the token unchanged (this is how
 *  already-Latin component names like "Arduino"/"Mega" pass through
 *  untranslated). */
function translateToken(token: string): string {
  const connectorStripped = stripToConnector(token);
  if (connectorStripped !== null) return connectorStripped;
  const bare = stripArticle(token);
  return COMPONENT_NOUNS[bare] ?? COLOR_WORDS[bare] ?? token;
}

const ENGLISH_COLOR_VALUES = new Set(Object.values(COLOR_WORDS));

function isValueToken(translated: string): boolean {
  return /^[\d.]/.test(translated) || ENGLISH_COLOR_VALUES.has(translated);
}

class IntentResolver implements IIntentResolver {
  resolve(text: string): IntentResolution {
    const trimmed = text.trim();
    if (!ARABIC_SCRIPT.test(trimmed)) return { status: 'unrecognized' };

    const trigger = ACTION_TRIGGERS.find((t) => t.pattern.test(trimmed));
    if (!trigger) return { status: 'unrecognized' };

    const rest = trimmed.replace(trigger.pattern, '').trim();
    if (rest.length === 0) {
      const message =
        trigger.intent === 'ADD_COMPONENT'
          ? 'What would you like to add?'
          : trigger.intent === 'REMOVE_COMPONENT'
            ? 'What would you like to remove?'
            : 'What would you like to change, and to what?';
      return { status: 'ambiguous', message };
    }

    const tokens = rest.split(/\s+/).map(translateToken);

    if (trigger.intent === 'MODIFY_PROPERTY') {
      // The value is whichever trailing token looks like a value
      // (color word or number) — everything before it is the target.
      // "خلي الليد أزرق" -> ["LED", "blue"] -> target "LED", value
      // "blue". Order-preserving, no reliance on a fixed word count.
      let valueStart = -1;
      for (let i = tokens.length - 1; i >= 0; i -= 1) {
        if (isValueToken(tokens[i])) {
          valueStart = i;
          break;
        }
      }
      if (valueStart === -1) {
        return { status: 'ambiguous', message: `What should "${rest}" be changed to?` };
      }
      const target = tokens.slice(0, valueStart).join(' ').trim();
      const value = tokens.slice(valueStart).join(' ').trim();
      if (target.length === 0) {
        return { status: 'ambiguous', message: `What would you like to change to "${value}"?` };
      }
      return { status: 'resolved', intent: 'MODIFY_PROPERTY', normalizedRequest: `change ${target} to ${value}` };
    }

    return {
      status: 'resolved',
      intent: trigger.intent,
      normalizedRequest: `${trigger.verb} ${tokens.join(' ')}`,
    };
  }
}

export const intentResolver = new IntentResolver();
