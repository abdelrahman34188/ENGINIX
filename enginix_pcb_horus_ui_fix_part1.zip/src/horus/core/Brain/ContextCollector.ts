/**
 * HORUS AI — Context Collector (Core/Brain).
 *
 * Responsible (once implemented) for gathering the pieces of live and
 * remembered context relevant to a reasoning request:
 *  - Current Circuit
 *  - Current PCB
 *  - Current Arduino Sketch
 *  - Current Simulation
 *  - Conversation Memory
 *  - User Memory
 *
 * Merges every source into a single structured context object. Intended
 * to back ReasoningPipeline's CollectContext stage. Distinct from
 * src/horus/context/ContextManager.ts, which owns live workspace-provider
 * snapshots (Simulator/PCB/Coding/Workspace/Gallery/Project) for the
 * wider app — ContextCollector is the Brain-level assembly point that
 * would draw on ContextManager, MemoryManager, and ConversationManager
 * once wired up. Does not itself fetch from those modules yet and does
 * not call any AI API.
 *
 * Interface + skeleton only — no logic, no implementation.
 */

export interface CurrentCircuitContext {
  circuit: unknown;
}

export interface CurrentPCBContext {
  pcb: unknown;
}

export interface CurrentArduinoSketchContext {
  sketch: unknown;
}

export interface CurrentSimulationContext {
  simulation: unknown;
}

export interface ConversationMemoryContext {
  conversationMemory: unknown;
}

export interface UserMemoryContext {
  userMemory: unknown;
}

/** One merged object combining every collected context source. */
export interface CollectedHorusContext {
  currentCircuit: CurrentCircuitContext;
  currentPCB: CurrentPCBContext;
  currentArduinoSketch: CurrentArduinoSketchContext;
  currentSimulation: CurrentSimulationContext;
  conversationMemory: ConversationMemoryContext;
  userMemory: UserMemoryContext;
}

export interface IContextCollector {
  /** Collect the current circuit context. */
  collectCurrentCircuit(): CurrentCircuitContext;

  /** Collect the current PCB context. */
  collectCurrentPCB(): CurrentPCBContext;

  /** Collect the current Arduino sketch context. */
  collectCurrentArduinoSketch(): CurrentArduinoSketchContext;

  /** Collect the current simulation context. */
  collectCurrentSimulation(): CurrentSimulationContext;

  /** Collect conversation memory context. */
  collectConversationMemory(): ConversationMemoryContext;

  /** Collect user memory context. */
  collectUserMemory(): UserMemoryContext;

  /** Collect all sources and return one structured context object. */
  collectAll(): CollectedHorusContext;
}

export class ContextCollector implements IContextCollector {
  collectCurrentCircuit(): CurrentCircuitContext {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  collectCurrentPCB(): CurrentPCBContext {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  collectCurrentArduinoSketch(): CurrentArduinoSketchContext {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  collectCurrentSimulation(): CurrentSimulationContext {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  collectConversationMemory(): ConversationMemoryContext {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  collectUserMemory(): UserMemoryContext {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  collectAll(): CollectedHorusContext {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
