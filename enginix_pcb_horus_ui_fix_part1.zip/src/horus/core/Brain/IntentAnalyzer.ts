/**
 * HORUS AI — Intent Analyzer (Core/Brain).
 *
 * Detects which of HORUS's supported intent categories a user request
 * belongs to, and returns that intent type — nothing else.
 *
 * Scope, deliberately narrow:
 *  - Detect intent. Return the intent type only.
 *  - No AI call, no provider call (does not import/touch AIGateway,
 *    AIProviderManager, GeminiProvider/GeminiClient, or anything in
 *    `core/AI/`).
 *  - No prompt generation (does not import/touch PromptBuilder,
 *    PromptValidator, or SystemPromptManager).
 *  - No simulator involvement (does not import/touch anything under
 *    `simulator`/`circuit`).
 *  - No tool selection or execution — that's DecisionEngine's and
 *    ToolExecutor's job, not this module's.
 *  - No frontend/UI changes — this file has no consumer wired in yet.
 *
 * Classification here is a plain, deterministic keyword match — no
 * model call, so behavior is fully inspectable and testable offline.
 * Used (once wired in) to back ReasoningPipeline's DetectIntent stage.
 */

/** Every intent type this analyzer can detect. */
export type HorusIntentType =
  | 'analyze_circuit'
  | 'fix_circuit'
  | 'generate_arduino'
  | 'explain_component'
  | 'convert_to_pcb'
  | 'chat';

export interface IntentAnalyzerInput {
  request: unknown;
  conversationContext?: unknown;
}

export interface IIntentAnalyzer {
  /** Detect and return the intent type for the given input — nothing else. */
  detectIntent(input: IntentAnalyzerInput): HorusIntentType;

  /** List every intent type this analyzer supports. */
  listSupportedIntents(): HorusIntentType[];
}

/** Every supported intent type, in priority order (first match wins
 *  when a request's text matches more than one category's keywords). */
export const HORUS_INTENT_TYPES: readonly HorusIntentType[] = [
  'fix_circuit',
  'convert_to_pcb',
  'generate_arduino',
  'explain_component',
  'analyze_circuit',
  'chat',
];

/** Keyword triggers per intent type. Plain substring match on the
 *  lowercased request text — no AI, no external calls. */
const INTENT_KEYWORDS: Readonly<Record<Exclude<HorusIntentType, 'chat'>, readonly string[]>> = {
  fix_circuit: ['fix', 'error', 'debug', 'broken', 'not working', "isn't working", 'short', 'troubleshoot'],
  convert_to_pcb: ['pcb', 'convert to pcb', 'board layout', 'footprint', 'gerber'],
  generate_arduino: ['arduino', 'sketch', 'generate code', 'write code', '.ino'],
  explain_component: ['explain', 'what is', "what's a", 'how does', 'datasheet', 'pinout'],
  analyze_circuit: ['analyze', 'analyse', 'review circuit', 'check circuit', 'circuit analysis'],
};

/** Pull plain text out of an unknown request shape without assuming a
 *  particular request format — accepts a raw string or an object with
 *  a `text`/`message`/`content` field; anything else yields ''. */
function extractText(request: unknown): string {
  if (typeof request === 'string') {
    return request;
  }
  if (request && typeof request === 'object') {
    const candidate = request as Record<string, unknown>;
    const field = candidate.text ?? candidate.message ?? candidate.content;
    if (typeof field === 'string') {
      return field;
    }
  }
  return '';
}

export class IntentAnalyzer implements IIntentAnalyzer {
  detectIntent(input: IntentAnalyzerInput): HorusIntentType {
    const text = extractText(input.request).toLowerCase();

    if (text.length === 0) {
      return 'chat';
    }

    for (const intent of HORUS_INTENT_TYPES) {
      if (intent === 'chat') {
        continue;
      }
      const keywords = INTENT_KEYWORDS[intent];
      if (keywords.some((keyword) => text.includes(keyword))) {
        return intent;
      }
    }

    return 'chat';
  }

  listSupportedIntents(): HorusIntentType[] {
    return [...HORUS_INTENT_TYPES];
  }
}

/** Shared instance — stateless, mirrors `router/IntentRouter.ts`'s
 *  exported `intentRouter` singleton. */
export const intentAnalyzer = new IntentAnalyzer();
