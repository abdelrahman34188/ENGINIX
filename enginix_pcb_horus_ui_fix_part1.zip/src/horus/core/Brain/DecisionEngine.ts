/**
 * HORUS AI — Decision Engine (Core/Brain).
 *
 * Responsible (once implemented) for choosing which registered tool
 * should execute a given request, e.g.:
 *  - Circuit question    -> CircuitTool
 *  - PCB question         -> PCBTool
 *  - Arduino code          -> ArduinoTool
 *  - Simulation             -> SimulationTool
 *  - Component search        -> ComponentTool
 *
 * Intended to consult ToolRegistry for available tools once implemented.
 * Used by HORUSBrain's plan()/execute() stages — does not itself execute
 * tools or call any AI API.
 *
 * Interface + skeleton only — no logic, no implementation.
 */

import type { HorusToolName } from '../Tools/ToolRegistry';

export interface DecisionEngineInput {
  request: unknown;
  analysis?: unknown;
}

export interface DecisionEngineResult {
  toolName: HorusToolName | undefined;
  reason?: string;
}

export interface IDecisionEngine {
  /** Decide which tool should handle the given input. */
  decideTool(input: DecisionEngineInput): DecisionEngineResult;

  /** Return the ranked list of candidate tools for the given input. */
  rankCandidates(input: DecisionEngineInput): DecisionEngineResult[];
}

export class DecisionEngine implements IDecisionEngine {
  decideTool(_input: DecisionEngineInput): DecisionEngineResult {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  rankCandidates(_input: DecisionEngineInput): DecisionEngineResult[] {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
