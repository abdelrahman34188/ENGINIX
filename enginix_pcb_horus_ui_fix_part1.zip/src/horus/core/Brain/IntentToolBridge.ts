/**
 * HORUS AI — Intent → Tool Bridge (Core/Brain).
 *
 * Connects `router/IntentRouter.ts` to `core/Brain/ToolExecutor.ts`:
 * a HORUS action button resolves to a structured intent (via
 * `IntentRouter`), and that intent id — never free text, never an AI
 * response — is mapped straight to a `ToolExecutionRequest` and handed
 * to `ToolExecutor`.
 *
 * Explicitly out of scope / untouched by this module:
 *  - No AI provider is called anywhere in this path (no Gemini).
 *  - `core/Managers/PromptManager.ts` is not read or written.
 *  - `core/AI/AIGateway.ts` is not read or written.
 *  - No UI component is modified — this is wiring only; callers (e.g.
 *    `components/horus-ai/HorusAIView.tsx`) opt in by importing
 *    `intentToolBridge` themselves.
 *
 * This is a second, independent path alongside `HORUSBrain.run()` /
 * `runtime.ts`'s `runHorusPrompt()` (the free-text -> AIGateway path).
 * The two are not wired together here, so neither can accidentally
 * fall through into the other.
 */

import { intentRouter, type HorusButtonIntent, type IIntentRouter, type IntentRouteResult } from '../../router/IntentRouter';
import { toolExecutor, type IToolExecutor, type ToolExecutionRequest, type ToolExecutionResult } from './ToolExecutor';
import type { HorusToolName } from '../Tools/ToolRegistry';

/** Fixed intent -> tool map. Every `HorusButtonIntent` must appear
 *  exactly once, so this stays exhaustive as new intents are added. */
const INTENT_TOOL_MAP: Readonly<Record<HorusButtonIntent, HorusToolName>> = {
  explain_component: 'ComponentTool',
  analyze_circuit: 'CircuitTool',
  generate_arduino: 'ArduinoTool',
  fix_errors: 'CircuitTool',
  convert_pcb: 'PCBTool',
};

export interface IIntentToolBridge {
  /** Route an already-known intent id straight to its tool and execute. */
  runIntent(intent: HorusButtonIntent, input: unknown): ToolExecutionResult;

  /** Route a HORUS action button's label to its intent, then to its tool. */
  runByLabel(label: string, input: unknown): ToolExecutionResult | undefined;

  /** Take an already-routed result (e.g. from `IntentRouter.routeByLabel`)
   *  and execute the tool it resolves to. This is the "only pass
   *  structured intents" entry point — `route` must be an
   *  `IntentRouteResult`, never a raw string or free-text request. */
  runRoutedIntent(route: IntentRouteResult, input: unknown): ToolExecutionResult;
}

export class IntentToolBridge implements IIntentToolBridge {
  private readonly router: IIntentRouter;
  private readonly executor: IToolExecutor;

  constructor(router: IIntentRouter = intentRouter, executor: IToolExecutor = toolExecutor) {
    this.router = router;
    this.executor = executor;
  }

  runIntent(intent: HorusButtonIntent, input: unknown): ToolExecutionResult {
    return this.runRoutedIntent(this.router.route(intent), input);
  }

  runByLabel(label: string, input: unknown): ToolExecutionResult | undefined {
    const route = this.router.routeByLabel(label);
    if (!route) {
      return undefined;
    }
    return this.runRoutedIntent(route, input);
  }

  runRoutedIntent(route: IntentRouteResult, input: unknown): ToolExecutionResult {
    const toolName = INTENT_TOOL_MAP[route.intent];
    const request: ToolExecutionRequest = { toolName, actionId: route.intent, input };
    this.executor.receiveRequest(request);
    return this.executor.executeTool(request);
  }
}

/** Shared instance — mirrors `intentRouter` / `toolExecutor` singletons. */
export const intentToolBridge = new IntentToolBridge();
