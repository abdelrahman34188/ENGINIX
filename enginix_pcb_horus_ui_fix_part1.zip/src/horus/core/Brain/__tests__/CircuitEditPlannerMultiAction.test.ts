import { describe, it, expect } from 'vitest';
import { CircuitEditPlanner, splitActionRequests } from '../CircuitEditPlanner';

describe('splitActionRequests', () => {
  it('splits a period-separated multi-action request into its clauses, in order', () => {
    const clauses = splitActionRequests('Replace R1 with 220Ω. Add LED. Connect LED to R1.');
    expect(clauses).toEqual(['Replace R1 with 220Ω', 'Add LED', 'Connect LED to R1']);
  });

  it('splits on "then" / "and then" as well as sentence punctuation', () => {
    expect(splitActionRequests('Add LED then connect it to R1')).toEqual(['Add LED', 'connect it to R1']);
    expect(splitActionRequests('Add LED and then connect it to R1')).toEqual([
      'Add LED',
      'connect it to R1',
    ]);
  });

  it('splits on semicolons and newlines too', () => {
    expect(splitActionRequests('Add LED; Remove R1\nRename C1 to Main Cap')).toEqual([
      'Add LED',
      'Remove R1',
      'Rename C1 to Main Cap',
    ]);
  });

  it('returns a single-element array for a single-action request', () => {
    expect(splitActionRequests('Add LED')).toEqual(['Add LED']);
  });

  it('drops empty clauses from doubled-up punctuation', () => {
    expect(splitActionRequests('Add LED... Remove R1.')).toEqual(['Add LED', 'Remove R1']);
  });

  it('returns an empty array for empty text', () => {
    expect(splitActionRequests('')).toEqual([]);
    expect(splitActionRequests('   ')).toEqual([]);
  });
});

describe('CircuitEditPlanner — multi-action', () => {
  const planner = new CircuitEditPlanner();

  it('isMultiActionRequest is true for a multi-clause request, false for a single one', () => {
    expect(planner.isMultiActionRequest({ request: 'Replace R1 with 220Ω. Add LED.' })).toBe(true);
    expect(planner.isMultiActionRequest({ request: 'Add LED' })).toBe(false);
    expect(planner.isMultiActionRequest({ request: '' })).toBe(false);
  });

  it('planEdits plans "Replace R1 with 220Ω. Add LED. Connect LED to R1." as three ordered actions', () => {
    const entries = planner.planEdits({ request: 'Replace R1 with 220Ω. Add LED. Connect LED to R1.' });

    expect(entries).toHaveLength(3);
    expect(entries.map((e) => e.index)).toEqual([0, 1, 2]);
    expect(entries.map((e) => e.requestText)).toEqual([
      'Replace R1 with 220Ω',
      'Add LED',
      'Connect LED to R1',
    ]);

    expect(entries[0].plan).toEqual(
      expect.objectContaining({ action: 'replace_component', target: expect.objectContaining({ raw: 'R1' }) }),
    );
    expect(entries[1].plan).toEqual(
      expect.objectContaining({ action: 'add_component', target: expect.objectContaining({ raw: 'LED' }) }),
    );
    expect(entries[2].plan).toEqual(
      expect.objectContaining({
        action: 'connect_components',
        target: expect.objectContaining({ raw: 'LED' }),
        secondaryTarget: expect.objectContaining({ raw: 'R1' }),
      }),
    );
  });

  it('planEditsJSON returns the same clauses in the compact EditPlanJSON shape', () => {
    const entries = planner.planEditsJSON({ request: 'Add LED. Remove R1.' });
    expect(entries).toEqual([
      { index: 0, requestText: 'Add LED', plan: { action: 'add', target: 'LED', value: null } },
      { index: 1, requestText: 'Remove R1', plan: { action: 'remove', target: 'R1', value: null } },
    ]);
  });

  it('reports a null plan (not a thrown error, not a dropped clause) for a clause that is not a recognizable edit', () => {
    const entries = planner.planEdits({ request: 'Add LED. Blah blah not an edit. Remove R1.' });
    expect(entries).toHaveLength(3);
    expect(entries[0].plan).not.toBeNull();
    expect(entries[1].plan).toBeNull();
    expect(entries[1].requestText).toBe('Blah blah not an edit');
    expect(entries[2].plan).not.toBeNull();
  });

  it('planEdits returns an empty array for an empty request', () => {
    expect(planner.planEdits({ request: '' })).toEqual([]);
  });
});
