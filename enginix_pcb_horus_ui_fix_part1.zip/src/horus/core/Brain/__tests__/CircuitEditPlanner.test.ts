import { describe, it, expect } from 'vitest';
import { CircuitEditPlanner, toEditPlanJSON } from '../CircuitEditPlanner';

describe('CircuitEditPlanner', () => {
  const planner = new CircuitEditPlanner();

  it('detects "Add LED" as add_component', () => {
    const plan = planner.planEdit({ request: 'Add LED' });
    expect(plan).toEqual(
      expect.objectContaining({
        action: 'add_component',
        target: expect.objectContaining({ raw: 'LED' }),
      }),
    );
  });

  it('detects "Remove resistor" as remove_component', () => {
    const plan = planner.planEdit({ request: 'Remove resistor' });
    expect(plan).toEqual(
      expect.objectContaining({
        action: 'remove_component',
        target: { raw: 'resistor', kind: 'type', componentType: 'resistor' },
      }),
    );
  });

  it('detects "Change resistor to 220Ω" as change_property with parsed value/unit', () => {
    const plan = planner.planEdit({ request: 'Change resistor to 220Ω' });
    expect(plan).toEqual(
      expect.objectContaining({
        action: 'change_property',
        target: { raw: 'resistor', kind: 'type', componentType: 'resistor' },
        propertyChange: { raw: '220Ω', value: '220', unit: 'Ω' },
      }),
    );
  });

  it('detects "Connect battery to switch" as connect_components with both targets', () => {
    const plan = planner.planEdit({ request: 'Connect battery to switch' });
    expect(plan).toEqual(
      expect.objectContaining({
        action: 'connect_components',
        target: { raw: 'battery', kind: 'type', componentType: 'battery' },
        secondaryTarget: { raw: 'switch', kind: 'type', componentType: 'switch' },
      }),
    );
  });

  it('detects "Disconnect LED" as disconnect_components', () => {
    const plan = planner.planEdit({ request: 'Disconnect LED' });
    expect(plan).toEqual(
      expect.objectContaining({
        action: 'disconnect_components',
        target: expect.objectContaining({ raw: 'LED' }),
      }),
    );
  });

  it('detects "Rename component" as rename_component even without a new name', () => {
    const plan = planner.planEdit({ request: 'Rename component' });
    expect(plan).toEqual(
      expect.objectContaining({
        action: 'rename_component',
        target: expect.objectContaining({ raw: 'component' }),
        newName: null,
      }),
    );
  });

  it('parses a new name when "rename X to Y" is given', () => {
    const plan = planner.planEdit({ request: 'Rename R1 to Main Resistor' });
    expect(plan).toEqual(
      expect.objectContaining({
        action: 'rename_component',
        target: { raw: 'R1', kind: 'designator', componentType: null },
        newName: 'Main Resistor',
      }),
    );
  });

  it('detects "Replace R1 with a 220Ω resistor" as replace_component with both targets', () => {
    const plan = planner.planEdit({ request: 'Replace R1 with a 220Ω resistor' });
    expect(plan).toEqual(
      expect.objectContaining({
        action: 'replace_component',
        target: { raw: 'R1', kind: 'designator', componentType: null },
        replacement: { raw: '220Ω resistor', kind: 'type', componentType: 'resistor' },
      }),
    );
  });

  it('detects "Swap component" as replace_component even without a replacement named', () => {
    const plan = planner.planEdit({ request: 'Swap component' });
    expect(plan).toEqual(
      expect.objectContaining({
        action: 'replace_component',
        target: expect.objectContaining({ raw: 'component' }),
        replacement: null,
      }),
    );
  });

  it('returns null for non-edit requests', () => {
    expect(planner.planEdit({ request: 'Why is my LED not lighting up?' })).toBeNull();
    expect(planner.planEdit({ request: 'Explain how a resistor works' })).toBeNull();
    expect(planner.isEditRequest({ request: 'Analyze this circuit' })).toBe(false);
  });

  it('returns null for empty/unrecognized request shapes', () => {
    expect(planner.planEdit({ request: '' })).toBeNull();
    expect(planner.planEdit({ request: {} })).toBeNull();
  });

  it('never mutates or reaches into simulator/circuit state — plan is pure text parsing', () => {
    // No CircuitEditor/CircuitTool import exists in this module at all;
    // this test just documents the guarantee the file header states.
    expect(planner.planEdit({ request: 'Add LED' })?.requestText).toBe('Add LED');
  });

  describe('target detection', () => {
    it('classifies a reference designator (e.g. "R1") as kind: designator', () => {
      const plan = planner.planEdit({ request: 'Change R1 to 330Ω' });
      expect(plan?.target).toEqual({ raw: 'R1', kind: 'designator', componentType: null });
    });

    it('classifies designators with letter+number+sub-index (e.g. "LED2")', () => {
      const plan = planner.planEdit({ request: 'Remove LED2' });
      expect(plan?.target).toEqual({ raw: 'LED2', kind: 'designator', componentType: null });
    });

    it('classifies a known component type word as kind: type', () => {
      const plan = planner.planEdit({ request: 'Add MOSFET' });
      expect(plan?.target).toEqual({ raw: 'MOSFET', kind: 'type', componentType: 'mosfet' });
    });

    it('classifies a component type phrase ("Replace Q1 with MOSFET")', () => {
      const plan = planner.planEdit({ request: 'Replace Q1 with MOSFET' });
      expect(plan?.target).toEqual({ raw: 'Q1', kind: 'designator', componentType: null });
      expect(plan?.replacement).toEqual({ raw: 'MOSFET', kind: 'type', componentType: 'mosfet' });
    });

    it('classifies multi-word type phrases by their trailing type word (e.g. "220Ω resistor")', () => {
      const plan = planner.planEdit({ request: 'Replace R1 with a 220Ω resistor' });
      expect(plan?.replacement).toEqual({ raw: '220Ω resistor', kind: 'type', componentType: 'resistor' });
    });

    it('classifies pronoun/selection references as kind: selected', () => {
      expect(planner.planEdit({ request: 'Remove it' })?.target).toEqual({
        raw: 'it', kind: 'selected', componentType: null,
      });
      expect(planner.planEdit({ request: 'Remove this' })?.target).toEqual({
        raw: 'this', kind: 'selected', componentType: null,
      });
    });

    it('classifies "the selected component" phrasing as kind: selected', () => {
      const plan = planner.planEdit({ request: 'Change the selected component to 10k' });
      expect(plan?.target).toEqual({ raw: 'selected component', kind: 'selected', componentType: null });
    });

    it('classifies an unrecognized free-text target as kind: unknown', () => {
      const plan = planner.planEdit({ request: 'Remove the thingamajig' });
      expect(plan?.target).toEqual({ raw: 'thingamajig', kind: 'unknown', componentType: null });
    });
  });

  describe('planEditJSON / toEditPlanJSON', () => {
    it('matches the compact { action, target, value } shape for a value change', () => {
      const json = planner.planEditJSON({ request: 'Change R1 to 220Ω' });
      expect(json).toEqual({ action: 'change_value', target: 'R1', value: '220Ω' });
    });

    it('maps add_component -> "add" with no value', () => {
      expect(planner.planEditJSON({ request: 'Add LED' })).toEqual({
        action: 'add',
        target: 'LED',
        value: null,
      });
    });

    it('maps remove_component -> "remove" with no value', () => {
      expect(planner.planEditJSON({ request: 'Remove resistor' })).toEqual({
        action: 'remove',
        target: 'resistor',
        value: null,
      });
    });

    it('maps connect_components -> "connect" with the second component as value', () => {
      expect(planner.planEditJSON({ request: 'Connect battery to switch' })).toEqual({
        action: 'connect',
        target: 'battery',
        value: 'switch',
      });
    });

    it('maps disconnect_components -> "disconnect"', () => {
      expect(planner.planEditJSON({ request: 'Disconnect LED' })).toEqual({
        action: 'disconnect',
        target: 'LED',
        value: null,
      });
    });

    it('maps rename_component -> "rename" with the new name as value', () => {
      expect(planner.planEditJSON({ request: 'Rename R1 to Main Resistor' })).toEqual({
        action: 'rename',
        target: 'R1',
        value: 'Main Resistor',
      });
    });

    it('maps replace_component -> "replace" with the replacement as value', () => {
      expect(planner.planEditJSON({ request: 'Replace R1 with a resistor' })).toEqual({
        action: 'replace',
        target: 'R1',
        value: 'resistor',
      });
    });

    it('returns null for non-edit requests', () => {
      expect(planner.planEditJSON({ request: 'Explain how a resistor works' })).toBeNull();
    });

    it('toEditPlanJSON is a pure mapping usable independently of the planner', () => {
      const plan = planner.planEdit({ request: 'Change resistor to 220Ω' });
      expect(plan).not.toBeNull();
      expect(toEditPlanJSON(plan!)).toEqual({
        action: 'change_value',
        target: 'resistor',
        value: '220Ω',
      });
    });
  });
});
