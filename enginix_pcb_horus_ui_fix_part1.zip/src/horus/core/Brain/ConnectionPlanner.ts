/**
 * HORUS AI — Connection Planner (Core/Brain) — Phase 3 (Auto Wiring).
 *
 * Synthesizes `PlannedConnection[]` for a resolved component list
 * generically — from each component's electrical *role*
 * (`ComponentRoles`: power source / controller / passthrough / load),
 * never from which named scenario ("LED circuit", "traffic light")
 * produced the list. `CircuitPlanner` calls this once, the same way,
 * for every scenario and for the generic fallback — nothing here
 * knows or cares what the user's goal text said.
 *
 * Two topologies, chosen purely by what roles are present:
 *  - No controller (`arduino`/`arduinoMega`/`arduinoNano`) present:
 *    a single series loop — power source, then every passthrough part
 *    (in the order they appear in the plan), then every load (in
 *    order), back to the power source's return terminal. This is a
 *    generic default for "put everything in one loop", not a claim
 *    about what's electrically optimal for an arbitrary circuit.
 *  - A controller present: each load gets its own digital pin
 *    (skipping D0/D1 — serial), in series with its own resistor when
 *    the plan has exactly as many resistors as loads (paired by
 *    order), then back to the controller's `GND`. Multiple loads get
 *    distinct pins, never the same one.
 *
 * Still only *planned* — every endpoint here is (type, instanceIndex,
 * role), not yet a real component id or confirmed-live terminal.
 * `WiringExecutor` is what resolves and verifies each of those against
 * the actual simulator, and is the only place a missing component or
 * terminal is ever reported — this module never invents one to keep a
 * chain "complete".
 */
import type { PlannedComponent, PlannedConnection, PlannedConnectionEndpoint } from './CircuitPlanner';
import { roleOf, isController, powerSourceIo, inlineIo, candidateDigitalPinLabels, ARDUINO_GND_LABEL } from '../../tools/ComponentRoles';

interface FlatInstance {
  type: string;
  instanceIndex: number;
}

/** Expands `components` (each with a `quantity`) into one entry per
 *  real instance, in the same order `CircuitPlanExecutor` creates them
 *  (`instanceIndex` 0-based per type) — the same indexing
 *  `WiringExecutor` uses to look an endpoint's real component up. */
function flattenInstances(components: PlannedComponent[]): FlatInstance[] {
  const flat: FlatInstance[] = [];
  for (const c of components) {
    for (let i = 0; i < c.quantity; i++) flat.push({ type: c.type, instanceIndex: i });
  }
  return flat;
}

function endpoint(type: string, instanceIndex: number, role: string): PlannedConnectionEndpoint {
  return { componentType: type, instanceIndex, role };
}

export function planConnections(components: PlannedComponent[]): PlannedConnection[] {
  const flat = flattenInstances(components);
  const controller = flat.find((f) => isController(f.type));

  if (controller) return planControllerTopology(flat, controller);
  return planSeriesTopology(flat);
}

// ---------------------------------------------------------------------------
// No-controller topology: one series loop through everything present.
// ---------------------------------------------------------------------------

function planSeriesTopology(flat: FlatInstance[]): PlannedConnection[] {
  const powerSource = flat.find((f) => roleOf(f.type) === 'powerSource');
  if (!powerSource) return []; // Nothing to reference a loop against.

  const chain = [
    ...flat.filter((f) => roleOf(f.type) === 'passthrough'),
    ...flat.filter((f) => roleOf(f.type) === 'load'),
  ];
  if (chain.length === 0) return []; // Bare power source alone — nothing to close a loop through.

  const io = powerSourceIo(powerSource.type)!;
  const connections: PlannedConnection[] = [];
  let prev = endpoint(powerSource.type, powerSource.instanceIndex, io.out);

  for (const node of chain) {
    const nodeIo = inlineIo(node.type);
    if (!nodeIo) continue; // Unknown role for this type — reported later by WiringExecutor if referenced elsewhere; skipped from the chain rather than guessed.
    const nodeIn = endpoint(node.type, node.instanceIndex, nodeIo.in);
    connections.push({ from: prev, to: nodeIn, description: `${describeEndpoint(prev)} to ${describeEndpoint(nodeIn)}.` });
    prev = endpoint(node.type, node.instanceIndex, nodeIo.out);
  }

  const back = endpoint(powerSource.type, powerSource.instanceIndex, io.return);
  connections.push({ from: prev, to: back, description: `${describeEndpoint(prev)} back to ${describeEndpoint(back)}, closing the loop.` });

  return connections;
}

// ---------------------------------------------------------------------------
// Controller topology: one digital pin (+ optional paired resistor) per
// load, all returning to the controller's shared GND.
// ---------------------------------------------------------------------------

function planControllerTopology(flat: FlatInstance[], controller: FlatInstance): PlannedConnection[] {
  const resistors = flat.filter((f) => roleOf(f.type) === 'passthrough');
  const loads = flat.filter((f) => roleOf(f.type) === 'load');
  if (loads.length === 0) return [];

  const pairResistors = resistors.length === loads.length;
  const pins = candidateDigitalPinLabels(loads.length);
  const connections: PlannedConnection[] = [];

  loads.forEach((load, i) => {
    const loadIo = inlineIo(load.type);
    if (!loadIo) return;

    const pinEndpoint = endpoint(controller.type, controller.instanceIndex, pins[i]);
    const loadIn = endpoint(load.type, load.instanceIndex, loadIo.in);
    const loadOut = endpoint(load.type, load.instanceIndex, loadIo.out);
    const gnd = endpoint(controller.type, controller.instanceIndex, ARDUINO_GND_LABEL);

    if (pairResistors) {
      const resistor = resistors[i];
      const resistorIn = endpoint(resistor.type, resistor.instanceIndex, 'pin1');
      const resistorOut = endpoint(resistor.type, resistor.instanceIndex, 'pin2');
      connections.push({ from: pinEndpoint, to: resistorIn, description: `${describeEndpoint(pinEndpoint)} to ${describeEndpoint(resistorIn)}.` });
      connections.push({ from: resistorOut, to: loadIn, description: `${describeEndpoint(resistorOut)} to ${describeEndpoint(loadIn)}.` });
    } else {
      connections.push({ from: pinEndpoint, to: loadIn, description: `${describeEndpoint(pinEndpoint)} to ${describeEndpoint(loadIn)}.` });
    }

    connections.push({ from: loadOut, to: gnd, description: `${describeEndpoint(loadOut)} to ${describeEndpoint(gnd)}.` });
  });

  return connections;
}

function describeEndpoint(e: PlannedConnectionEndpoint): string {
  return `${e.componentType} #${e.instanceIndex + 1} (${e.role})`;
}
