/**
 * HORUS AI — Tool Executor (Core/Brain).
 *
 * Responsible (once implemented) for the execution stage that follows
 * DecisionEngine's tool selection:
 *  - Receive a tool request (tool name + input, as decided upstream).
 *  - Locate the requested tool via ToolRegistry.
 *  - Execute the located tool with the given input.
 *  - Return a structured result (success/failure, output, error info).
 *
 * Sits between DecisionEngine and the concrete Tools
 * (CircuitTool, PCBTool, ArduinoTool, SimulationTool, ComponentTool).
 * Used by HORUSBrain's execute() stage — does not itself decide which
 * tool to use (that is DecisionEngine's responsibility) and does not
 * call any AI API.
 *
 * Implementation status: locates a tool via ToolRegistry and returns a
 * structured result. The concrete Tools (CircuitTool, PCBTool, etc.)
 * are still skeletons themselves, so "executing" a tool here just means
 * confirming it's registered and handing its input back as output —
 * no AI provider is called and no Gemini request is made anywhere in
 * this path.
 */

import type { HorusToolName, IToolRegistry } from '../Tools/ToolRegistry';
import { toolRegistry } from '../Tools/ToolRegistry';
import {
  buildAnalyzeCircuitResult,
  buildExplainComponentResult,
  buildFixErrorsResult,
  buildConvertPcbResult,
  buildGenerateArduinoResult,
} from './HorusActionResults';

export interface ToolExecutionRequest {
  toolName: HorusToolName;
  /** Which of the five HORUS actions this request is for, when known —
   *  lets `executeTool` pick the right real result builder below. Two
   *  actions (`analyze_circuit`/`fix_errors`) share `toolName:
   *  'CircuitTool'`, so `toolName` alone isn't enough to disambiguate. */
  actionId?: string;
  input: unknown;
}

export type ToolExecutionStatus = 'success' | 'error';

export interface ToolExecutionResult {
  status: ToolExecutionStatus;
  toolName: HorusToolName;
  output?: unknown;
  error?: string;
}

export interface IToolExecutor {
  /** Receive a tool execution request. */
  receiveRequest(request: ToolExecutionRequest): void;

  /** Locate the requested tool via the tool registry. */
  locateTool(toolName: HorusToolName): unknown;

  /** Execute the located tool against the given request. */
  executeTool(request: ToolExecutionRequest): ToolExecutionResult;

  /** Return the structured result of the last execution. */
  getResult(): ToolExecutionResult | undefined;
}

export class ToolExecutor implements IToolExecutor {
  private readonly registry: IToolRegistry;
  private pendingRequest: ToolExecutionRequest | undefined;
  private lastResult: ToolExecutionResult | undefined;

  constructor(registry: IToolRegistry = toolRegistry) {
    this.registry = registry;
  }

  receiveRequest(request: ToolExecutionRequest): void {
    this.pendingRequest = request;
  }

  locateTool(toolName: HorusToolName): unknown {
    return this.registry.getTool(toolName);
  }

  executeTool(request: ToolExecutionRequest): ToolExecutionResult {
    this.pendingRequest = request;
    const tool = this.locateTool(request.toolName);

    if (!tool) {
      const result: ToolExecutionResult = {
        status: 'error',
        toolName: request.toolName,
        error: `Tool "${request.toolName}" is not registered.`,
      };
      this.lastResult = result;
      return result;
    }

    // Previously: `output: request.input` — this just echoed the caller's
    // request (e.g. `{ conversationId }`) straight back as the "result".
    // Now: run the real handler for the requested action, reading the
    // live circuit and existing engines (see HorusActionResults.ts).
    let output: unknown;
    try {
      output = this.buildOutput(request);
    } catch (err) {
      const result: ToolExecutionResult = {
        status: 'error',
        toolName: request.toolName,
        error: err instanceof Error ? err.message : String(err),
      };
      this.lastResult = result;
      return result;
    }

    const result: ToolExecutionResult = { status: 'success', toolName: request.toolName, output };
    this.lastResult = result;
    return result;
  }

  /** Picks the real result builder for this request's action. Falls back
   *  to handing the input back only for an unrecognized `actionId` (e.g.
   *  a future action not yet wired here), so unknown requests fail loud
   *  rather than silently returning nothing. */
  private buildOutput(request: ToolExecutionRequest): unknown {
    switch (request.actionId) {
      case 'analyze_circuit':
        return buildAnalyzeCircuitResult();
      case 'explain_component':
        return buildExplainComponentResult();
      case 'fix_errors':
        return buildFixErrorsResult();
      case 'convert_pcb':
        return buildConvertPcbResult();
      case 'generate_arduino':
        return buildGenerateArduinoResult();
      default:
        throw new Error(`No result builder wired for action "${request.actionId ?? request.toolName}".`);
    }
  }

  getResult(): ToolExecutionResult | undefined {
    return this.lastResult;
  }
}

/** Shared instance — stateless besides the last request/result, mirrors
 *  `router/IntentRouter.ts`'s exported `intentRouter` singleton. */
export const toolExecutor = new ToolExecutor();
