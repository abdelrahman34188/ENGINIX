/**
 * HORUS AI — HORUSBrain (Core/Brain).
 *
 * Responsible (once implemented) for the central reasoning pipeline:
 * receiving the user request, conversation context, project context, and
 * memory, then driving that input through analyze -> plan -> execute ->
 * review -> respond.
 *
 * Implementation status: minimal but functional straight-line pipeline
 * — receive -> build a StructuredPrompt (PromptBuilder) -> validate
 * (PromptValidator) -> send (AIGateway, which resolves the active
 * provider and calls it). This intentionally does NOT implement
 * intent analysis, tool execution, multi-turn conversation history, or
 * knowledge-base grounding (see IntentAnalyzer.ts, ToolExecutor.ts,
 * ConversationManager.ts, KnowledgeBaseManager.ts — still skeletons):
 * those aren't needed for a single stateless prompt-in/text-out request
 * and are a larger, separate piece of work. `analyze`/`plan`/`execute`/
 * `review`/`respond` below are the minimal versions of those steps —
 * assemble the prompt, validate it, call the gateway, pass the result
 * through unchanged, return the text — not full reasoning stages.
 *
 * The interface below fixes synchronous-looking (`unknown`/`void`)
 * return types, but `execute()`/`startReasoningPipeline()` are
 * implemented as async internally — `unknown`/`void` both structurally
 * accept a `Promise` in TypeScript, so this stays interface-compatible.
 * `run()` is the practical entry point callers should use.
 *
 * A second, separate entry point — `buildBrainRequest()` — runs the
 * non-AI wiring stage: IntentAnalyzer -> Planner -> ContextBuilder ->
 * a structured `BrainRequest`. It does not call AIGateway, does not
 * call ToolExecutor, and does not touch `run()`/`startReasoningPipeline()`
 * or any of the fields/methods those use — the two entry points are
 * independent, so neither can fall through into the other. It's the
 * non-AI counterpart to `run()`, for callers that just need to know
 * what HORUS would do with a request, without actually doing it.
 *
 * A third entry point — `handleRequest()` — completes the full
 * pipeline: User Request -> IntentAnalyzer -> Planner -> ContextBuilder
 * -> ResponseOrchestrator -> `BrainResponse`. It's `buildBrainRequest()`
 * followed by handing the resulting `BrainRequest` to
 * `ResponseOrchestrator.handle()`, which is what actually calls
 * `ToolExecutor` or `AIGateway`. Independent of `run()`/
 * `startReasoningPipeline()` — the three entry points don't call each
 * other.
 *
 * Invariant: whenever Planner decides an AI response is required
 * (`plan.requiresTool === false`), the call path is always
 * Brain -> AIGateway -> Provider -> back to AIGateway -> back to
 * Brain, with the response returned as this method's/`run()`'s
 * result. AIGateway alone resolves and calls the active provider
 * (`AIGateway.send()` -> `providerManager.getCurrentProvider()` ->
 * `provider.generate()`), and hands the normalized `AIResponse`
 * straight back to its caller — Brain never receives anything from a
 * provider except through that return value. Neither this file nor
 * `ResponseOrchestrator.ts` imports `GeminiProvider`, `GeminiClient`,
 * `AIProviderManager`, or `ProviderRegistry` — Gemini (or any other
 * provider) is never called directly from Brain, and no UI has a path
 * to a provider either (both AI-calling entry points below are the
 * only callers of `AIGateway.send()` in this file). This holds for
 * both AI-calling entry points: `run()` (which calls `aiGateway.send()`
 * directly, unchanged from before) and `handleRequest()` (which calls
 * it exclusively through `ResponseOrchestrator`).
 *
 * Mirror invariant for tools: whenever Planner selects a tool
 * (`plan.requiresTool === true`), the call path is always
 * Brain -> ResponseOrchestrator -> ToolExecutor — `handleRequest()`
 * never calls `ToolExecutor` itself; only `ResponseOrchestrator.handle()`
 * does. No tool is ever called directly from a UI component: nothing
 * outside `core/Brain/` imports `ToolExecutor`, so a button handler has
 * no path to a tool that skips this pipeline.
 */

import type { IPromptBuilder, StructuredPrompt } from '../Prompt/PromptBuilder';
import type { IPromptValidator } from '../Prompt/PromptValidator';
import type { ISystemPromptManager } from '../Prompt/SystemPromptManager';
import type { IAIGateway } from '../AI/AIGateway';
import type { AIResponse } from '../AI/AIResponse';
import { HORUS_AI_NAME, HORUS_AI_ROLE } from '../../identity';
import { intentAnalyzer, type HorusIntentType, type IIntentAnalyzer } from './IntentAnalyzer';
import { planner, type ExecutionPlan, type IPlanner } from './Planner';
import { contextBuilder, type ContextBuilderInput, type HorusContext, type IContextBuilder } from './ContextBuilder';
import { ResponseOrchestrator, type IResponseOrchestrator, type BrainResponse } from './ResponseOrchestrator';

export interface HORUSBrainInput {
  userRequest: unknown;
  conversationContext: unknown;
  projectContext: unknown;
  memory: unknown;
}

/** Input for the non-AI `buildBrainRequest()` flow: the raw pieces
 *  ContextBuilder merges, plus the user request IntentAnalyzer reads. */
export interface BuildBrainRequestInput extends ContextBuilderInput {
  userRequest: unknown;
}

/** The structured result of User -> IntentAnalyzer -> Planner ->
 *  ContextBuilder. No AI has been called and no tool has been
 *  executed to produce this — it's a description of what HORUS would
 *  do next, not the doing of it. */
export interface BrainRequest {
  intent: HorusIntentType;
  plan: ExecutionPlan;
  context: HorusContext;
}

export interface IHORUSBrain {
  /** Receive the user request. */
  receiveUserRequest(request: unknown): void;

  /** Receive the conversation context. */
  receiveConversationContext(context: unknown): void;

  /** Receive the project context. */
  receiveProjectContext(context: unknown): void;

  /** Receive memory. */
  receiveMemory(memory: unknown): void;

  /** Start the reasoning pipeline. */
  startReasoningPipeline(): void;

  /** Analyze the received input. */
  analyze(): unknown;

  /** Plan a course of action. */
  plan(): unknown;

  /** Execute the plan. */
  execute(): unknown;

  /** Review the execution result. */
  review(): unknown;

  /** Produce the final response. */
  respond(): unknown;
}

export class HORUSBrain implements IHORUSBrain {
  private userRequest: unknown;
  private conversationContext: unknown;
  private projectContext: unknown;
  private memory: unknown;
  private structuredPrompt: StructuredPrompt | undefined;
  private result: AIResponse | undefined;

  private readonly promptBuilder: IPromptBuilder;
  private readonly promptValidator: IPromptValidator;
  private readonly systemPromptManager: ISystemPromptManager;
  private readonly aiGateway: IAIGateway;

  // Collaborators for the non-AI `buildBrainRequest()` flow only.
  // Defaulted to the shared singletons (matching how each of those
  // modules exports one) so existing `new HORUSBrain(...)` call sites
  // — which only ever pass the four AI-flow args above — keep working
  // unchanged.
  private readonly intentAnalyzer: IIntentAnalyzer;
  private readonly planner: IPlanner;
  private readonly contextBuilder: IContextBuilder;

  // Collaborator for the full `handleRequest()` pipeline only.
  // Defaulted to a `ResponseOrchestrator` built from this same
  // instance's AI-flow deps, so existing `new HORUSBrain(...)` call
  // sites keep working unchanged.
  private readonly responseOrchestrator: IResponseOrchestrator;

  constructor(
    promptBuilder: IPromptBuilder,
    promptValidator: IPromptValidator,
    systemPromptManager: ISystemPromptManager,
    aiGateway: IAIGateway,
    intentAnalyzerDep: IIntentAnalyzer = intentAnalyzer,
    plannerDep: IPlanner = planner,
    contextBuilderDep: IContextBuilder = contextBuilder,
    responseOrchestratorDep?: IResponseOrchestrator,
  ) {
    this.promptBuilder = promptBuilder;
    this.promptValidator = promptValidator;
    this.systemPromptManager = systemPromptManager;
    this.aiGateway = aiGateway;
    this.intentAnalyzer = intentAnalyzerDep;
    this.planner = plannerDep;
    this.contextBuilder = contextBuilderDep;
    this.responseOrchestrator =
      responseOrchestratorDep ??
      new ResponseOrchestrator(aiGateway, promptBuilder, promptValidator, systemPromptManager);
  }

  receiveUserRequest(request: unknown): void {
    this.userRequest = request;
  }

  receiveConversationContext(context: unknown): void {
    this.conversationContext = context;
  }

  receiveProjectContext(context: unknown): void {
    this.projectContext = context;
  }

  receiveMemory(memory: unknown): void {
    this.memory = memory;
  }

  /** Return everything received so far, for the next stage to consume. */
  analyze(): unknown {
    return {
      userRequest: this.userRequest,
      conversationContext: this.conversationContext,
      projectContext: this.projectContext,
      memory: this.memory,
    };
  }

  /** Assemble the StructuredPrompt from what's been received. */
  plan(): unknown {
    this.structuredPrompt = this.promptBuilder.build({
      systemPrompt: this.systemPromptManager.getSystemPrompt(),
      identity: { identity: { name: HORUS_AI_NAME, role: HORUS_AI_ROLE } },
      userRequest: { userRequest: this.userRequest },
      conversationContext: { conversationContext: this.conversationContext },
      memoryContext: { memoryContext: this.memory },
      // HORUS doesn't yet distinguish circuit/PCB/Arduino/simulation
      // context — whatever project context was received is passed
      // through as circuit context, the rest left empty.
      circuitContext: { circuitContext: this.projectContext },
      pcbContext: { pcbContext: undefined },
      arduinoContext: { arduinoContext: undefined },
      simulationContext: { simulationContext: undefined },
    });
    return this.structuredPrompt;
  }

  /** Validate the planned prompt, then send it through the AI Gateway. */
  async execute(): Promise<AIResponse> {
    if (!this.structuredPrompt) {
      this.plan();
    }
    const validation = this.promptValidator.validate(this.structuredPrompt!);
    this.result = await this.aiGateway.send({ prompt: this.structuredPrompt!, validation });
    return this.result;
  }

  /** Pass the result through unchanged — no validation/auto-fix engine
   *  wired up yet (see ValidationEngine.ts / AutoFixEngine.ts). */
  review(): unknown {
    return this.result;
  }

  respond(): unknown {
    return this.result;
  }

  async startReasoningPipeline(): Promise<void> {
    this.analyze();
    this.plan();
    await this.execute();
    this.review();
    this.respond();
  }

  /**
   * Practical entry point: receive a request (plus optional context),
   * run it through the pipeline above, and return the final AIResponse.
   * Not part of `IHORUSBrain` — callers that only know the interface can
   * still drive the individual steps directly if they need to.
   */
  async run(input: HORUSBrainInput): Promise<AIResponse> {
    this.receiveUserRequest(input.userRequest);
    this.receiveConversationContext(input.conversationContext);
    this.receiveProjectContext(input.projectContext);
    this.receiveMemory(input.memory);
    await this.startReasoningPipeline();
    return this.result!;
  }

  /**
   * Non-AI entry point: User -> IntentAnalyzer -> Planner ->
   * ContextBuilder -> structured `BrainRequest`.
   *
   * Detects the intent behind `input.userRequest`, decides the tool
   * that intent would require, merges the given context pieces, and
   * returns all three together. Does not call `execute()` or
   * `startReasoningPipeline()`, does not touch `aiGateway`, and does
   * not invoke any tool — it only describes what HORUS would do next.
   */
  buildBrainRequest(input: BuildBrainRequestInput): BrainRequest {
    const intent = this.intentAnalyzer.detectIntent({ request: input.userRequest });
    const plan = this.planner.createPlan({ intent });
    const context = this.contextBuilder.build(input);
    return { intent, plan, context };
  }

  /**
   * Full pipeline entry point: User Request -> IntentAnalyzer ->
   * Planner -> ContextBuilder -> ResponseOrchestrator -> `BrainResponse`.
   *
   * Builds the `BrainRequest` (via `buildBrainRequest()`) and hands it
   * to `ResponseOrchestrator.handle()`, which calls `ToolExecutor` or
   * `AIGateway` as the plan requires. Independent of `run()` /
   * `startReasoningPipeline()` — this method never touches those.
   *
   * When `plan.requiresTool` is `false` (an AI response is required),
   * this method does not call any provider itself and has no fallback
   * path of its own — `responseOrchestrator.handle()` is the only call
   * made, and it is that object's `AIGateway` dependency, not this
   * method, that ever resolves and calls a provider.
   *
   * When `plan.requiresTool` is `true` (a tool is required instead),
   * the same holds for tools: this method does not call `ToolExecutor`
   * itself — `responseOrchestrator.handle()` is still the only call
   * made, and it is that object's `ToolExecutor` dependency that
   * locates and executes the tool.
   */
  async handleRequest(input: BuildBrainRequestInput): Promise<BrainResponse> {
    const request = this.buildBrainRequest(input);
    return this.responseOrchestrator.handle(request);
  }
}
