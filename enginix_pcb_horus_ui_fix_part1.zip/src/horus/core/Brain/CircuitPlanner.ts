/**
 * HORUS AI — Auto Circuit Planner (Core/Brain) — Phase 1.
 *
 * Reads a user's engineering *goal* ("create a traffic light system")
 * and reasons out what building it would require: which components,
 * how many of each, what property values they'd need, and what the
 * finished circuit has to actually do — without touching the
 * simulator in any way.
 *
 * Scope, deliberately narrow (Phase 1 only):
 *  - Planning only. This module never creates, wires, or otherwise
 *    mutates a component — it has no reference to `CircuitEditor`,
 *    `CircuitToolBridge`, `EditExecutor`, or `CircuitTool`, and
 *    imports nothing from them.
 *  - No wires/connections are created or even described as concrete
 *    terminal-to-terminal links — `circuitRequirements` says what
 *    must eventually be true of the wiring ("each LED needs its own
 *    series resistor"), not how to wire it. That's an execution-phase
 *    concern.
 *  - No execution — `planCircuit()` only returns a `CircuitPlan`; it
 *    never calls a tool, never dispatches an edit, never touches
 *    `ToolManager`/`ToolRegistry`.
 *  - The existing Add/Remove/Connect/Disconnect pipeline
 *    (`CircuitEditPlanner` -> `EditValidator` -> `SmartComponentResolver`
 *    -> `EditExecutor`) is completely untouched by this file — this
 *    module only *reads* one pure, stateless function off
 *    `SmartComponentResolver` (`resolveComponentType`) to check a
 *    candidate part against the real catalog; it never calls anything
 *    that resolves against a *live* circuit or mutates one.
 *  - Source of truth: every component this planner proposes is
 *    resolved against the simulator's real registry
 *    (`componentDefs.ts`'s `componentNames`/`defaultProperties`, via
 *    `SmartComponentResolver`'s alias/name matching — the same
 *    catalog `KnowledgeBaseManager`'s `ComponentsRepository` is built
 *    from). Nothing is ever invented: a part the registry doesn't
 *    have comes back in `unavailableComponents`, never silently
 *    substituted or fabricated.
 *  - Deterministic, offline reasoning: goal -> scenario -> component
 *    needs is plain keyword/pattern matching over the goal text, the
 *    same style `CircuitEditPlanner`/`IntentAnalyzer` already use —
 *    no model call, fully inspectable and testable.
 */

import { componentNames, defaultProperties } from '../../../circuit/componentDefs';
import { smartComponentResolver } from '../../tools/SmartComponentResolver';
import { planConnections } from './ConnectionPlanner';

/** One property value the plan proposes for a component, expressed in
 *  the same shape the simulator's own `PropertyDef`s use (key + real
 *  default from `componentDefs.ts`, optionally overridden by the
 *  scenario's engineering reasoning — e.g. "220Ω current-limiting
 *  resistor" instead of the resistor's generic 1kΩ default). */
export interface PlannedComponentProperty {
  key: string;
  name: string;
  value: number | string | boolean;
  unit?: string;
}

/** One line item in the plan: a real, registry-backed component type,
 *  how many are needed, what property values they'd need, and *why*
 *  (the engineering reasoning, not just the user's own words). */
export interface PlannedComponent {
  /** Real `ComponentType` id from `componentDefs.ts` (e.g. `'led'`) —
   *  never a made-up type. */
  type: string;
  /** Real display name from `componentNames` (e.g. `'LED'`). */
  name: string;
  quantity: number;
  properties: PlannedComponentProperty[];
  /** Why this component is required for the stated goal. */
  rationale: string;
  /** Set only when the requested part named a category with more than
   *  one real match (e.g. "Arduino" -> Uno/Mega/Nano) and this plan
   *  picked the most common one — the other real, registry-backed
   *  options the next phase (or the user) could pick instead. Empty
   *  when there was exactly one match. */
  alternativeTypes: string[];
}

/** A requested part that has no match anywhere in the simulator's
 *  real component registry — reported, never substituted or invented. */
export interface UnavailableComponent {
  requested: string;
  reason: string;
}

/** One endpoint of a `PlannedConnection` — identifies a component by
 *  its real type (matching a `PlannedComponent.type` in the same
 *  plan) and, for a type requested with `quantity > 1`, which
 *  0-indexed instance (in creation order) this endpoint means. `role`
 *  is an engineering-level terminal name (`'positive'`, `'anode'`,
 *  `'pin1'`, ...) resolved against the real component's terminals at
 *  execution time (`WiringExecutor`/`TerminalRoles`) — never a raw,
 *  simulator-specific label baked in here. */
export interface PlannedConnectionEndpoint {
  componentType: string;
  instanceIndex: number;
  role: string;
}

/** One planned wire, still short of any real component/terminal id —
 *  those only exist once `CircuitPlanExecutor` has actually created
 *  the components. `WiringExecutor` (Phase 3) is what turns this into
 *  a real, verified connection. */
export interface PlannedConnection {
  from: PlannedConnectionEndpoint;
  to: PlannedConnectionEndpoint;
  description: string;
}

/** The structured plan `planCircuit()` returns — describes what
 *  building the goal would require, not the doing of it. */
export interface CircuitPlan {
  /** The goal exactly as given. */
  goal: string;
  /** Which built-in reasoning template matched, or `'generic'` when
   *  none did and the plan falls back to scanning the goal text for
   *  known component names. Purely informational/debuggable — not a
   *  claim of authority over what the user meant. */
  scenario: string;
  /** One-line human-readable summary of what's being planned. */
  summary: string;
  /** Required components, each already resolved against the real
   *  registry — the "shopping list" for the next (execution) phase. */
  components: PlannedComponent[];
  /** Parts this plan reasoned it would need but that don't exist in
   *  the current simulator's registry. */
  unavailableComponents: UnavailableComponent[];
  /** What the finished circuit needs to *do*, in plain engineering
   *  terms — behavior, not wiring. */
  functionalRequirements: string[];
  /** What must be true of how the components are put together —
   *  topology-level requirements (series/parallel, shared ground,
   *  one resistor per LED, ...), still short of actual wire endpoints. */
  circuitRequirements: string[];
  /** Concrete, role-based wire endpoints — the executable counterpart
   *  to `circuitRequirements`'s prose. Generated generically by
   *  `ConnectionPlanner.planConnections()` from `components`' real
   *  electrical roles (power source / passthrough / load / controller)
   *  for every scenario and the generic fallback alike — never
   *  authored per named scenario. Empty when no power source (or, for
   *  a controller topology, no load) is present to build a loop
   *  against; never padded with a guess. */
  plannedConnections: PlannedConnection[];
}

export interface CircuitPlannerInput {
  goal: string;
}

export interface ICircuitPlanner {
  /** Reason about `goal` and return a structured plan. Never mutates
   *  anything, never calls a tool, never touches the simulator. */
  planCircuit(input: CircuitPlannerInput): CircuitPlan;
}

// ---------------------------------------------------------------------------
// Component resolution — the one bridge to the real registry.
// ---------------------------------------------------------------------------

interface ResolvedNeed {
  component: PlannedComponent | null;
  unavailable: UnavailableComponent | null;
}

/** Resolves one requested part (by its common name/alias, e.g. "LED",
 *  "flame sensor", "Arduino") against the real component registry via
 *  `SmartComponentResolver.resolveComponentType()` — the same,
 *  unmodified lookup the live Add-component pipeline already uses —
 *  and turns a real match into a `PlannedComponent` seeded with that
 *  type's actual `defaultProperties`, overridden by whatever specific
 *  values this scenario's engineering reasoning calls for. Never
 *  invents a type: an unresolved request becomes an
 *  `UnavailableComponent` instead. */
function resolveNeed(
  requested: string,
  quantity: number,
  rationale: string,
  propertyOverrides: Readonly<Record<string, number | string | boolean>> = {},
): ResolvedNeed {
  const resolution = smartComponentResolver.resolveComponentType(requested);

  if (resolution.status === 'unavailable' || resolution.candidateTypes.length === 0) {
    return {
      component: null,
      unavailable: {
        requested,
        reason: 'Not available in the current simulator component registry.',
      },
    };
  }

  // 'resolved' -> exactly one candidate. 'ambiguous' -> more than one
  // real match (e.g. "Arduino" -> Uno/Mega/Nano); this planning layer
  // picks the first (most-likely, per SmartComponentResolver's own
  // ordering) and records the rest as alternatives rather than
  // blocking the whole plan on a clarifying question — that
  // conversational step belongs to a later phase, not this one.
  const [primaryType, ...alternativeTypes] = resolution.candidateTypes;
  const type = primaryType;
  const name = componentNames[type as keyof typeof componentNames] ?? type;
  const schema = defaultProperties[type] ?? [];

  const properties: PlannedComponentProperty[] = schema.map((prop) => ({
    key: prop.key,
    name: prop.name,
    unit: prop.unit,
    value: Object.prototype.hasOwnProperty.call(propertyOverrides, prop.key)
      ? propertyOverrides[prop.key]
      : prop.defaultValue,
  }));

  return {
    component: { type, name, quantity, properties, rationale, alternativeTypes },
    unavailable: null,
  };
}

/** Accumulates `resolveNeed()` results into a plan's `components` /
 *  `unavailableComponents` lists, merging quantity when the same real
 *  type is requested more than once by the same scenario (e.g. three
 *  separate "220Ω resistor" needs for a traffic light's three LEDs
 *  become one `resistor` line item with `quantity: 3`). */
class PlanBuilder {
  private readonly byType = new Map<string, PlannedComponent>();
  private readonly unavailable: UnavailableComponent[] = [];

  add(
    requested: string,
    quantity: number,
    rationale: string,
    propertyOverrides?: Readonly<Record<string, number | string | boolean>>,
  ): void {
    const { component, unavailable } = resolveNeed(requested, quantity, rationale, propertyOverrides);
    if (unavailable) {
      this.unavailable.push(unavailable);
      return;
    }
    if (!component) return;

    const existing = this.byType.get(component.type);
    if (existing) {
      existing.quantity += component.quantity;
      // Keep the first rationale/properties; just note the additional
      // use so the "why" stays legible instead of being overwritten.
      if (!existing.rationale.includes(rationale)) {
        existing.rationale = `${existing.rationale} Also needed: ${rationale.charAt(0).toLowerCase()}${rationale.slice(1)}`;
      }
    } else {
      this.byType.set(component.type, component);
    }
  }

  components(): PlannedComponent[] {
    return Array.from(this.byType.values());
  }

  unavailableComponents(): UnavailableComponent[] {
    return this.unavailable;
  }
}

// ---------------------------------------------------------------------------
// Scenario templates — engineering reasoning, not word-for-word echo.
// ---------------------------------------------------------------------------

interface ScenarioResult {
  scenario: string;
  summary: string;
  builder: PlanBuilder;
  functionalRequirements: string[];
  circuitRequirements: string[];
}

function planSimpleLedCircuit(): ScenarioResult {
  const builder = new PlanBuilder();
  builder.add('battery', 1, 'DC power source to drive the LED.', { voltage: 9 });
  builder.add(
    'resistor',
    1,
    "Limits current through the LED so it stays under the LED's maximum current rating.",
    { resistance: 220 },
  );
  builder.add('switch', 1, 'Lets the user open/close the circuit on demand.');
  builder.add('led', 1, 'The circuit\'s visible output/indicator element.', { color: '#ff0000' });

  return {
    scenario: 'simple_led_circuit',
    summary: 'A minimal switched, current-limited LED indicator circuit.',
    builder,
    functionalRequirements: [
      'LED turns on when the switch is closed and off when it is open.',
      "Current through the LED stays within its maximum current rating at all times.",
    ],
    circuitRequirements: [
      'Battery, switch, resistor, and LED form a single closed series loop.',
      'Resistor sits in series between the power source and the LED (either side).',
      "LED is oriented so its anode faces the positive supply, per its forward-voltage polarity.",
    ],
  };
}

function planTrafficLightSystem(): ScenarioResult {
  const builder = new PlanBuilder();
  builder.add('arduino', 1, 'Programmable controller to sequence the lights with timed delays.');
  builder.add('led', 1, 'Stop-phase signal.', { color: '#ff0000' });
  builder.add('led', 1, 'Ready/caution-phase signal.', { color: '#ffff00' });
  builder.add('led', 1, 'Go-phase signal.', { color: '#00ff00' });
  builder.add(
    'resistor',
    3,
    'One current-limiting resistor per LED, protecting each from exceeding its rated current.',
    { resistance: 220 },
  );

  return {
    scenario: 'traffic_light_system',
    summary: 'A microcontroller-sequenced red/yellow/green traffic light.',
    builder,
    functionalRequirements: [
      'Exactly one of the three LEDs is on at any given time.',
      'Lights cycle in a fixed order — green, then yellow, then red, then back to green — each held for a defined duration.',
      "Arduino drives each LED's on/off state from its own digital output pin.",
    ],
    circuitRequirements: [
      'Each LED has its own series current-limiting resistor — never shared between LEDs.',
      "Each LED-resistor pair connects to a distinct Arduino digital output pin and to a common ground.",
      "All components share a single ground reference with the Arduino.",
    ],
  };
}

function planFireAlarmSystem(): ScenarioResult {
  const builder = new PlanBuilder();
  builder.add('arduino', 1, 'Reads the flame sensor and drives the alarm outputs.');
  builder.add('flame sensor', 1, 'Detects the presence of fire/flame and reports it to the controller.');
  builder.add('buzzer', 1, 'Audible alarm output when fire is detected.');
  builder.add('led', 1, 'Visual alarm indicator alongside the buzzer.', { color: '#ff0000' });
  builder.add(
    'resistor',
    1,
    "Limits current through the indicator LED so it stays under its maximum current rating.",
    { resistance: 220 },
  );

  return {
    scenario: 'fire_alarm_system',
    summary: 'A flame-sensor-triggered audible + visual fire alarm.',
    builder,
    functionalRequirements: [
      'Buzzer and LED activate together when the flame sensor detects fire above its trip threshold.',
      'Buzzer and LED stay off during normal (no-fire) conditions.',
      'Arduino continuously polls the flame sensor and updates the alarm outputs accordingly.',
    ],
    circuitRequirements: [
      "Flame sensor's output connects to an Arduino input pin.",
      'Buzzer and LED (with its series resistor) each connect to their own Arduino output pin.',
      'Sensor, buzzer, LED, and Arduino share a common ground.',
    ],
  };
}

/** Scenario patterns, most-specific first — the first pattern whose
 *  regex matches the (lowercased) goal text wins. Kept small and
 *  explicit by design: these are the reasoning templates HORUS
 *  currently knows, not an attempt to cover every possible circuit. */
const SCENARIOS: ReadonlyArray<{ pattern: RegExp; build: () => ScenarioResult }> = [
  { pattern: /traffic\s*light/i, build: planTrafficLightSystem },
  { pattern: /fire\s*alarm/i, build: planFireAlarmSystem },
  { pattern: /\bled\b.*\bcircuit\b|\bsimple\b.*\bled\b|\bled\s*circuit\b/i, build: planSimpleLedCircuit },
];

// ---------------------------------------------------------------------------
// Generic fallback — no template matched.
// ---------------------------------------------------------------------------

/** Candidate multi-word-then-single-word phrases to try resolving
 *  against the registry, extracted from free text. Checked longest
 *  first (2-word windows before single words) so e.g. "flame sensor"
 *  resolves as one part rather than two failed single-word lookups. */
function candidatePhrases(goal: string): string[] {
  const words = goal
    .toLowerCase()
    .replace(/[^a-z0-9\s]+/g, ' ')
    .split(/\s+/)
    .filter(Boolean);

  const phrases: string[] = [];
  for (let i = 0; i < words.length - 1; i += 1) {
    phrases.push(`${words[i]} ${words[i + 1]}`);
  }
  phrases.push(...words);
  return phrases;
}

const STOP_WORDS = new Set([
  'a', 'an', 'the', 'create', 'build', 'make', 'design', 'circuit', 'system',
  'with', 'and', 'for', 'using', 'that', 'to', 'of', 'simple', 'basic',
]);

/** No scenario template matched: fall back to scanning the goal text
 *  itself for real, registry-backed component names/aliases (via the
 *  same `resolveComponentType()` used everywhere else in this file),
 *  rather than inventing a plan out of nothing. Anything recognized
 *  becomes a line item; the rest of the goal is simply not addressed —
 *  this stays honest about not having a purpose-built template for it. */
function planGeneric(goal: string): ScenarioResult {
  const builder = new PlanBuilder();
  const matchedTypes = new Set<string>();

  for (const phrase of candidatePhrases(goal)) {
    if (STOP_WORDS.has(phrase)) continue;
    const resolution = smartComponentResolver.resolveComponentType(phrase);
    if (resolution.status === 'unavailable' || resolution.type === null) continue;
    const [primaryType] = resolution.candidateTypes;
    if (matchedTypes.has(primaryType)) continue;
    matchedTypes.add(primaryType);
    builder.add(phrase, 1, `Explicitly mentioned in the request ("${phrase}").`);
  }

  // Basic engineering completion: a bare LED mention with no power
  // source/current-limiting named still needs both to actually work.
  if (matchedTypes.has('led')) {
    if (!matchedTypes.has('resistor')) {
      builder.add('resistor', 1, "Current-limiting resistor the LED needs but the request didn't mention.", {
        resistance: 220,
      });
    }
    if (!matchedTypes.has('battery') && !matchedTypes.has('arduino')) {
      builder.add('battery', 1, "Power source the circuit needs but the request didn't mention.", { voltage: 9 });
    }
  }

  const requirements =
    builder.components().length > 0
      ? {
          functionalRequirements: [
            'Behavior inferred only from the components explicitly recognized above — confirm intended behavior before building.',
          ],
          circuitRequirements: [
            'Recognized components must be connected into a single working circuit appropriate to their function.',
          ],
        }
      : {
          functionalRequirements: [],
          circuitRequirements: [],
        };

  return {
    scenario: 'generic',
    summary:
      builder.components().length > 0
        ? 'No built-in template matched this goal; plan built from components explicitly named in the request.'
        : "No built-in template matched this goal, and no known component names were recognized in it — more detail is needed before a plan can be built.",
    builder,
    ...requirements,
  };
}

// ---------------------------------------------------------------------------
// Planner
// ---------------------------------------------------------------------------

export class CircuitPlanner implements ICircuitPlanner {
  planCircuit(input: CircuitPlannerInput): CircuitPlan {
    const goal = input.goal.trim();
    const matchedScenario = SCENARIOS.find((s) => s.pattern.test(goal));
    const result = matchedScenario ? matchedScenario.build() : planGeneric(goal);
    const components = result.builder.components();

    return {
      goal,
      scenario: result.scenario,
      summary: result.summary,
      components,
      unavailableComponents: result.builder.unavailableComponents(),
      functionalRequirements: result.functionalRequirements,
      circuitRequirements: result.circuitRequirements,
      // Generic for every scenario and the fallback alike — see
      // `ConnectionPlanner`'s header for why this is never authored
      // per named scenario.
      plannedConnections: planConnections(components),
    };
  }
}

/** Shared instance — stateless, mirrors `planner`/`intentResolver`. */
export const circuitPlanner = new CircuitPlanner();
