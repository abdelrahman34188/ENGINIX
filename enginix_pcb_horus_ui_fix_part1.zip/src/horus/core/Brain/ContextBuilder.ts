/**
 * HORUS AI — Context Builder (Core/Brain).
 *
 * Merges the separate pieces of context HORUS has available into one
 * flat context object:
 *  - workspace
 *  - current circuit
 *  - selected component
 *  - history
 *  - user request
 *
 * Scope, deliberately narrow:
 *  - Build and return the merged context object — nothing else.
 *  - No AI call, no provider call (does not import/touch AIGateway,
 *    AIProviderManager, GeminiProvider/GeminiClient, or anything in
 *    `core/AI/`).
 *  - No execution — this module never calls `ToolExecutor`, `Planner`,
 *    or anything that acts on the context it builds.
 *  - No prompt generation (does not import/touch PromptBuilder,
 *    PromptValidator, or SystemPromptManager).
 *
 * Every input is accepted as `unknown` and merged as-is — this module
 * doesn't assume or depend on the shape of workspace/circuit/component/
 * history data (e.g. `context/providers/*ContextProvider.ts`), so it
 * has no import on those, on the simulator, or on anything circuit-
 * related. Building the context is a plain merge — no model call, no
 * side effects.
 */

export interface ContextBuilderInput {
  workspace?: unknown;
  currentCircuit?: unknown;
  selectedComponent?: unknown;
  history?: unknown;
  userRequest?: unknown;
}

/** The merged context object Planner/ToolExecutor (once wired in) can
 *  consume — every field mirrors one input, unchanged. */
export interface HorusContext {
  workspace: unknown;
  currentCircuit: unknown;
  selectedComponent: unknown;
  history: unknown;
  userRequest: unknown;
}

export interface IContextBuilder {
  /** Merge the given pieces into a single HorusContext object. */
  build(input: ContextBuilderInput): HorusContext;
}

export class ContextBuilder implements IContextBuilder {
  build(input: ContextBuilderInput): HorusContext {
    return {
      workspace: input.workspace,
      currentCircuit: input.currentCircuit,
      selectedComponent: input.selectedComponent,
      history: input.history,
      userRequest: input.userRequest,
    };
  }
}

/** Shared instance — stateless, mirrors `Planner.ts`'s exported
 *  `planner` singleton. */
export const contextBuilder = new ContextBuilder();
