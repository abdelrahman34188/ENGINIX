/**
 * HORUS AI — Response Orchestrator (Core/Brain).
 *
 * Receives a `BrainRequest` (HORUSBrain's `buildBrainRequest()` output —
 * intent + plan + merged context), calls `ToolExecutor` or `AIGateway`
 * as the plan requires, and returns one unified `BrainResponse`.
 *
 * Decision rule, straight from Planner's own `requiresTool` flag:
 *  - `plan.requiresTool === true`  -> call `ToolExecutor` only.
 *  - `plan.requiresTool === false` -> call `AIGateway` only (the
 *    `chat` intent — plain conversation needs no tool).
 * Exactly one of `toolResult` / `aiResponse` is ever populated; the
 * other stays `undefined`. Architecture only: this module doesn't
 * decide *how* a tool executes or *how* a provider generates — it
 * only decides *which one to call* and hands off to the existing
 * `ToolExecutor`/`AIGateway` for that.
 *
 * Explicitly out of scope / untouched by this module:
 *  - No frontend/UI changes — no consumer wired in yet.
 *  - No simulator involvement (does not import/touch anything under
 *    `simulator`/`circuit`).
 *  - No provider changes — does not import/touch
 *    `AIProviderManager`, `ProviderRegistry`, `GeminiProvider`, or
 *    `GeminiClient`; provider resolution stays entirely inside
 *    `AIGateway`, as it already does.
 *  - No changes to `ToolExecutor.ts`, `AIGateway.ts`, `Planner.ts`,
 *    `IntentAnalyzer.ts`, `ContextBuilder.ts`, or `HORUSBrain.ts` —
 *    this file only imports and calls them.
 */

import type { BrainRequest } from './HORUSBrain';
import { toolExecutor, type IToolExecutor, type ToolExecutionResult } from './ToolExecutor';
import type { IAIGateway, ValidatedPrompt } from '../AI/AIGateway';
import type { AIResponse } from '../AI/AIResponse';
import type { IPromptBuilder, StructuredPrompt } from '../Prompt/PromptBuilder';
import type { IPromptValidator } from '../Prompt/PromptValidator';
import type { ISystemPromptManager } from '../Prompt/SystemPromptManager';
import { HORUS_AI_NAME, HORUS_AI_ROLE } from '../../identity';

/** The unified result of orchestrating one `BrainRequest`. Exactly one
 *  of `toolResult` / `aiResponse` is populated, matching whichever
 *  branch `plan.requiresTool` selected. */
export interface BrainResponse {
  request: BrainRequest;
  toolResult?: ToolExecutionResult;
  aiResponse?: AIResponse;
}

export interface IResponseOrchestrator {
  /** Receive a BrainRequest and route it to ToolExecutor or AIGateway. */
  handle(request: BrainRequest): Promise<BrainResponse>;
}

export class ResponseOrchestrator implements IResponseOrchestrator {
  private readonly toolExecutorDep: IToolExecutor;
  private readonly aiGateway: IAIGateway;
  private readonly promptBuilder: IPromptBuilder;
  private readonly promptValidator: IPromptValidator;
  private readonly systemPromptManager: ISystemPromptManager;

  constructor(
    aiGateway: IAIGateway,
    promptBuilder: IPromptBuilder,
    promptValidator: IPromptValidator,
    systemPromptManager: ISystemPromptManager,
    toolExecutorDep: IToolExecutor = toolExecutor,
  ) {
    this.aiGateway = aiGateway;
    this.promptBuilder = promptBuilder;
    this.promptValidator = promptValidator;
    this.systemPromptManager = systemPromptManager;
    this.toolExecutorDep = toolExecutorDep;
  }

  async handle(request: BrainRequest): Promise<BrainResponse> {
    if (request.plan.requiresTool && request.plan.toolName) {
      const toolResult = this.callTool(request);
      return { request, toolResult };
    }

    const aiResponse = await this.callAI(request);
    return { request, aiResponse };
  }

  /** Call ToolExecutor with the plan's tool and the request's merged
   *  context as input. No AI involved on this branch. */
  private callTool(request: BrainRequest): ToolExecutionResult {
    const toolExecutionRequest = {
      toolName: request.plan.toolName!,
      input: request.context,
    };
    this.toolExecutorDep.receiveRequest(toolExecutionRequest);
    return this.toolExecutorDep.executeTool(toolExecutionRequest);
  }

  /** Build a StructuredPrompt from the request's context, validate it,
   *  and send it through AIGateway. No tool involved on this branch. */
  private async callAI(request: BrainRequest): Promise<AIResponse> {
    const { context } = request;
    const prompt: StructuredPrompt = this.promptBuilder.build({
      systemPrompt: { systemPrompt: this.systemPromptManager.getSystemPrompt() },
      identity: { identity: { name: HORUS_AI_NAME, role: HORUS_AI_ROLE } },
      userRequest: { userRequest: context.userRequest },
      conversationContext: { conversationContext: context.history },
      memoryContext: { memoryContext: undefined },
      circuitContext: { circuitContext: context.currentCircuit },
      pcbContext: { pcbContext: undefined },
      arduinoContext: { arduinoContext: undefined },
      simulationContext: { simulationContext: undefined },
    });
    const validation = this.promptValidator.validate(prompt);
    const validatedPrompt: ValidatedPrompt = { prompt, validation };
    return this.aiGateway.send(validatedPrompt);
  }
}
