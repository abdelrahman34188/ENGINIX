/**
 * HORUS AI — Circuit Edit Planner (Core/Brain).
 *
 * Detects requests that ask to edit the circuit — add/remove a
 * component, change a property, connect/disconnect components, rename
 * a component — and returns a structured `EditPlan` describing what was
 * asked for. Nothing else.
 *
 * Scope, deliberately narrow, matching `IntentAnalyzer.ts` and
 * `Planner.ts` at this stage:
 *  - Detect edit requests only. Non-edit requests (chat, analysis,
 *    questions, etc.) yield `isEditRequest() === false` /
 *    `planEdit() === null`.
 *  - Return an `EditPlan` only — a plain description of the requested
 *    edit (action + targets/values as parsed from the request text).
 *    `planEdit()` returns the richer internal shape; `planEditJSON()`
 *    returns the compact, serializable `{ action, target, value }`
 *    shape (see `EditPlanJSON` below) for callers that just want that.
 *  - No execution. This module never calls `CircuitTool`,
 *    `CircuitToolBridge`, `CircuitEditor`, or anything under
 *    `simulator`/`circuit` — it has no way to change the circuit, only
 *    to describe what a caller *could* do with the plan.
 *  - No mutation of the simulator, HORUS's other state, or the request
 *    itself.
 *  - No AI call, no provider call (does not import/touch AIGateway,
 *    AIProviderManager, GeminiProvider/GeminiClient, or anything in
 *    `core/AI/`).
 *  - Multi-action requests (e.g. "Replace R1 with 220Ω. Add LED.
 *    Connect LED to R1.") are supported via `splitActionRequests()` /
 *    `planEdits()` / `planEditsJSON()`, but only as splitting +
 *    per-clause planning — still no execution, no ordering decisions
 *    beyond "the order the user wrote them in", and no cross-clause
 *    reasoning (each clause is planned independently of the others).
 *    Sequencing and stop-on-failure behavior belong to a future
 *    executor, not this module.
 *
 * Classification and extraction here are plain, deterministic
 * keyword/regex matching over the request text — no model call, so
 * behavior is fully inspectable and testable offline, the same as
 * `IntentAnalyzer`'s keyword matching.
 */

/** Every edit action this planner can detect. */
export type CircuitEditActionType =
  | 'add_component'
  | 'remove_component'
  | 'change_property'
  | 'connect_components'
  | 'disconnect_components'
  | 'rename_component'
  | 'replace_component';

/** How a target reference was classified against the request text:
 *  - `designator`: a reference-designator-style name (e.g. "R1", "LED2",
 *    "Q1") — an existing component identified by its instance name.
 *  - `type`: a component type/category (e.g. "resistor", "MOSFET",
 *    "capacitor") — no specific instance named, just a kind of part.
 *  - `selected`: refers to whatever is currently selected/active in the
 *    editor (e.g. "it", "this", "the selected component"), not resolved
 *    to an actual component here — that's a caller's job.
 *  - `unknown`: didn't match any of the above patterns. */
export type CircuitEditTargetKind = 'designator' | 'type' | 'selected' | 'unknown';

/** A component as referred to in the request text — not yet resolved
 *  against any real circuit; that resolution is a caller's job, using
 *  a real tool (e.g. `CircuitTool`), never this planner's. */
export interface CircuitEditTargetRef {
  /** The target exactly as the user phrased it, trimmed (e.g.
   *  "resistor", "R1", "the LED"). */
  raw: string;
  /** How `raw` was classified: designator, type, selected, or unknown.
   *  Plain pattern matching over `raw` — no lookup against any real
   *  circuit or component list. */
  kind: CircuitEditTargetKind;
  /** Set only when `kind === 'type'`: the component type as parsed
   *  from `raw`, normalized to a canonical lowercase name (e.g. "MOSFET"
   *  and "mosfet" both -> "mosfet"). Null otherwise. */
  componentType: string | null;
}

/** A parsed "set to <value>" clause, e.g. "220Ω" -> value "220",
 *  unit "Ω". `unit` is null when no recognizable unit was present. */
export interface CircuitEditPropertyChange {
  /** The full value phrase exactly as written (e.g. "220Ω", "5v"). */
  raw: string;
  value: string | null;
  unit: string | null;
}

/** The structured plan `planEdit()` returns — describes what was
 *  asked for, not the doing of it. */
export interface CircuitEditPlan {
  action: CircuitEditActionType;
  /** Primary target: the component to add/remove/change/rename, or the
   *  "from" side of a connect/disconnect. Null if it couldn't be
   *  parsed out of the request text. */
  target: CircuitEditTargetRef | null;
  /** The "to" side of a connect, or the second component named in a
   *  disconnect. Null for actions that only take one target. */
  secondaryTarget: CircuitEditTargetRef | null;
  /** Set only for `change_property`. */
  propertyChange: CircuitEditPropertyChange | null;
  /** Set only for `rename_component`, when a new name was given. */
  newName: string | null;
  /** Set only for `replace_component`: the replacement component as
   *  phrased in the request (e.g. "resistor" in "replace R1 with a
   *  resistor"). Null if it couldn't be parsed out. */
  replacement: CircuitEditTargetRef | null;
  /** The original request text, verbatim, for traceability. */
  requestText: string;
}

export interface CircuitEditPlannerInput {
  request: unknown;
  conversationContext?: unknown;
}

/** The compact action vocabulary used by the JSON `EditPlan` shape —
 *  distinct from `CircuitEditActionType` above, which is this module's
 *  own richer internal representation. */
export type EditPlanAction = 'add' | 'remove' | 'connect' | 'disconnect' | 'change_value' | 'rename' | 'replace';

/**
 * The structured JSON `EditPlan` this module hands off, e.g.:
 *   { action: "change_value", target: "R1", value: "220Ω" }
 * Deliberately flat and serializable — three fields, no nesting — so
 * it's trivial to log, send over a wire, or hand to a future executor.
 * Still just a description of the requested edit: producing this object
 * performs no simulator action.
 */
export interface EditPlanJSON {
  action: EditPlanAction;
  /** The component being acted on (e.g. "R1", "LED"). Null when the
   *  request didn't name one clearly enough to parse. */
  target: string | null;
  /** The action's associated value, meaning depends on `action`:
   *  change_value -> the new value ("220Ω"); rename -> the new name;
   *  connect/disconnect -> the other component involved; replace ->
   *  the replacement component; add/remove -> null (nothing to set). */
  value: string | null;
}

/** `CircuitEditActionType` -> compact `EditPlanAction`. Exhaustive so
 *  this stays in sync as actions are added. */
const ACTION_TYPE_TO_JSON: Readonly<Record<CircuitEditActionType, EditPlanAction>> = {
  add_component: 'add',
  remove_component: 'remove',
  connect_components: 'connect',
  disconnect_components: 'disconnect',
  change_property: 'change_value',
  rename_component: 'rename',
  replace_component: 'replace',
};

/** Converts the planner's internal `CircuitEditPlan` into the compact
 *  `EditPlanJSON` shape. Pure mapping — no parsing, no execution. */
export function toEditPlanJSON(plan: CircuitEditPlan): EditPlanJSON {
  const action = ACTION_TYPE_TO_JSON[plan.action];
  const target = plan.target?.raw ?? null;

  let value: string | null;
  switch (plan.action) {
    case 'change_property':
      value = plan.propertyChange?.raw ?? null;
      break;
    case 'rename_component':
      value = plan.newName ?? null;
      break;
    case 'replace_component':
      value = plan.replacement?.raw ?? null;
      break;
    case 'connect_components':
    case 'disconnect_components':
      value = plan.secondaryTarget?.raw ?? null;
      break;
    case 'add_component':
    case 'remove_component':
      value = null;
      break;
    default:
      value = null;
  }

  return { action, target, value };
}

/**
 * One clause of a multi-action request, split out by
 * `splitActionRequests()`, paired with the single-clause plan
 * `planEdit()` produces for it. `plan` is null when the clause didn't
 * read as a recognizable edit action — the caller (a future executor)
 * decides what to do with that, this module just reports it honestly
 * rather than silently dropping the clause.
 */
export interface MultiEditPlanEntry {
  /** Position of this clause in the original request, 0-based. */
  index: number;
  /** The clause exactly as split out, trimmed. */
  requestText: string;
  plan: CircuitEditPlan | null;
}

/** Same as `MultiEditPlanEntry`, with the compact `EditPlanJSON` shape
 *  in place of the richer internal plan. */
export interface MultiEditPlanJSONEntry {
  index: number;
  requestText: string;
  plan: EditPlanJSON | null;
}

/**
 * Splits a request that may describe several actions back-to-back
 * (e.g. "Replace R1 with 220Ω. Add LED. Connect LED to R1.") into its
 * individual clauses, in the order given. Splits on sentence-ending
 * punctuation (`.`, `!`, `?`), semicolons, newlines, and the
 * conjunctions "and then"/"then" — the same connectors a person would
 * naturally chain actions with — then trims and drops empty pieces.
 * A single-action request simply comes back as a one-element array.
 * Pure text splitting — no classification, no parsing of what each
 * piece asks for; that's `planEdit()`'s job per clause.
 */
export function splitActionRequests(text: string): string[] {
  return text
    .split(/[.!?;\n]+|(?:\band\s+then\b)|(?:\bthen\b)/i)
    .map((part) => part.trim())
    .filter((part) => part.length > 0);
}

export interface ICircuitEditPlanner {
  /** True when the request text reads as a circuit-edit request. */
  isEditRequest(input: CircuitEditPlannerInput): boolean;

  /** Detect and parse an edit request into an `EditPlan`. Returns null
   *  when the request isn't an edit request. */
  planEdit(input: CircuitEditPlannerInput): CircuitEditPlan | null;

  /** Same as `planEdit`, but returns the compact `EditPlanJSON` shape
   *  (`{ action, target, value }`) instead of the richer internal plan.
   *  Returns null when the request isn't an edit request. */
  planEditJSON(input: CircuitEditPlannerInput): EditPlanJSON | null;

  /** True when the request text splits into more than one action
   *  clause (see `splitActionRequests()`) — a hint to a caller that
   *  `planEdits()` (not just `planEdit()`) is the right call. */
  isMultiActionRequest(input: CircuitEditPlannerInput): boolean;

  /** Splits the request into its individual action clauses (see
   *  `splitActionRequests()`) and plans each one independently, in
   *  order. Every clause gets an entry — including one whose `plan`
   *  comes back null because that clause wasn't a recognizable edit —
   *  so a caller can tell "no actions here" from "one of the actions
   *  didn't parse" positionally. Returns an empty array only when the
   *  request itself is empty. */
  planEdits(input: CircuitEditPlannerInput): MultiEditPlanEntry[];

  /** Same as `planEdits`, with each entry's plan in the compact
   *  `EditPlanJSON` shape. */
  planEditsJSON(input: CircuitEditPlannerInput): MultiEditPlanJSONEntry[];
}

/** Keyword triggers per action, in priority order (first match wins —
 *  `disconnect_components` before `connect_components` so "disconnect
 *  the LED" isn't caught by a bare "connect" substring check, and
 *  `rename_component` before `change_property` so "rename X to Y"
 *  isn't read as a property change, and `replace_component` before
 *  `remove_component`/`add_component` so "replace X with Y" isn't
 *  caught by a bare "remove"/"add" substring check). */
const ACTION_ORDER: readonly CircuitEditActionType[] = [
  'disconnect_components',
  'connect_components',
  'rename_component',
  'replace_component',
  'change_property',
  'remove_component',
  'add_component',
];

const ACTION_KEYWORDS: Readonly<Record<CircuitEditActionType, readonly RegExp[]>> = {
  disconnect_components: [/\bdisconnect\b/i, /\bunwire\b/i, /\bremove\s+(?:the\s+)?wire\b/i],
  connect_components: [/\bconnect\b/i, /\bwire\b/i, /\blink\b/i],
  rename_component: [/\brename\b/i, /\bcall\s+it\b/i, /\blabel\s+it\b/i],
  replace_component: [/\breplace\b/i, /\bswap\b/i, /\bsubstitute\b/i],
  change_property: [/\bchange\b/i, /\bset\b/i, /\bupdate\b/i, /\badjust\b/i],
  remove_component: [/\bremove\b/i, /\bdelete\b/i, /\btake\s+out\b/i],
  add_component: [/\badd\b/i, /\bplace\b/i, /\binsert\b/i, /\bput\s+a\b/i],
};

/** Reference-designator prefixes recognized as "this names a specific
 *  instance" (e.g. R1, LED2, Q1, C3, U4, SW1) — standard schematic
 *  designator letters followed by a number, optionally with a trailing
 *  sub-index letter (e.g. "R1a"). Deliberately just a shape check, not
 *  a lookup against real circuit component IDs. */
const DESIGNATOR_PATTERN = /^[A-Za-z]{1,4}\d+[A-Za-z]?$/;

/** Known component type/category words. Not exhaustive — new types can
 *  be added freely; anything not on this list simply classifies as
 *  `unknown` rather than `type`, which is a safe default (the caller
 *  still gets `raw` to work with). */
const COMPONENT_TYPE_WORDS: readonly string[] = [
  'resistor', 'capacitor', 'inductor', 'diode', 'led', 'transistor',
  'mosfet', 'bjt', 'battery', 'switch', 'button', 'relay', 'fuse',
  'potentiometer', 'transformer', 'sensor', 'buzzer', 'speaker',
  'motor', 'ic', 'chip', 'microcontroller', 'op-amp', 'opamp',
  'regulator', 'crystal', 'oscillator', 'connector', 'header',
  'wire', 'ground', 'jumper', 'photoresistor', 'thermistor',
  'zener', 'rectifier', 'triac', 'scr', 'thyristor',
];
const COMPONENT_TYPE_SET = new Set(COMPONENT_TYPE_WORDS);

/** Phrases that refer to whatever's currently selected/active in the
 *  editor rather than naming a component or type. Resolving "selected"
 *  to an actual component is a caller's job — this planner only flags
 *  the reference as `kind: 'selected'`. */
const SELECTED_REFERENCE_PATTERNS: readonly RegExp[] = [
  /^it$/i,
  /^this$/i,
  /^that$/i,
  /^this\s+(?:one|component|part)$/i,
  /^that\s+(?:one|component|part)$/i,
  /^the\s+selected\s+component$/i,
  /^the\s+selected\s+(?:one|part)$/i,
  /^the\s+current(?:ly\s+selected)?\s+component$/i,
  /^selected\s+component$/i,
  /^current\s+component$/i,
];

/** Classifies a cleaned target string as a designator, a component
 *  type, a "currently selected" reference, or unknown. Pure pattern
 *  matching over `raw` — no lookup against any real circuit. */
function classifyTarget(raw: string): { kind: CircuitEditTargetKind; componentType: string | null } {
  if (SELECTED_REFERENCE_PATTERNS.some((pattern) => pattern.test(raw))) {
    return { kind: 'selected', componentType: null };
  }
  if (DESIGNATOR_PATTERN.test(raw)) {
    return { kind: 'designator', componentType: null };
  }
  const normalized = raw.toLowerCase();
  if (COMPONENT_TYPE_SET.has(normalized)) {
    return { kind: 'type', componentType: normalized };
  }
  // Multi-word phrases like "220Ω resistor" or "MOSFET transistor" —
  // classify as `type` if the last word is a known type word, using
  // that word as the canonical componentType.
  const words = normalized.split(/\s+/);
  const lastWord = words[words.length - 1];
  if (words.length > 1 && COMPONENT_TYPE_SET.has(lastWord)) {
    return { kind: 'type', componentType: lastWord };
  }
  return { kind: 'unknown', componentType: null };
}
function extractText(request: unknown): string {
  if (typeof request === 'string') {
    return request;
  }
  if (request && typeof request === 'object') {
    const candidate = request as Record<string, unknown>;
    const field = candidate.text ?? candidate.message ?? candidate.content;
    if (typeof field === 'string') {
      return field;
    }
  }
  return '';
}

function cleanTarget(text: string | undefined): CircuitEditTargetRef | null {
  if (!text) return null;
  const trimmed = text
    .trim()
    .replace(/^(?:the|an|a)\s+/i, '')
    .replace(/[.?!]+$/, '')
    .trim();
  if (trimmed.length === 0) return null;
  const { kind, componentType } = classifyTarget(trimmed);
  return { raw: trimmed, kind, componentType };
}

/** Parses a value phrase like "220Ω", "220 ohms", "5v", "10uF" into a
 *  leading numeric value and a trailing unit token, when present. */
export function parsePropertyValue(text: string): CircuitEditPropertyChange {
  const raw = text.trim().replace(/[.?!]+$/, '');
  const match = raw.match(/^([\d.]+)\s*([a-zA-ZΩµμ]+)?$/);
  if (!match) {
    return { raw, value: null, unit: null };
  }
  return { raw, value: match[1], unit: match[2] ?? null };
}

function detectAction(text: string): CircuitEditActionType | null {
  for (const action of ACTION_ORDER) {
    if (ACTION_KEYWORDS[action].some((pattern) => pattern.test(text))) {
      return action;
    }
  }
  return null;
}

function parsePlan(action: CircuitEditActionType, text: string, requestText: string): CircuitEditPlan {
  const base: CircuitEditPlan = {
    action,
    target: null,
    secondaryTarget: null,
    propertyChange: null,
    newName: null,
    replacement: null,
    requestText,
  };

  switch (action) {
    case 'add_component': {
      const m = text.match(/\b(?:add|place|insert|put)\s+(?:a\s+)?(.+)$/i);
      base.target = cleanTarget(m?.[1]);
      return base;
    }
    case 'remove_component': {
      const m = text.match(/\b(?:remove|delete|take\s+out)\s+(.+)$/i);
      base.target = cleanTarget(m?.[1]);
      return base;
    }
    case 'connect_components': {
      const m = text.match(/\b(?:connect|wire|link)\s+(.+?)\s+(?:to|with)\s+(.+)$/i);
      if (m) {
        base.target = cleanTarget(m[1]);
        base.secondaryTarget = cleanTarget(m[2]);
      } else {
        const fallback = text.match(/\b(?:connect|wire|link)\s+(.+)$/i);
        base.target = cleanTarget(fallback?.[1]);
      }
      return base;
    }
    case 'disconnect_components': {
      const m = text.match(/\bdisconnect\s+(.+?)\s+from\s+(.+)$/i);
      if (m) {
        base.target = cleanTarget(m[1]);
        base.secondaryTarget = cleanTarget(m[2]);
      } else {
        const fallback = text.match(/\b(?:disconnect|unwire)\s+(.+)$/i);
        base.target = cleanTarget(fallback?.[1]);
      }
      return base;
    }
    case 'rename_component': {
      const m = text.match(/\brename\s+(.+?)\s+to\s+(.+)$/i)
        ?? text.match(/\brename\s+(.+)$/i);
      if (m) {
        base.target = cleanTarget(m[1]);
        base.newName = m[2] ? m[2].trim().replace(/[.?!]+$/, '') : null;
      }
      return base;
    }
    case 'change_property': {
      const m = text.match(/\b(?:change|set|update|adjust)\s+(.+?)\s+to\s+(.+)$/i);
      if (m) {
        base.target = cleanTarget(m[1]);
        base.propertyChange = parsePropertyValue(m[2]);
      } else {
        const fallback = text.match(/\b(?:change|set|update|adjust)\s+(.+)$/i);
        base.target = cleanTarget(fallback?.[1]);
      }
      return base;
    }
    case 'replace_component': {
      const m = text.match(/\b(?:replace|swap|substitute)\s+(.+?)\s+(?:with|for|by)\s+(.+)$/i);
      if (m) {
        base.target = cleanTarget(m[1]);
        base.replacement = cleanTarget(m[2]);
      } else {
        const fallback = text.match(/\b(?:replace|swap|substitute)\s+(.+)$/i);
        base.target = cleanTarget(fallback?.[1]);
      }
      return base;
    }
    default:
      return base;
  }
}

export class CircuitEditPlanner implements ICircuitEditPlanner {
  isEditRequest(input: CircuitEditPlannerInput): boolean {
    const text = extractText(input.request);
    if (text.length === 0) return false;
    return detectAction(text) !== null;
  }

  planEdit(input: CircuitEditPlannerInput): CircuitEditPlan | null {
    const requestText = extractText(input.request);
    if (requestText.length === 0) return null;

    const action = detectAction(requestText);
    if (!action) return null;

    return parsePlan(action, requestText, requestText);
  }

  planEditJSON(input: CircuitEditPlannerInput): EditPlanJSON | null {
    const plan = this.planEdit(input);
    return plan ? toEditPlanJSON(plan) : null;
  }

  isMultiActionRequest(input: CircuitEditPlannerInput): boolean {
    const text = extractText(input.request);
    if (text.length === 0) return false;
    return splitActionRequests(text).length > 1;
  }

  planEdits(input: CircuitEditPlannerInput): MultiEditPlanEntry[] {
    const text = extractText(input.request);
    if (text.length === 0) return [];

    return splitActionRequests(text).map((clause, index) => ({
      index,
      requestText: clause,
      plan: this.planEdit({ request: clause, conversationContext: input.conversationContext }),
    }));
  }

  planEditsJSON(input: CircuitEditPlannerInput): MultiEditPlanJSONEntry[] {
    return this.planEdits(input).map(({ index, requestText, plan }) => ({
      index,
      requestText,
      plan: plan ? toEditPlanJSON(plan) : null,
    }));
  }
}

/** Shared instance — stateless, mirrors `IntentAnalyzer.ts`'s exported
 *  `intentAnalyzer` singleton and `Planner.ts`'s exported `planner`. */
export const circuitEditPlanner = new CircuitEditPlanner();
