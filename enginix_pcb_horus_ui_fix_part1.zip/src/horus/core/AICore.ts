/**
 * HORUS AI — AI Core.
 *
 * The orchestration point that would (once implemented) coordinate a
 * request across Conversation Manager, Context Manager, Knowledge Base
 * Manager, Tool Manager, Validation Engine, Auto Fix Engine, Memory
 * Manager, and an AI Provider.
 *
 * AI Core depends on every collaborator only through its interface
 * (Dependency Inversion) and receives them via constructor injection, so
 * each module stays swappable and independently testable. No collaborator
 * is instantiated here, and no request/response logic is implemented —
 * this is the architecture wiring only.
 */

import type { AIProvider } from '../provider/AIProvider';
import type { IConversationManager } from '../conversation/ConversationManager';
import type { IContextManager } from '../context/ContextManager';
import type { IKnowledgeBaseManager } from '../knowledge/KnowledgeBaseManager';
import type { IToolManager } from '../tools/ToolManager';
import type { IValidationEngine } from '../validation/ValidationEngine';
import type { IAutoFixEngine } from '../autofix/AutoFixEngine';
import type { IMemoryManager } from '../memory/MemoryManager';

/** Dependencies AI Core is composed from. Every field is an interface —
 *  AI Core never depends on a concrete implementation. */
export interface AICoreDependencies {
  provider: AIProvider;
  conversationManager: IConversationManager;
  contextManager: IContextManager;
  knowledgeBaseManager: IKnowledgeBaseManager;
  toolManager: IToolManager;
  validationEngine: IValidationEngine;
  autoFixEngine: IAutoFixEngine;
  memoryManager: IMemoryManager;
}

export interface HorusRequest {
  conversationId: string;
  userMessage: string;
}

export interface HorusResponse {
  conversationId: string;
  reply: string;
}

export interface IAICore {
  /** Handle a single user request end-to-end. Not implemented yet. */
  handleRequest(request: HorusRequest): Promise<HorusResponse>;
}

export class AICore implements IAICore {
  private readonly deps: AICoreDependencies;

  constructor(deps: AICoreDependencies) {
    this.deps = deps;
  }

  handleRequest(_request: HorusRequest): Promise<HorusResponse> {
    // Referencing `deps` keeps it a real (not just declared) dependency
    // without introducing any request-handling logic yet.
    void this.deps;
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
