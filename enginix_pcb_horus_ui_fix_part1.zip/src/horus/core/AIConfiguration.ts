/**
 * HORUS AI — AI Configuration.
 *
 * Owns per-provider configuration for every AI vendor HORUS knows about
 * (see `provider/AIProviderManager.ts` for the shared `AIProviderId`
 * union), plus which one is currently active. This is the single source
 * of truth `AICore`, `PromptManager`, and provider adapters will read
 * from once implemented — provider adapters (e.g. `GeminiProvider`)
 * remain unaware of *how* a value was configured, only that
 * `AIConfiguration` can hand them one.
 *
 * Relationship to other HORUS modules (architecture only):
 *  - `ProviderRegistry` holds provider *instances* (behavior).
 *    `AIConfiguration` holds provider *settings* (data). `AIProviderManager`
 *    is expected to consult `AIConfiguration.getActiveProviderId()` when
 *    asked "which provider is active", rather than owning that concept
 *    itself once wired up.
 *  - Values are intended to ultimately be sourced from / synced with the
 *    existing Settings surfaces (e.g. `src/lib/geminiSettings.ts`,
 *    `SettingsDialog`, `SettingsEvents`) — this module does not modify
 *    Settings and does not decide persistence strategy at this stage.
 *
 * Implementation status: this module is a functional in-memory
 * configuration store (plain CRUD over a `Map`, plus the active-provider
 * id) — it holds whatever values callers give it via
 * `setProviderConfiguration` / `setActiveProvider` / `setValidationState`.
 * It still does not read from or write to any external backing source
 * (localStorage, `geminiSettings`, etc.) itself — `refresh()` is a no-op
 * until that sync strategy is decided — so it is not yet the persistent
 * source of truth, only the in-memory one consulted at request time
 * (e.g. by `GeminiProvider.testConnection()`).
 */

import type { AIProviderId } from '../provider/AIProviderManager';

/** Re-exported for convenience so callers of this file don't also need to
 *  import `AIProviderId` from the provider module directly. */
export type { AIProviderId } from '../provider/AIProviderManager';

/**
 * Result of the last credential/connectivity check for a provider's
 * configuration, mirroring the "Test Connection" concept surfaced in
 * Settings and in `AIProvider.testConnection()`. Purely descriptive state
 * here — this module does not perform the check itself.
 */
export type AIConfigurationValidationState =
  | 'unvalidated'
  | 'validating'
  | 'valid'
  | 'invalid';

/** Configuration values stored independently for a single provider. */
export interface AIProviderConfiguration {
  /** Human-readable label for display in Settings/UI. */
  providerName: string;
  /** Stable identifier this configuration belongs to. */
  providerId: AIProviderId;
  apiKey: string | undefined;
  selectedModel: string | undefined;
  temperature: number | undefined;
  maxTokens: number | undefined;
  /** Outcome of the last validation attempt for this provider's config. */
  validationState: AIConfigurationValidationState;
}

/** Partial update payload — every field but the target provider is optional. */
export type AIProviderConfigurationUpdate = Partial<
  Omit<AIProviderConfiguration, 'providerId'>
>;

/** Snapshot of the whole configuration surface — every known provider's
 *  settings plus which one is active. */
export interface AIConfigurationSnapshot {
  activeProviderId: AIProviderId | undefined;
  providers: Record<AIProviderId, AIProviderConfiguration | undefined>;
}

export interface IAIConfiguration {
  /** Get the currently active provider identifier. */
  getActiveProviderId(): AIProviderId | undefined;

  /**
   * Switch the active provider. Does not create, validate, or otherwise
   * alter that provider's stored configuration — it only changes which
   * provider's configuration is considered active.
   */
  setActiveProvider(id: AIProviderId): void;

  /** Get the full stored configuration for one provider, if any. */
  getProviderConfiguration(id: AIProviderId): AIProviderConfiguration | undefined;

  /** Get the stored configuration for every provider that has one. */
  getAllProviderConfigurations(): AIProviderConfiguration[];

  /**
   * Create or merge-update the stored configuration for one provider.
   * Providers are configured independently of one another — updating one
   * never reads or mutates another provider's configuration.
   */
  setProviderConfiguration(
    id: AIProviderId,
    values: AIProviderConfigurationUpdate,
  ): void;

  /** Remove a provider's stored configuration entirely. */
  clearProviderConfiguration(id: AIProviderId): void;

  /** Get the validation state for one provider's configuration. */
  getValidationState(id: AIProviderId): AIConfigurationValidationState | undefined;

  /**
   * Record the outcome of a validation/connectivity check for one
   * provider's configuration. Does not perform the check itself — that is
   * `AIProvider.testConnection()`'s responsibility once implemented.
   */
  setValidationState(id: AIProviderId, state: AIConfigurationValidationState): void;

  /** Get a full snapshot: every provider's configuration plus which is active. */
  getSnapshot(): AIConfigurationSnapshot;

  /** Refresh cached configuration values from their backing source. */
  refresh(): void;
}

/** Every identifier the architecture reserves, used only to build a full
 *  `providers` map in `getSnapshot()` — not a statement about which ones
 *  have a concrete adapter (see `SUPPORTED_PROVIDER_IDS` for that). */
const ALL_PROVIDER_IDS: readonly AIProviderId[] = ['gemini', 'openai', 'groq', 'openrouter'];

export class AIConfiguration implements IAIConfiguration {
  /** Per-provider configuration store. Keyed by provider id so every
   *  provider's settings are held independently of the others. */
  private readonly configurations = new Map<AIProviderId, AIProviderConfiguration>();

  private activeProviderId: AIProviderId | undefined;

  getActiveProviderId(): AIProviderId | undefined {
    return this.activeProviderId;
  }

  setActiveProvider(id: AIProviderId): void {
    this.activeProviderId = id;
  }

  getProviderConfiguration(id: AIProviderId): AIProviderConfiguration | undefined {
    return this.configurations.get(id);
  }

  getAllProviderConfigurations(): AIProviderConfiguration[] {
    return Array.from(this.configurations.values());
  }

  setProviderConfiguration(
    id: AIProviderId,
    values: AIProviderConfigurationUpdate,
  ): void {
    const existing = this.configurations.get(id);
    this.configurations.set(id, {
      providerName: values.providerName ?? existing?.providerName ?? id,
      providerId: id,
      apiKey: values.apiKey ?? existing?.apiKey,
      selectedModel: values.selectedModel ?? existing?.selectedModel,
      temperature: values.temperature ?? existing?.temperature,
      maxTokens: values.maxTokens ?? existing?.maxTokens,
      validationState: values.validationState ?? existing?.validationState ?? 'unvalidated',
    });
  }

  clearProviderConfiguration(id: AIProviderId): void {
    this.configurations.delete(id);
  }

  getValidationState(id: AIProviderId): AIConfigurationValidationState | undefined {
    return this.configurations.get(id)?.validationState;
  }

  setValidationState(id: AIProviderId, state: AIConfigurationValidationState): void {
    const existing = this.configurations.get(id);
    if (existing) {
      this.configurations.set(id, { ...existing, validationState: state });
      return;
    }
    this.configurations.set(id, {
      providerName: id,
      providerId: id,
      apiKey: undefined,
      selectedModel: undefined,
      temperature: undefined,
      maxTokens: undefined,
      validationState: state,
    });
  }

  getSnapshot(): AIConfigurationSnapshot {
    const providers = {} as Record<AIProviderId, AIProviderConfiguration | undefined>;
    for (const id of ALL_PROVIDER_IDS) {
      providers[id] = this.configurations.get(id);
    }
    return { activeProviderId: this.activeProviderId, providers };
  }

  refresh(): void {
    // No external backing source (localStorage/Settings sync) wired up
    // yet at this stage — nothing to refresh from. No-op.
  }
}
