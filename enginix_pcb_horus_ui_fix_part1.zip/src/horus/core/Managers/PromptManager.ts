/**
 * HORUS AI — Prompt Manager.
 *
 * Responsible (once implemented) for assembling the final prompt sent to
 * the model from three distinct parts:
 *  - System Prompt   — fixed behavioral/role instructions.
 *  - User Prompt      — the current user request/input.
 *  - Context Prompt   — injected project / circuit / PCB / memory context.
 *
 * Isolated from MemoryManager (persistent recall) and AICore (model
 * invocation) — PromptManager only builds and validates prompt text; it
 * does not store memory and does not call any API.
 *
 * Interface + skeleton only — no logic, no prompt content, no AI logic,
 * no API calls implemented yet.
 */

export interface IPromptManager {
  /** Set the system prompt (fixed instructions/role). */
  setSystemPrompt(prompt: string): void;

  /** Get the currently set system prompt. */
  getSystemPrompt(): string | undefined;

  /** Set the user prompt (current user request/input). */
  setUserPrompt(prompt: string): void;

  /** Get the currently set user prompt. */
  getUserPrompt(): string | undefined;

  /** Set the context prompt (project/circuit/PCB/memory context). */
  setContextPrompt(prompt: string): void;

  /** Get the currently set context prompt. */
  getContextPrompt(): string | undefined;

  /** Assemble system + user + context into the final prompt. */
  buildFinalPrompt(): string;

  /** Validate the assembled prompt before it is sent. */
  validatePrompt(): boolean;

  /** Clear all prompt parts. */
  reset(): void;
}

export class PromptManager implements IPromptManager {
  setSystemPrompt(_prompt: string): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getSystemPrompt(): string | undefined {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  setUserPrompt(_prompt: string): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getUserPrompt(): string | undefined {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  setContextPrompt(_prompt: string): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getContextPrompt(): string | undefined {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  buildFinalPrompt(): string {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  validatePrompt(): boolean {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  reset(): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
