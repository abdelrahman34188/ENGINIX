/**
 * HORUS AI — Memory Manager (Core/Managers).
 *
 * Responsible (once implemented) for session and project-level memory used
 * to assemble prompts and maintain continuity across the HORUS workflow:
 *  - Chat history
 *  - Project context
 *  - Opened circuit context
 *  - PCB context
 *  - User preferences
 *
 * Also responsible for clearing, loading, and saving memory as a whole.
 *
 * Note: distinct from src/horus/memory/MemoryManager.ts, which is a
 * narrower durable key/value recall store. This manager aggregates the
 * broader set of context categories consumed by PromptManager.
 *
 * Interface + skeleton only — no logic, no persistence implementation,
 * no AI logic implemented yet.
 */

export interface IMemoryManager {
  // --- Chat history ---
  addChatMessage(message: unknown): void;
  getChatHistory(): unknown[] | undefined;
  clearChatHistory(): void;

  // --- Project context ---
  setProjectContext(context: unknown): void;
  getProjectContext(): unknown | undefined;
  clearProjectContext(): void;

  // --- Opened circuit context ---
  setCircuitContext(context: unknown): void;
  getCircuitContext(): unknown | undefined;
  clearCircuitContext(): void;

  // --- PCB context ---
  setPcbContext(context: unknown): void;
  getPcbContext(): unknown | undefined;
  clearPcbContext(): void;

  // --- User preferences ---
  setUserPreferences(preferences: unknown): void;
  getUserPreferences(): unknown | undefined;
  clearUserPreferences(): void;

  // --- Whole-memory operations ---
  clearMemory(): void;
  loadMemory(source?: unknown): void;
  saveMemory(destination?: unknown): void;
}

export class MemoryManager implements IMemoryManager {
  // --- Chat history ---
  addChatMessage(_message: unknown): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getChatHistory(): unknown[] | undefined {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  clearChatHistory(): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  // --- Project context ---
  setProjectContext(_context: unknown): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getProjectContext(): unknown | undefined {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  clearProjectContext(): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  // --- Opened circuit context ---
  setCircuitContext(_context: unknown): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getCircuitContext(): unknown | undefined {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  clearCircuitContext(): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  // --- PCB context ---
  setPcbContext(_context: unknown): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getPcbContext(): unknown | undefined {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  clearPcbContext(): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  // --- User preferences ---
  setUserPreferences(_preferences: unknown): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getUserPreferences(): unknown | undefined {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  clearUserPreferences(): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  // --- Whole-memory operations ---
  clearMemory(): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  loadMemory(_source?: unknown): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  saveMemory(_destination?: unknown): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
