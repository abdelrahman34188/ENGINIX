/**
 * HORUS AI — Tool Registry (Core/Tools).
 *
 * Responsible (once implemented) for registering the set of tools
 * available to HORUS and allowing future lookup by tool name, keeping
 * the tool architecture modular — new tools are added here rather than
 * hardcoded elsewhere.
 *
 * Note: distinct from src/horus/tools/ToolManager.ts, which is intended
 * for invocation/dispatch of tool calls. ToolRegistry only registers and
 * looks up tool placeholders; it does not invoke tools and is not
 * connected to any AI/provider logic yet.
 *
 * Interface + skeleton only — no logic, no dispatch, no AI logic
 * implemented yet.
 */

export type HorusToolName =
  | 'CircuitTool'
  | 'PCBTool'
  | 'ArduinoTool'
  | 'SimulationTool'
  | 'ComponentTool';

export interface HorusToolPlaceholder {
  name: HorusToolName;
  /** Reserved for future description text. */
  description?: string;
}

export interface IToolRegistry {
  /** Register a tool placeholder under its name. */
  register(tool: HorusToolPlaceholder): void;

  /** Look up a registered tool placeholder by name. */
  getTool(name: HorusToolName): HorusToolPlaceholder | undefined;

  /** List all registered tool placeholders. */
  listTools(): HorusToolPlaceholder[];

  /** Check whether a tool name is registered. */
  hasTool(name: HorusToolName): boolean;

  /** Unregister a tool by name. */
  unregister(name: HorusToolName): void;
}

export class ToolRegistry implements IToolRegistry {
  private readonly tools = new Map<HorusToolName, HorusToolPlaceholder>();

  register(tool: HorusToolPlaceholder): void {
    this.tools.set(tool.name, tool);
  }

  getTool(name: HorusToolName): HorusToolPlaceholder | undefined {
    return this.tools.get(name);
  }

  listTools(): HorusToolPlaceholder[] {
    return Array.from(this.tools.values());
  }

  hasTool(name: HorusToolName): boolean {
    return this.tools.has(name);
  }

  unregister(name: HorusToolName): void {
    this.tools.delete(name);
  }
}

/**
 * Placeholder tool entries for the tools HORUS will support.
 * Names only — no descriptions, parameters, or handlers yet.
 */
export const HORUS_TOOL_PLACEHOLDERS: HorusToolPlaceholder[] = [
  { name: 'CircuitTool' },
  { name: 'PCBTool' },
  { name: 'ArduinoTool' },
  { name: 'SimulationTool' },
  { name: 'ComponentTool' },
];

/** Shared instance, pre-populated with every known tool placeholder —
 *  mirrors `router/IntentRouter.ts`'s exported `intentRouter` singleton. */
export const toolRegistry = new ToolRegistry();
HORUS_TOOL_PLACEHOLDERS.forEach((tool) => toolRegistry.register(tool));
