/**
 * HORUS AI — Arduino Tool (Core/Tools).
 *
 * Skeleton placeholder for the ArduinoTool registered in ToolRegistry.
 * Responsible (once implemented) for exposing sketch/compile/upload and
 * runtime access for HORUS to reason about and act on Arduino code.
 *
 * Interface + skeleton only — no logic, no AI logic implemented yet.
 */

export interface IHorusArduinoTool {
  /** Get the current Arduino sketch. */
  getSketch(): unknown;

  /** Compile the current sketch. */
  compileSketch(): unknown;

  /** Upload the compiled sketch. */
  uploadSketch(): unknown;

  /** Get the current pin map. */
  getPinMap(): unknown;

  /** Get the serial output. */
  getSerialOutput(): unknown;
}

export class ArduinoTool implements IHorusArduinoTool {
  getSketch(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  compileSketch(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  uploadSketch(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getPinMap(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getSerialOutput(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
