/**
 * HORUS AI — PCB Tool (Core/Tools).
 *
 * Skeleton placeholder for the PCBTool registered in ToolRegistry.
 * Responsible (once implemented) for exposing read/export access to the
 * current PCB for HORUS to reason about and act on.
 *
 * Interface + skeleton only — no logic, no AI logic implemented yet.
 */

export interface IHorusPCBTool {
  /** Get the current PCB. */
  getPCB(): unknown;

  /** Get the board size/dimensions. */
  getBoardSize(): unknown;

  /** Get the traces on the PCB. */
  getTraces(): unknown[];

  /** Get the layers of the PCB. */
  getLayers(): unknown[];

  /** Export the PCB. */
  exportPCB(): unknown;
}

export class PCBTool implements IHorusPCBTool {
  getPCB(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getBoardSize(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getTraces(): unknown[] {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getLayers(): unknown[] {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  exportPCB(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
