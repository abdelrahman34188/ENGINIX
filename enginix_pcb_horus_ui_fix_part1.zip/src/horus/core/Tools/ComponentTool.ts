/**
 * HORUS AI — Component Tool (Core/Tools).
 *
 * Skeleton placeholder for the ComponentTool registered in ToolRegistry.
 * Responsible (once implemented) for exposing component search, data
 * access, and updates for HORUS to reason about and act on.
 *
 * Interface + skeleton only — no logic, no AI logic implemented yet.
 */

export interface IHorusComponentTool {
  /** Search for a component. */
  searchComponent(query: string): unknown[];

  /** Get data for a specific component. */
  getComponentData(componentId: string): unknown;

  /** Update a component's value. */
  updateComponentValue(componentId: string, value: unknown): void;

  /** List available component categories. */
  listCategories(): string[];
}

export class ComponentTool implements IHorusComponentTool {
  searchComponent(_query: string): unknown[] {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getComponentData(_componentId: string): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  updateComponentValue(_componentId: string, _value: unknown): void {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  listCategories(): string[] {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
