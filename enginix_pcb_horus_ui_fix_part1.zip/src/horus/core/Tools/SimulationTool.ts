/**
 * HORUS AI — Simulation Tool (Core/Tools).
 *
 * Skeleton placeholder for the SimulationTool registered in ToolRegistry.
 * Responsible (once implemented) for exposing simulation control and
 * state access for HORUS to reason about and act on.
 *
 * Interface + skeleton only — no logic, no AI logic implemented yet.
 */

export interface IHorusSimulationTool {
  /** Start the simulation. */
  startSimulation(): unknown;

  /** Stop the simulation. */
  stopSimulation(): unknown;

  /** Reset the simulation. */
  resetSimulation(): unknown;

  /** Get the current simulation state. */
  getSimulationState(): unknown;
}

export class SimulationTool implements IHorusSimulationTool {
  startSimulation(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  stopSimulation(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  resetSimulation(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getSimulationState(): unknown {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }
}
