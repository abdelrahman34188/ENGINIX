/**
 * HORUS AI — Conversation Manager (Core/Chat).
 *
 * Owns one conversation's turn sequence: receive a user message, append
 * an assistant reply, and return the ordered history. Also holds the
 * latest circuit context JSON attached to a conversation (storage
 * only — see `attachCircuitContext`/`getCircuitContext` below).
 *
 * Scope, deliberately narrow:
 *  - receive user message
 *  - append assistant reply
 *  - return conversation history
 *  - store/retrieve the latest attached circuit context, verbatim
 *  Nothing else (no summarization/trimming, no multi-conversation
 *  listing, no persistence) — that breadth belongs to a higher-level
 *  manager, not this module. Attaching a circuit context is storage
 *  only: no analysis, no reshaping, no reasoning about what's stored.
 *  - No AI (does not import/touch `AIGateway`, any provider, or
 *    `PromptBuilder`/`PromptValidator`/`SystemPromptManager` — this
 *    module stores turns, it doesn't produce a reply's content).
 *  - No frontend (no consumer wired in yet).
 *  - No simulator involvement (does not import/touch anything under
 *    `simulator`/`circuit`).
 *
 * Distinct from `conversation/ConversationManager.ts`, which already
 * exists at a different path with a different, broader shape
 * (start/append/getHistory/clear across multiple conversations, string-
 * only `content`). This module is self-contained — its own message
 * type, no import of that file or of `Chat/ChatSession.ts` — so it has
 * no dependency on either still-unimplemented/parallel module.
 *
 * Implementation status: architecture only. Turns are held in-memory
 * per conversation id — no persistence backend has been decided yet
 * (see `Chat/ChatSession.ts` for that concern).
 */

export interface ConversationTurn {
  id: string;
  role: 'user' | 'assistant';
  content: unknown;
  timestamp: number;
}

export interface IConversationManager {
  /** Receive a user message, appending it to the conversation's history. */
  receiveUserMessage(conversationId: string, content: unknown): ConversationTurn;

  /** Append an assistant reply to the conversation's history. */
  appendAssistantReply(conversationId: string, content: unknown): ConversationTurn;

  /** Return the full ordered turn history for a conversation. */
  getHistory(conversationId: string): ConversationTurn[];

  /**
   * Attach the latest circuit context JSON (from `CircuitContextBuilder`)
   * to a conversation, replacing whatever was attached before. Storage
   * only — no analysis, no reshaping, no AI call. Callers (e.g.
   * `runtime.ts`) do this once per outgoing request, before the request
   * is sent, so the current circuit snapshot travels with the
   * conversation it belongs to.
   */
  attachCircuitContext(conversationId: string, circuitContext: unknown): void;

  /** Return the most recently attached circuit context for a conversation, or undefined if none has been attached yet. */
  getCircuitContext(conversationId: string): unknown;
}

/** Generate a turn id. Plain, dependency-free — no external id library. */
function generateTurnId(): string {
  return `turn_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

export class ConversationManager implements IConversationManager {
  private readonly conversations = new Map<string, ConversationTurn[]>();
  private readonly circuitContexts = new Map<string, unknown>();

  private appendTurn(conversationId: string, role: 'user' | 'assistant', content: unknown): ConversationTurn {
    const turn: ConversationTurn = {
      id: generateTurnId(),
      role,
      content,
      timestamp: Date.now(),
    };
    const history = this.conversations.get(conversationId) ?? [];
    history.push(turn);
    this.conversations.set(conversationId, history);
    return turn;
  }

  receiveUserMessage(conversationId: string, content: unknown): ConversationTurn {
    return this.appendTurn(conversationId, 'user', content);
  }

  appendAssistantReply(conversationId: string, content: unknown): ConversationTurn {
    return this.appendTurn(conversationId, 'assistant', content);
  }

  getHistory(conversationId: string): ConversationTurn[] {
    return [...(this.conversations.get(conversationId) ?? [])];
  }

  attachCircuitContext(conversationId: string, circuitContext: unknown): void {
    this.circuitContexts.set(conversationId, circuitContext);
  }

  getCircuitContext(conversationId: string): unknown {
    return this.circuitContexts.get(conversationId);
  }
}

/** Shared instance — mirrors the singleton pattern used across
 *  `core/Brain/` and `core/Chat/` (e.g. `toolExecutor`, `chatSessionStore`). */
export const conversationManager = new ConversationManager();
