/**
 * HORUS AI — Chat Manager (Core/Chat).
 *
 * Orchestrates the first real, end-to-end message flow:
 *
 *   Chat -> ConversationManager -> HORUS Brain -> AIGateway ->
 *   Gemini Provider -> HORUS Brain -> ConversationManager -> Chat
 *
 * i.e.: receive the message from Chat, record it via ConversationManager,
 * hand it to HORUS Brain's plain text-in/text-out entry point (`run()`),
 * which itself goes straight to AIGateway (which resolves and calls the
 * active provider — currently Gemini) and returns the reply, record
 * that reply via ConversationManager, and return the updated history
 * back to Chat.
 *
 * Scope, deliberately narrow — this is the *first* real flow, not the
 * full one:
 *  - No tool execution. `IHorusBrainForChat` below only requires
 *    `run()` (HORUSBrain's original straight-line AI pipeline), not
 *    `handleRequest()` (which can route through Planner to
 *    `ToolExecutor`). `run()` structurally never touches
 *    `ToolExecutor` — see `HORUSBrain.ts`'s `execute()` — so this
 *    module cannot trigger a tool call even indirectly.
 *  - Only text conversation. The reply this module records and
 *    returns is `AIResponse.text` — a plain string — not a tool
 *    result of any kind.
 *  - No frontend changes — no UI component is imported or modified;
 *    "Chat" here means whatever caller invokes `sendMessage()`, not a
 *    specific component.
 *  - No simulator involvement (does not import/touch anything under
 *    `simulator`/`circuit`).
 *  - Does not call `AIGateway` or any provider itself — Brain's
 *    `run()` is the only thing that does either, exactly as already
 *    wired in `HORUSBrain.ts`/`runtime.ts`. This module only sequences
 *    the steps above.
 *
 * Depends on `Chat/ConversationManager.ts` (turn-by-turn receive/
 * append/history) and on a narrow slice of `Brain/HORUSBrain.ts`'s
 * public surface (`run()`, `HORUSBrainInput`) plus `AI/AIResponse.ts`'s
 * `AIResponse`, rather than the whole concrete `HORUSBrain` class or
 * `ResponseOrchestrator`/`BrainResponse` — so this file doesn't need to
 * know how Brain is constructed, only that it can `run()`.
 */

import { conversationManager, type ConversationTurn, type IConversationManager } from './ConversationManager';
import type { HORUSBrainInput } from '../Brain/HORUSBrain';
import type { AIResponse } from '../AI/AIResponse';

/** The narrow slice of HORUSBrain's surface ChatManager needs for this
 *  first flow — just enough to hand off a request and get a plain
 *  `AIResponse` back, with no tool involved. */
export interface IHorusBrainForChat {
  run(input: HORUSBrainInput): Promise<AIResponse>;
}

/** One `sendMessage()` call's input: the raw user message plus whatever
 *  optional context Brain's `run()` accepts. */
export interface ChatManagerSendInput {
  conversationId: string;
  userRequest: unknown;
  projectContext?: unknown;
  memory?: unknown;
}

/** What `sendMessage()` hands back to Chat: the full updated turn
 *  history plus the raw `AIResponse` that produced the latest reply,
 *  for callers that need more than the appended text (e.g. errors). */
export interface ChatManagerSendResult {
  history: ConversationTurn[];
  aiResponse: AIResponse;
}

export interface IChatManager {
  /** Run one full turn: Chat -> ConversationManager -> Brain ->
   *  AIGateway -> Provider -> Brain -> ConversationManager -> Chat. */
  sendMessage(input: ChatManagerSendInput): Promise<ChatManagerSendResult>;
}

export class ChatManager implements IChatManager {
  private readonly conversations: IConversationManager;
  private readonly brain: IHorusBrainForChat;

  constructor(brain: IHorusBrainForChat, conversations: IConversationManager = conversationManager) {
    this.brain = brain;
    this.conversations = conversations;
  }

  async sendMessage(input: ChatManagerSendInput): Promise<ChatManagerSendResult> {
    const { conversationId, userRequest, projectContext, memory } = input;

    // Chat -> ConversationManager: record the incoming user message.
    this.conversations.receiveUserMessage(conversationId, userRequest);

    // ConversationManager -> HORUS Brain -> AIGateway -> Gemini Provider
    // -> HORUS Brain: run() is the plain text-in/text-out AI pipeline;
    // it never calls ToolExecutor.
    const aiResponse = await this.brain.run({
      userRequest,
      conversationContext: this.conversations.getHistory(conversationId),
      projectContext,
      memory,
    });

    // HORUS Brain -> ConversationManager: record the reply text.
    this.conversations.appendAssistantReply(conversationId, aiResponse.text);

    // ConversationManager -> Chat: return the updated history.
    return {
      history: this.conversations.getHistory(conversationId),
      aiResponse,
    };
  }
}
