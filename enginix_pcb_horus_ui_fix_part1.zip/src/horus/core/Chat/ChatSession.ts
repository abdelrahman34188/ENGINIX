/**
 * HORUS AI — Chat Session (Core/Chat).
 *
 * Owns the create/load/save lifecycle for a single HORUS chat session —
 * an id, its message list, and its timestamps.
 *
 * Scope, deliberately narrow:
 *  - create session
 *  - load session
 *  - save session
 *  Nothing else (no rename, no delete, no listing, no message-level
 *  helpers) — that breadth belongs to a higher-level manager, not this
 *  module.
 *  - No UI (no consumer wired in yet).
 *  - No simulator involvement (does not import/touch anything under
 *    `simulator`/`circuit`).
 *  - No AI logic (does not import/touch `AIGateway`, any provider, or
 *    `PromptBuilder`/`PromptValidator`/`SystemPromptManager` — a
 *    session holds messages, it doesn't produce them).
 *
 * Distinct from `conversation/SessionManager.ts`, which is the broader,
 * multi-session manager (list/rename/delete/append across every known
 * session). This module is the narrower unit that manager would own one
 * of — create/load/save for a single session — and is self-contained
 * (its own message type, no import of `SessionManager.ts` or
 * `ConversationManager.ts`) so it has no dependency on that still-
 * unimplemented module.
 *
 * Implementation status: architecture only. `save`/`load` back onto an
 * in-memory store as a placeholder — no real persistence backend
 * (localStorage, file, DB) has been decided yet.
 */

export interface ChatSessionMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: unknown;
  timestamp: number;
}

export interface ChatSession {
  id: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatSessionMessage[];
}

export interface IChatSessionStore {
  /** Create a new, empty chat session and return it. */
  createSession(id?: string): ChatSession;

  /** Load a previously saved chat session by id. */
  loadSession(id: string): ChatSession | undefined;

  /** Save (create or overwrite) a chat session. */
  saveSession(session: ChatSession): void;
}

/** Generate a session id when the caller doesn't supply one. Plain,
 *  dependency-free — no external id library. */
function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

export class ChatSessionStore implements IChatSessionStore {
  private readonly sessions = new Map<string, ChatSession>();

  createSession(id?: string): ChatSession {
    const now = Date.now();
    const session: ChatSession = {
      id: id ?? generateSessionId(),
      createdAt: now,
      updatedAt: now,
      messages: [],
    };
    this.sessions.set(session.id, session);
    return session;
  }

  loadSession(id: string): ChatSession | undefined {
    return this.sessions.get(id);
  }

  saveSession(session: ChatSession): void {
    this.sessions.set(session.id, { ...session, updatedAt: Date.now() });
  }
}

/** Shared instance — mirrors the singleton pattern used across
 *  `core/Brain/` (e.g. `toolExecutor`, `contextBuilder`). */
export const chatSessionStore = new ChatSessionStore();
