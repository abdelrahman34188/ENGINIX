/**
 * HORUS AI — AI Event Bus — Simulator event emitter.
 *
 * Thin, strongly-typed wrapper over `IAIEventBus.publish()` for every
 * Simulator action HORUS should be notified about. This is the one
 * entry point the Simulator module would call once it's wired up —
 * one method per action, each fixed to the 'simulator' event module so
 * callers can't mis-tag an event. This file does not import from or
 * modify `src/circuit`; it is designed to be called BY it later.
 */

import type { IAIEventBus } from '../AIEventBus';
import type { HorusEvent } from '../HorusEvent';
import { SimulatorEventName } from '../catalog/SimulatorEvents';
import type {
  ComponentAddedPayload,
  ComponentRemovedPayload,
  WireAddedPayload,
  WireRemovedPayload,
  ComponentValueChangedPayload,
  SimulationStartedPayload,
  SimulationStoppedPayload,
} from '../catalog/SimulatorEvents';

export interface ISimulatorEventEmitter {
  componentAdded(payload: ComponentAddedPayload): Promise<HorusEvent<ComponentAddedPayload>>;
  componentRemoved(payload: ComponentRemovedPayload): Promise<HorusEvent<ComponentRemovedPayload>>;
  wireAdded(payload: WireAddedPayload): Promise<HorusEvent<WireAddedPayload>>;
  wireRemoved(payload: WireRemovedPayload): Promise<HorusEvent<WireRemovedPayload>>;
  componentValueChanged(
    payload: ComponentValueChangedPayload
  ): Promise<HorusEvent<ComponentValueChangedPayload>>;
  simulationStarted(payload: SimulationStartedPayload): Promise<HorusEvent<SimulationStartedPayload>>;
  simulationStopped(payload: SimulationStoppedPayload): Promise<HorusEvent<SimulationStoppedPayload>>;
}

export class SimulatorEventEmitter implements ISimulatorEventEmitter {
  constructor(private readonly bus: IAIEventBus) {}

  componentAdded(payload: ComponentAddedPayload) {
    return this.bus.publish({ module: 'simulator', eventName: SimulatorEventName.ComponentAdded, payload });
  }

  componentRemoved(payload: ComponentRemovedPayload) {
    return this.bus.publish({ module: 'simulator', eventName: SimulatorEventName.ComponentRemoved, payload });
  }

  wireAdded(payload: WireAddedPayload) {
    return this.bus.publish({ module: 'simulator', eventName: SimulatorEventName.WireAdded, payload });
  }

  wireRemoved(payload: WireRemovedPayload) {
    return this.bus.publish({ module: 'simulator', eventName: SimulatorEventName.WireRemoved, payload });
  }

  componentValueChanged(payload: ComponentValueChangedPayload) {
    return this.bus.publish({
      module: 'simulator',
      eventName: SimulatorEventName.ComponentValueChanged,
      payload,
    });
  }

  simulationStarted(payload: SimulationStartedPayload) {
    return this.bus.publish({ module: 'simulator', eventName: SimulatorEventName.SimulationStarted, payload });
  }

  simulationStopped(payload: SimulationStoppedPayload) {
    return this.bus.publish({ module: 'simulator', eventName: SimulatorEventName.SimulationStopped, payload });
  }
}
