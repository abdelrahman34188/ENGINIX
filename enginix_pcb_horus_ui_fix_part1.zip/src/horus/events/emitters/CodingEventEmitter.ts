/**
 * HORUS AI — AI Event Bus — Coding event emitter.
 *
 * Thin, strongly-typed wrapper over `IAIEventBus.publish()` for every
 * Coding action HORUS should be notified about. This is the one entry
 * point the Coding module would call once it's wired up. This file does
 * not import from or modify `src/arduino`; it is designed to be called
 * BY it later.
 */

import type { IAIEventBus } from '../AIEventBus';
import type { HorusEvent } from '../HorusEvent';
import { CodingEventName } from '../catalog/CodingEvents';
import type {
  CodeChangedPayload,
  FileOpenedPayload,
  FileSavedPayload,
  CompileStartedPayload,
  CompileFinishedPayload,
} from '../catalog/CodingEvents';

export interface ICodingEventEmitter {
  codeChanged(payload: CodeChangedPayload): Promise<HorusEvent<CodeChangedPayload>>;
  fileOpened(payload: FileOpenedPayload): Promise<HorusEvent<FileOpenedPayload>>;
  fileSaved(payload: FileSavedPayload): Promise<HorusEvent<FileSavedPayload>>;
  compileStarted(payload: CompileStartedPayload): Promise<HorusEvent<CompileStartedPayload>>;
  compileFinished(payload: CompileFinishedPayload): Promise<HorusEvent<CompileFinishedPayload>>;
}

export class CodingEventEmitter implements ICodingEventEmitter {
  constructor(private readonly bus: IAIEventBus) {}

  codeChanged(payload: CodeChangedPayload) {
    return this.bus.publish({ module: 'coding', eventName: CodingEventName.CodeChanged, payload });
  }

  fileOpened(payload: FileOpenedPayload) {
    return this.bus.publish({ module: 'coding', eventName: CodingEventName.FileOpened, payload });
  }

  fileSaved(payload: FileSavedPayload) {
    return this.bus.publish({ module: 'coding', eventName: CodingEventName.FileSaved, payload });
  }

  compileStarted(payload: CompileStartedPayload) {
    return this.bus.publish({ module: 'coding', eventName: CodingEventName.CompileStarted, payload });
  }

  compileFinished(payload: CompileFinishedPayload) {
    return this.bus.publish({ module: 'coding', eventName: CodingEventName.CompileFinished, payload });
  }
}
