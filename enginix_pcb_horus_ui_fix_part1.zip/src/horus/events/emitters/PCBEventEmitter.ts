/**
 * HORUS AI — AI Event Bus — PCB event emitter.
 *
 * Thin, strongly-typed wrapper over `IAIEventBus.publish()` for every
 * PCB action HORUS should be notified about. This is the one entry
 * point the PCB module would call once it's wired up. This file does
 * not import from or modify `src/pcb`; it is designed to be called BY
 * it later.
 */

import type { IAIEventBus } from '../AIEventBus';
import type { HorusEvent } from '../HorusEvent';
import { PCBEventName } from '../catalog/PCBEvents';
import type {
  ConvertToPCBPayload,
  ComponentMovedPayload,
  TraceAddedPayload,
  TraceRemovedPayload,
  AutoRoutingFinishedPayload,
} from '../catalog/PCBEvents';

export interface IPCBEventEmitter {
  convertToPCB(payload: ConvertToPCBPayload): Promise<HorusEvent<ConvertToPCBPayload>>;
  componentMoved(payload: ComponentMovedPayload): Promise<HorusEvent<ComponentMovedPayload>>;
  traceAdded(payload: TraceAddedPayload): Promise<HorusEvent<TraceAddedPayload>>;
  traceRemoved(payload: TraceRemovedPayload): Promise<HorusEvent<TraceRemovedPayload>>;
  autoRoutingFinished(
    payload: AutoRoutingFinishedPayload
  ): Promise<HorusEvent<AutoRoutingFinishedPayload>>;
}

export class PCBEventEmitter implements IPCBEventEmitter {
  constructor(private readonly bus: IAIEventBus) {}

  convertToPCB(payload: ConvertToPCBPayload) {
    return this.bus.publish({ module: 'pcb', eventName: PCBEventName.ConvertToPCB, payload });
  }

  componentMoved(payload: ComponentMovedPayload) {
    return this.bus.publish({ module: 'pcb', eventName: PCBEventName.ComponentMoved, payload });
  }

  traceAdded(payload: TraceAddedPayload) {
    return this.bus.publish({ module: 'pcb', eventName: PCBEventName.TraceAdded, payload });
  }

  traceRemoved(payload: TraceRemovedPayload) {
    return this.bus.publish({ module: 'pcb', eventName: PCBEventName.TraceRemoved, payload });
  }

  autoRoutingFinished(payload: AutoRoutingFinishedPayload) {
    return this.bus.publish({ module: 'pcb', eventName: PCBEventName.AutoRoutingFinished, payload });
  }
}
