/**
 * HORUS AI — AI Event Bus — Workspace event emitter.
 *
 * Thin, strongly-typed wrapper over `IAIEventBus.publish()` for every
 * app-shell action HORUS should be notified about. This is the one
 * entry point the shell would call once it's wired up. This file does
 * not import from or modify the shell/pages; it is designed to be
 * called BY them later.
 */

import type { IAIEventBus } from '../AIEventBus';
import type { HorusEvent } from '../HorusEvent';
import { WorkspaceEventName } from '../catalog/WorkspaceEvents';
import type {
  PageChangedPayload,
  ProjectOpenedPayload,
  ProjectClosedPayload,
} from '../catalog/WorkspaceEvents';

export interface IWorkspaceEventEmitter {
  pageChanged(payload: PageChangedPayload): Promise<HorusEvent<PageChangedPayload>>;
  projectOpened(payload: ProjectOpenedPayload): Promise<HorusEvent<ProjectOpenedPayload>>;
  projectClosed(payload: ProjectClosedPayload): Promise<HorusEvent<ProjectClosedPayload>>;
}

export class WorkspaceEventEmitter implements IWorkspaceEventEmitter {
  constructor(private readonly bus: IAIEventBus) {}

  pageChanged(payload: PageChangedPayload) {
    return this.bus.publish({ module: 'workspace', eventName: WorkspaceEventName.PageChanged, payload });
  }

  projectOpened(payload: ProjectOpenedPayload) {
    return this.bus.publish({ module: 'workspace', eventName: WorkspaceEventName.ProjectOpened, payload });
  }

  projectClosed(payload: ProjectClosedPayload) {
    return this.bus.publish({ module: 'workspace', eventName: WorkspaceEventName.ProjectClosed, payload });
  }
}
