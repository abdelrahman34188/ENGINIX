/**
 * HORUS AI — AI Event Bus — Settings event emitter.
 *
 * Thin, strongly-typed wrapper over `IAIEventBus.publish()` for every
 * Settings action HORUS should be notified about. This is the one entry
 * point Settings would call once it's wired up. This file does not
 * import from or modify the Settings module; it is designed to be
 * called BY it later. Publishes only that a key/provider changed, never
 * the key value itself — see `catalog/SettingsEvents.ts`.
 */

import type { IAIEventBus } from '../AIEventBus';
import type { HorusEvent } from '../HorusEvent';
import { SettingsEventName } from '../catalog/SettingsEvents';
import type { ApiKeyUpdatedPayload, AIProviderChangedPayload } from '../catalog/SettingsEvents';

export interface ISettingsEventEmitter {
  apiKeyUpdated(payload: ApiKeyUpdatedPayload): Promise<HorusEvent<ApiKeyUpdatedPayload>>;
  aiProviderChanged(payload: AIProviderChangedPayload): Promise<HorusEvent<AIProviderChangedPayload>>;
}

export class SettingsEventEmitter implements ISettingsEventEmitter {
  constructor(private readonly bus: IAIEventBus) {}

  apiKeyUpdated(payload: ApiKeyUpdatedPayload) {
    return this.bus.publish({ module: 'settings', eventName: SettingsEventName.ApiKeyUpdated, payload });
  }

  aiProviderChanged(payload: AIProviderChangedPayload) {
    return this.bus.publish({
      module: 'settings',
      eventName: SettingsEventName.AIProviderChanged,
      payload,
    });
  }
}
