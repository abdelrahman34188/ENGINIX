/**
 * HORUS AI — AI Event Bus.
 *
 * Notifies HORUS AI whenever something changes inside ENGINIX. This is
 * transport infrastructure only: it moves structured `HorusEvent`
 * objects from publishers (Simulator, PCB, Coding, Workspace, Project,
 * Settings) to subscribers (HORUS AI modules such as Context Manager).
 * It does not read, interpret, or react to event content, does not talk
 * to any AI provider, and does not implement conversations — see
 * `core/AICore.ts` for that, once implemented.
 *
 * Isolation: nothing here imports from `src/circuit`, `src/pcb`,
 * `src/arduino`, the Project Gallery, or Settings. Those modules would
 * import `AIEventBus` and call `publish()`/`broadcast()` from their own
 * code later — this file does not reach into them.
 *
 * Fully functional infrastructure (unlike the still-skeleton AI Core /
 * Knowledge Base modules): publish, subscribe, unsubscribe, and
 * broadcast all work. What's deliberately absent is any AI behavior —
 * subscribers are the caller's own callbacks, not HORUS reasoning.
 */

import type {
  HorusEvent,
  HorusEventHandler,
  HorusEventInput,
  HorusEventModule,
  HorusEventSubscription,
  HorusEventSubscriptionTarget,
} from './HorusEvent';
import { HORUS_EVENT_WILDCARD } from './HorusEvent';

export interface IAIEventBus {
  /**
   * Publish an event to every subscriber registered for its module, plus
   * every wildcard subscriber. Dispatch is asynchronous — the returned
   * promise resolves once every subscriber has been notified (errors
   * thrown by individual subscribers are isolated so one bad subscriber
   * cannot block the rest).
   */
  publish<TPayload = unknown>(event: HorusEventInput<TPayload>): Promise<HorusEvent<TPayload>>;

  /**
   * Broadcast an event to every subscriber across every module,
   * regardless of which module they subscribed to. Use for HORUS-wide
   * notifications that don't belong to one area alone. Also asynchronous.
   */
  broadcast<TPayload = unknown>(event: HorusEventInput<TPayload>): Promise<HorusEvent<TPayload>>;

  /**
   * Register a handler for events from one module, or pass the wildcard
   * to receive every event. Returns a subscription handle carrying the
   * id and its own `unsubscribe()`.
   */
  subscribe<TPayload = unknown>(
    module: HorusEventSubscriptionTarget,
    handler: HorusEventHandler<TPayload>
  ): HorusEventSubscription;

  /** Remove a subscription by id. No-op if the id is unknown. */
  unsubscribe(subscriptionId: string): void;

  /** Number of currently active subscriptions (all modules + wildcard combined). */
  subscriberCount(): number;
}

interface InternalSubscription {
  id: string;
  module: HorusEventSubscriptionTarget;
  handler: HorusEventHandler<any>;
}

let nextSubscriptionId = 1;

export class AIEventBus implements IAIEventBus {
  private readonly subscriptions = new Map<string, InternalSubscription>();

  subscribe<TPayload = unknown>(
    module: HorusEventSubscriptionTarget,
    handler: HorusEventHandler<TPayload>
  ): HorusEventSubscription {
    const id = `horus-evt-sub-${nextSubscriptionId++}`;
    const record: InternalSubscription = { id, module, handler };
    this.subscriptions.set(id, record);

    return {
      id,
      module,
      unsubscribe: () => this.unsubscribe(id),
    };
  }

  unsubscribe(subscriptionId: string): void {
    this.subscriptions.delete(subscriptionId);
  }

  subscriberCount(): number {
    return this.subscriptions.size;
  }

  async publish<TPayload = unknown>(
    event: HorusEventInput<TPayload>
  ): Promise<HorusEvent<TPayload>> {
    const stamped = this.stamp(event);
    const targets = this.listenersFor(stamped.module);
    await this.dispatch(stamped, targets);
    return stamped;
  }

  async broadcast<TPayload = unknown>(
    event: HorusEventInput<TPayload>
  ): Promise<HorusEvent<TPayload>> {
    const stamped = this.stamp(event);
    // Every subscriber, regardless of which module they registered for.
    const targets = Array.from(this.subscriptions.values());
    await this.dispatch(stamped, targets);
    return stamped;
  }

  private stamp<TPayload>(event: HorusEventInput<TPayload>): HorusEvent<TPayload> {
    return { ...event, timestamp: Date.now() };
  }

  private listenersFor(module: HorusEventModule): InternalSubscription[] {
    return Array.from(this.subscriptions.values()).filter(
      (s) => s.module === module || s.module === HORUS_EVENT_WILDCARD
    );
  }

  /** Dispatch is always asynchronous, and one subscriber throwing/rejecting
   *  never prevents the others from being notified. */
  private async dispatch<TPayload>(
    event: HorusEvent<TPayload>,
    targets: InternalSubscription[]
  ): Promise<void> {
    await Promise.all(
      targets.map(async (target) => {
        try {
          await Promise.resolve().then(() => target.handler(event));
        } catch {
          // Isolate subscriber failures — the bus's job is delivery, not
          // subscriber correctness. No AI logic reacts to this here.
        }
      })
    );
  }
}
