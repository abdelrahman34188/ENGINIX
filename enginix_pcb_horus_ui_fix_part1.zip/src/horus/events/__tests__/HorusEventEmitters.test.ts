import { describe, it, expect, vi } from 'vitest';
import { AIEventBus } from '../AIEventBus';
import { HorusEventEmitters } from '../HorusEventEmitters';
import { SimulatorEventName } from '../catalog/SimulatorEvents';
import { CodingEventName } from '../catalog/CodingEvents';
import { PCBEventName } from '../catalog/PCBEvents';
import { WorkspaceEventName } from '../catalog/WorkspaceEvents';
import { SettingsEventName } from '../catalog/SettingsEvents';

describe('HorusEventEmitters', () => {
  it('publishes every Simulator action under the simulator module with the right event name', async () => {
    const bus = new AIEventBus();
    const emitters = new HorusEventEmitters(bus);
    const received: string[] = [];
    bus.subscribe('simulator', (e) => received.push(e.eventName));

    await emitters.simulator.componentAdded({ componentId: 1, componentType: 'resistor' });
    await emitters.simulator.componentRemoved({ componentId: 1 });
    await emitters.simulator.wireAdded({ wireId: 1, fromComponentId: 1, toComponentId: 2 });
    await emitters.simulator.wireRemoved({ wireId: 1 });
    await emitters.simulator.componentValueChanged({
      componentId: 1,
      propertyKey: 'resistance',
      oldValue: 100,
      newValue: 220,
    });
    await emitters.simulator.simulationStarted({ componentCount: 2 });
    await emitters.simulator.simulationStopped({ reason: 'user' });

    expect(received).toEqual([
      SimulatorEventName.ComponentAdded,
      SimulatorEventName.ComponentRemoved,
      SimulatorEventName.WireAdded,
      SimulatorEventName.WireRemoved,
      SimulatorEventName.ComponentValueChanged,
      SimulatorEventName.SimulationStarted,
      SimulatorEventName.SimulationStopped,
    ]);
  });

  it('publishes every Coding action under the coding module with the right event name', async () => {
    const bus = new AIEventBus();
    const emitters = new HorusEventEmitters(bus);
    const received: string[] = [];
    bus.subscribe('coding', (e) => received.push(e.eventName));

    await emitters.coding.codeChanged({ fileName: 'sketch.ino', lineCount: 10 });
    await emitters.coding.fileOpened({ fileName: 'sketch.ino' });
    await emitters.coding.fileSaved({ fileName: 'sketch.ino' });
    await emitters.coding.compileStarted({ fileName: 'sketch.ino', boardType: 'Uno' });
    await emitters.coding.compileFinished({ success: true, errorCount: 0 });

    expect(received).toEqual([
      CodingEventName.CodeChanged,
      CodingEventName.FileOpened,
      CodingEventName.FileSaved,
      CodingEventName.CompileStarted,
      CodingEventName.CompileFinished,
    ]);
  });

  it('publishes every PCB action under the pcb module with the right event name', async () => {
    const bus = new AIEventBus();
    const emitters = new HorusEventEmitters(bus);
    const received: string[] = [];
    bus.subscribe('pcb', (e) => received.push(e.eventName));

    await emitters.pcb.convertToPCB({ sourceComponentCount: 5 });
    await emitters.pcb.componentMoved({ componentId: 'c1', x: 1, y: 2, layer: 'top' });
    await emitters.pcb.traceAdded({ traceId: 't1', netName: 'GND' });
    await emitters.pcb.traceRemoved({ traceId: 't1' });
    await emitters.pcb.autoRoutingFinished({ routedTraceCount: 4, unroutedNetCount: 0 });

    expect(received).toEqual([
      PCBEventName.ConvertToPCB,
      PCBEventName.ComponentMoved,
      PCBEventName.TraceAdded,
      PCBEventName.TraceRemoved,
      PCBEventName.AutoRoutingFinished,
    ]);
  });

  it('publishes every Workspace action under the workspace module with the right event name', async () => {
    const bus = new AIEventBus();
    const emitters = new HorusEventEmitters(bus);
    const received: string[] = [];
    bus.subscribe('workspace', (e) => received.push(e.eventName));

    await emitters.workspace.pageChanged({ fromPage: 'simulator', toPage: 'pcb' });
    await emitters.workspace.projectOpened({ projectName: 'My Robot' });
    await emitters.workspace.projectClosed({ projectName: 'My Robot' });

    expect(received).toEqual([
      WorkspaceEventName.PageChanged,
      WorkspaceEventName.ProjectOpened,
      WorkspaceEventName.ProjectClosed,
    ]);
  });

  it('publishes every Settings action under the settings module without leaking key material', async () => {
    const bus = new AIEventBus();
    const emitters = new HorusEventEmitters(bus);
    const events: Array<{ eventName: string; payload: unknown }> = [];
    bus.subscribe('settings', (e) => events.push({ eventName: e.eventName, payload: e.payload }));

    await emitters.settings.apiKeyUpdated({ provider: 'gemini' });
    await emitters.settings.aiProviderChanged({ fromProvider: 'gemini', toProvider: 'openai' });

    expect(events[0]).toEqual({ eventName: SettingsEventName.ApiKeyUpdated, payload: { provider: 'gemini' } });
    expect(events[1]).toEqual({
      eventName: SettingsEventName.AIProviderChanged,
      payload: { fromProvider: 'gemini', toProvider: 'openai' },
    });
    // Guard against accidental future fields carrying secret material.
    for (const e of events) {
      expect(JSON.stringify(e.payload)).not.toMatch(/key|secret|token/i);
    }
  });

  it('every emitted event still carries a timestamp, module, name and payload', async () => {
    const bus = new AIEventBus();
    const emitters = new HorusEventEmitters(bus);
    const event = await emitters.simulator.componentAdded({ componentId: 9, componentType: 'led' });

    expect(typeof event.timestamp).toBe('number');
    expect(event.module).toBe('simulator');
    expect(event.eventName).toBe(SimulatorEventName.ComponentAdded);
    expect(event.payload).toEqual({ componentId: 9, componentType: 'led' });
  });

  it('a future module can subscribe to everything via the wildcard without any emitter changes', async () => {
    const bus = new AIEventBus();
    const emitters = new HorusEventEmitters(bus);
    const futureModuleHandler = vi.fn();
    bus.subscribe('*', futureModuleHandler);

    await emitters.pcb.traceAdded({ traceId: 't9', netName: 'VCC' });
    await emitters.workspace.pageChanged({ fromPage: 'coding', toPage: 'gallery' });

    expect(futureModuleHandler).toHaveBeenCalledTimes(2);
  });

  it('each emitter only publishes to its own module, never cross-talking', async () => {
    const bus = new AIEventBus();
    const emitters = new HorusEventEmitters(bus);
    const pcbHandler = vi.fn();
    bus.subscribe('pcb', pcbHandler);

    await emitters.simulator.componentAdded({ componentId: 1, componentType: 'resistor' });
    await emitters.coding.fileSaved({ fileName: 'a.ino' });
    await emitters.workspace.projectOpened({ projectName: 'X' });
    await emitters.settings.apiKeyUpdated({ provider: 'gemini' });

    expect(pcbHandler).not.toHaveBeenCalled();
  });
});
