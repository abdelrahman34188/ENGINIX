import { describe, it, expect, vi } from 'vitest';
import { AIEventBus } from '../AIEventBus';
import { HORUS_EVENT_WILDCARD } from '../HorusEvent';
import type { HorusEvent } from '../HorusEvent';

describe('AIEventBus', () => {
  it('delivers a published event only to subscribers of its module', async () => {
    const bus = new AIEventBus();
    const simHandler = vi.fn();
    const pcbHandler = vi.fn();
    bus.subscribe('simulator', simHandler);
    bus.subscribe('pcb', pcbHandler);

    await bus.publish({ module: 'simulator', eventName: 'component.added', payload: { id: 1 } });

    expect(simHandler).toHaveBeenCalledTimes(1);
    expect(pcbHandler).not.toHaveBeenCalled();
  });

  it('stamps every event with a numeric timestamp, module, name and payload', async () => {
    const bus = new AIEventBus();
    let received: HorusEvent | undefined;
    bus.subscribe('coding', (event) => {
      received = event;
    });

    const before = Date.now();
    await bus.publish({ module: 'coding', eventName: 'sketch.changed', payload: { lines: 42 } });
    const after = Date.now();

    expect(received).toBeDefined();
    expect(received!.module).toBe('coding');
    expect(received!.eventName).toBe('sketch.changed');
    expect(received!.payload).toEqual({ lines: 42 });
    expect(received!.timestamp).toBeGreaterThanOrEqual(before);
    expect(received!.timestamp).toBeLessThanOrEqual(after);
  });

  it('delivers events to wildcard subscribers regardless of module', async () => {
    const bus = new AIEventBus();
    const wildcardHandler = vi.fn();
    bus.subscribe(HORUS_EVENT_WILDCARD, wildcardHandler);

    await bus.publish({ module: 'pcb', eventName: 'trace.routed', payload: {} });
    await bus.publish({ module: 'settings', eventName: 'units.changed', payload: {} });

    expect(wildcardHandler).toHaveBeenCalledTimes(2);
  });

  it('supports every event category', async () => {
    const bus = new AIEventBus();
    const seen: string[] = [];
    bus.subscribe(HORUS_EVENT_WILDCARD, (event) => {
      seen.push(event.module);
    });

    const categories = ['simulator', 'pcb', 'coding', 'workspace', 'project', 'settings'] as const;
    for (const module of categories) {
      await bus.publish({ module, eventName: 'test.event', payload: null });
    }

    expect(seen).toEqual(categories);
  });

  it('broadcast notifies every subscriber across every module', async () => {
    const bus = new AIEventBus();
    const simHandler = vi.fn();
    const pcbHandler = vi.fn();
    const wildcardHandler = vi.fn();
    bus.subscribe('simulator', simHandler);
    bus.subscribe('pcb', pcbHandler);
    bus.subscribe(HORUS_EVENT_WILDCARD, wildcardHandler);

    await bus.broadcast({ module: 'workspace', eventName: 'project.reset', payload: {} });

    expect(simHandler).toHaveBeenCalledTimes(1);
    expect(pcbHandler).toHaveBeenCalledTimes(1);
    expect(wildcardHandler).toHaveBeenCalledTimes(1);
  });

  it('stops notifying a handler after unsubscribe (by id and by handle)', async () => {
    const bus = new AIEventBus();
    const handlerA = vi.fn();
    const handlerB = vi.fn();
    const subA = bus.subscribe('project', handlerA);
    const subB = bus.subscribe('project', handlerB);

    bus.unsubscribe(subA.id);
    subB.unsubscribe();

    await bus.publish({ module: 'project', eventName: 'project.saved', payload: {} });

    expect(handlerA).not.toHaveBeenCalled();
    expect(handlerB).not.toHaveBeenCalled();
  });

  it('unsubscribe is a no-op for an unknown id', () => {
    const bus = new AIEventBus();
    expect(() => bus.unsubscribe('does-not-exist')).not.toThrow();
  });

  it('tracks subscriber count as subscriptions are added and removed', () => {
    const bus = new AIEventBus();
    expect(bus.subscriberCount()).toBe(0);
    const sub1 = bus.subscribe('simulator', vi.fn());
    bus.subscribe('pcb', vi.fn());
    expect(bus.subscriberCount()).toBe(2);
    sub1.unsubscribe();
    expect(bus.subscriberCount()).toBe(1);
  });

  it('dispatch is asynchronous: publish resolves after a microtask, not synchronously', () => {
    const bus = new AIEventBus();
    let called = false;
    bus.subscribe('settings', () => {
      called = true;
    });

    const promise = bus.publish({ module: 'settings', eventName: 'theme.changed', payload: {} });
    // The handler must not have run synchronously before the publish call returns control.
    expect(called).toBe(false);
    return promise.then(() => {
      expect(called).toBe(true);
    });
  });

  it('isolates a throwing subscriber so other subscribers still get notified', async () => {
    const bus = new AIEventBus();
    const okHandler = vi.fn();
    bus.subscribe('coding', () => {
      throw new Error('boom');
    });
    bus.subscribe('coding', okHandler);

    await expect(
      bus.publish({ module: 'coding', eventName: 'compile.error', payload: {} })
    ).resolves.toBeDefined();
    expect(okHandler).toHaveBeenCalledTimes(1);
  });

  it('supports an async subscriber handler', async () => {
    const bus = new AIEventBus();
    const seen: number[] = [];
    bus.subscribe('simulator', async (event) => {
      await Promise.resolve();
      seen.push((event.payload as { value: number }).value);
    });

    await bus.publish({ module: 'simulator', eventName: 'value.updated', payload: { value: 7 } });
    expect(seen).toEqual([7]);
  });
});
