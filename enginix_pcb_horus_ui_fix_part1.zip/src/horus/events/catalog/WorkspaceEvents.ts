/**
 * HORUS AI — AI Event Bus — Workspace event catalog.
 *
 * Names and payload shapes for every app-shell action HORUS should be
 * notified about. Pure data contracts — publishing itself happens via
 * `WorkspaceEventEmitter` (see `../emitters/WorkspaceEventEmitter.ts`),
 * which the shell can call once it's wired up. Nothing here imports
 * from or modifies the shell/pages.
 */

import type { WorkspacePage } from '../../context/providers/WorkspaceContextProvider';

export const WorkspaceEventName = {
  PageChanged: 'workspace.page.changed',
  ProjectOpened: 'workspace.project.opened',
  ProjectClosed: 'workspace.project.closed',
} as const;

export type WorkspaceEventName = (typeof WorkspaceEventName)[keyof typeof WorkspaceEventName];

export interface PageChangedPayload {
  fromPage: WorkspacePage;
  toPage: WorkspacePage;
}

export interface ProjectOpenedPayload {
  projectName: string;
}

export interface ProjectClosedPayload {
  projectName: string;
}
