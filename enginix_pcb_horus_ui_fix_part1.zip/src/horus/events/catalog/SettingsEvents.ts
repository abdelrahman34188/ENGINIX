/**
 * HORUS AI — AI Event Bus — Settings event catalog.
 *
 * Names and payload shapes for every Settings action HORUS should be
 * notified about. Pure data contracts — publishing itself happens via
 * `SettingsEventEmitter` (see `../emitters/SettingsEventEmitter.ts`),
 * which Settings can call once it's wired up. Nothing here imports from
 * or modifies the Settings module.
 *
 * Deliberately excludes secret material: `ApiKeyUpdatedPayload` carries
 * only which provider's key changed, never the key value itself — the
 * Event Bus is internal notification infrastructure, not a place to
 * move credentials through.
 */

export const SettingsEventName = {
  ApiKeyUpdated: 'settings.apiKey.updated',
  AIProviderChanged: 'settings.aiProvider.changed',
} as const;

export type SettingsEventName = (typeof SettingsEventName)[keyof typeof SettingsEventName];

export interface ApiKeyUpdatedPayload {
  /** Which provider's key was updated. Never the key value itself. */
  provider: string;
}

export interface AIProviderChangedPayload {
  fromProvider: string | null;
  toProvider: string;
}
