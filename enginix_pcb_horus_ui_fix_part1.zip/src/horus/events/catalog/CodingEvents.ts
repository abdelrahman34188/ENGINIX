/**
 * HORUS AI — AI Event Bus — Coding event catalog.
 *
 * Names and payload shapes for every Coding action HORUS should be
 * notified about. Pure data contracts — publishing itself happens via
 * `CodingEventEmitter` (see `../emitters/CodingEventEmitter.ts`), which
 * the Coding module can call once it's wired up. Nothing here imports
 * from or modifies `src/arduino`.
 */

export const CodingEventName = {
  CodeChanged: 'coding.code.changed',
  FileOpened: 'coding.file.opened',
  FileSaved: 'coding.file.saved',
  CompileStarted: 'coding.compile.started',
  CompileFinished: 'coding.compile.finished',
} as const;

export type CodingEventName = (typeof CodingEventName)[keyof typeof CodingEventName];

export interface CodeChangedPayload {
  fileName: string | null;
  lineCount: number;
}

export interface FileOpenedPayload {
  fileName: string;
}

export interface FileSavedPayload {
  fileName: string;
}

export interface CompileStartedPayload {
  fileName: string | null;
  boardType: string | null;
}

export interface CompileFinishedPayload {
  success: boolean;
  errorCount: number;
}
