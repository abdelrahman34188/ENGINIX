/**
 * HORUS AI — AI Event Bus — PCB event catalog.
 *
 * Names and payload shapes for every PCB action HORUS should be
 * notified about. Pure data contracts — publishing itself happens via
 * `PCBEventEmitter` (see `../emitters/PCBEventEmitter.ts`), which the
 * PCB module can call once it's wired up. Nothing here imports from or
 * modifies `src/pcb`.
 */

export const PCBEventName = {
  ConvertToPCB: 'pcb.convertToPcb',
  ComponentMoved: 'pcb.component.moved',
  TraceAdded: 'pcb.trace.added',
  TraceRemoved: 'pcb.trace.removed',
  AutoRoutingFinished: 'pcb.autoRouting.finished',
} as const;

export type PCBEventName = (typeof PCBEventName)[keyof typeof PCBEventName];

export interface ConvertToPCBPayload {
  sourceComponentCount: number;
}

export interface ComponentMovedPayload {
  componentId: string;
  x: number;
  y: number;
  layer: string;
}

export interface TraceAddedPayload {
  traceId: string;
  netName: string;
}

export interface TraceRemovedPayload {
  traceId: string;
}

export interface AutoRoutingFinishedPayload {
  routedTraceCount: number;
  unroutedNetCount: number;
}
