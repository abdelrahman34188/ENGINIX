/**
 * HORUS AI — AI Event Bus — Simulator event catalog.
 *
 * Names and payload shapes for every Simulator action HORUS should be
 * notified about. Pure data contracts — publishing itself happens via
 * `SimulatorEventEmitter` (see `../emitters/SimulatorEventEmitter.ts`),
 * which the Simulator module can call once it's wired up. Nothing here
 * imports from or modifies `src/circuit`.
 */

export const SimulatorEventName = {
  ComponentAdded: 'simulator.component.added',
  ComponentRemoved: 'simulator.component.removed',
  WireAdded: 'simulator.wire.added',
  WireRemoved: 'simulator.wire.removed',
  ComponentValueChanged: 'simulator.component.valueChanged',
  SimulationStarted: 'simulator.simulation.started',
  SimulationStopped: 'simulator.simulation.stopped',
} as const;

export type SimulatorEventName = (typeof SimulatorEventName)[keyof typeof SimulatorEventName];

export interface ComponentAddedPayload {
  componentId: number;
  componentType: string;
}

export interface ComponentRemovedPayload {
  componentId: number;
}

export interface WireAddedPayload {
  wireId: number;
  fromComponentId: number;
  toComponentId: number;
}

export interface WireRemovedPayload {
  wireId: number;
}

export interface ComponentValueChangedPayload {
  componentId: number;
  propertyKey: string;
  oldValue: number | string | boolean;
  newValue: number | string | boolean;
}

export interface SimulationStartedPayload {
  componentCount: number;
}

export interface SimulationStoppedPayload {
  reason: 'user' | 'error' | 'reset';
}
