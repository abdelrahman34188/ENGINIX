/**
 * HORUS AI — AI Event Bus — emitter registry.
 *
 * Composes one typed emitter per ENGINIX module (Simulator, Coding,
 * PCB, Workspace, Settings) over a single shared `IAIEventBus`, the
 * same "one object to depend on" pattern `ContextManager` uses for its
 * providers. A business-logic module wires up later by importing this
 * registry (or just the one emitter it needs) and calling its typed
 * methods — no changes to `AIEventBus` or to HORUS are required to add
 * that wiring, and no changes here are required to add a new
 * *subscriber*: anything can call `bus.subscribe(...)` independently.
 *
 * This file does not import from or modify any business-logic module.
 */

import type { IAIEventBus } from './AIEventBus';
import { SimulatorEventEmitter } from './emitters/SimulatorEventEmitter';
import type { ISimulatorEventEmitter } from './emitters/SimulatorEventEmitter';
import { CodingEventEmitter } from './emitters/CodingEventEmitter';
import type { ICodingEventEmitter } from './emitters/CodingEventEmitter';
import { PCBEventEmitter } from './emitters/PCBEventEmitter';
import type { IPCBEventEmitter } from './emitters/PCBEventEmitter';
import { WorkspaceEventEmitter } from './emitters/WorkspaceEventEmitter';
import type { IWorkspaceEventEmitter } from './emitters/WorkspaceEventEmitter';
import { SettingsEventEmitter } from './emitters/SettingsEventEmitter';
import type { ISettingsEventEmitter } from './emitters/SettingsEventEmitter';

export interface IHorusEventEmitters {
  readonly simulator: ISimulatorEventEmitter;
  readonly coding: ICodingEventEmitter;
  readonly pcb: IPCBEventEmitter;
  readonly workspace: IWorkspaceEventEmitter;
  readonly settings: ISettingsEventEmitter;
}

export class HorusEventEmitters implements IHorusEventEmitters {
  readonly simulator: ISimulatorEventEmitter;
  readonly coding: ICodingEventEmitter;
  readonly pcb: IPCBEventEmitter;
  readonly workspace: IWorkspaceEventEmitter;
  readonly settings: ISettingsEventEmitter;

  constructor(bus: IAIEventBus) {
    this.simulator = new SimulatorEventEmitter(bus);
    this.coding = new CodingEventEmitter(bus);
    this.pcb = new PCBEventEmitter(bus);
    this.workspace = new WorkspaceEventEmitter(bus);
    this.settings = new SettingsEventEmitter(bus);
  }
}
