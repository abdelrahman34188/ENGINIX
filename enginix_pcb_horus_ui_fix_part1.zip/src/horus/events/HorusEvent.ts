/**
 * HORUS AI — AI Event Bus — event shape definitions.
 *
 * Pure data contracts: what an event looks like and which parts of
 * ENGINIX can raise one. No dispatch logic lives here — see
 * `AIEventBus.ts` for that. Kept separate so any module can depend on
 * "what an event is" without depending on the bus that moves it.
 *
 * Interfaces only — no AI reasoning, no conversation handling.
 */

/**
 * Every ENGINIX area the AI Event Bus knows how to receive notifications
 * from. Mirrors the isolation boundaries used elsewhere in HORUS AI
 * (Simulator / PCB / Coding / Workspace / Project Gallery) plus Settings,
 * since Settings changes (units, theme, board defaults, ...) are also
 * relevant live context for HORUS.
 */
export type HorusEventModule =
  | 'simulator'
  | 'pcb'
  | 'coding'
  | 'workspace'
  | 'project'
  | 'settings';

/**
 * One notification that something changed inside ENGINIX.
 *
 * `payload` is intentionally untyped structured data (`unknown` by
 * default, narrowable via the generic) — the bus does not interpret or
 * validate event contents, it only moves them.
 */
export interface HorusEvent<TPayload = unknown> {
  /** When the event occurred (ms since epoch, `Date.now()`). */
  timestamp: number;
  /** Which ENGINIX area raised the event. */
  module: HorusEventModule;
  /** Name of what happened, e.g. 'component.added', 'trace.routed'. */
  eventName: string;
  /** Structured data describing the change. No free-form AI content. */
  payload: TPayload;
}

/** Fields the caller supplies; `timestamp` is stamped by the bus itself
 *  at publish time so producers never have to agree on a clock. */
export type HorusEventInput<TPayload = unknown> = Omit<HorusEvent<TPayload>, 'timestamp'>;

/** A subscriber's callback. Always awaited — subscribers themselves may
 *  be synchronous or asynchronous; the bus treats every dispatch as
 *  asynchronous regardless. */
export type HorusEventHandler<TPayload = unknown> = (
  event: HorusEvent<TPayload>
) => void | Promise<void>;

/** Special subscription target that receives every event regardless of
 *  module — used for HORUS-wide listeners (e.g. Context Manager keeping
 *  a unified snapshot fresh). */
export const HORUS_EVENT_WILDCARD = '*' as const;

export type HorusEventSubscriptionTarget = HorusEventModule | typeof HORUS_EVENT_WILDCARD;

/** Handle returned from `subscribe()`. Callers can either hold the id and
 *  pass it to `unsubscribe()`, or call `unsubscribe()` on the handle
 *  itself. */
export interface HorusEventSubscription {
  readonly id: string;
  readonly module: HorusEventSubscriptionTarget;
  unsubscribe(): void;
}
