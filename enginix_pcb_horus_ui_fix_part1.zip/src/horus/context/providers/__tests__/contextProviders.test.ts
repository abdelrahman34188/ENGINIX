import { describe, it, expect } from 'vitest';
import { SimulatorContextProvider } from '../SimulatorContextProvider';
import { PCBContextProvider } from '../PCBContextProvider';
import { CodingContextProvider } from '../CodingContextProvider';
import { WorkspaceContextProvider } from '../WorkspaceContextProvider';
import { ProjectContextProvider } from '../ProjectContextProvider';
import { ContextManager } from '../../ContextManager';
import { ProjectGalleryContextProvider } from '../ProjectGalleryContextProvider';
import type { IProjectGalleryContextProvider, ProjectGalleryContextSnapshot } from '../ProjectGalleryContextProvider';

/**
 * The real ProjectGalleryContextProvider is an out-of-scope skeleton (Project
 * Gallery must not be modified for this task) and its `collect()` still
 * throws by design. This stub stands in for it so ContextManager-level
 * merge tests can exercise the five implemented providers without relying
 * on that untouched module.
 */
class StubGalleryProvider implements IProjectGalleryContextProvider {
  async collect(): Promise<ProjectGalleryContextSnapshot> {
    return {
      capturedAt: Date.now(),
      savedProjectCount: 0,
      selectedProjectId: null,
      mostRecentProjectName: null,
    };
  }
  getSourceId(): string {
    return 'gallery';
  }
}

describe('SimulatorContextProvider', () => {
  it('collects an empty snapshot before any update', async () => {
    const provider = new SimulatorContextProvider();
    const snap = await provider.collect();
    expect(snap.componentCount).toBe(0);
    expect(snap.wireCount).toBe(0);
    expect(snap.simulationState).toBe('stopped');
    expect(snap.isSimulationRunning).toBe(false);
    expect(snap.components).toEqual([]);
    expect(snap.wires).toEqual([]);
    expect(snap.values).toEqual({});
    expect(typeof snap.capturedAt).toBe('number');
  });

  it('reflects live updates in the next collected snapshot', async () => {
    const provider = new SimulatorContextProvider();
    provider.update({
      simulationState: 'running',
      selectedComponentId: 1,
      components: [
        { id: 1, type: 'resistor', label: 'R1', x: 0, y: 0, rotation: 0, selected: true },
        { id: 2, type: 'led', label: 'D1', x: 1, y: 1, rotation: 0, selected: false },
      ],
      wires: [{ id: 1, fromComponentId: 1, toComponentId: 2, netLabel: null, selected: false }],
      values: [{ componentId: 1, voltage: 5, current: 0.01, power: 0.05 }],
    });

    const snap = await provider.collect();
    expect(snap.isSimulationRunning).toBe(true);
    expect(snap.componentCount).toBe(2);
    expect(snap.wireCount).toBe(1);
    expect(snap.selectedComponentId).toBe(1);
    expect(snap.componentTypeCounts).toEqual({ resistor: 1, led: 1 });
    expect(snap.values[1]).toEqual({ componentId: 1, voltage: 5, current: 0.01, power: 0.05 });
  });

  it('resets back to empty state', async () => {
    const provider = new SimulatorContextProvider();
    provider.update({ simulationState: 'running', components: [{ id: 1, type: 'resistor', label: 'R1', x: 0, y: 0, rotation: 0, selected: false }] });
    provider.reset();
    const snap = await provider.collect();
    expect(snap.componentCount).toBe(0);
    expect(snap.simulationState).toBe('stopped');
  });

  it('reports its source id', () => {
    expect(new SimulatorContextProvider().getSourceId()).toBe('simulator');
  });
});

describe('PCBContextProvider', () => {
  it('collects an empty snapshot before any update', async () => {
    const provider = new PCBContextProvider();
    const snap = await provider.collect();
    expect(snap.boardComponentCount).toBe(0);
    expect(snap.routedTraceCount).toBe(0);
    expect(snap.layers).toEqual([]);
    expect(snap.boardSize).toBeNull();
  });

  it('reflects live updates, deriving routed trace count', async () => {
    const provider = new PCBContextProvider();
    provider.update({
      components: [{ id: 'c1', refDes: 'R1', footprint: '0805', x: 0, y: 0, layer: 'top', rotation: 0, selected: false }],
      traces: [
        { id: 't1', netName: 'GND', layer: 'top', width: 0.25, routed: true },
        { id: 't2', netName: 'VCC', layer: 'bottom', width: 0.25, routed: false },
      ],
      layers: ['top', 'bottom'],
      boardSize: { width: 50, height: 30, unit: 'mm' },
      unroutedNetCount: 1,
      drcIssueCount: 2,
    });

    const snap = await provider.collect();
    expect(snap.boardComponentCount).toBe(1);
    expect(snap.routedTraceCount).toBe(1);
    expect(snap.unroutedNetCount).toBe(1);
    expect(snap.drcIssueCount).toBe(2);
    expect(snap.layers).toEqual(['top', 'bottom']);
    expect(snap.boardSize).toEqual({ width: 50, height: 30, unit: 'mm' });
  });

  it('reports its source id', () => {
    expect(new PCBContextProvider().getSourceId()).toBe('pcb');
  });
});

describe('CodingContextProvider', () => {
  it('collects an empty snapshot before any update', async () => {
    const provider = new CodingContextProvider();
    const snap = await provider.collect();
    expect(snap.currentSketch).toBeNull();
    expect(snap.compilerStatus).toBe('idle');
    expect(snap.lineCount).toBe(0);
  });

  it('derives line count from the current sketch text', async () => {
    const provider = new CodingContextProvider();
    provider.update({
      currentSketch: 'void setup() {}\nvoid loop() {}\n',
      openFile: 'sketch.ino',
      arduinoBoard: 'Uno',
      compilerStatus: 'success',
      compileErrorCount: 0,
      selectedComponentId: 3,
    });

    const snap = await provider.collect();
    expect(snap.lineCount).toBe(3);
    expect(snap.openFile).toBe('sketch.ino');
    expect(snap.arduinoBoard).toBe('Uno');
    expect(snap.compilerStatus).toBe('success');
    expect(snap.selectedComponentId).toBe(3);
  });

  it('reports its source id', () => {
    expect(new CodingContextProvider().getSourceId()).toBe('coding');
  });
});

describe('WorkspaceContextProvider', () => {
  it('collects an empty snapshot before any update', async () => {
    const provider = new WorkspaceContextProvider();
    const snap = await provider.collect();
    expect(snap.currentPage).toBe('unknown');
    expect(snap.currentProject).toBeNull();
    expect(snap.userSelection).toBeNull();
  });

  it('reflects live updates', async () => {
    const provider = new WorkspaceContextProvider();
    provider.update({
      currentPage: 'pcb',
      currentProject: 'My Robot',
      hasUnsavedChanges: true,
      userSelection: { kind: 'component', id: 42 },
    });

    const snap = await provider.collect();
    expect(snap.currentPage).toBe('pcb');
    expect(snap.activeModule).toBe('pcb');
    expect(snap.currentProject).toBe('My Robot');
    expect(snap.openProjectName).toBe('My Robot');
    expect(snap.hasUnsavedChanges).toBe(true);
    expect(snap.userSelection).toEqual({ kind: 'component', id: 42 });
  });

  it('reports its source id', () => {
    expect(new WorkspaceContextProvider().getSourceId()).toBe('workspace');
  });
});

describe('ProjectContextProvider', () => {
  it('collects an empty snapshot before any update', async () => {
    const provider = new ProjectContextProvider();
    const snap = await provider.collect();
    expect(snap.projectName).toBeNull();
    expect(snap.savedStatus).toBe('never-saved');
    expect(snap.metadata).toEqual({ id: null, description: null, createdAt: null, updatedAt: null, tags: [] });
  });

  it('reflects live updates, merging partial metadata', async () => {
    const provider = new ProjectContextProvider();
    provider.update({ projectName: 'My Robot', savedStatus: 'saved', metadata: { id: 'p1', tags: ['robotics'] } });
    provider.update({ metadata: { description: 'A line-following robot' } });

    const snap = await provider.collect();
    expect(snap.projectName).toBe('My Robot');
    expect(snap.savedStatus).toBe('saved');
    expect(snap.metadata.id).toBe('p1');
    expect(snap.metadata.tags).toEqual(['robotics']);
    expect(snap.metadata.description).toBe('A line-following robot');
  });

  it('reports its source id', () => {
    expect(new ProjectContextProvider().getSourceId()).toBe('project');
  });
});

describe('ContextManager', () => {
  it('merges every provider snapshot, including the new project provider', async () => {
    const manager = new ContextManager({
      simulator: new SimulatorContextProvider(),
      pcb: new PCBContextProvider(),
      coding: new CodingContextProvider(),
      workspace: new WorkspaceContextProvider(),
      gallery: new StubGalleryProvider(),
      project: new ProjectContextProvider(),
    });

    const merged = await manager.collectContext();
    expect(merged.simulator).toBeDefined();
    expect(merged.pcb).toBeDefined();
    expect(merged.coding).toBeDefined();
    expect(merged.workspace).toBeDefined();
    expect(merged.project).toBeDefined();
    expect(merged.project.savedStatus).toBe('never-saved');
    expect(typeof merged.mergedAt).toBe('number');
    expect(manager.getCurrentContext()).toEqual(merged);

    manager.clearContext();
    expect(manager.getCurrentContext()).toBeUndefined();
  });

  it('still throws for the untouched Project Gallery provider (skeleton only)', () => {
    expect(() => new ProjectGalleryContextProvider().collect()).toThrow(
      'Not implemented — HORUS AI architecture stage only.'
    );
  });
});
