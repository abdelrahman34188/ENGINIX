/**
 * HORUS AI — Context Manager — Simulator context provider.
 *
 * Exposes structured context about the currently open circuit simulator
 * state (what's on the canvas, whether it's running, what's selected).
 * Isolated from the Simulator module itself — this file does not import
 * from `src/circuit`; live state is pushed in through `update()` by
 * whatever integration wires HORUS to the Simulator page later, so
 * `src/circuit` stays untouched.
 *
 * Live collection is implemented: `update()` stores the latest snapshot
 * pieces it is given, and `collect()` returns the most recently known
 * state. No AI logic, no reasoning — structured data only.
 */

import type { ContextSnapshot, IContextProvider } from '../ContextProvider';

/** A single component as it currently exists on the simulator canvas. */
export interface SimulatorComponentInfo {
  id: number;
  type: string;
  label: string;
  x: number;
  y: number;
  rotation: number;
  selected: boolean;
}

/** A single wire as it currently exists on the simulator canvas. */
export interface SimulatorWireInfo {
  id: number;
  fromComponentId: number;
  toComponentId: number;
  netLabel: string | null;
  selected: boolean;
}

/** Live measured values for one component (updated each simulation frame). */
export interface SimulatorComponentValues {
  componentId: number;
  voltage: number;
  current: number;
  power: number;
}

export type SimulatorRunState = 'stopped' | 'running' | 'paused' | 'error';

export interface SimulatorContextSnapshot extends ContextSnapshot {
  isSimulationRunning: boolean;
  simulationState: SimulatorRunState;
  componentCount: number;
  wireCount: number;
  selectedComponentId: number | null;
  /** Component type counts, e.g. { resistor: 3, led: 2 }. */
  componentTypeCounts: Record<string, number>;
  /** Current components on the canvas. */
  components: SimulatorComponentInfo[];
  /** Current wires on the canvas. */
  wires: SimulatorWireInfo[];
  /** Current live-measured values, keyed by component id. */
  values: Record<number, SimulatorComponentValues>;
}

/** Live input the integration layer pushes into this provider. Every field optional so partial updates are cheap. */
export interface SimulatorLiveInput {
  simulationState?: SimulatorRunState;
  selectedComponentId?: number | null;
  components?: SimulatorComponentInfo[];
  wires?: SimulatorWireInfo[];
  values?: SimulatorComponentValues[];
}

export type ISimulatorContextProvider = IContextProvider<SimulatorContextSnapshot>;

const EMPTY_SNAPSHOT_STATE = {
  simulationState: 'stopped' as SimulatorRunState,
  selectedComponentId: null as number | null,
  components: [] as SimulatorComponentInfo[],
  wires: [] as SimulatorWireInfo[],
  values: {} as Record<number, SimulatorComponentValues>,
};

export class SimulatorContextProvider implements ISimulatorContextProvider {
  private readonly sourceId = 'simulator';
  private state = { ...EMPTY_SNAPSHOT_STATE };

  /** Merge in newly observed live state from the Simulator page/hook. */
  update(input: SimulatorLiveInput): void {
    if (input.simulationState !== undefined) this.state.simulationState = input.simulationState;
    if (input.selectedComponentId !== undefined) this.state.selectedComponentId = input.selectedComponentId;
    if (input.components !== undefined) this.state.components = input.components;
    if (input.wires !== undefined) this.state.wires = input.wires;
    if (input.values !== undefined) {
      const values: Record<number, SimulatorComponentValues> = {};
      for (const v of input.values) values[v.componentId] = v;
      this.state.values = values;
    }
  }

  /** Discard all known live state, reverting to an empty snapshot. */
  reset(): void {
    this.state = { ...EMPTY_SNAPSHOT_STATE };
  }

  async collect(): Promise<SimulatorContextSnapshot> {
    const componentTypeCounts: Record<string, number> = {};
    for (const c of this.state.components) {
      componentTypeCounts[c.type] = (componentTypeCounts[c.type] ?? 0) + 1;
    }

    return {
      capturedAt: Date.now(),
      isSimulationRunning: this.state.simulationState === 'running',
      simulationState: this.state.simulationState,
      componentCount: this.state.components.length,
      wireCount: this.state.wires.length,
      selectedComponentId: this.state.selectedComponentId,
      componentTypeCounts,
      components: this.state.components,
      wires: this.state.wires,
      values: this.state.values,
    };
  }

  getSourceId(): string {
    return this.sourceId;
  }
}
