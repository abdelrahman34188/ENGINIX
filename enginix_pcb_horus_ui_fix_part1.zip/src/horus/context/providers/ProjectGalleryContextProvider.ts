/**
 * HORUS AI — Context Manager — Project Gallery context provider.
 *
 * Exposes structured context about src/lib/projectStorage. Isolated from that
 * module itself — this file does not import from it; it is designed to
 * be fed its state through its own inputs once implemented, so it stays
 * untouched.
 *
 * Interface + skeleton only — no logic implemented yet.
 */

import type { ContextSnapshot, IContextProvider } from '../ContextProvider';
import { BaseContextProvider } from '../ContextProvider';

export interface ProjectGalleryContextSnapshot extends ContextSnapshot {
  savedProjectCount: number;
  selectedProjectId: string | null;
  mostRecentProjectName: string | null;
}

export type IProjectGalleryContextProvider = IContextProvider<ProjectGalleryContextSnapshot>;

export class ProjectGalleryContextProvider
  extends BaseContextProvider<ProjectGalleryContextSnapshot>
  implements IProjectGalleryContextProvider
{
  constructor() {
    super('gallery');
  }
}
