/**
 * HORUS AI — Context Manager — Coding context provider.
 *
 * Exposes structured context about src/arduino. Isolated from that
 * module itself — this file does not import from it; live state is
 * pushed in through `update()` by whatever integration wires HORUS to
 * the Coding page later, so `src/arduino` stays untouched.
 *
 * Live collection is implemented: `update()` stores the latest snapshot
 * pieces it is given, and `collect()` returns the most recently known
 * state. No AI logic, no reasoning — structured data only.
 */

import type { ContextSnapshot, IContextProvider } from '../ContextProvider';

export type CompilerStatus = 'idle' | 'compiling' | 'success' | 'error';

export interface CodingContextSnapshot extends ContextSnapshot {
  activeFileName: string | null;
  boardType: string | null;
  isRunning: boolean;
  compileErrorCount: number;
  lineCount: number;
  /** Full text of the currently open sketch. */
  currentSketch: string | null;
  /** File currently open in the editor (name/path as known by Coding). */
  openFile: string | null;
  /** Arduino board target selected for this sketch. */
  arduinoBoard: string | null;
  /** Current compiler/build status. */
  compilerStatus: CompilerStatus;
  /** Component (in the circuit) currently selected/associated with the sketch, if any. */
  selectedComponentId: number | null;
}

/** Live input the integration layer pushes into this provider. Every field optional so partial updates are cheap. */
export interface CodingLiveInput {
  activeFileName?: string | null;
  boardType?: string | null;
  isRunning?: boolean;
  compileErrorCount?: number;
  currentSketch?: string | null;
  openFile?: string | null;
  arduinoBoard?: string | null;
  compilerStatus?: CompilerStatus;
  selectedComponentId?: number | null;
}

export type ICodingContextProvider = IContextProvider<CodingContextSnapshot>;

const EMPTY_SNAPSHOT_STATE = {
  activeFileName: null as string | null,
  boardType: null as string | null,
  isRunning: false,
  compileErrorCount: 0,
  currentSketch: null as string | null,
  openFile: null as string | null,
  arduinoBoard: null as string | null,
  compilerStatus: 'idle' as CompilerStatus,
  selectedComponentId: null as number | null,
};

export class CodingContextProvider implements ICodingContextProvider {
  private readonly sourceId = 'coding';
  private state = { ...EMPTY_SNAPSHOT_STATE };

  /** Merge in newly observed live state from the Coding page/hook. */
  update(input: CodingLiveInput): void {
    if (input.activeFileName !== undefined) this.state.activeFileName = input.activeFileName;
    if (input.boardType !== undefined) this.state.boardType = input.boardType;
    if (input.isRunning !== undefined) this.state.isRunning = input.isRunning;
    if (input.compileErrorCount !== undefined) this.state.compileErrorCount = input.compileErrorCount;
    if (input.currentSketch !== undefined) this.state.currentSketch = input.currentSketch;
    if (input.openFile !== undefined) this.state.openFile = input.openFile;
    if (input.arduinoBoard !== undefined) this.state.arduinoBoard = input.arduinoBoard;
    if (input.compilerStatus !== undefined) this.state.compilerStatus = input.compilerStatus;
    if (input.selectedComponentId !== undefined) this.state.selectedComponentId = input.selectedComponentId;
  }

  /** Discard all known live state, reverting to an empty snapshot. */
  reset(): void {
    this.state = { ...EMPTY_SNAPSHOT_STATE };
  }

  async collect(): Promise<CodingContextSnapshot> {
    const lineCount = this.state.currentSketch ? this.state.currentSketch.split('\n').length : 0;

    return {
      capturedAt: Date.now(),
      activeFileName: this.state.activeFileName,
      boardType: this.state.boardType,
      isRunning: this.state.isRunning,
      compileErrorCount: this.state.compileErrorCount,
      lineCount,
      currentSketch: this.state.currentSketch,
      openFile: this.state.openFile,
      arduinoBoard: this.state.arduinoBoard,
      compilerStatus: this.state.compilerStatus,
      selectedComponentId: this.state.selectedComponentId,
    };
  }

  getSourceId(): string {
    return this.sourceId;
  }
}
