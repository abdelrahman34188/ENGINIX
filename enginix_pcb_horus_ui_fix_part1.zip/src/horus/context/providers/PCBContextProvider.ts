/**
 * HORUS AI — Context Manager — PCB context provider.
 *
 * Exposes structured context about src/pcb. Isolated from that module
 * itself — this file does not import from it; live state is pushed in
 * through `update()` by whatever integration wires HORUS to the PCB
 * page later, so `src/pcb` stays untouched.
 *
 * Live collection is implemented: `update()` stores the latest snapshot
 * pieces it is given, and `collect()` returns the most recently known
 * state. No AI logic, no reasoning — structured data only.
 */

import type { ContextSnapshot, IContextProvider } from '../ContextProvider';

/** A single placed component/footprint on the board. */
export interface PCBComponentInfo {
  id: string;
  refDes: string;
  footprint: string;
  x: number;
  y: number;
  layer: string;
  rotation: number;
  selected: boolean;
}

/** A single routed (or partially routed) trace. */
export interface PCBTraceInfo {
  id: string;
  netName: string;
  layer: string;
  width: number;
  routed: boolean;
}

export interface PCBBoardSize {
  width: number;
  height: number;
  unit: 'mm' | 'in';
}

export interface PCBContextSnapshot extends ContextSnapshot {
  boardComponentCount: number;
  unroutedNetCount: number;
  routedTraceCount: number;
  drcIssueCount: number;
  selectedFootprintId: string | null;
  /** Components currently placed on the board. */
  components: PCBComponentInfo[];
  /** Traces currently on the board. */
  traces: PCBTraceInfo[];
  /** Layer names currently available/in use on the board. */
  layers: string[];
  /** Current board outline size, if known. */
  boardSize: PCBBoardSize | null;
}

/** Live input the integration layer pushes into this provider. Every field optional so partial updates are cheap. */
export interface PCBLiveInput {
  selectedFootprintId?: string | null;
  components?: PCBComponentInfo[];
  traces?: PCBTraceInfo[];
  layers?: string[];
  boardSize?: PCBBoardSize | null;
  unroutedNetCount?: number;
  drcIssueCount?: number;
}

export type IPCBContextProvider = IContextProvider<PCBContextSnapshot>;

const EMPTY_SNAPSHOT_STATE = {
  selectedFootprintId: null as string | null,
  components: [] as PCBComponentInfo[],
  traces: [] as PCBTraceInfo[],
  layers: [] as string[],
  boardSize: null as PCBBoardSize | null,
  unroutedNetCount: 0,
  drcIssueCount: 0,
};

export class PCBContextProvider implements IPCBContextProvider {
  private readonly sourceId = 'pcb';
  private state = { ...EMPTY_SNAPSHOT_STATE };

  /** Merge in newly observed live state from the PCB page/hook. */
  update(input: PCBLiveInput): void {
    if (input.selectedFootprintId !== undefined) this.state.selectedFootprintId = input.selectedFootprintId;
    if (input.components !== undefined) this.state.components = input.components;
    if (input.traces !== undefined) this.state.traces = input.traces;
    if (input.layers !== undefined) this.state.layers = input.layers;
    if (input.boardSize !== undefined) this.state.boardSize = input.boardSize;
    if (input.unroutedNetCount !== undefined) this.state.unroutedNetCount = input.unroutedNetCount;
    if (input.drcIssueCount !== undefined) this.state.drcIssueCount = input.drcIssueCount;
  }

  /** Discard all known live state, reverting to an empty snapshot. */
  reset(): void {
    this.state = { ...EMPTY_SNAPSHOT_STATE };
  }

  async collect(): Promise<PCBContextSnapshot> {
    return {
      capturedAt: Date.now(),
      boardComponentCount: this.state.components.length,
      unroutedNetCount: this.state.unroutedNetCount,
      routedTraceCount: this.state.traces.filter((t) => t.routed).length,
      drcIssueCount: this.state.drcIssueCount,
      selectedFootprintId: this.state.selectedFootprintId,
      components: this.state.components,
      traces: this.state.traces,
      layers: this.state.layers,
      boardSize: this.state.boardSize,
    };
  }

  getSourceId(): string {
    return this.sourceId;
  }
}
