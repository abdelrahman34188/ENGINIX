/**
 * HORUS AI — Context Manager — Workspace context provider.
 *
 * Exposes structured context about the app shell (active page/panel
 * state, current project, current selection). Isolated from that module
 * itself — this file does not import from it; live state is pushed in
 * through `update()` by whatever integration wires HORUS to the app
 * shell later, so the shell stays untouched.
 *
 * Live collection is implemented: `update()` stores the latest snapshot
 * pieces it is given, and `collect()` returns the most recently known
 * state. No AI logic, no reasoning — structured data only.
 */

import type { ContextSnapshot, IContextProvider } from '../ContextProvider';

export type WorkspacePage = 'simulator' | 'pcb' | 'coding' | 'gallery' | 'settings' | 'unknown';

/** Generic description of whatever the user currently has selected in the shell. */
export interface WorkspaceSelection {
  kind: string;
  id: string | number;
}

export interface WorkspaceContextSnapshot extends ContextSnapshot {
  activeModule: WorkspacePage;
  openProjectName: string | null;
  hasUnsavedChanges: boolean;
  /** Page currently displayed in the app shell. */
  currentPage: WorkspacePage;
  /** Project currently open, if any. */
  currentProject: string | null;
  /** Whatever the user currently has selected in the shell, if anything. */
  userSelection: WorkspaceSelection | null;
}

/** Live input the integration layer pushes into this provider. Every field optional so partial updates are cheap. */
export interface WorkspaceLiveInput {
  currentPage?: WorkspacePage;
  currentProject?: string | null;
  hasUnsavedChanges?: boolean;
  userSelection?: WorkspaceSelection | null;
}

export type IWorkspaceContextProvider = IContextProvider<WorkspaceContextSnapshot>;

const EMPTY_SNAPSHOT_STATE = {
  currentPage: 'unknown' as WorkspacePage,
  currentProject: null as string | null,
  hasUnsavedChanges: false,
  userSelection: null as WorkspaceSelection | null,
};

export class WorkspaceContextProvider implements IWorkspaceContextProvider {
  private readonly sourceId = 'workspace';
  private state = { ...EMPTY_SNAPSHOT_STATE };

  /** Merge in newly observed live state from the app shell. */
  update(input: WorkspaceLiveInput): void {
    if (input.currentPage !== undefined) this.state.currentPage = input.currentPage;
    if (input.currentProject !== undefined) this.state.currentProject = input.currentProject;
    if (input.hasUnsavedChanges !== undefined) this.state.hasUnsavedChanges = input.hasUnsavedChanges;
    if (input.userSelection !== undefined) this.state.userSelection = input.userSelection;
  }

  /** Discard all known live state, reverting to an empty snapshot. */
  reset(): void {
    this.state = { ...EMPTY_SNAPSHOT_STATE };
  }

  async collect(): Promise<WorkspaceContextSnapshot> {
    return {
      capturedAt: Date.now(),
      activeModule: this.state.currentPage,
      openProjectName: this.state.currentProject,
      hasUnsavedChanges: this.state.hasUnsavedChanges,
      currentPage: this.state.currentPage,
      currentProject: this.state.currentProject,
      userSelection: this.state.userSelection,
    };
  }

  getSourceId(): string {
    return this.sourceId;
  }
}
