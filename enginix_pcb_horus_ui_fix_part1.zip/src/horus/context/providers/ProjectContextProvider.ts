/**
 * HORUS AI — Context Manager — Project context provider.
 *
 * Exposes structured context about the currently open project itself
 * (name, saved status, metadata) — distinct from the Workspace provider,
 * which tracks *shell/page* state, and from the Project Gallery
 * provider, which tracks the list of saved projects. Isolated from
 * `src/lib/projectStorage` — this file does not import from it; live
 * state is pushed in through `update()` by whatever integration wires
 * HORUS to project save/load later, so that module stays untouched.
 *
 * Live collection is implemented: `update()` stores the latest snapshot
 * pieces it is given, and `collect()` returns the most recently known
 * state. No AI logic, no reasoning — structured data only.
 */

import type { ContextSnapshot, IContextProvider } from '../ContextProvider';

export type ProjectSavedStatus = 'saved' | 'unsaved' | 'saving' | 'never-saved';

/** Descriptive metadata about the current project. */
export interface ProjectMetadata {
  id: string | null;
  description: string | null;
  createdAt: number | null;
  updatedAt: number | null;
  tags: string[];
}

export interface ProjectContextSnapshot extends ContextSnapshot {
  /** Name of the currently open project. */
  projectName: string | null;
  /** Whether the current project has unsaved changes. */
  savedStatus: ProjectSavedStatus;
  /** Descriptive metadata about the current project. */
  metadata: ProjectMetadata;
}

/** Live input the integration layer pushes into this provider. Every field optional so partial updates are cheap. */
export interface ProjectLiveInput {
  projectName?: string | null;
  savedStatus?: ProjectSavedStatus;
  metadata?: Partial<ProjectMetadata>;
}

export type IProjectContextProvider = IContextProvider<ProjectContextSnapshot>;

const EMPTY_METADATA: ProjectMetadata = {
  id: null,
  description: null,
  createdAt: null,
  updatedAt: null,
  tags: [],
};

const EMPTY_SNAPSHOT_STATE = {
  projectName: null as string | null,
  savedStatus: 'never-saved' as ProjectSavedStatus,
  metadata: { ...EMPTY_METADATA },
};

export class ProjectContextProvider implements IProjectContextProvider {
  private readonly sourceId = 'project';
  private state = { ...EMPTY_SNAPSHOT_STATE, metadata: { ...EMPTY_METADATA } };

  /** Merge in newly observed live state from project save/load logic. */
  update(input: ProjectLiveInput): void {
    if (input.projectName !== undefined) this.state.projectName = input.projectName;
    if (input.savedStatus !== undefined) this.state.savedStatus = input.savedStatus;
    if (input.metadata !== undefined) {
      this.state.metadata = { ...this.state.metadata, ...input.metadata };
    }
  }

  /** Discard all known live state, reverting to an empty snapshot. */
  reset(): void {
    this.state = { ...EMPTY_SNAPSHOT_STATE, metadata: { ...EMPTY_METADATA } };
  }

  async collect(): Promise<ProjectContextSnapshot> {
    return {
      capturedAt: Date.now(),
      projectName: this.state.projectName,
      savedStatus: this.state.savedStatus,
      metadata: this.state.metadata,
    };
  }

  getSourceId(): string {
    return this.sourceId;
  }
}
