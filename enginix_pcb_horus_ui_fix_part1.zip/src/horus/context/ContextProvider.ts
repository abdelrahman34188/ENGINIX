/**
 * HORUS AI — Context Manager — generic context provider contract.
 *
 * Every source-specific provider (Simulator, PCB, Coding, Workspace,
 * Project Gallery) implements this same shape, isolated from the others,
 * so `ContextManager` can collect and merge them uniformly without
 * knowing anything about a particular source. A provider exposes
 * *structured data only* — no free-form strings, no AI reasoning — and
 * never reaches into Simulator/PCB/Coding internals directly; each
 * concrete provider is designed to receive its source data through its
 * own inputs later, so those modules stay untouched.
 *
 * Interface + skeleton only — no logic implemented yet.
 */

/** Every context snapshot carries when it was captured. */
export interface ContextSnapshot {
  capturedAt: number;
}

/**
 * Uniform contract for a single source's context provider.
 *
 * - `collect`     — produce a fresh structured snapshot from this source.
 * - `getSourceId` — stable identifier used as this provider's key in the
 *                   unified context object `ContextManager` builds.
 */
export interface IContextProvider<T extends ContextSnapshot> {
  /** Produce a fresh structured snapshot of this source's current state. */
  collect(): Promise<T>;

  /** Stable identifier for this provider (e.g. 'simulator', 'pcb'). */
  getSourceId(): string;
}

/**
 * Shared skeleton so each concrete provider doesn't repeat the same
 * "not implemented yet" wiring. Concrete providers extend this and only
 * add their own snapshot type + source id — no provider contains real
 * source data itself at this stage.
 */
export abstract class BaseContextProvider<T extends ContextSnapshot>
  implements IContextProvider<T>
{
  protected readonly sourceId: string;

  constructor(sourceId: string) {
    this.sourceId = sourceId;
  }

  collect(): Promise<T> {
    throw new Error('Not implemented — HORUS AI architecture stage only.');
  }

  getSourceId(): string {
    return this.sourceId;
  }
}
