/**
 * HORUS AI — Context Manager.
 *
 * Allows HORUS to understand the user's current working context.
 * Deliberately separate from Knowledge Base Manager (reference/domain
 * knowledge) and Conversation Manager (chat turn history): this owns
 * *live state of the workspace* — what the user is looking at right now
 * across Simulator, PCB, Coding, Workspace shell, and Project Gallery.
 *
 * Each source has its own isolated `IContextProvider` (see
 * `providers/*.ts`) that exposes structured data only. `ContextManager`
 * never reaches into Simulator/PCB/Coding internals directly — it is
 * composed with providers via constructor injection, exactly the way
 * `AICore` is composed with its own collaborators, so those modules stay
 * untouched. `collectContext()` gathers every provider's snapshot and
 * merges them into one unified object; a provider that isn't implemented
 * yet simply means that slice of the merge isn't available yet.
 *
 * Interface + skeleton only — no AI logic implemented yet.
 */

import type { ISimulatorContextProvider, SimulatorContextSnapshot } from './providers/SimulatorContextProvider';
import type { IPCBContextProvider, PCBContextSnapshot } from './providers/PCBContextProvider';
import type { ICodingContextProvider, CodingContextSnapshot } from './providers/CodingContextProvider';
import type { IWorkspaceContextProvider, WorkspaceContextSnapshot } from './providers/WorkspaceContextProvider';
import type { IProjectGalleryContextProvider, ProjectGalleryContextSnapshot } from './providers/ProjectGalleryContextProvider';
import type { IProjectContextProvider, ProjectContextSnapshot } from './providers/ProjectContextProvider';

/** The set of source providers Context Manager composes. */
export interface ContextManagerDependencies {
  simulator: ISimulatorContextProvider;
  pcb: IPCBContextProvider;
  coding: ICodingContextProvider;
  workspace: IWorkspaceContextProvider;
  gallery: IProjectGalleryContextProvider;
  project: IProjectContextProvider;
}

/** One merged snapshot combining every source's structured context. */
export interface UnifiedHorusContext {
  simulator: SimulatorContextSnapshot;
  pcb: PCBContextSnapshot;
  coding: CodingContextSnapshot;
  workspace: WorkspaceContextSnapshot;
  gallery: ProjectGalleryContextSnapshot;
  project: ProjectContextSnapshot;
  mergedAt: number;
}

export interface IContextManager {
  /** Collect every provider's current snapshot and merge them into one object. */
  collectContext(): Promise<UnifiedHorusContext>;

  /** The most recently merged context, if `collectContext` has been called. */
  getCurrentContext(): UnifiedHorusContext | undefined;

  /** Discard the stored merged context. */
  clearContext(): void;

  readonly simulator: ISimulatorContextProvider;
  readonly pcb: IPCBContextProvider;
  readonly coding: ICodingContextProvider;
  readonly workspace: IWorkspaceContextProvider;
  readonly gallery: IProjectGalleryContextProvider;
  readonly project: IProjectContextProvider;
}

export class ContextManager implements IContextManager {
  readonly simulator: ISimulatorContextProvider;
  readonly pcb: IPCBContextProvider;
  readonly coding: ICodingContextProvider;
  readonly workspace: IWorkspaceContextProvider;
  readonly gallery: IProjectGalleryContextProvider;
  readonly project: IProjectContextProvider;

  private current: UnifiedHorusContext | undefined;

  constructor(deps: ContextManagerDependencies) {
    this.simulator = deps.simulator;
    this.pcb = deps.pcb;
    this.coding = deps.coding;
    this.workspace = deps.workspace;
    this.gallery = deps.gallery;
    this.project = deps.project;
  }

  async collectContext(): Promise<UnifiedHorusContext> {
    const [simulator, pcb, coding, workspace, gallery, project] = await Promise.all([
      this.simulator.collect(),
      this.pcb.collect(),
      this.coding.collect(),
      this.workspace.collect(),
      this.gallery.collect(),
      this.project.collect(),
    ]);

    const merged: UnifiedHorusContext = {
      simulator,
      pcb,
      coding,
      workspace,
      gallery,
      project,
      mergedAt: Date.now(),
    };

    this.current = merged;
    return merged;
  }

  getCurrentContext(): UnifiedHorusContext | undefined {
    return this.current;
  }

  clearContext(): void {
    this.current = undefined;
  }
}
