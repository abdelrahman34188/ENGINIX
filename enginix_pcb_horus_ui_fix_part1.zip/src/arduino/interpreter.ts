// Arduino Coding Core — Interpreter
//
// Tree-walking evaluator over the AST produced by parser.ts. Every exec/eval
// function is a generator, and delegation uses `yield*`, so a `delay()` deep
// inside nested calls/loops can pause the *entire* call stack without
// blocking the JS thread — the driver (ArduinoRuntime) just stops calling
// `.next()` until virtual time catches up, then resumes exactly where it
// left off. A per-tick step budget guards against sketches with tight loops
// and no delay() (e.g. `while(true){}`), so the engine always yields back to
// the host instead of hanging it.

import type { Node, FunctionDecl, VarDecl, Block, Expr, Stmt } from './parser';
import type { ArduinoValue, Diagnostic, PinIO, SerialEntry } from './types';

class ReturnSignal { value: ArduinoValue; constructor(value: ArduinoValue) { this.value = value; } }
class BreakSignal {}
class ContinueSignal {}

class Scope {
  private vars = new Map<string, ArduinoValue>();
  private parent: Scope | null;
  constructor(parent: Scope | null) { this.parent = parent; }
  declare(name: string, value: ArduinoValue) { this.vars.set(name, value); }
  has(name: string): boolean { return this.vars.has(name) || (this.parent?.has(name) ?? false); }
  get(name: string): ArduinoValue {
    if (this.vars.has(name)) return this.vars.get(name);
    if (this.parent) return this.parent.get(name);
    throw new Error(`'${name}' was not declared in this scope`);
  }
  /** Returns true if the assignment found somewhere to land. */
  set(name: string, value: ArduinoValue): boolean {
    if (this.vars.has(name)) { this.vars.set(name, value); return true; }
    if (this.parent) return this.parent.set(name, value);
    return false;
  }
}

export interface InterpreterOptions {
  pinIO: PinIO;
  stepBudget?: number; // max AST steps executed per resume before yielding
  serialBufferLimit?: number;
  onDiagnostic?: (d: Diagnostic) => void;
}

const CONSTANTS: Record<string, ArduinoValue> = {
  HIGH: 1, LOW: 0,
  INPUT: 0, OUTPUT: 1, INPUT_PULLUP: 2,
  LED_BUILTIN: 13,
  PI: Math.PI, HALF_PI: Math.PI / 2, TWO_PI: Math.PI * 2,
  DEG_TO_RAD: Math.PI / 180, RAD_TO_DEG: 180 / Math.PI,
  true: true, false: false,
  // SPI
  MSBFIRST: 1, LSBFIRST: 0,
  SPI_MODE0: 0, SPI_MODE1: 1, SPI_MODE2: 2, SPI_MODE3: 3,
  // Analog pins. Real boards number these differently per chip (Uno's A0 is
  // 14, Mega's A0 is 54), but this engine has no per-board pin map - it just
  // needs *a* value each analog-pin constant can carry through pinMode()/
  // digitalRead()/analogRead() unambiguously as "analog pin N", so A0-A15
  // are given one consistent numbering (14 + N) regardless of which board
  // the sketch targets. A board-facing PinIO implementation (e.g.
  // CircuitPinIO) is expected to decode pin >= 14 back to analog index
  // (pin - 14) using this same offset.
  A0: 14, A1: 15, A2: 16, A3: 17, A4: 18, A5: 19,
  A6: 20, A7: 21, A8: 22, A9: 23, A10: 24, A11: 25,
  A12: 26, A13: 27, A14: 28, A15: 29,
  // DHT.h sensor-type selectors, e.g. `DHT dht(2, DHT11);`
  DHT11: 11, DHT22: 22,
};

const SERVO_MIN_PULSE = 544;
const SERVO_MAX_PULSE = 2400;

interface ServoState { pin: number | null; angleDeg: number; minPulse: number; maxPulse: number; }
interface StepperState { stepsPerRev: number; pins: number[]; rpm: number; position: number; phase: number; }
interface WireState { txAddress: number | null; txBuffer: number[]; rxBuffer: number[]; rxIndex: number; }

function toNumber(v: ArduinoValue): number {
  if (typeof v === 'number') return v;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (typeof v === 'string') return v.length; // Arduino String has no implicit numeric cast; length is the closest useful fallback
  return 0;
}
function clamp(v: number, lo: number, hi: number): number { return Math.min(Math.max(v, lo), hi); }
function isTruthy(v: ArduinoValue): boolean {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'number') return v !== 0;
  if (typeof v === 'string') return v.length > 0;
  if (Array.isArray(v)) return v.length > 0;
  return false;
}
function defaultForType(varType: string): ArduinoValue {
  const t = varType.replace('*', '').trim();
  if (t === 'bool' || t === 'boolean') return false;
  if (t === 'String') return '';
  return 0;
}
function coerceForType(varType: string, v: ArduinoValue): ArduinoValue {
  const t = varType.replace('*', '').trim();
  if (t === 'bool' || t === 'boolean') return isTruthy(v);
  if (t === 'String') return typeof v === 'string' ? v : String(v);
  if (Array.isArray(v)) return v;
  return toNumber(v);
}

export class Interpreter {
  readonly global = new Scope(null);
  readonly functions = new Map<string, FunctionDecl>();
  readonly diagnostics: Diagnostic[] = [];
  readonly serialLog: SerialEntry[] = [];
  clockMillis = 0;
  private steps = 0;
  private stepBudget: number;
  private serialBufferLimit: number;
  private serialSeqCounter = 0;
  private pinIO: PinIO;
  private onDiagnostic?: (d: Diagnostic) => void;

  // Library object state, keyed by the sketch's variable name — same
  // convention this file already uses for `Serial` (matched by identifier
  // text rather than a resolved object value). See evalMemberCall.
  private servos = new Map<string, ServoState>();
  private steppers = new Map<string, StepperState>();
  private wire: WireState = { txAddress: null, txBuffer: [], rxBuffer: [], rxIndex: 0 };
  // `DHT dht(pin, DHT11);` — each instance just remembers which pin it was
  // attached to; readTemperature()/readHumidity() resolve the live value
  // through PinIO.readDht() every call, so multiple DHT variables (even on
  // different pins) work independently and always see current values.
  private dhts = new Map<string, { pin: number }>();

  constructor(program: Extract<Node, { kind: 'Program' }>, opts: InterpreterOptions) {
    this.pinIO = opts.pinIO;
    this.stepBudget = opts.stepBudget ?? 20000;
    this.serialBufferLimit = opts.serialBufferLimit ?? 500;
    this.onDiagnostic = opts.onDiagnostic;
    for (const [k, v] of Object.entries(CONSTANTS)) this.global.declare(k, v);
    for (const fn of program.functions) this.functions.set(fn.name, fn);
  }

  private reportRuntimeError(line: number, message: string) {
    const d: Diagnostic = { line, column: 1, message, severity: 'error' };
    this.diagnostics.push(d);
    this.onDiagnostic?.(d);
  }

  /** Runs all global variable initializers into the global scope. Globals may not call delay(). */
  initGlobals(globals: VarDecl[]) {
    for (const decl of globals) {
      const gen = this.evalVarDecl(decl, this.global);
      let r = gen.next();
      // Globals must not yield (no delay() at global scope); drain defensively.
      while (!r.done) r = gen.next();
    }
  }

  hasFunction(name: string): boolean { return this.functions.has(name); }

  /** Generator that runs one call to a named function (e.g. "setup" or "loop") to completion, yielding on delay()/step-budget. */
  *callNamed(name: string): Generator<void, ArduinoValue, void> {
    const fn = this.functions.get(name);
    if (!fn) return undefined;
    return yield* this.callFunction(fn, []);
  }

  private *checkBudget(): Generator<void, void, void> {
    this.steps++;
    if (this.steps >= this.stepBudget) {
      this.steps = 0;
      yield;
    }
  }

  private *callFunction(fn: FunctionDecl, args: ArduinoValue[]): Generator<void, ArduinoValue, void> {
    const scope = new Scope(this.global);
    fn.params.forEach((p, idx) => scope.declare(p.name, args[idx]));
    try {
      yield* this.execBlock(fn.body, scope);
    } catch (e) {
      if (e instanceof ReturnSignal) return e.value;
      throw e;
    }
    return undefined;
  }

  private *execBlock(block: Block, parentScope: Scope): Generator<void, void, void> {
    const scope = new Scope(parentScope);
    for (const stmt of block.statements) {
      yield* this.checkBudget();
      yield* this.execStmt(stmt, scope);
    }
  }

  private *execStmt(stmt: Stmt, scope: Scope): Generator<void, void, void> {
    switch (stmt.kind) {
      case 'Block': yield* this.execBlock(stmt, scope); return;
      case 'VarDeclStmt':
        for (const d of stmt.decls) yield* this.evalVarDecl(d, scope);
        return;
      case 'ExprStmt': yield* this.evalExpr(stmt.expr, scope); return;
      case 'If': {
        const test = yield* this.evalExpr(stmt.test, scope);
        if (isTruthy(test)) yield* this.execStmt(stmt.consequent, scope);
        else if (stmt.alternate) yield* this.execStmt(stmt.alternate, scope);
        return;
      }
      case 'For': {
        const loopScope = new Scope(scope);
        if (stmt.init) yield* this.execStmt(stmt.init, loopScope);
        let guard = 0;
        for (;;) {
          if (guard++ > 5_000_000) { this.reportRuntimeError(stmt.line, 'for-loop exceeded maximum iteration guard'); break; }
          if (stmt.test) { const t = yield* this.evalExpr(stmt.test, loopScope); if (!isTruthy(t)) break; }
          yield* this.checkBudget();
          try {
            yield* this.execStmt(stmt.body, loopScope);
          } catch (e) {
            if (e instanceof BreakSignal) break;
            if (!(e instanceof ContinueSignal)) throw e;
          }
          if (stmt.update) yield* this.evalExpr(stmt.update, loopScope);
        }
        return;
      }
      case 'While': {
        let guard = 0;
        for (;;) {
          if (guard++ > 5_000_000) { this.reportRuntimeError(stmt.line, 'while-loop exceeded maximum iteration guard'); break; }
          const t = yield* this.evalExpr(stmt.test, scope);
          if (!isTruthy(t)) break;
          yield* this.checkBudget();
          try { yield* this.execStmt(stmt.body, scope); }
          catch (e) { if (e instanceof BreakSignal) break; if (!(e instanceof ContinueSignal)) throw e; }
        }
        return;
      }
      case 'DoWhile': {
        let guard = 0;
        do {
          if (guard++ > 5_000_000) { this.reportRuntimeError(stmt.line, 'do-while exceeded maximum iteration guard'); break; }
          yield* this.checkBudget();
          try { yield* this.execStmt(stmt.body, scope); }
          catch (e) { if (e instanceof BreakSignal) break; if (!(e instanceof ContinueSignal)) throw e; }
        } while (isTruthy(yield* this.evalExpr(stmt.test, scope)));
        return;
      }
      case 'Return': {
        const value = stmt.value ? yield* this.evalExpr(stmt.value, scope) : undefined;
        throw new ReturnSignal(value);
      }
      case 'Break': throw new BreakSignal();
      case 'Continue': throw new ContinueSignal();
      default:
        return;
    }
  }

  private *evalVarDecl(decl: VarDecl, scope: Scope): Generator<void, void, void> {
    if (decl.varType === 'Servo') {
      this.servos.set(decl.name, { pin: null, angleDeg: 0, minPulse: SERVO_MIN_PULSE, maxPulse: SERVO_MAX_PULSE });
      scope.declare(decl.name, 0);
      return;
    }
    if (decl.varType === 'DHT') {
      const argVals: ArduinoValue[] = [];
      for (const a of decl.ctorArgs ?? []) argVals.push(yield* this.evalExpr(a, scope));
      const pin = Math.trunc(toNumber(argVals[0] ?? 0));
      this.dhts.set(decl.name, { pin });
      scope.declare(decl.name, 0);
      return;
    }
    if (decl.varType === 'Stepper') {
      const argVals: number[] = [];
      for (const a of decl.ctorArgs ?? []) argVals.push(toNumber(yield* this.evalExpr(a, scope)));
      const stepsPerRev = Math.max(1, Math.trunc(argVals[0] ?? 0));
      const pins = argVals.slice(1).map((p) => Math.trunc(p));
      this.steppers.set(decl.name, { stepsPerRev, pins, rpm: 0, position: 0, phase: 0 });
      scope.declare(decl.name, 0);
      return;
    }
    if (decl.init && decl.init.kind === 'Array') {
      const elements: ArduinoValue[] = [];
      for (const el of decl.init.elements) elements.push(yield* this.evalExpr(el, scope));
      scope.declare(decl.name, elements);
      return;
    }
    if (decl.arraySize) {
      const size = Math.max(0, Math.trunc(toNumber(yield* this.evalExpr(decl.arraySize, scope))));
      scope.declare(decl.name, new Array(size).fill(defaultForType(decl.varType)));
      return;
    }
    if (decl.init) {
      const v = yield* this.evalExpr(decl.init as Expr, scope);
      scope.declare(decl.name, coerceForType(decl.varType, v));
      return;
    }
    scope.declare(decl.name, defaultForType(decl.varType));
  }

  private *evalExpr(expr: Expr, scope: Scope): Generator<void, ArduinoValue, void> {
    switch (expr.kind) {
      case 'Number': return expr.value;
      case 'Str': return expr.value;
      case 'Bool': return expr.value;
      case 'Ident': {
        try { return scope.get(expr.name); }
        catch { this.reportRuntimeError(expr.line, `'${expr.name}' was not declared in this scope`); return 0; }
      }
      case 'Array': {
        const elements: ArduinoValue[] = [];
        for (const el of expr.elements) elements.push(yield* this.evalExpr(el, scope));
        return elements;
      }
      case 'Index': {
        const target = yield* this.evalExpr(expr.target, scope);
        const idx = Math.trunc(toNumber(yield* this.evalExpr(expr.index, scope)));
        if (!Array.isArray(target)) { this.reportRuntimeError(expr.line, 'Indexing a non-array value'); return 0; }
        if (idx < 0 || idx >= target.length) { this.reportRuntimeError(expr.line, `Array index ${idx} out of bounds (length ${target.length})`); return 0; }
        return target[idx];
      }
      case 'Assign': return yield* this.evalAssign(expr, scope);
      case 'Unary': return yield* this.evalUnary(expr, scope);
      case 'Binary': return yield* this.evalBinary(expr, scope);
      case 'Logical': {
        const left = yield* this.evalExpr(expr.left, scope);
        if (expr.op === '&&') return isTruthy(left) ? isTruthy(yield* this.evalExpr(expr.right, scope)) : false;
        return isTruthy(left) ? true : isTruthy(yield* this.evalExpr(expr.right, scope));
      }
      case 'Ternary': {
        const t = yield* this.evalExpr(expr.test, scope);
        return isTruthy(t) ? yield* this.evalExpr(expr.consequent, scope) : yield* this.evalExpr(expr.alternate, scope);
      }
      case 'Call': return yield* this.evalCall(expr.callee, expr.args, scope, expr.line);
      case 'MemberCall': return yield* this.evalMemberCall(expr, scope);
      case 'Member': return 0; // bare property access (no known objects expose readable properties here)
      default: return 0;
    }
  }

  private *evalLvalueRef(expr: Expr, scope: Scope): Generator<void, { get(): ArduinoValue; set(v: ArduinoValue): void }, void> {
    if (expr.kind === 'Ident') {
      const name = expr.name;
      return { get: () => scope.get(name), set: (v) => { if (!scope.set(name, v)) scope.declare(name, v); } };
    }
    if (expr.kind === 'Index') {
      const target = yield* this.evalExpr(expr.target, scope);
      const idx = Math.trunc(toNumber(yield* this.evalExpr(expr.index, scope)));
      return {
        get: () => (Array.isArray(target) ? target[idx] ?? 0 : 0),
        set: (v) => { if (Array.isArray(target)) target[idx] = v; },
      };
    }
    this.reportRuntimeError(expr.line, 'Invalid assignment target');
    return { get: () => 0, set: () => {} };
  }

  private *evalAssign(expr: Extract<Expr, { kind: 'Assign' }>, scope: Scope): Generator<void, ArduinoValue, void> {
    const ref = yield* this.evalLvalueRef(expr.target, scope);
    const rhs = yield* this.evalExpr(expr.value, scope);
    let next: ArduinoValue;
    if (expr.op === '=') next = rhs;
    else {
      const cur = ref.get();
      const op = expr.op.slice(0, -1);
      next = applyBinaryOp(op, cur, rhs);
    }
    ref.set(next);
    return next;
  }

  private *evalUnary(expr: Extract<Expr, { kind: 'Unary' }>, scope: Scope): Generator<void, ArduinoValue, void> {
    if (expr.op === '++' || expr.op === '--') {
      const ref = yield* this.evalLvalueRef(expr.argument, scope);
      const cur = toNumber(ref.get());
      const next = expr.op === '++' ? cur + 1 : cur - 1;
      ref.set(next);
      return expr.prefix ? next : cur;
    }
    const v = yield* this.evalExpr(expr.argument, scope);
    if (expr.op === '!') return !isTruthy(v);
    if (expr.op === '-') return -toNumber(v);
    if (expr.op === '+') return toNumber(v);
    if (expr.op === '~') return ~toNumber(v);
    return v;
  }

  private *evalBinary(expr: Extract<Expr, { kind: 'Binary' }>, scope: Scope): Generator<void, ArduinoValue, void> {
    const left = yield* this.evalExpr(expr.left, scope);
    const right = yield* this.evalExpr(expr.right, scope);
    return applyBinaryOp(expr.op, left, right);
  }

  private *evalArgs(args: Expr[], scope: Scope): Generator<void, ArduinoValue[], void> {
    const out: ArduinoValue[] = [];
    for (const a of args) out.push(yield* this.evalExpr(a, scope));
    return out;
  }

  private *evalCall(callee: string, argNodes: Expr[], scope: Scope, line: number): Generator<void, ArduinoValue, void> {
    // --- Timing ---
    if (callee === 'delay') {
      const [ms] = yield* this.evalArgs(argNodes, scope);
      const target = this.clockMillis + Math.max(0, toNumber(ms));
      while (this.clockMillis < target) yield;
      return undefined;
    }
    if (callee === 'delayMicroseconds') {
      const [us] = yield* this.evalArgs(argNodes, scope);
      const target = this.clockMillis + Math.max(0, toNumber(us)) / 1000;
      while (this.clockMillis < target) yield;
      return undefined;
    }
    if (callee === 'millis') return Math.floor(this.clockMillis);
    if (callee === 'micros') return Math.floor(this.clockMillis * 1000);

    // --- Digital / analog I/O ---
    if (callee === 'pinMode') {
      const [pin, mode] = yield* this.evalArgs(argNodes, scope);
      const modeNum = toNumber(mode);
      const modeStr = modeNum === 2 ? 'INPUT_PULLUP' : modeNum === 1 ? 'OUTPUT' : 'INPUT';
      this.pinIO.pinMode(Math.trunc(toNumber(pin)), modeStr);
      return undefined;
    }
    if (callee === 'digitalWrite') {
      const [pin, val] = yield* this.evalArgs(argNodes, scope);
      this.pinIO.digitalWrite(Math.trunc(toNumber(pin)), toNumber(val) ? 1 : 0);
      return undefined;
    }
    if (callee === 'digitalRead') {
      const [pin] = yield* this.evalArgs(argNodes, scope);
      return this.pinIO.digitalRead(Math.trunc(toNumber(pin)));
    }
    if (callee === 'analogWrite') {
      const [pin, val] = yield* this.evalArgs(argNodes, scope);
      this.pinIO.analogWrite(Math.trunc(toNumber(pin)), Math.max(0, Math.min(255, Math.trunc(toNumber(val)))));
      return undefined;
    }
    if (callee === 'analogRead') {
      const [pin] = yield* this.evalArgs(argNodes, scope);
      return this.pinIO.analogRead(Math.trunc(toNumber(pin)));
    }
    // tone()/noTone(): no dedicated PinIO hook - a (passive) buzzer in the
    // simulator already decodes its driving pin's duty-cycle voltage into an
    // audible frequency (see the passiveBuzzer case in simulator.ts), so the
    // most faithful thing this engine can do without a per-board timer pin
    // is drive the pin with a PWM duty that maps monotonically to the
    // requested frequency via analogWrite(). Duration, if given, is not
    // auto-stopped (matching this engine's "no timers besides delay()"
    // design) - sketches that pass a duration should still call noTone()
    // themselves, exactly as sketches that don't rely on it already must.
    if (callee === 'tone') {
      const args = yield* this.evalArgs(argNodes, scope);
      const pin = Math.trunc(toNumber(args[0]));
      const freq = Math.max(0, toNumber(args[1]));
      const duty = Math.max(20, Math.min(255, Math.round((freq / 5000) * 255)));
      this.pinIO.analogWrite(pin, duty);
      return undefined;
    }
    if (callee === 'noTone') {
      const [pin] = yield* this.evalArgs(argNodes, scope);
      this.pinIO.analogWrite(Math.trunc(toNumber(pin)), 0);
      return undefined;
    }
    // pulseIn(pin, value, [timeoutUs]): blocks (across ticks, like delay())
    // until `pin` reaches `value`, then measures how long it stays there,
    // returning the duration in microseconds - or 0 on timeout. This is the
    // standard way HC-SR04-style ultrasonic sketches read their Echo pin
    // (echo pulse width is proportional to distance), and had no
    // implementation at all here, which meant every such sketch either
    // failed at runtime ("unknown function") or silently read a distance of
    // zero forever. No dedicated PinIO hook is needed: this polls the
    // existing digitalRead() primitive every tick, exactly like a real AVR
    // core's software implementation of pulseIn() polls its input register,
    // so it works unmodified against MemoryPinIO and CircuitPinIO alike (the
    // latter already reflects the simulator's live Echo-pin voltage there).
    if (callee === 'pulseIn') {
      const args = yield* this.evalArgs(argNodes, scope);
      const pin = Math.trunc(toNumber(args[0]));
      const level: 0 | 1 = toNumber(args[1]) ? 1 : 0;
      const timeoutUs = args.length > 2 ? Math.max(0, toNumber(args[2])) : 1000000; // Arduino default: 1s
      const timeoutMillis = timeoutUs / 1000;
      const waitStart = this.clockMillis;
      while (this.pinIO.digitalRead(pin) !== level) {
        if (this.clockMillis - waitStart >= timeoutMillis) return 0;
        yield;
      }
      const pulseStart = this.clockMillis;
      while (this.pinIO.digitalRead(pin) === level) {
        if (this.clockMillis - waitStart >= timeoutMillis) return 0;
        yield;
      }
      return Math.round((this.clockMillis - pulseStart) * 1000);
    }

    // --- Math / misc helpers ---
    if (callee === 'min') { const [a, b] = yield* this.evalArgs(argNodes, scope); return Math.min(toNumber(a), toNumber(b)); }
    if (callee === 'max') { const [a, b] = yield* this.evalArgs(argNodes, scope); return Math.max(toNumber(a), toNumber(b)); }
    if (callee === 'abs') { const [a] = yield* this.evalArgs(argNodes, scope); return Math.abs(toNumber(a)); }
    if (callee === 'constrain') { const [v, lo, hi] = yield* this.evalArgs(argNodes, scope); return Math.min(Math.max(toNumber(v), toNumber(lo)), toNumber(hi)); }
    if (callee === 'map') {
      const [v, inMin, inMax, outMin, outMax] = yield* this.evalArgs(argNodes, scope);
      const [x, a1, a2, b1, b2] = [v, inMin, inMax, outMin, outMax].map(toNumber);
      if (a2 - a1 === 0) return b1;
      return (x - a1) * (b2 - b1) / (a2 - a1) + b1;
    }
    if (callee === 'sq') { const [a] = yield* this.evalArgs(argNodes, scope); return toNumber(a) * toNumber(a); }
    if (callee === 'sqrt') { const [a] = yield* this.evalArgs(argNodes, scope); return Math.sqrt(toNumber(a)); }
    if (callee === 'pow') { const [a, b] = yield* this.evalArgs(argNodes, scope); return Math.pow(toNumber(a), toNumber(b)); }
    if (callee === 'round') { const [a] = yield* this.evalArgs(argNodes, scope); return Math.round(toNumber(a)); }
    if (callee === 'floor') { const [a] = yield* this.evalArgs(argNodes, scope); return Math.floor(toNumber(a)); }
    if (callee === 'ceil') { const [a] = yield* this.evalArgs(argNodes, scope); return Math.ceil(toNumber(a)); }
    if (callee === 'random') {
      const args = yield* this.evalArgs(argNodes, scope);
      if (args.length >= 2) { const lo = toNumber(args[0]), hi = toNumber(args[1]); return Math.floor(Math.random() * (hi - lo)) + lo; }
      if (args.length === 1) return Math.floor(Math.random() * toNumber(args[0]));
      return Math.floor(Math.random() * 2147483647);
    }
    if (callee === 'randomSeed') { yield* this.evalArgs(argNodes, scope); return undefined; }

    // --- SPI settings helper (used inline: SPI.beginTransaction(SPISettings(...))) ---
    if (callee === 'SPISettings') { yield* this.evalArgs(argNodes, scope); return undefined; }

    // --- User-defined function ---
    const fn = this.functions.get(callee);
    if (fn) {
      const args = yield* this.evalArgs(argNodes, scope);
      return yield* this.callFunction(fn, args);
    }

    this.reportRuntimeError(line, `Call to unknown function '${callee}(...)'`);
    yield* this.evalArgs(argNodes, scope); // still evaluate args for side effects, matching real eval order
    return 0;
  }

  private *evalMemberCall(expr: Extract<Expr, { kind: 'MemberCall' }>, scope: Scope): Generator<void, ArduinoValue, void> {
    const obj = expr.object.kind === 'Ident' ? expr.object.name : '';
    if (obj === 'Serial') {
      const args = yield* this.evalArgs(expr.args, scope);
      switch (expr.property) {
        case 'begin': return undefined;
        case 'print': this.pushSerial(String(args[0] ?? '')); return undefined;
        case 'println': this.pushSerial(String(args[0] ?? '') + '\n'); return undefined;
        case 'available': return 0;
        case 'read': return -1;
        default: return undefined;
      }
    }
    if (this.servos.has(obj)) {
      const args = yield* this.evalArgs(expr.args, scope);
      return this.callServoMethod(obj, expr.property, args);
    }
    if (this.steppers.has(obj)) {
      return yield* this.callStepperMethod(obj, expr.property, expr.args, scope);
    }
    if (this.dhts.has(obj)) {
      const args = yield* this.evalArgs(expr.args, scope);
      return this.callDhtMethod(obj, expr.property, args);
    }
    if (obj === 'Wire') {
      const args = yield* this.evalArgs(expr.args, scope);
      return this.callWireMethod(expr.property, args);
    }
    if (obj === 'SPI') {
      const args = yield* this.evalArgs(expr.args, scope);
      return this.callSpiMethod(expr.property, args);
    }
    // Unknown object — evaluate args for side effects, then no-op.
    yield* this.evalArgs(expr.args, scope);
    return undefined;
  }

  // --- Servo -----------------------------------------------------------
  private callServoMethod(name: string, property: string, args: ArduinoValue[]): ArduinoValue {
    const s = this.servos.get(name)!;
    switch (property) {
      case 'attach': {
        s.pin = Math.trunc(toNumber(args[0]));
        if (args.length >= 3) { s.minPulse = toNumber(args[1]); s.maxPulse = toNumber(args[2]); }
        this.pinIO.pinMode(s.pin, 'OUTPUT');
        return s.pin;
      }
      case 'detach': {
        if (s.pin !== null) this.pinIO.servoDetach?.(s.pin);
        s.pin = null;
        return undefined;
      }
      case 'attached': return s.pin !== null;
      case 'write': {
        const raw = toNumber(args[0]);
        // Mirrors real Servo.write(): only values at/above the minimum pulse
        // width are treated as a direct microsecond pulse; anything below
        // that (including out-of-range angles like 300) is a degree value,
        // clamped to 0-180.
        s.angleDeg = raw >= s.minPulse
          ? clamp((raw - s.minPulse) * 180 / (s.maxPulse - s.minPulse), 0, 180)
          : clamp(raw, 0, 180);
        this.applyServoOutput(s);
        return undefined;
      }
      case 'writeMicroseconds': {
        const us = clamp(toNumber(args[0]), s.minPulse, s.maxPulse);
        s.angleDeg = clamp((us - s.minPulse) * 180 / (s.maxPulse - s.minPulse), 0, 180);
        this.applyServoOutput(s);
        return undefined;
      }
      case 'read': return Math.round(s.angleDeg);
      default: return undefined;
    }
  }

  private applyServoOutput(s: ServoState) {
    if (s.pin === null) return;
    if (this.pinIO.servoWrite) { this.pinIO.servoWrite(s.pin, s.angleDeg); return; }
    // Fallback for a PinIO that doesn't model servo pulses: drive the pin
    // with a proportional PWM duty cycle so something observable still happens.
    this.pinIO.analogWrite(s.pin, Math.round((s.angleDeg / 180) * 255));
  }

  // --- Stepper -----------------------------------------------------------
  // Full-step sequences matching the classic Arduino Stepper library.
  private static readonly STEP_SEQUENCE_4WIRE = [
    [1, 0, 1, 0], [0, 1, 1, 0], [0, 1, 0, 1], [1, 0, 0, 1],
  ];
  private static readonly STEP_SEQUENCE_2WIRE = [
    [1, 0], [1, 1], [0, 1], [0, 0],
  ];

  private *callStepperMethod(name: string, property: string, argNodes: Expr[], scope: Scope): Generator<void, ArduinoValue, void> {
    const s = this.steppers.get(name)!;
    if (property === 'setSpeed') {
      const [rpm] = yield* this.evalArgs(argNodes, scope);
      s.rpm = Math.max(0, toNumber(rpm));
      return undefined;
    }
    if (property === 'step') {
      const [stepsArg] = yield* this.evalArgs(argNodes, scope);
      const steps = Math.trunc(toNumber(stepsArg));
      const dir = steps >= 0 ? 1 : -1;
      const count = Math.abs(steps);
      const msPerStep = s.rpm > 0 ? (60000 / s.stepsPerRev) / s.rpm : 0;
      for (let i = 0; i < count; i++) {
        s.phase = (s.phase + dir + 4) % 4;
        s.position += dir;
        this.writeStepperPhase(s);
        if (msPerStep > 0) {
          const target = this.clockMillis + msPerStep;
          while (this.clockMillis < target) yield;
        } else {
          yield* this.checkBudget();
        }
      }
      return undefined;
    }
    if (property === 'numOfSteps' || property === 'version') return s.stepsPerRev;
    yield* this.evalArgs(argNodes, scope);
    return undefined;
  }

  private writeStepperPhase(s: StepperState) {
    const table = s.pins.length >= 4 ? Interpreter.STEP_SEQUENCE_4WIRE : Interpreter.STEP_SEQUENCE_2WIRE;
    const pattern = table[s.phase % table.length];
    for (let i = 0; i < s.pins.length && i < pattern.length; i++) {
      this.pinIO.digitalWrite(s.pins[i], pattern[i] as 0 | 1);
    }
  }

  // --- DHT11 / DHT22 -----------------------------------------------------
  // Mirrors the real DHT.h API surface: begin() is a no-op (real hardware
  // just needs the pin held idle-high, which the simulator's electrical
  // model already does), and the two readers pull the sensor's *current*
  // Properties-panel value through PinIO.readDht() on every call — so
  // edits made while the sim is running show up immediately, exactly like
  // dragging a real potentiometer/thermostat next to a live sensor would.
  private callDhtMethod(name: string, property: string, args: ArduinoValue[]): ArduinoValue {
    const d = this.dhts.get(name)!;
    switch (property) {
      case 'begin':
        return undefined;
      case 'readTemperature': {
        const reading = this.pinIO.readDht?.(d.pin);
        if (!reading) return NaN; // disconnected / unpowered — matches real DHT.h
        const fahrenheit = isTruthy(args[0]);
        return fahrenheit ? (reading.temperatureC * 9) / 5 + 32 : reading.temperatureC;
      }
      case 'readHumidity': {
        const reading = this.pinIO.readDht?.(d.pin);
        return reading ? reading.humidity : NaN; // disconnected / unpowered
      }
      default:
        return undefined;
    }
  }

  // --- Wire (I2C) ----------------------------------------------------------
  private callWireMethod(property: string, args: ArduinoValue[]): ArduinoValue {
    const w = this.wire;
    switch (property) {
      case 'begin': return undefined;
      case 'beginTransmission': w.txAddress = Math.trunc(toNumber(args[0])); w.txBuffer = []; return undefined;
      case 'write': {
        const v = args[0];
        if (typeof v === 'string') { for (let i = 0; i < v.length; i++) w.txBuffer.push(v.charCodeAt(i)); return v.length; }
        w.txBuffer.push(Math.trunc(toNumber(v)) & 0xff);
        return 1;
      }
      case 'endTransmission': {
        if (w.txAddress !== null) this.pinIO.i2cWrite?.(w.txAddress, w.txBuffer);
        w.txBuffer = [];
        return 0; // 0 == success, matching the real Wire API's return code
      }
      case 'requestFrom': {
        const address = Math.trunc(toNumber(args[0]));
        const count = Math.max(0, Math.trunc(toNumber(args[1])));
        w.rxBuffer = this.pinIO.i2cRead ? this.pinIO.i2cRead(address, count) : new Array(count).fill(0);
        w.rxIndex = 0;
        return w.rxBuffer.length;
      }
      case 'available': return Math.max(0, w.rxBuffer.length - w.rxIndex);
      case 'read': return w.rxIndex < w.rxBuffer.length ? w.rxBuffer[w.rxIndex++] : -1;
      default: return undefined;
    }
  }

  // --- SPI -------------------------------------------------------------
  private callSpiMethod(property: string, args: ArduinoValue[]): ArduinoValue {
    switch (property) {
      case 'begin': case 'end': case 'beginTransaction': case 'endTransaction':
      case 'setBitOrder': case 'setDataMode': case 'setClockDivider': case 'usingInterrupt':
        return undefined;
      case 'transfer': {
        const byte = Math.trunc(toNumber(args[0])) & 0xff;
        return this.pinIO.spiTransfer ? this.pinIO.spiTransfer(byte) : 0;
      }
      case 'transfer16': {
        const word = Math.trunc(toNumber(args[0])) & 0xffff;
        if (!this.pinIO.spiTransfer) return 0;
        const hi = this.pinIO.spiTransfer((word >> 8) & 0xff);
        const lo = this.pinIO.spiTransfer(word & 0xff);
        return ((hi & 0xff) << 8) | (lo & 0xff);
      }
      default: return undefined;
    }
  }

  private pushSerial(text: string) {
    this.serialLog.push({ text, atMillis: Math.floor(this.clockMillis), seq: ++this.serialSeqCounter });
    if (this.serialLog.length > this.serialBufferLimit) this.serialLog.shift();
  }
}

function applyBinaryOp(op: string, left: ArduinoValue, right: ArduinoValue): ArduinoValue {
  if (op === '+' && (typeof left === 'string' || typeof right === 'string')) {
    return String(left ?? '') + String(right ?? '');
  }
  const a = toNumber(left), b = toNumber(right);
  switch (op) {
    case '+': return a + b;
    case '-': return a - b;
    case '*': return a * b;
    case '/': return b === 0 ? 0 : a / b;
    case '%': return b === 0 ? 0 : a % b;
    case '&': return a & b;
    case '|': return a | b;
    case '^': return a ^ b;
    case '<<': return a << b;
    case '>>': return a >> b;
    case '==': return typeof left === 'string' || typeof right === 'string' ? left === right : a === b;
    case '!=': return typeof left === 'string' || typeof right === 'string' ? left !== right : a !== b;
    case '<': return a < b;
    case '>': return a > b;
    case '<=': return a <= b;
    case '>=': return a >= b;
    default: return 0;
  }
}
