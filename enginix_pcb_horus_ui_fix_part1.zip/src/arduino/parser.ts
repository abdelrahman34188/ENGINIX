// Arduino Coding Core — Parser
//
// Recursive-descent / precedence-climbing parser for the supported C/C++
// subset. Produces a plain-object AST that interpreter.ts walks. Parsing
// never throws for malformed input — errors are collected and returned
// alongside whatever partial AST could be recovered, so the caller can
// always show diagnostics instead of a crash.

import { tokenize, type Token } from './lexer';
import type { Diagnostic } from './types';

export type Node = { line: number } & (
  | { kind: 'Program'; functions: FunctionDecl[]; globals: VarDecl[] }
  | { kind: 'FunctionDecl'; name: string; returnType: string; params: Param[]; body: Block }
  | { kind: 'VarDecl'; varType: string; name: string; arraySize: Expr | null; init: Expr | ExprList | null; ctorArgs?: Expr[] }
  | { kind: 'Block'; statements: Stmt[] }
  | { kind: 'If'; test: Expr; consequent: Stmt; alternate: Stmt | null }
  | { kind: 'For'; init: Stmt | null; test: Expr | null; update: Expr | null; body: Stmt }
  | { kind: 'While'; test: Expr; body: Stmt }
  | { kind: 'DoWhile'; test: Expr; body: Stmt }
  | { kind: 'Return'; value: Expr | null }
  | { kind: 'Break' }
  | { kind: 'Continue' }
  | { kind: 'ExprStmt'; expr: Expr }
  | { kind: 'VarDeclStmt'; decls: VarDecl[] }
  | { kind: 'Number'; value: number }
  | { kind: 'Str'; value: string }
  | { kind: 'Bool'; value: boolean }
  | { kind: 'Ident'; name: string }
  | { kind: 'Array'; elements: Expr[] }
  | { kind: 'Index'; target: Expr; index: Expr }
  | { kind: 'Call'; callee: string; args: Expr[] }
  | { kind: 'Member'; object: Expr; property: string }
  | { kind: 'MemberCall'; object: Expr; property: string; args: Expr[] }
  | { kind: 'Assign'; op: string; target: Expr; value: Expr }
  | { kind: 'Binary'; op: string; left: Expr; right: Expr }
  | { kind: 'Logical'; op: '&&' | '||'; left: Expr; right: Expr }
  | { kind: 'Unary'; op: string; argument: Expr; prefix: boolean }
  | { kind: 'Ternary'; test: Expr; consequent: Expr; alternate: Expr }
);

export type FunctionDecl = Extract<Node, { kind: 'FunctionDecl' }>;
export type VarDecl = Extract<Node, { kind: 'VarDecl' }>;
export type Block = Extract<Node, { kind: 'Block' }>;
export type Stmt = Node;
export type Expr = Node;
export type ExprList = { kind: 'Array'; elements: Expr[]; line: number };
export interface Param { paramType: string; name: string; isArray: boolean }
export interface ParseResult { program: Node | null; errors: Diagnostic[] }

const TYPE_KEYWORDS = new Set([
  'void', 'int', 'float', 'double', 'bool', 'boolean', 'char', 'byte',
  'long', 'short', 'unsigned', 'String',
]);

// Library object types (Servo/Stepper). These lex as plain IDENT tokens (not
// KEYWORD), and unlike primitives can be instantiated with constructor-call
// syntax: `Stepper myStepper(200, 8, 9, 10, 11);`. Wire/SPI are NOT here —
// like Serial, they're singleton globals used directly (`Wire.begin()`),
// never declared by the sketch, so the parser doesn't need to know them.
const OBJECT_TYPES = new Set(['Servo', 'Stepper', 'DHT']);

export class Parser {
  private tokens: Token[];
  private pos = 0;
  private errors: Diagnostic[] = [];

  constructor(source: string) {
    const { tokens, errors } = tokenize(source);
    this.tokens = tokens;
    for (const e of errors) this.errors.push({ ...e, message: e.message, severity: 'error' });
  }

  private peek(offset = 0): Token { return this.tokens[Math.min(this.pos + offset, this.tokens.length - 1)]; }
  private at(value: string): boolean { const t = this.peek(); return (t.type === 'PUNCT' || t.type === 'KEYWORD') && t.value === value; }
  private atType(type: Token['type']): boolean { return this.peek().type === type; }
  private advance(): Token { const t = this.tokens[this.pos]; if (this.pos < this.tokens.length - 1) this.pos++; return t; }
  private expect(value: string): Token {
    if (this.at(value)) return this.advance();
    const t = this.peek();
    this.err(t.line, t.column, `Expected '${value}' but found '${t.value || '<eof>'}'`);
    return t; // don't advance — best-effort recovery
  }
  private err(line: number, column: number, message: string) {
    this.errors.push({ line, column, message, severity: 'error' });
  }

  // Storage/qualifier keywords that may precede a real type (`const int x`,
  // `static byte y`). They carry no semantic weight for this interpreter
  // (everything here is already effectively mutable/global-static), so
  // they're recognized only so the parser can skip over them.
  private static readonly TYPE_QUALIFIERS = new Set(['const', 'static']);

  private isTypeStart(): boolean {
    const t = this.peek();
    if (t.type === 'KEYWORD' && TYPE_KEYWORDS.has(t.value)) return true;
    if (t.type === 'KEYWORD' && Parser.TYPE_QUALIFIERS.has(t.value)) return true;
    // Object-type declarations (`Servo foo;` / `Stepper foo(...)`) lex as a
    // plain IDENT. Only treat it as a type if an identifier (the variable
    // name) follows — otherwise `Servo` alone could just be a variable/call
    // expression (e.g. reassigning something named the same, however
    // unlikely) and we don't want to misparse a statement.
    if (t.type === 'IDENT' && OBJECT_TYPES.has(t.value) && this.peek(1).type === 'IDENT') return true;
    return false;
  }

  private parseType(): string {
    // Skip (and discard) any leading qualifiers - `const int` and `int` are
    // treated identically by this interpreter, and qualifiers may appear in
    // any order/quantity before the real type (`static const int`).
    while (this.peek().type === 'KEYWORD' && Parser.TYPE_QUALIFIERS.has(this.peek().value)) {
      this.advance();
    }
    let s = this.advance().value; // first word of the actual type (e.g. 'unsigned')
    while (this.isTypeStart() && this.peek().value !== s && !Parser.TYPE_QUALIFIERS.has(this.peek().value)) {
      // e.g. "unsigned long" — combine words
      s += ' ' + this.advance().value;
    }
    while (this.at('*')) { this.advance(); s += '*'; }
    return s;
  }

  parse(): ParseResult {
    const functions: FunctionDecl[] = [];
    const globals: VarDecl[] = [];
    let guard = 0;
    while (!this.atType('EOF')) {
      if (guard++ > 200000) { this.err(this.peek().line, this.peek().column, 'Parser aborted: input too large or stuck'); break; }
      const startPos = this.pos;
      if (this.at(';')) { this.advance(); continue; }
      if (!this.isTypeStart()) {
        const t = this.peek();
        this.err(t.line, t.column, `Expected a type at top level, found '${t.value || '<eof>'}'`);
        this.advance();
        continue;
      }
      const line = this.peek().line;
      const type = this.parseType();
      const nameTok = this.peek();
      if (nameTok.type !== 'IDENT') {
        this.err(nameTok.line, nameTok.column, `Expected an identifier after type '${type}'`);
        this.advance();
        continue;
      }
      const name = this.advance().value;
      if (this.at('(') && !OBJECT_TYPES.has(type)) {
        // Function declaration
        this.advance();
        const params: Param[] = [];
        while (!this.at(')') && !this.atType('EOF')) {
          if (this.isTypeStart()) {
            const pType = this.parseType();
            let pName = '';
            if (this.atType('IDENT')) pName = this.advance().value;
            let isArray = false;
            if (this.at('[')) { this.advance(); this.expect(']'); isArray = true; }
            params.push({ paramType: pType, name: pName, isArray });
          } else this.advance();
          if (this.at(',')) this.advance();
        }
        this.expect(')');
        if (this.at(';')) { this.advance(); continue; } // prototype only, no body
        const body = this.parseBlock();
        functions.push({ kind: 'FunctionDecl', name, returnType: type, params, body, line });
      } else {
        // Global variable declaration(s)
        this.pos = startPos;
        const decls = this.parseVarDeclStatementBody();
        this.expect(';');
        for (const d of decls) globals.push(d);
      }
      if (this.pos === startPos) this.advance(); // safety: always make progress
    }
    const program: Node = { kind: 'Program', functions, globals, line: 1 };
    return { program, errors: this.errors };
  }

  // Parses "type name (= init)? (, name (= init)?)*" without the trailing ';'
  private parseVarDeclStatementBody(): VarDecl[] {
    const line = this.peek().line;
    const type = this.parseType();
    const decls: VarDecl[] = [];
    do {
      const nameTok = this.peek();
      if (nameTok.type !== 'IDENT') { this.err(nameTok.line, nameTok.column, 'Expected identifier in declaration'); break; }
      const name = this.advance().value;
      let arraySize: Expr | null = null;
      if (this.at('[')) {
        this.advance();
        arraySize = this.at(']') ? null : this.parseExpression();
        this.expect(']');
      }
      let init: Expr | ExprList | null = null;
      let ctorArgs: Expr[] | undefined;
      if (this.at('(')) {
        // Constructor-call style init, e.g. `Stepper myStepper(200, 8, 9, 10, 11);`
        this.advance();
        ctorArgs = [];
        while (!this.at(')') && !this.atType('EOF')) {
          ctorArgs.push(this.parseExpression());
          if (this.at(',')) this.advance(); else break;
        }
        this.expect(')');
      } else if (this.at('=')) {
        this.advance();
        if (this.at('{')) init = this.parseArrayLiteral();
        else init = this.parseExpression();
      }
      decls.push({ kind: 'VarDecl', varType: type, name, arraySize, init, ctorArgs, line });
    } while (this.at(',') && this.advance());
    return decls;
  }

  private parseArrayLiteral(): ExprList {
    const line = this.peek().line;
    this.expect('{');
    const elements: Expr[] = [];
    while (!this.at('}') && !this.atType('EOF')) {
      elements.push(this.parseExpression());
      if (this.at(',')) this.advance(); else break;
    }
    this.expect('}');
    return { kind: 'Array', elements, line };
  }

  private parseBlock(): Block {
    const line = this.peek().line;
    this.expect('{');
    const statements: Stmt[] = [];
    let guard = 0;
    while (!this.at('}') && !this.atType('EOF')) {
      if (guard++ > 200000) break;
      const before = this.pos;
      statements.push(this.parseStatement());
      if (this.pos === before) this.advance();
    }
    this.expect('}');
    return { kind: 'Block', statements, line };
  }

  private parseStatement(): Stmt {
    const line = this.peek().line;
    if (this.at('{')) return this.parseBlock();
    if (this.at('if')) return this.parseIf();
    if (this.at('for')) return this.parseFor();
    if (this.at('while')) return this.parseWhile();
    if (this.at('do')) return this.parseDoWhile();
    if (this.at('return')) {
      this.advance();
      const value = this.at(';') ? null : this.parseExpression();
      this.expect(';');
      return { kind: 'Return', value, line };
    }
    if (this.at('break')) { this.advance(); this.expect(';'); return { kind: 'Break', line }; }
    if (this.at('continue')) { this.advance(); this.expect(';'); return { kind: 'Continue', line }; }
    if (this.isTypeStart()) {
      const decls = this.parseVarDeclStatementBody();
      this.expect(';');
      return { kind: 'VarDeclStmt', decls, line };
    }
    const expr = this.parseExpression();
    this.expect(';');
    return { kind: 'ExprStmt', expr, line };
  }

  private parseIf(): Stmt {
    const line = this.peek().line;
    this.advance();
    this.expect('(');
    const test = this.parseExpression();
    this.expect(')');
    const consequent = this.parseStatement();
    let alternate: Stmt | null = null;
    if (this.at('else')) { this.advance(); alternate = this.parseStatement(); }
    return { kind: 'If', test, consequent, alternate, line };
  }

  private parseFor(): Stmt {
    const line = this.peek().line;
    this.advance();
    this.expect('(');
    let init: Stmt | null = null;
    if (!this.at(';')) {
      init = this.isTypeStart()
        ? { kind: 'VarDeclStmt', decls: this.parseVarDeclStatementBody(), line: this.peek().line }
        : { kind: 'ExprStmt', expr: this.parseExpression(), line: this.peek().line };
    }
    this.expect(';');
    const test = this.at(';') ? null : this.parseExpression();
    this.expect(';');
    const update = this.at(')') ? null : this.parseExpression();
    this.expect(')');
    const body = this.parseStatement();
    return { kind: 'For', init, test, update, body, line };
  }

  private parseWhile(): Stmt {
    const line = this.peek().line;
    this.advance();
    this.expect('(');
    const test = this.parseExpression();
    this.expect(')');
    const body = this.parseStatement();
    return { kind: 'While', test, body, line };
  }

  private parseDoWhile(): Stmt {
    const line = this.peek().line;
    this.advance();
    const body = this.parseStatement();
    this.expect('while');
    this.expect('(');
    const test = this.parseExpression();
    this.expect(')');
    this.expect(';');
    return { kind: 'DoWhile', test, body, line };
  }

  // ---- Expressions (precedence climbing) ----

  parseExpression(): Expr { return this.parseAssignment(); }

  private parseAssignment(): Expr {
    const left = this.parseTernary();
    const ASSIGN_OPS = ['=', '+=', '-=', '*=', '/=', '%=', '&=', '|=', '^=', '<<=', '>>='];
    const t = this.peek();
    if (t.type === 'PUNCT' && ASSIGN_OPS.includes(t.value)) {
      this.advance();
      const value = this.parseAssignment();
      return { kind: 'Assign', op: t.value, target: left, value, line: t.line };
    }
    return left;
  }

  private parseTernary(): Expr {
    const test = this.parseLogicalOr();
    if (this.at('?')) {
      const line = this.peek().line;
      this.advance();
      const consequent = this.parseAssignment();
      this.expect(':');
      const alternate = this.parseAssignment();
      return { kind: 'Ternary', test, consequent, alternate, line };
    }
    return test;
  }

  private parseLogicalOr(): Expr {
    let left = this.parseLogicalAnd();
    while (this.at('||')) {
      const line = this.advance().line;
      left = { kind: 'Logical', op: '||', left, right: this.parseLogicalAnd(), line };
    }
    return left;
  }
  private parseLogicalAnd(): Expr {
    let left = this.parseBitOr();
    while (this.at('&&')) {
      const line = this.advance().line;
      left = { kind: 'Logical', op: '&&', left, right: this.parseBitOr(), line };
    }
    return left;
  }
  private parseBitOr(): Expr {
    let left = this.parseBitXor();
    while (this.at('|')) { const line = this.advance().line; left = { kind: 'Binary', op: '|', left, right: this.parseBitXor(), line }; }
    return left;
  }
  private parseBitXor(): Expr {
    let left = this.parseBitAnd();
    while (this.at('^')) { const line = this.advance().line; left = { kind: 'Binary', op: '^', left, right: this.parseBitAnd(), line }; }
    return left;
  }
  private parseBitAnd(): Expr {
    let left = this.parseEquality();
    while (this.at('&')) { const line = this.advance().line; left = { kind: 'Binary', op: '&', left, right: this.parseEquality(), line }; }
    return left;
  }
  private parseEquality(): Expr {
    let left = this.parseRelational();
    while (this.at('==') || this.at('!=')) {
      const op = this.advance();
      left = { kind: 'Binary', op: op.value, left, right: this.parseRelational(), line: op.line };
    }
    return left;
  }
  private parseRelational(): Expr {
    let left = this.parseShift();
    while (this.at('<') || this.at('>') || this.at('<=') || this.at('>=')) {
      const op = this.advance();
      left = { kind: 'Binary', op: op.value, left, right: this.parseShift(), line: op.line };
    }
    return left;
  }
  private parseShift(): Expr {
    let left = this.parseAdditive();
    while (this.at('<<') || this.at('>>')) {
      const op = this.advance();
      left = { kind: 'Binary', op: op.value, left, right: this.parseAdditive(), line: op.line };
    }
    return left;
  }
  private parseAdditive(): Expr {
    let left = this.parseMultiplicative();
    while (this.at('+') || this.at('-')) {
      const op = this.advance();
      left = { kind: 'Binary', op: op.value, left, right: this.parseMultiplicative(), line: op.line };
    }
    return left;
  }
  private parseMultiplicative(): Expr {
    let left = this.parseUnary();
    while (this.at('*') || this.at('/') || this.at('%')) {
      const op = this.advance();
      left = { kind: 'Binary', op: op.value, left, right: this.parseUnary(), line: op.line };
    }
    return left;
  }
  private parseUnary(): Expr {
    if (this.at('!') || this.at('-') || this.at('+') || this.at('~')) {
      const op = this.advance();
      return { kind: 'Unary', op: op.value, argument: this.parseUnary(), prefix: true, line: op.line };
    }
    if (this.at('++') || this.at('--')) {
      const op = this.advance();
      return { kind: 'Unary', op: op.value, argument: this.parseUnary(), prefix: true, line: op.line };
    }
    return this.parsePostfix();
  }
  private parsePostfix(): Expr {
    let expr = this.parsePrimary();
    for (;;) {
      if (this.at('[')) {
        const line = this.advance().line;
        const index = this.parseExpression();
        this.expect(']');
        expr = { kind: 'Index', target: expr, index, line };
      } else if (this.at('.')) {
        const line = this.advance().line;
        const prop = this.atType('IDENT') || this.atType('KEYWORD') ? this.advance().value : '';
        if (this.at('(')) {
          this.advance();
          const args: Expr[] = [];
          while (!this.at(')') && !this.atType('EOF')) {
            args.push(this.parseExpression());
            if (this.at(',')) this.advance(); else break;
          }
          this.expect(')');
          expr = { kind: 'MemberCall', object: expr, property: prop, args, line };
        } else {
          expr = { kind: 'Member', object: expr, property: prop, line };
        }
      } else if (this.at('++') || this.at('--')) {
        const op = this.advance();
        expr = { kind: 'Unary', op: op.value, argument: expr, prefix: false, line: op.line };
      } else break;
    }
    return expr;
  }
  private parsePrimary(): Expr {
    const t = this.peek();
    if (t.type === 'NUMBER') { this.advance(); return { kind: 'Number', value: t.numValue ?? 0, line: t.line }; }
    if (t.type === 'STRING') { this.advance(); return { kind: 'Str', value: t.value, line: t.line }; }
    if (t.type === 'CHAR') { this.advance(); return { kind: 'Number', value: t.numValue ?? 0, line: t.line }; }
    if (t.type === 'KEYWORD' && (t.value === 'true' || t.value === 'false')) {
      this.advance();
      return { kind: 'Bool', value: t.value === 'true', line: t.line };
    }
    if (t.value === '(') {
      this.advance();
      const e = this.parseExpression();
      this.expect(')');
      return e;
    }
    if (t.value === '{') return this.parseArrayLiteral();
    if (t.type === 'IDENT' || t.type === 'KEYWORD') {
      this.advance();
      if (this.at('(')) {
        this.advance();
        const args: Expr[] = [];
        while (!this.at(')') && !this.atType('EOF')) {
          args.push(this.parseExpression());
          if (this.at(',')) this.advance(); else break;
        }
        this.expect(')');
        return { kind: 'Call', callee: t.value, args, line: t.line };
      }
      return { kind: 'Ident', name: t.value, line: t.line };
    }
    this.err(t.line, t.column, `Unexpected token '${t.value || '<eof>'}'`);
    this.advance();
    return { kind: 'Number', value: 0, line: t.line };
  }
}

export function parseSketch(source: string): ParseResult {
  return new Parser(source).parse();
}
