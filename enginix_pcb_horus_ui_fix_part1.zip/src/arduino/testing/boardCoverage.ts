// Arduino Coding Core — Board & Component Coverage Suite
//
// Cross-checks every supported board (Uno/arduino, arduinoNano, arduinoMega)
// against every relevant pin feature and Arduino-side component category
// requested for release validation: digital pins, analog pins, PWM, Servo,
// Relay, Motors (DC + Stepper), Pumps, Sensors (analog + digital + HC-SR04
// pulseIn), and misc PWM-driven peripherals (buzzer/RGB LED), plus a
// multi-tick Coding<->Simulator synchronization check per board.
//
// Pure, side-effect-free (no process.exit, no top-level execution) so it's
// safe for tsc's project-wide type-check and safe to import from a UI
// "Run self-test" action. Call runBoardCoverageSuite() to execute it.

// Extended validation: every board x every relevant component/pin feature.
// Read-only probe script - does not modify src/. Reports pass/fail per case.

import { ArduinoRuntime } from '../ArduinoRuntime';
import { CircuitPinIO, type BoardLike } from '../CircuitPinIO';

import type { TestResult } from './regression';

const tests: Array<{ name: string; run: () => void }> = [];
function record(name: string, run: () => void) { tests.push({ name, run }); }
function assertEqual(actual: unknown, expected: unknown, label: string) {
  if (actual !== expected) throw new Error(`${label}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}
function assertTrue(cond: boolean, label: string) { if (!cond) throw new Error(label); }

function fakeBoard(type: string): BoardLike { return { type, props: {}, state: {} }; }

const BOARDS = ['arduino', 'arduinoNano', 'arduinoMega'];
const PWM_PIN_FOR: Record<string,number> = { arduino: 9, arduinoNano: 9, arduinoMega: 44 };
const NON_PWM_DIGITAL_FOR: Record<string,number> = { arduino: 8, arduinoNano: 8, arduinoMega: 50 };
const MAX_DIGITAL_PIN: Record<string,number> = { arduino: 13, arduinoNano: 13, arduinoMega: 53 };

// --- 1. Digital pins on every board ---
for (const boardType of BOARDS) {
  record(`[${boardType}] digital OUTPUT write HIGH/LOW`, () => {
    const board = fakeBoard(boardType);
    const io = new CircuitPinIO(() => board);
    io.pinMode(7, 'OUTPUT');
    io.digitalWrite(7, 1);
    assertEqual(board.props.d7, true, 'HIGH');
    io.digitalWrite(7, 0);
    assertEqual(board.props.d7, false, 'LOW');
  });
  record(`[${boardType}] digital INPUT read via state.digitalValues`, () => {
    const board = fakeBoard(boardType);
    board.props.d7_mode = 'INPUT';
    board.state.digitalValues = { D7: true };
    const io = new CircuitPinIO(() => board);
    assertEqual(io.digitalRead(7), 1, 'digitalRead reflects sim state');
  });
  record(`[${boardType}] highest valid digital pin (${MAX_DIGITAL_PIN[boardType]}) works`, () => {
    const board = fakeBoard(boardType);
    const io = new CircuitPinIO(() => board);
    const p = MAX_DIGITAL_PIN[boardType];
    io.pinMode(p, 'OUTPUT');
    io.digitalWrite(p, 1);
    assertEqual(board.props[`d${p}`], true, `pin ${p} driven`);
  });
}

// --- 2. Analog pins (A0-A5) on every board via runtime sketch ---
for (const boardType of BOARDS) {
  record(`[${boardType}] analogRead(A0) via full sketch compile+run`, () => {
    const board = fakeBoard(boardType);
    const digitalCount = boardType === 'arduinoMega' ? 54 : 14;
    board.state.analogValues = { A0: 777 };
    const io = new CircuitPinIO(() => board);
    const rt = new ArduinoRuntime();
    const compiled = rt.compile(`
      int reading;
      void setup() {}
      void loop() { reading = analogRead(A0); }
    `);
    assertTrue(compiled.success, `compile failed: ${JSON.stringify(compiled.errors)}`);
    rt.attachPinIO(io);
    rt.start();
    rt.tick(2);
    assertEqual(io.analogRead(digitalCount), 777, 'A0 maps to digitalCount pin index for this board');
  });
}

// --- 3. PWM on every board's PWM-capable and non-PWM pins ---
for (const boardType of BOARDS) {
  const pwmPin = PWM_PIN_FOR[boardType];
  const nonPwmPin = NON_PWM_DIGITAL_FOR[boardType];
  record(`[${boardType}] analogWrite on PWM pin ${pwmPin} sets PWM mode+duty`, () => {
    const board = fakeBoard(boardType);
    const io = new CircuitPinIO(() => board);
    io.analogWrite(pwmPin, 200);
    assertEqual(board.props[`d${pwmPin}_mode`], 'PWM', 'mode');
    assertEqual(board.props[`d${pwmPin}_pwm`], 200, 'duty');
  });
  record(`[${boardType}] analogWrite on non-PWM pin ${nonPwmPin} falls back to digital`, () => {
    const board = fakeBoard(boardType);
    const io = new CircuitPinIO(() => board);
    io.analogWrite(nonPwmPin, 200);
    assertEqual(board.props[`d${nonPwmPin}_mode`], 'OUTPUT', 'mode falls back');
  });
}

// --- 4. Servo on every board ---
for (const boardType of BOARDS) {
  record(`[${boardType}] Servo.write(45) drives PWM duty proportionally`, () => {
    const board = fakeBoard(boardType);
    const io = new CircuitPinIO(() => board);
    const rt = new ArduinoRuntime();
    const compiled = rt.compile(`
      #include <Servo.h>
      Servo s;
      void setup() { s.attach(6); s.write(45); }
      void loop() {}
    `);
    assertTrue(compiled.success, `compile failed: ${JSON.stringify(compiled.errors)}`);
    rt.attachPinIO(io);
    rt.start();
    rt.tick(2);
    const duty = board.props.d6_pwm as number;
    assertEqual(Math.round((duty/255)*180), 45, 'servo angle round-trips');
  });
}

// --- 5. Relay (digital output component driven by relay module IN pin) ---
for (const boardType of BOARDS) {
  record(`[${boardType}] Relay module IN pin driven HIGH/LOW via digitalWrite`, () => {
    const board = fakeBoard(boardType);
    const io = new CircuitPinIO(() => board);
    io.pinMode(4, 'OUTPUT');
    io.digitalWrite(4, 1);
    assertEqual(board.props.d4, true, 'relay energized (active-high IN pin)');
    io.digitalWrite(4, 0);
    assertEqual(board.props.d4, false, 'relay de-energized');
  });
}

// --- 6. Motors (DC motor via PWM, L293D/L298N direction pins via digital) ---
for (const boardType of BOARDS) {
  const pwmPin = PWM_PIN_FOR[boardType];
  record(`[${boardType}] DC motor speed via analogWrite (PWM) + direction pins via digitalWrite`, () => {
    const board = fakeBoard(boardType);
    const io = new CircuitPinIO(() => board);
    io.analogWrite(pwmPin, 180); // ENA speed
    io.pinMode(2, 'OUTPUT'); io.digitalWrite(2, 1); // IN1
    io.pinMode(3, 'OUTPUT'); io.digitalWrite(3, 0); // IN2
    assertEqual(board.props[`d${pwmPin}_pwm`], 180, 'ENA speed duty');
    assertEqual(board.props.d2, true, 'IN1 forward');
    assertEqual(board.props.d3, false, 'IN2 forward');
  });
  record(`[${boardType}] Stepper motor 4-wire coil sequence via Stepper library`, () => {
    const board = fakeBoard(boardType);
    const io = new CircuitPinIO(() => board);
    const rt = new ArduinoRuntime();
    const compiled = rt.compile(`
      #include <Stepper.h>
      Stepper st(200, 2, 3, 4, 5);
      void setup() { st.setSpeed(60); st.step(4); }
      void loop() {}
    `);
    assertTrue(compiled.success, `compile failed: ${JSON.stringify(compiled.errors)}`);
    rt.attachPinIO(io);
    rt.start();
    rt.tick(2); rt.tick(10);
    const anyDriven = [2,3,4,5].some(p => board.props[`d${p}`] !== undefined);
    assertTrue(anyDriven, 'stepper coil pins driven');
  });
}

// --- 7. Pumps (water pump - same drive mechanism as DC motor, PWM or relay-switched) ---
for (const boardType of BOARDS) {
  const pwmPin = PWM_PIN_FOR[boardType];
  record(`[${boardType}] Water pump driven via PWM (variable flow) and plain digital (on/off via relay)`, () => {
    const board = fakeBoard(boardType);
    const io = new CircuitPinIO(() => board);
    io.analogWrite(pwmPin, 255); // full flow
    assertEqual(board.props[`d${pwmPin}_pwm`], 255, 'pump PWM full duty');
    io.pinMode(5, 'OUTPUT'); io.digitalWrite(5, 1); // relay-switched on/off pump
    assertEqual(board.props.d5, true, 'pump relay switched on');
  });
}

// --- 8. Sensors: analog (LM35, LDR, MQ-2, potentiometer, flame) + digital (PIR, IR obstacle) + HC-SR04 pulseIn ---
for (const boardType of BOARDS) {
  const digitalCount = boardType === 'arduinoMega' ? 54 : 14;
  record(`[${boardType}] Analog sensor (LM35/LDR/MQ-2/flame) read via analogRead`, () => {
    const board = fakeBoard(boardType);
    board.state.analogValues = { A0: 342 };
    const io = new CircuitPinIO(() => board);
    assertEqual(io.analogRead(digitalCount), 342, 'sensor ADC value read');
  });
  record(`[${boardType}] Digital sensor (PIR/IR obstacle) read via digitalRead`, () => {
    const board = fakeBoard(boardType);
    board.props.d2_mode = 'INPUT';
    board.state.digitalValues = { D2: true };
    const io = new CircuitPinIO(() => board);
    assertEqual(io.digitalRead(2), 1, 'PIR motion detected HIGH');
  });
  record(`[${boardType}] HC-SR04 ultrasonic via trigger pulse + pulseIn echo`, () => {
    const board = fakeBoard(boardType);
    // Simulate echo pin going HIGH immediately and LOW after ~5 ticks (crude, since fakeBoard has no real physics)
    const io = new CircuitPinIO(() => board);
    const rt = new ArduinoRuntime();
    const compiled = rt.compile(`
      long duration;
      void setup() { pinMode(7, OUTPUT); pinMode(8, INPUT); }
      void loop() {
        digitalWrite(7, HIGH);
        delayMicroseconds(10);
        digitalWrite(7, LOW);
        duration = pulseIn(8, HIGH, 5000);
      }
    `);
    assertTrue(compiled.success, `compile failed: ${JSON.stringify(compiled.errors)}`);
    rt.attachPinIO(io);
    rt.start();
    // Drive echo pin state directly through board.state to emulate the sim
    board.state.digitalValues = { D8: false };
    rt.tick(1);
    assertEqual(rt.getStatus(), 'running', 'pulseIn does not crash or hang the runtime while waiting/timing out');
  });
}

// --- 9. Buzzer / RGB LED / Neopixel / LCD / OLED / 7-segment (digital + PWM combos) ---
for (const boardType of BOARDS) {
  const pwmPin = PWM_PIN_FOR[boardType];
  record(`[${boardType}] Passive buzzer via tone()/noTone() (PWM-based)`, () => {
    const board = fakeBoard(boardType);
    const io = new CircuitPinIO(() => board);
    const rt = new ArduinoRuntime();
    const compiled = rt.compile(`
      void setup() { tone(${pwmPin}, 440); }
      void loop() {}
    `);
    assertTrue(compiled.success, `compile failed: ${JSON.stringify(compiled.errors)}`);
    rt.attachPinIO(io);
    rt.start();
    rt.tick(2);
    assertTrue((board.props[`d${pwmPin}_pwm`] as number) > 0, 'tone() drives PWM duty for buzzer pitch');
  });
  record(`[${boardType}] RGB LED via 3x analogWrite PWM channels`, () => {
    const board = fakeBoard(boardType);
    const io = new CircuitPinIO(() => board);
    const pins = boardType === 'arduinoMega' ? [44, 45, 46] : [9, 10, 11];
    io.analogWrite(pins[0], 255); io.analogWrite(pins[1], 0); io.analogWrite(pins[2], 128);
    assertEqual(board.props[`d${pins[0]}_pwm`], 255, 'R channel');
    assertEqual(board.props[`d${pins[1]}_pwm`], 0, 'G channel');
    assertEqual(board.props[`d${pins[2]}_pwm`], 128, 'B channel');
  });
}

// --- 10. Coding <-> Simulator sync: rapid multi-tick consistency across a mixed sketch ---
for (const boardType of BOARDS) {
  record(`[${boardType}] Coding workspace stays synchronized with simulator across many ticks (mixed I/O sketch)`, () => {
    const board = fakeBoard(boardType);
    const pwmPin = PWM_PIN_FOR[boardType];
    const io = new CircuitPinIO(() => board);
    const rt = new ArduinoRuntime();
    const compiled = rt.compile(`
      int b = 0;
      void setup() { pinMode(2, OUTPUT); }
      void loop() {
        digitalWrite(2, b % 2);
        analogWrite(${pwmPin}, b);
        b = (b + 25) % 256;
        delay(1);
      }
    `);
    assertTrue(compiled.success, `compile failed: ${JSON.stringify(compiled.errors)}`);
    rt.attachPinIO(io);
    rt.start();
    const seenPwm = new Set<number>();
    for (let i = 0; i < 12; i++) { rt.tick(1); seenPwm.add(board.props[`d${pwmPin}_pwm`] as number); }
    assertTrue(seenPwm.size > 3, `expected multiple distinct PWM values across ticks, got ${seenPwm.size}`);
    assertEqual(rt.getStatus(), 'running', 'runtime stable throughout');
  });
}


export function runBoardCoverageSuite(): TestResult[] {
  return tests.map(({ name, run }) => {
    try {
      run();
      return { name, passed: true };
    } catch (e) {
      return { name, passed: false, message: (e as Error).message };
    }
  });
}
