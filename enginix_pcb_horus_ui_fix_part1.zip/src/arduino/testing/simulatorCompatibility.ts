// Arduino Coding Core — Simulator Compatibility Suite
//
// Verifies CircuitPinIO correctly bridges ArduinoRuntime to a board
// component, using the exact prop/state contract the (untouched) circuit
// simulator relies on: `d{n}_mode` / `d{n}` / `d{n}_pwm` props, and
// `state.digitalValues` / `state.analogValues`. This never touches
// /src/circuit - it fakes the board component's shape instead - so it can
// run headlessly and stays honest about what CircuitPinIO itself does,
// independent of the simulator's own (separately tested) electrical solve.
//
// Pure, side-effect-free (no process.exit, no top-level execution): call
// runSimulatorCompatibilitySuite() from the "Run self-test" action or a
// build step.

import { ArduinoRuntime } from '../ArduinoRuntime';
import { CircuitPinIO, type BoardLike } from '../CircuitPinIO';
import type { TestResult } from './regression';

function assertEqual(actual: unknown, expected: unknown, label: string) {
  if (actual !== expected) throw new Error(`${label}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}
function assertTrue(cond: boolean, label: string) {
  if (!cond) throw new Error(label);
}

function fakeBoard(type: string = 'arduino'): BoardLike {
  return { type, props: {}, state: {} };
}

function runToCompletion(rt: ArduinoRuntime, ticks = 5, dtMs = 2) {
  for (let i = 0; i < ticks; i++) rt.tick(dtMs);
}

const tests: Array<{ name: string; run: () => void }> = [];
function test(name: string, run: () => void) { tests.push({ name, run }); }

// --- Digital output components (LED, relay, buzzer, solenoid, etc.) -------
test('digitalWrite drives d{n}_mode=OUTPUT and d{n} immediately (LED / relay / solenoid / buzzer)', () => {
  const board = fakeBoard();
  const io = new CircuitPinIO(() => board);
  const rt = new ArduinoRuntime();
  const compiled = rt.compile(`
    void setup() { pinMode(8, OUTPUT); }
    void loop() { digitalWrite(8, HIGH); }
  `);
  assertTrue(compiled.success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  runToCompletion(rt);
  assertEqual(board.props.d8_mode, 'OUTPUT', 'pin 8 mode');
  assertEqual(board.props.d8, true, 'pin 8 value (drives LED/relay/buzzer/solenoid coil net HIGH)');
});

// --- PWM output (dimmable LED, DC motor speed, water pump, RGB channels) --
test('analogWrite on a PWM-capable pin sets PWM mode + duty (DC motor / water pump / RGB channel)', () => {
  const board = fakeBoard();
  const io = new CircuitPinIO(() => board);
  const rt = new ArduinoRuntime();
  const compiled = rt.compile(`
    void setup() { pinMode(9, OUTPUT); }
    void loop() { analogWrite(9, 128); }
  `);
  assertTrue(compiled.success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  runToCompletion(rt);
  assertEqual(board.props.d9_mode, 'PWM', 'pin 9 mode');
  assertEqual(board.props.d9_pwm, 128, 'pin 9 duty');
});

test('analogWrite on a non-PWM pin falls back to a crude digital split (documented hardware limitation)', () => {
  const board = fakeBoard();
  const io = new CircuitPinIO(() => board);
  io.analogWrite(8, 200);
  assertEqual(board.props.d8_mode, 'OUTPUT', 'pin 8 falls back to OUTPUT (not PWM-capable)');
  assertEqual(board.props.d8, true, 'duty > 127 reads as HIGH');
});

// --- Servo -----------------------------------------------------------------
test('Servo.write() reproduces the commanded angle via the simulator\'s duty<->angle decode', () => {
  const board = fakeBoard();
  const io = new CircuitPinIO(() => board);
  const rt = new ArduinoRuntime();
  const compiled = rt.compile(`
    #include <Servo.h>
    Servo myServo;
    void setup() { myServo.attach(6); myServo.write(90); }
    void loop() {}
  `);
  assertTrue(compiled.success, `compile failed: ${JSON.stringify(compiled.errors)}`);
  rt.attachPinIO(io);
  rt.start();
  runToCompletion(rt);
  assertEqual(board.props.d6_mode, 'PWM', 'servo pin goes into PWM mode');
  // Reverse the simulator's own decode: dutyFrac = pwm/255, angle = dutyFrac*180
  const duty = board.props.d6_pwm as number;
  const decodedAngle = Math.round((duty / 255) * 180);
  assertEqual(decodedAngle, 90, 'angle survives the encode/decode round-trip');
});

// --- Stepper motor (StepperPins helper in interpreter.ts) -------------------
test('Stepper step pins are driven as plain digital outputs', () => {
  const board = fakeBoard();
  const io = new CircuitPinIO(() => board);
  io.digitalWrite(2, 1);
  io.digitalWrite(3, 0);
  io.digitalWrite(4, 1);
  io.digitalWrite(5, 0);
  assertEqual(board.props.d2, true, 'stepper coil 1');
  assertEqual(board.props.d3, false, 'stepper coil 2');
  assertEqual(board.props.d4, true, 'stepper coil 3');
  assertEqual(board.props.d5, false, 'stepper coil 4');
});

// --- Sensors (analogRead-based: LM35, LDR, MQ-2, flame, potentiometer) -----
test('analogRead surfaces the board state.analogValues the simulator already computed for sensors', () => {
  const board = fakeBoard();
  board.state.analogValues = { A0: 512 };
  const io = new CircuitPinIO(() => board);
  const rt = new ArduinoRuntime();
  const compiled = rt.compile(`
    int reading;
    void setup() {}
    void loop() { reading = analogRead(A0); }
  `);
  assertTrue(compiled.success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();
  runToCompletion(rt);
  assertEqual(io.analogRead(14), 512, 'A0 (pin 14) reads the sensor-driven ADC value');
});

// --- analogRead live updates + A0-A5 coverage -------------------------------
// Regression guard for the reported bug: "analogRead(A0) always returns a
// constant value". CircuitPinIO.analogRead() itself has no cache/memo of any
// kind - every call re-reads board.state.analogValues fresh off whatever
// board object getBoard() currently returns (see CircuitPinIO.ts) - so if a
// sketch reads a constant value despite the wired source's voltage actually
// changing, it means the *board reference/state* handed to analogRead()
// wasn't refreshed between reads, not a bug in analogRead() itself. This
// test simulates that refresh explicitly (a fresh state.analogValues object
// each "tick", exactly as CircuitEditor.runSimulation()'s per-frame
// updateComponentState() clone does) and asserts every pin A0-A5 tracks the
// change on every read - i.e. this is the live-update contract analogRead()
// must uphold, not a one-shot static read.
test('analogRead(A0-A5) tracks live voltage changes on every call, not just the first (0V/2.5V/5V -> 0/512/1023)', () => {
  const board = fakeBoard();
  const io = new CircuitPinIO(() => board);
  const pins = ['A0', 'A1', 'A2', 'A3', 'A4', 'A5'];
  const arduinoPinFor = (label: string) => 14 + Number(label.slice(1));

  for (const label of pins) {
    const arduinoPin = arduinoPinFor(label);

    // 0V -> 0
    board.state.analogValues = { [label]: 0 };
    assertEqual(io.analogRead(arduinoPin), 0, `${label} at 0V should read 0`);

    // 2.5V (mid-scale, 5V reference) -> ~512
    board.state.analogValues = { [label]: 512 };
    assertEqual(io.analogRead(arduinoPin), 512, `${label} at 2.5V should read ~512`);

    // 5V -> 1023
    board.state.analogValues = { [label]: 1023 };
    assertEqual(io.analogRead(arduinoPin), 1023, `${label} at 5V should read 1023`);

    // Simulates a live wiper sweep across several simulation "frames": a
    // brand-new state.analogValues object each time (matching
    // updateComponentState's `{ ...comp, state: {...} }` clone-per-tick
    // pattern), asserting analogRead reflects each one immediately with no
    // staleness/caching in between.
    const sweep = [0, 256, 512, 767, 1023];
    for (const expected of sweep) {
      board.state.analogValues = { [label]: expected }; // fresh object each "tick", old one discarded
      assertEqual(io.analogRead(arduinoPin), expected, `${label} should reflect this tick's value immediately (got stale/constant reading otherwise)`);
    }
  }
});

// --- analogRead via a running sketch, across multiple ticks with the -------
// --- board's analog value changing mid-run (not just injected once up front)
test('a running sketch\'s analogRead(A0) sees each tick\'s updated voltage, never freezing at the first value', () => {
  const board = fakeBoard();
  board.state.analogValues = { A0: 0 };
  const io = new CircuitPinIO(() => board);
  const rt = new ArduinoRuntime();
  const compiled = rt.compile(`
    int reading;
    void setup() {}
    void loop() { reading = analogRead(A0); }
  `);
  assertTrue(compiled.success, 'compile failed');
  rt.attachPinIO(io);
  rt.start();

  const sweep = [0, 256, 512, 767, 1023];
  for (const expected of sweep) {
    board.state.analogValues = { A0: expected }; // mimics a live wiper move between ticks
    rt.tick(2);
    assertEqual(io.analogRead(14), expected, `A0 mid-run should track the updated voltage (tick value ${expected})`);
  }
});

// --- Digital sensors (PIR, IR obstacle, pushbutton via INPUT_PULLUP) -------
test('digitalRead reflects state.digitalValues for an INPUT/INPUT_PULLUP pin (PIR / IR obstacle / button)', () => {
  const board = fakeBoard();
  board.props.d7_mode = 'INPUT_PULLUP';
  board.state.digitalValues = { D7: false }; // pulled to GND by the sensor/button
  const io = new CircuitPinIO(() => board);
  assertEqual(io.digitalRead(7), 0, 'reads LOW when the sensor/button pulls the pin down');
});

// --- ICs (74HC595 shift register, L293D/L298N direction pins, etc.) -------
test('Multiple simultaneous digital pins stay independently addressable (74HC595 / L293D-style multi-pin ICs)', () => {
  const board = fakeBoard();
  const io = new CircuitPinIO(() => board);
  io.pinMode(10, 'OUTPUT'); // latch
  io.pinMode(11, 'OUTPUT'); // clock
  io.pinMode(12, 'OUTPUT'); // data
  io.digitalWrite(10, 0);
  io.digitalWrite(11, 1);
  io.digitalWrite(12, 1);
  assertEqual(board.props.d10, false, 'latch pin independent');
  assertEqual(board.props.d11, true, 'clock pin independent');
  assertEqual(board.props.d12, true, 'data pin independent');
});

// --- pinMode / digitalWrite interplay (INPUT_PULLUP without explicit mode) -
test('digitalWrite(pin, HIGH) on an INPUT pin enables INPUT_PULLUP, matching real AVR behavior', () => {
  const board = fakeBoard();
  const io = new CircuitPinIO(() => board);
  io.pinMode(4, 'INPUT');
  io.digitalWrite(4, 1);
  assertEqual(board.props.d4_mode, 'INPUT_PULLUP', 'HIGH write to INPUT pin flips to INPUT_PULLUP');
});

// --- Board variants (Mega has more pins + a different PWM pin set) --------
test('Arduino Mega exposes 54 digital pins and its own PWM pin set', () => {
  const board = fakeBoard('arduinoMega');
  const io = new CircuitPinIO(() => board);
  io.analogWrite(44, 100); // PWM-capable on Mega, not on Uno/Nano
  assertEqual(board.props.d44_mode, 'PWM', 'Mega pin 44 supports PWM');
  io.analogWrite(50, 100); // not PWM-capable on Mega
  assertEqual(board.props.d50_mode, 'OUTPUT', 'Mega pin 50 falls back to digital');
});

test('Out-of-range pins are ignored rather than throwing (no simulator crashes)', () => {
  const board = fakeBoard();
  const io = new CircuitPinIO(() => board);
  io.digitalWrite(99, 1);
  io.pinMode(99, 'OUTPUT');
  io.analogWrite(99, 200);
  assertTrue(board.props.d99 === undefined, 'no prop created for an out-of-range pin');
});

test('Missing board (component removed/undo mid-run) is a silent no-op, not a crash', () => {
  const io = new CircuitPinIO(() => undefined);
  io.digitalWrite(8, 1);
  io.pinMode(8, 'OUTPUT');
  io.analogWrite(9, 200);
  assertEqual(io.digitalRead(8), 0, 'reads default 0 with no board attached');
  assertEqual(io.analogRead(14), 0, 'reads default 0 with no board attached');
});

// --- End-to-end: full ArduinoRuntime tick loop stays synchronized ---------
test('tick() keeps simulator state synchronized across multiple frames (PWM fade, like a breathing LED)', () => {
  const board = fakeBoard();
  const io = new CircuitPinIO(() => board);
  const rt = new ArduinoRuntime();
  const compiled = rt.compile(`
    int brightness = 0;
    void setup() { pinMode(9, OUTPUT); }
    void loop() {
      analogWrite(9, brightness);
      brightness = brightness + 51;
      if (brightness > 255) { brightness = 0; }
      delay(1);
    }
  `);
  assertTrue(compiled.success, `compile failed: ${JSON.stringify(compiled.errors)}`);
  rt.attachPinIO(io);
  rt.start();
  const seen: number[] = [];
  for (let i = 0; i < 8; i++) {
    rt.tick(1);
    seen.push(board.props.d9_pwm as number);
  }
  assertTrue(seen.some(v => v === 0), 'duty cycle reached 0 at some frame');
  assertTrue(seen.some(v => v === 51), 'duty cycle reached 51 at some frame');
  assertTrue(seen.some(v => v === 204), 'duty cycle reached 204 at some frame - values update every tick, in sync with the sketch');
});

export function runSimulatorCompatibilitySuite(): TestResult[] {
  return tests.map(({ name, run }) => {
    try {
      run();
      return { name, passed: true };
    } catch (e) {
      return { name, passed: false, message: (e as Error).message };
    }
  });
}
