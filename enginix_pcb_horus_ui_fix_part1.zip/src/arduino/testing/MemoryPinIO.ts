// Arduino Coding Core — MemoryPinIO
//
// A trivial, dependency-free PinIO used by the regression suite (and
// available for any embedder that wants to run a sketch headlessly, e.g.
// to validate it compiles/executes before wiring it to real hardware).
// Records every pinMode()/digitalWrite()/analogWrite() call and lets a test
// (or a future board integration) push simulated digitalRead()/analogRead()
// values in.

import type { PinIO, PinMode } from '../types';

export class MemoryPinIO implements PinIO {
  modes = new Map<number, PinMode>();
  digitalOut = new Map<number, 0 | 1>();
  analogOut = new Map<number, number>();
  private digitalIn = new Map<number, 0 | 1>();
  private analogIn = new Map<number, number>();
  writeHistory: Array<{ kind: 'digital' | 'analog' | 'mode'; pin: number; value: number | PinMode; atCall: number }> = [];
  private callCount = 0;

  pinMode(pin: number, mode: PinMode): void {
    this.modes.set(pin, mode);
    this.writeHistory.push({ kind: 'mode', pin, value: mode, atCall: this.callCount++ });
  }
  digitalWrite(pin: number, value: 0 | 1): void {
    this.digitalOut.set(pin, value);
    this.writeHistory.push({ kind: 'digital', pin, value, atCall: this.callCount++ });
  }
  digitalRead(pin: number): 0 | 1 {
    return this.digitalIn.get(pin) ?? 0;
  }
  analogWrite(pin: number, value: number): void {
    this.analogOut.set(pin, value);
    this.writeHistory.push({ kind: 'analog', pin, value, atCall: this.callCount++ });
  }
  analogRead(pin: number): number {
    return this.analogIn.get(pin) ?? 0;
  }

  /** Test/embedder hook: simulate an external signal driving a digital input pin. */
  setDigitalInput(pin: number, value: 0 | 1) { this.digitalIn.set(pin, value); }
  /** Test/embedder hook: simulate an external signal driving an analog input pin (0-1023). */
  setAnalogInput(pin: number, value: number) { this.analogIn.set(pin, value); }

  // --- Optional library hooks (Servo/Wire/SPI) — recorded for assertions ---
  servoAngles = new Map<number, number>();
  i2cWrites: Array<{ address: number; bytes: number[] }> = [];
  private i2cReadFixture = new Map<number, number[]>();
  spiTransferred: number[] = [];
  private spiEcho = true;

  servoWrite(pin: number, angleDeg: number): void { this.servoAngles.set(pin, angleDeg); }
  servoDetach(pin: number): void { this.servoAngles.delete(pin); }

  i2cWrite(address: number, bytes: number[]): void { this.i2cWrites.push({ address, bytes: [...bytes] }); }
  i2cRead(address: number, count: number): number[] {
    const fixture = this.i2cReadFixture.get(address);
    if (fixture) return fixture.slice(0, count);
    return new Array(count).fill(0);
  }
  /** Test hook: pre-load bytes a given I2C address will return via Wire.requestFrom(). */
  setI2CReadFixture(address: number, bytes: number[]) { this.i2cReadFixture.set(address, bytes); }

  spiTransfer(byte: number): number {
    this.spiTransferred.push(byte);
    return this.spiEcho ? byte : 0;
  }
}
