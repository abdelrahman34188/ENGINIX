// Arduino Coding Core — Lexer
//
// Tokenizes an Arduino sketch (a subset of C/C++). Handles line/block
// comments, the small set of preprocessor lines Arduino sketches commonly
// use (#include / #define), numbers (int/float/hex), strings, chars,
// identifiers/keywords, and operators.

export type TokenType =
  | 'NUMBER' | 'STRING' | 'CHAR' | 'IDENT' | 'KEYWORD'
  | 'PUNCT' | 'EOF';

export interface Token {
  type: TokenType;
  value: string;
  numValue?: number;
  line: number;
  column: number;
}

const KEYWORDS = new Set([
  'void', 'int', 'float', 'double', 'bool', 'boolean', 'char', 'byte',
  'long', 'short', 'unsigned', 'const', 'static', 'String',
  'if', 'else', 'for', 'while', 'do', 'return', 'break', 'continue',
  'true', 'false', 'struct',
]);

export interface LexResult {
  tokens: Token[];
  errors: { line: number; column: number; message: string }[];
}

/** Simple #define NAME VALUE macro expansion (textual, single-token value only). */
function expandDefines(src: string): string {
  const defines = new Map<string, string>();
  const lines = src.split('\n');
  const out: string[] = [];
  for (const line of lines) {
    const m = /^\s*#define\s+(\w+)\s+(.+?)\s*$/.exec(line);
    if (m) {
      defines.set(m[1], m[2]);
      out.push(''); // keep line numbering stable
      continue;
    }
    if (/^\s*#/.test(line)) {
      // #include or other directive we don't need to act on
      out.push('');
      continue;
    }
    out.push(line);
  }
  let joined = out.join('\n');
  if (defines.size > 0) {
    // Replace whole-word occurrences of each macro name with its value.
    for (const [name, value] of defines) {
      joined = joined.replace(new RegExp(`\\b${name}\\b`, 'g'), value);
    }
  }
  return joined;
}

export function tokenize(source: string): LexResult {
  const src = expandDefines(source);
  const tokens: Token[] = [];
  const errors: LexResult['errors'] = [];
  let i = 0;
  let line = 1;
  let col = 1;
  const n = src.length;

  const advance = (count = 1) => {
    for (let k = 0; k < count; k++) {
      if (src[i] === '\n') { line++; col = 1; } else { col++; }
      i++;
    }
  };

  const isDigit = (c: string) => c >= '0' && c <= '9';
  const isIdentStart = (c: string) => /[A-Za-z_]/.test(c);
  const isIdentPart = (c: string) => /[A-Za-z0-9_]/.test(c);

  while (i < n) {
    const c = src[i];

    if (c === ' ' || c === '\t' || c === '\r' || c === '\n') { advance(); continue; }

    // Line comment
    if (c === '/' && src[i + 1] === '/') {
      while (i < n && src[i] !== '\n') advance();
      continue;
    }
    // Block comment
    if (c === '/' && src[i + 1] === '*') {
      const startLine = line, startCol = col;
      advance(2);
      let closed = false;
      while (i < n) {
        if (src[i] === '*' && src[i + 1] === '/') { advance(2); closed = true; break; }
        advance();
      }
      if (!closed) errors.push({ line: startLine, column: startCol, message: 'Unterminated block comment' });
      continue;
    }

    const startLine = line, startCol = col;

    // Number: int, float, hex (0x..)
    if (isDigit(c) || (c === '.' && isDigit(src[i + 1] ?? ''))) {
      let s = '';
      if (c === '0' && (src[i + 1] === 'x' || src[i + 1] === 'X')) {
        s += src[i] + src[i + 1];
        advance(2);
        while (i < n && /[0-9a-fA-F]/.test(src[i])) { s += src[i]; advance(); }
        tokens.push({ type: 'NUMBER', value: s, numValue: parseInt(s, 16), line: startLine, column: startCol });
        continue;
      }
      while (i < n && isDigit(src[i])) { s += src[i]; advance(); }
      if (src[i] === '.') { s += src[i]; advance(); while (i < n && isDigit(src[i])) { s += src[i]; advance(); } }
      if (src[i] === 'e' || src[i] === 'E') {
        s += src[i]; advance();
        if (src[i] === '+' || src[i] === '-') { s += src[i]; advance(); }
        while (i < n && isDigit(src[i])) { s += src[i]; advance(); }
      }
      // Trailing type suffixes (100UL, 3.14f, etc.) — consume, ignore.
      while (i < n && /[uUlLfF]/.test(src[i])) advance();
      tokens.push({ type: 'NUMBER', value: s, numValue: parseFloat(s), line: startLine, column: startCol });
      continue;
    }

    // String literal
    if (c === '"') {
      advance();
      let s = '';
      while (i < n && src[i] !== '"') {
        if (src[i] === '\\' && i + 1 < n) {
          const esc = src[i + 1];
          const map: Record<string, string> = { n: '\n', t: '\t', r: '\r', '"': '"', '\\': '\\', '0': '\0' };
          s += map[esc] ?? esc;
          advance(2);
        } else {
          s += src[i];
          advance();
        }
      }
      if (i >= n) errors.push({ line: startLine, column: startCol, message: 'Unterminated string literal' });
      advance(); // closing quote
      tokens.push({ type: 'STRING', value: s, line: startLine, column: startCol });
      continue;
    }

    // Char literal
    if (c === "'") {
      advance();
      let ch = '';
      if (src[i] === '\\' && i + 1 < n) {
        const esc = src[i + 1];
        const map: Record<string, string> = { n: '\n', t: '\t', r: '\r', "'": "'", '\\': '\\', '0': '\0' };
        ch = map[esc] ?? esc;
        advance(2);
      } else {
        ch = src[i] ?? '';
        advance();
      }
      if (src[i] === "'") advance();
      else errors.push({ line: startLine, column: startCol, message: 'Unterminated char literal' });
      tokens.push({ type: 'CHAR', value: ch, numValue: ch.charCodeAt(0), line: startLine, column: startCol });
      continue;
    }

    // Identifier / keyword
    if (isIdentStart(c)) {
      let s = '';
      while (i < n && isIdentPart(src[i])) { s += src[i]; advance(); }
      tokens.push({ type: KEYWORDS.has(s) ? 'KEYWORD' : 'IDENT', value: s, line: startLine, column: startCol });
      continue;
    }

    // Operators / punctuation (longest match first)
    const threeChar = src.substr(i, 3);
    const twoChar = src.substr(i, 2);
    const THREE = ['<<=', '>>='];
    const TWO = ['==', '!=', '<=', '>=', '&&', '||', '++', '--', '+=', '-=', '*=', '/=', '%=', '<<', '>>', '&=', '|=', '^='];
    if (THREE.includes(threeChar)) {
      tokens.push({ type: 'PUNCT', value: threeChar, line: startLine, column: startCol });
      advance(3);
      continue;
    }
    if (TWO.includes(twoChar)) {
      tokens.push({ type: 'PUNCT', value: twoChar, line: startLine, column: startCol });
      advance(2);
      continue;
    }
    if ('+-*/%=<>!&|^~?:;,.(){}[]'.includes(c)) {
      tokens.push({ type: 'PUNCT', value: c, line: startLine, column: startCol });
      advance();
      continue;
    }

    errors.push({ line: startLine, column: startCol, message: `Unexpected character '${c}'` });
    advance();
  }

  tokens.push({ type: 'EOF', value: '', line, column: col });
  return { tokens, errors };
}
