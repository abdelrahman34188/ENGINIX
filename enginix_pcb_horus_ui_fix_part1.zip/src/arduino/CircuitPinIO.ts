// Arduino Coding Core — CircuitPinIO
//
// The board-facing PinIO implementation that connects a running sketch
// (ArduinoRuntime) to an Arduino/Mega/Nano board component sitting in the
// circuit simulator. This is the only file in /src/arduino that knows the
// board component's prop-naming convention (`d{n}_mode`, `d{n}`, `d{n}_pwm`,
// `state.digitalValues`, `state.analogValues`) - everything else in this
// subsystem stays hardware-and-simulator-agnostic, per the design goal in
// types.ts.
//
// Deliberately decoupled from the circuit/ module: rather than importing
// CircuitEditor or Component, this takes a plain `getBoard()` accessor
// returning anything with the shape it needs. That keeps /src/arduino
// import-free of /src/circuit (so it stays independently testable - see
// testing/simulatorCompatibility.ts) while still reading/writing the exact
// same live component object the simulator's own solve loop already reads
// every animation frame. Mutating its `props`/`state` here is enough for
// changes to take effect immediately: CircuitEditor's own render loop
// re-runs the electrical solve every frame regardless of what changed the
// props, so no explicit "push" back into the simulator is needed or wanted
// here (that would cross into simulator territory).

import type { PinIO, PinMode, PinComponentMapEntry, WiredComponentRef } from './types';

/** Minimal terminal shape needed for component-map lookups. */
export interface BoardTerminalLike {
  label: string;
  netId: number | null;
}

/** The minimal shape this adapter needs from a board component. */
export interface BoardLike {
  type: string; // 'arduino' | 'arduinoMega' | 'arduinoNano'
  props: Record<string, number | string | boolean>;
  state: Record<string, unknown>;
  // Optional richer shape, needed only for getComponentMap(). Real
  // Component objects already have these; a bare test fixture that omits
  // them simply gets an empty component map rather than an error.
  id?: number;
  label?: string;
  terminals?: BoardTerminalLike[];
}

/** Any other component on the canvas, as needed for component-map lookups. */
export interface WiredComponentLike {
  id: number;
  type: string;
  label: string;
  terminals: BoardTerminalLike[];
  // Optional richer shape, needed only for readDht(). Real Component
  // objects already carry these (same convention as BoardLike above); a
  // bare test fixture that omits them just means readDht() can't see that
  // component's live values.
  props?: Record<string, unknown>;
}

/** Everything getComponentMap() / readDht() needs beyond the board itself. */
export interface CircuitContext {
  /** Every component currently on the canvas (including the board - it's filtered out internally). */
  components: WiredComponentLike[];
  /** Net -> terminal-count map from the simulator's last solve (see SimulationResult.netTerminalCounts). */
  netTerminalCounts?: Map<number, number>;
  /** Net -> voltage map from the simulator's last solve (see SimulationResult.nodeVoltages). Used by readDht() to confirm a sensor is actually powered, not just wired. */
  nodeVoltages?: Map<number, number>;
}

// Where "analog pin 0" (A0) begins, per board - not a fixed global
// constant, because it can't be: a Mega has 54 real digital pins (0-53), so
// treating any pin >= 14 as analog would misclassify Mega's own digital
// pins 14-53 (including several of its PWM pins, e.g. 44-46) as analog.
// The boundary is exactly each board's own digital pin count, which also
// happens to match the fixed A0=14 given to Uno/Nano sketches in
// interpreter.ts's CONSTANTS table (Uno/Nano have exactly 14 digital pins).
// A Mega sketch that references the A0..A15 constants will therefore read
// them as digital pins 14-29 (which are real, valid Mega digital pins) -
// exact Mega analog-pin numbering (real hardware: A0=54) isn't
// representable without making the interpreter's constants board-aware,
// which is out of scope here; this is a documented limitation, not a
// silent miscalculation.
// Mirrors the real Uno/Nano/Mega PWM-capable pin sets used in
// componentDefs.ts. Duplicated here (rather than imported) to keep this
// file free of any /src/circuit dependency - these are fixed hardware
// facts, not simulator internals, so drift risk is low.
const PWM_PINS: Record<string, ReadonlySet<number>> = {
  arduino: new Set([3, 5, 6, 9, 10, 11]),
  arduinoNano: new Set([3, 5, 6, 9, 10, 11]),
  arduinoMega: new Set([2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 44, 45, 46]),
};

const DIGITAL_PIN_COUNT: Record<string, number> = {
  arduino: 14,
  arduinoNano: 14,
  arduinoMega: 54,
};

export class CircuitPinIO implements PinIO {
  constructor(
    private getBoard: () => BoardLike | undefined,
    // Optional: only needed for getComponentMap(). Omitting it (e.g. an
    // older call site, or a headless test) just means getComponentMap()
    // returns an empty list - digitalRead/Write and everything else here
    // are completely unaffected.
    private getContext?: () => CircuitContext | undefined,
  ) {}

  private digitalPinCount(board: BoardLike): number {
    return DIGITAL_PIN_COUNT[board.type] ?? 14;
  }

  private isValidDigitalPin(board: BoardLike, pin: number): boolean {
    return pin >= 0 && pin < this.digitalPinCount(board);
  }

  private isAnalogPin(board: BoardLike, pin: number): boolean {
    return pin >= this.digitalPinCount(board);
  }

  private analogIndex(board: BoardLike, pin: number): number {
    return this.isAnalogPin(board, pin) ? pin - this.digitalPinCount(board) : pin;
  }

  pinMode(pin: number, mode: PinMode): void {
    const board = this.getBoard();
    if (!board) return;
    // Analog-pin-as-digital-I/O isn't modeled by the simulator's board
    // component (it only exposes d{n}_mode props for D0..Dn); analogRead()
    // itself is unaffected by pinMode, so there's nothing to set.
    if (this.isAnalogPin(board, pin)) return;
    if (!this.isValidDigitalPin(board, pin)) return;
    board.props[`d${pin}_mode`] = mode;
  }

  digitalWrite(pin: number, value: 0 | 1): void {
    const board = this.getBoard();
    if (!board) return;
    if (this.isAnalogPin(board, pin) || !this.isValidDigitalPin(board, pin)) return;
    const mode = (board.props[`d${pin}_mode`] as string) || 'OUTPUT';
    // Matches real AVR behavior: digitalWrite(pin, HIGH) on an INPUT pin
    // enables the internal weak pull-up instead of driving the pin, and is
    // how most sketches actually set INPUT_PULLUP without an explicit
    // pinMode() call.
    if (mode === 'INPUT') {
      board.props[`d${pin}_mode`] = value ? 'INPUT_PULLUP' : 'INPUT';
      return;
    }
    if (mode === 'INPUT_PULLUP') return; // pin is an input; a plain digitalWrite() here doesn't turn it into an output on real hardware
    board.props[`d${pin}_mode`] = 'OUTPUT';
    board.props[`d${pin}`] = !!value;
  }

  digitalRead(pin: number): 0 | 1 {
    const board = this.getBoard();
    if (!board) return 0;
    if (this.isAnalogPin(board, pin)) {
      // Digital-read of an analog pin: threshold the ADC value at midscale,
      // the same 2.5V/1023-scale midpoint the board component itself uses
      // for its own digital pins.
      const analogValues = board.state.analogValues as Record<string, number> | undefined;
      const v = analogValues?.[`A${this.analogIndex(board, pin)}`] ?? 0;
      return v > 511 ? 1 : 0;
    }
    if (!this.isValidDigitalPin(board, pin)) return 0;
    const digitalValues = board.state.digitalValues as Record<string, boolean> | undefined;
    const label = `D${pin}`;
    if (digitalValues && label in digitalValues) return digitalValues[label] ? 1 : 0;
    // Pin isn't in INPUT/INPUT_PULLUP mode (the only modes the simulator
    // populates digitalValues for) - reading an OUTPUT pin on real hardware
    // just returns whatever it's currently being driven to.
    return board.props[`d${pin}`] ? 1 : 0;
  }

  analogWrite(pin: number, value: number): void {
    const board = this.getBoard();
    if (!board) return;
    if (this.isAnalogPin(board, pin) || !this.isValidDigitalPin(board, pin)) return;
    const duty = Math.max(0, Math.min(255, Math.round(value)));
    const pwmPins = PWM_PINS[board.type] ?? PWM_PINS.arduino;
    if (pwmPins.has(pin)) {
      board.props[`d${pin}_mode`] = 'PWM';
      board.props[`d${pin}_pwm`] = duty;
    } else {
      // analogWrite() on a non-PWM-capable pin is undefined behavior on
      // real hardware; the closest faithful approximation is a crude
      // digital HIGH/LOW split at mid-duty.
      board.props[`d${pin}_mode`] = 'OUTPUT';
      board.props[`d${pin}`] = duty > 127;
    }
  }

  analogRead(pin: number): number {
    const board = this.getBoard();
    if (!board) return 0;
    const analogValues = board.state.analogValues as Record<string, number> | undefined;
    return analogValues?.[`A${this.analogIndex(board, pin)}`] ?? 0;
  }

  // --- Servo -------------------------------------------------------------
  // Servo.write()/writeMicroseconds() report an angle here (see
  // interpreter.ts). The simulator's servoMotor component decodes its
  // driving pin's duty-cycle voltage (0-5V, from d{n}_pwm/PWM mode) linearly
  // back onto 0-180deg *regardless of its own minPulse/maxPulse props*
  // (those cancel out between encode and decode), so a plain
  // angle/180 * 255 duty reproduces the commanded angle exactly. Servos are
  // conventionally wired to whichever pin is convenient (software PWM), so
  // this bypasses analogWrite()'s PWM-capable-pin restriction on purpose.
  servoWrite(pin: number, angleDeg: number): void {
    const board = this.getBoard();
    if (!board) return;
    if (this.isAnalogPin(board, pin) || !this.isValidDigitalPin(board, pin)) return;
    const angle = Math.max(0, Math.min(180, angleDeg));
    board.props[`d${pin}_mode`] = 'PWM';
    board.props[`d${pin}_pwm`] = Math.round((angle / 180) * 255);
  }

  servoDetach(pin: number): void {
    const board = this.getBoard();
    if (!board) return;
    if (this.isAnalogPin(board, pin) || !this.isValidDigitalPin(board, pin)) return;
    board.props[`d${pin}_mode`] = 'INPUT';
  }

  // --- DHT11 / DHT22 -----------------------------------------------------
  // dht.readTemperature()/readHumidity() (see interpreter.ts) resolve here:
  // find whichever DHT sensor has its DATA pin on the same net as the
  // board pin the sketch declared (`DHT dht(pin, DHT11)`), and hand back
  // its live Properties-panel values — no bit-banging needed, matching how
  // the real DHT.h library hides the single-wire protocol from sketches.
  // Returns null (which the interpreter turns into NAN) whenever there's
  // no DHT wired to this pin, its DATA line isn't actually connected to
  // the board, or its VCC/GND aren't both wired to a live supply — i.e.
  // "disconnected or powered incorrectly", per the DHT.h contract.
  readDht(pin: number): { temperatureC: number; humidity: number } | null {
    const board = this.getBoard();
    if (!board || board.id === undefined || !board.terminals) return null;
    if (this.isAnalogPin(board, pin) || !this.isValidDigitalPin(board, pin)) return null;
    const boardTerminal = board.terminals.find(t => t.label === `D${pin}`);
    if (!boardTerminal || boardTerminal.netId === null) return null;

    const ctx = this.getContext?.();
    if (!ctx?.components) return null;
    const counts = ctx.netTerminalCounts;
    const voltages = ctx.nodeVoltages;

    // A net with only one terminal on it is floating — same "isWired"
    // convention getComponentMap() already uses.
    const isWired = (netId: number | null | undefined) =>
      netId !== null && netId !== undefined && (counts?.get(netId) ?? 0) > 1;

    for (const comp of ctx.components) {
      if (comp.type !== 'dht11' && comp.type !== 'dht22') continue;
      const terminals = comp.terminals; // VCC, DATA, NC, GND
      const dataTerm = terminals[1];
      if (!dataTerm || dataTerm.netId === null || dataTerm.netId !== boardTerminal.netId) continue;

      const vccTerm = terminals[0];
      const gndTerm = terminals[3];
      if (!isWired(vccTerm?.netId) || !isWired(gndTerm?.netId)) return null; // disconnected

      if (voltages) {
        const vccV = vccTerm.netId !== null ? (voltages.get(vccTerm.netId) ?? 0) : 0;
        const gndV = gndTerm.netId !== null ? (voltages.get(gndTerm.netId) ?? 0) : 0;
        // Needs a real supply across VCC/GND (real modules run on 3.3-5V);
        // anything close to 0V between them means it's powered incorrectly.
        if (Math.abs(vccV - gndV) < 2.5) return null;
      }

      if (comp.props?.enabled === false) return null;
      const isDht22 = comp.type === 'dht22';
      const tMin = isDht22 ? -40 : 0, tMax = isDht22 ? 80 : 50;
      const hMin = isDht22 ? 0 : 20, hMax = isDht22 ? 100 : 90;
      const temperatureC = Math.max(tMin, Math.min(tMax, (comp.props?.temperature as number) ?? 25));
      const humidity = Math.max(hMin, Math.min(hMax, (comp.props?.humidity as number) ?? 50));
      return { temperatureC, humidity };
    }
    return null; // no DHT wired to this pin
  }

  // --- Component map -------------------------------------------------------
  // Live wiring snapshot: for every one of the board's pins, which other
  // components (if any) are wired to it right now. Generic over component
  // type - it only ever looks at terminals/netId, so every existing and
  // future component in the simulator is supported automatically, with no
  // per-component-type code here. Returns [] rather than throwing whenever
  // the richer BoardLike/CircuitContext shape isn't available (e.g. a bare
  // test fixture, or no context accessor was given to the constructor).
  getComponentMap(): PinComponentMapEntry[] {
    const board = this.getBoard();
    if (!board || board.id === undefined || !board.terminals) return [];
    const ctx = this.getContext?.();

    const netIndex = new Map<number, WiredComponentRef[]>();
    if (ctx?.components) {
      for (const comp of ctx.components) {
        if (comp.id === board.id) continue; // don't list the board's own other pins as "connected components"
        for (const t of comp.terminals) {
          if (t.netId === null) continue;
          const refs = netIndex.get(t.netId) ?? [];
          refs.push({ type: comp.type, label: comp.label || comp.type, terminal: t.label });
          netIndex.set(t.netId, refs);
        }
      }
    }

    const counts = ctx?.netTerminalCounts;
    return board.terminals.map(t => ({
      label: t.label,
      // Same "isWired" convention used throughout simulator.ts: a net with
      // only one terminal on it is floating, not connected.
      connected: t.netId !== null && (counts?.get(t.netId) ?? 0) > 1,
      components: t.netId !== null ? (netIndex.get(t.netId) ?? []) : [],
    }));
  }
}
