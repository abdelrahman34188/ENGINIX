// Arduino Coding Core — ArduinoRuntime
//
// The single public entry point for this subsystem. Everything else in
// /src/arduino is an implementation detail this class hides.
//
//   const rt = new ArduinoRuntime();
//   const result = rt.compile(sketchSource);
//   if (result.success) {
//     rt.attachPinIO(myPinIO);
//     rt.start();
//     // once per animation frame / simulation tick:
//     rt.tick(dtMs);
//   }
//
// Design goals (per the Arduino Coding Core spec):
//  - setup() runs exactly once, to completion, before loop() ever starts.
//  - loop() re-runs indefinitely; delay()/delayMicroseconds() pause the
//    *virtual* clock without blocking the calling thread.
//  - A sketch that never calls delay() (a tight loop) cannot hang the host:
//    the interpreter's step budget forces a yield back to tick() regardless.
//  - Nothing in here ever throws back out to the caller — compile/runtime
//    errors are captured as diagnostics and surfaced via getDiagnostics()/
//    getStatus(), and tick() becomes a no-op once status is 'error' or
//    'stopped'. This is what "no simulator crashes" means for this engine.

import { parseSketch } from './parser';
import { Interpreter } from './interpreter';
import type { Diagnostic, PinComponentMapEntry, PinIO, RuntimeStatus, SerialEntry } from './types';

export interface CompileResult {
  success: boolean;
  errors: Diagnostic[];
  hasSetup: boolean;
  hasLoop: boolean;
}

export class ArduinoRuntime {
  private status: RuntimeStatus = 'idle';
  private interpreter: Interpreter | null = null;
  private pinIO: PinIO | null = null;
  private program: ReturnType<typeof parseSketch>['program'] = null;
  private diagnostics: Diagnostic[] = [];

  private setupGen: Generator<void, unknown, void> | null = null;
  private setupDone = false;
  private loopGen: Generator<void, unknown, void> | null = null;

  private stepBudget: number;
  constructor(opts: { stepBudget?: number } = {}) {
    this.stepBudget = opts.stepBudget ?? 20000;
  }

  compile(source: string): CompileResult {
    this.reset();
    let program: ReturnType<typeof parseSketch>['program'] = null;
    let errors: Diagnostic[];
    try {
      const result = parseSketch(source);
      program = result.program;
      errors = result.errors;
    } catch (e) {
      // parseSketch is documented to never throw, but this is the single
      // compile entry point every language buffer runs through, so it's
      // guarded anyway - a bug here should surface as a compile error, not
      // crash the editor.
      program = null;
      errors = [{ line: 1, column: 1, message: `Internal compiler error: ${(e as Error).message}`, severity: 'error' }];
    }
    this.program = program;
    this.diagnostics = errors;

    const programNode = program && program.kind === 'Program' ? program : null;
    const hasSetup = !!programNode?.functions.some(f => f.name === 'setup');
    const hasLoop = !!programNode?.functions.some(f => f.name === 'loop');
    if (!hasSetup) this.diagnostics.push({ line: 1, column: 1, message: "Sketch is missing a 'void setup()' function", severity: 'error' });
    if (!hasLoop) this.diagnostics.push({ line: 1, column: 1, message: "Sketch is missing a 'void loop()' function", severity: 'error' });

    // Non-fatal warnings: guarded independently so any bug here degrades to
    // "no warnings produced" rather than blocking compilation or crashing.
    try {
      if (programNode) {
        for (const fn of programNode.functions) {
          if ((fn.name === 'setup' || fn.name === 'loop') && fn.body.statements.length === 0) {
            this.diagnostics.push({
              line: 1,
              column: 1,
              message: `'${fn.name}()' is empty — it won't do anything`,
              severity: 'warning',
            });
          }
        }
      }
    } catch {
      // never let the warning pass affect compile success/failure
    }

    const success = this.diagnostics.filter(d => d.severity === 'error').length === 0;
    this.status = success ? 'compiled' : 'error';
    return { success, errors: this.diagnostics, hasSetup, hasLoop };
  }

  attachPinIO(pinIO: PinIO) { this.pinIO = pinIO; }

  /** Begins execution: builds the interpreter and queues setup() to run on the next tick(s). */
  start(): boolean {
    if (this.status !== 'compiled' && this.status !== 'stopped') return false;
    if (!this.program || this.program.kind !== 'Program' || !this.pinIO) {
      this.pushError('Cannot start: no compiled program or no PinIO attached');
      return false;
    }
    this.interpreter = new Interpreter(this.program, {
      pinIO: this.pinIO,
      stepBudget: this.stepBudget,
      onDiagnostic: (d) => this.diagnostics.push(d),
    });
    try {
      this.interpreter.initGlobals(this.program.globals);
    } catch (e) {
      this.pushError(`Failed to initialize global variables: ${(e as Error).message}`);
      return false;
    }
    this.setupDone = false;
    this.setupGen = this.interpreter.callNamed('setup');
    this.loopGen = null;
    this.status = 'running';
    return true;
  }

  stop() {
    this.status = 'stopped';
    this.setupGen = null;
    this.loopGen = null;
  }

  reset() {
    this.status = 'idle';
    this.interpreter = null;
    this.program = null;
    this.diagnostics = [];
    this.setupGen = null;
    this.setupDone = false;
    this.loopGen = null;
  }

  getStatus(): RuntimeStatus { return this.status; }
  getDiagnostics(): Diagnostic[] { return this.diagnostics; }
  getSerialLog(): SerialEntry[] { return this.interpreter?.serialLog ?? []; }
  getMillis(): number { return this.interpreter ? Math.floor(this.interpreter.clockMillis) : 0; }
  /** Live wiring snapshot from the attached PinIO, if it supports one (see PinIO.getComponentMap). Empty when not attached or not supported. */
  getComponentMap(): PinComponentMapEntry[] { return this.pinIO?.getComponentMap?.() ?? []; }

  /**
   * Advances the virtual clock by dtMs and runs as much of setup()/loop()
   * as the step budget allows. Safe to call every animation frame; safe to
   * call with large or irregular dt (e.g. after a tab was backgrounded).
   */
  tick(dtMs: number): void {
    if (this.status !== 'running' || !this.interpreter) return;
    this.interpreter.clockMillis += Math.max(0, dtMs);

    try {
      if (!this.setupDone) {
        if (!this.setupGen) { this.setupDone = true; }
        else {
          const r = this.setupGen.next();
          if (r.done) { this.setupDone = true; this.setupGen = null; }
          else return; // setup() yielded (e.g. mid-delay); resume next tick
        }
      }
      // Run loop() iterations until this tick's time/step budget is spent.
      // A fresh generator is created per iteration since loop() re-enters
      // from the top each time, exactly like real Arduino firmware.
      let guardIterations = 0;
      for (;;) {
        if (guardIterations++ > 10000) return; // extreme case: thousands of zero-cost loop() calls in one tick
        if (!this.loopGen) this.loopGen = this.interpreter.callNamed('loop');
        const r = this.loopGen.next();
        if (r.done) { this.loopGen = null; continue; } // loop() finished instantly (no delay) -> re-enter immediately
        return; // loop() yielded (delay in progress, or step budget hit) -> resume next tick
      }
    } catch (e) {
      this.pushError(`Runtime error: ${(e as Error).message}`);
      this.status = 'error';
    }
  }

  private pushError(message: string) {
    this.diagnostics.push({ line: 1, column: 1, message, severity: 'error' });
    this.status = 'error';
  }
}
