// Arduino Coding Core — shared types
//
// This subsystem is intentionally self-contained: it has no imports from
// /src/circuit, /src/pcb, or any other existing system, and nothing outside
// /src/arduino imports it (yet). It exposes a small, stable surface
// (ArduinoRuntime + PinIO) that a future integration point can wire into a
// board component without this subsystem needing to know about wires,
// nets, or the circuit solver.

export type PinMode = 'INPUT' | 'OUTPUT' | 'INPUT_PULLUP';

/** Arduino runtime values. Arrays are mutable (pass-by-reference, like C). */
export type ArduinoValue = number | string | boolean | ArduinoValue[] | undefined;

export interface Diagnostic {
  line: number;
  column: number;
  message: string;
  severity: 'error' | 'warning';
}

/** One other component wired to a given pin, as reported by getComponentMap(). */
export interface WiredComponentRef {
  /** Component type as used internally by the simulator, e.g. 'led', 'servoMotor'. Opaque here. */
  type: string;
  /** Display label as shown on the canvas. */
  label: string;
  /** Which terminal of that component is wired here, e.g. 'Anode', 'Signal'. */
  terminal: string;
}

/** What (if anything) is wired to one of the board's pins right now. */
export interface PinComponentMapEntry {
  /** Board terminal label, e.g. 'D13', 'A0', 'GND', '5V'. */
  label: string;
  /** True if this pin is actually wired to something. */
  connected: boolean;
  /** Every other component sharing this pin's net (empty if unconnected). */
  components: WiredComponentRef[];
}

/**
 * The board-facing side of the engine. Anything that wants to actually run
 * a sketch against real hardware/simulated hardware implements this and
 * passes it to ArduinoRuntime.attachPinIO(). A no-op/in-memory
 * implementation (see MemoryPinIO) is used for headless testing.
 */
export interface PinIO {
  pinMode(pin: number, mode: PinMode): void;
  digitalWrite(pin: number, value: 0 | 1): void;
  digitalRead(pin: number): 0 | 1;
  analogWrite(pin: number, value: number): void; // 0-255 PWM duty
  analogRead(pin: number): number; // 0-1023

  // --- Optional library-facing hooks -------------------------------------
  // All optional so any existing PinIO implementation (real or test) keeps
  // working untouched (no regressions). A board/simulator that wants richer
  // visuals (a servo horn rotating, an I2C/SPI bus trace) can implement
  // these; when absent, the library still behaves correctly by falling back
  // to the plain digital/analog primitives above.

  /** Servo.write()/writeMicroseconds() report the commanded angle (0-180) here. */
  servoWrite?(pin: number, angleDeg: number): void;
  /** Servo.detach() notification, for simulators that want to stop drawing a horn. */
  servoDetach?(pin: number): void;

  /** I2C: master -> slave byte write, address is the 7-bit device address. */
  i2cWrite?(address: number, bytes: number[]): void;
  /** I2C: master requests `count` bytes from a slave; return what the slave has. */
  i2cRead?(address: number, count: number): number[];

  /** SPI: full-duplex single-byte transfer; return the byte shifted in. */
  spiTransfer?(byte: number): number;

  /**
   * DHT11/DHT22 library support (DHT.h's `dht.readTemperature()` /
   * `dht.readHumidity()`): returns the live reading of whichever DHT
   * sensor is wired to this pin's DATA line right now, or null if no DHT
   * is wired there, or the sensor is disconnected/unpowered — the
   * interpreter turns a null here into NAN, matching the real library.
   */
  readDht?(pin: number): { temperatureC: number; humidity: number } | null;

  /**
   * Live snapshot of which simulator components are wired to each of the
   * board's pins right now (digital, analog, and power/GND/AREF/RESET).
   * Purely a diagnostics/introspection channel - the interpreter never
   * calls this itself, so its absence (e.g. MemoryPinIO in tests) changes
   * no sketch behavior. Implemented by CircuitPinIO for boards placed in
   * the Circuit Simulator.
   */
  getComponentMap?(): PinComponentMapEntry[];
}

export type RuntimeStatus = 'idle' | 'compiled' | 'running' | 'error' | 'stopped';

export interface SerialEntry {
  text: string;
  atMillis: number;
  /** Monotonically increasing across a run, independent of the entry's
   * position in the (capped, shifting) serial log array. Lets consumers
   * (e.g. the Serial Monitor's Clear button) mark "everything up to here
   * as cleared" without depending on array indices that move as old
   * entries get trimmed off the front once the buffer limit is hit. */
  seq: number;
}
