/**
 * PCB Editor - Pick & Place (centroid) export
 * Standard CSV shape most assembly houses (JLCPCB, PCBWay, etc.) accept:
 * Designator, Footprint, Mid X, Mid Y, Layer, Rotation.
 * Origin matches the Gerber/drill export - board-space mm, top-left of
 * the board at (0,0).
 */

import type { PCBState } from './types';
import { FOOTPRINTS } from './footprints';

export interface PickPlaceRow {
  refDes: string;
  footprint: string;
  x: number;
  y: number;
  layer: 'top' | 'bottom';
  rotation: number;
}

export function buildPickPlace(state: PCBState): PickPlaceRow[] {
  const rows: PickPlaceRow[] = [];
  for (const comp of state.components) {
    const fp = FOOTPRINTS[comp.footprint];
    if (!fp) continue;
    rows.push({
      refDes: comp.refDes,
      footprint: fp.type,
      x: comp.x,
      y: comp.y,
      layer: comp.side,
      rotation: comp.rotation,
    });
  }
  return rows.sort((a, b) => a.refDes.localeCompare(b.refDes, undefined, { numeric: true }));
}

function csvEscape(v: string): string {
  if (/[",\n]/.test(v)) return `"${v.replace(/"/g, '""')}"`;
  return v;
}

export function pickPlaceToCSV(state: PCBState): string {
  const rows = buildPickPlace(state);
  const header = ['Designator', 'Footprint', 'Mid X (mm)', 'Mid Y (mm)', 'Layer', 'Rotation (deg)'];
  const lines = [header.join(',')];
  for (const r of rows) {
    lines.push([
      csvEscape(r.refDes),
      csvEscape(r.footprint),
      r.x.toFixed(4),
      r.y.toFixed(4),
      r.layer === 'top' ? 'Top' : 'Bottom',
      String(r.rotation),
    ].join(','));
  }
  return lines.join('\n') + '\n';
}
