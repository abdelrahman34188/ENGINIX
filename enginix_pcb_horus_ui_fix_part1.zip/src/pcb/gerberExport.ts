/**
 * Gerber (RS-274X) + Excellon drill export.
 * Produces a real, importable (if simplified) fabrication set:
 *   board.gtl  - top copper
 *   board.gbl  - bottom copper
 *   board.gko  - board outline (Edge.Cuts)
 *   board.drl  - Excellon drill file (plated through-holes + vias)
 * Bundled into a single .zip via a dependency-free zip writer.
 */

import type { PCBState, Side } from './types';
import { FOOTPRINTS } from './footprints';
import { padAbsolutePos } from './geometry';
import { buildZip } from './zip';

// RS-274X coordinates: format %FSLAX34Y34*% => 3 integer digits, 4 decimal
// digits, leading-zero suppression. We encode mm as integer 1/10000ths.
function coord(mm: number): string {
  return String(Math.round(mm * 10000));
}

function gerberHeader(layerName: string): string {
  return [
    '%FSLAX34Y34*%',
    '%MOMM*%',
    `%LN${layerName}*%`,
    '%LPD*%',
    'G01*',
  ].join('\n') + '\n';
}

interface Aperture { code: number; diameterMm: number; }

function collectApertures(diameters: number[]): { list: Aperture[]; lookup: (d: number) => number } {
  const unique = Array.from(new Set(diameters.map(d => Math.round(d * 1000) / 1000))).sort((a, b) => a - b);
  const list: Aperture[] = unique.map((d, i) => ({ code: 10 + i, diameterMm: d }));
  const lookup = (d: number) => {
    const rd = Math.round(d * 1000) / 1000;
    const found = list.find(a => Math.abs(a.diameterMm - rd) < 0.0005);
    return found ? found.code : list[0].code;
  };
  return { list, lookup };
}

function apertureDefs(list: Aperture[]): string {
  return list.map(a => `%ADD${a.code}C,${a.diameterMm.toFixed(4)}*%`).join('\n') + '\n';
}

function copperLayerGerber(state: PCBState, layer: Side): string {
  const traceWidths = state.traces.filter(t => t.layer === layer).map(t => t.width);
  const padDiameters: number[] = [];
  for (const comp of state.components) {
    const fp = FOOTPRINTS[comp.footprint];
    if (!fp) continue;
    for (const pad of fp.pads) {
      // Through-hole pads (have drill) appear on both copper layers.
      if (pad.drill) padDiameters.push(Math.max(pad.width, pad.height));
    }
  }
  const viaDiameters = state.vias.map(v => v.size);
  const allDiameters = [...traceWidths, ...padDiameters, ...viaDiameters];
  if (allDiameters.length === 0) allDiameters.push(0.25);

  const { list, lookup } = collectApertures(allDiameters);

  let body = '';

  for (const trace of state.traces) {
    if (trace.layer !== layer || trace.points.length < 2) continue;
    const dcode = lookup(trace.width);
    body += `D${dcode}*\n`;
    trace.points.forEach((p, i) => {
      body += `X${coord(p.x)}Y${coord(p.y)}D${i === 0 ? '02' : '01'}*\n`;
    });
  }

  for (const comp of state.components) {
    const fp = FOOTPRINTS[comp.footprint];
    if (!fp) continue;
    for (const pad of fp.pads) {
      if (!pad.drill) continue; // SMD pads not modeled on the opposite layer
      const abs = padAbsolutePos(comp, pad);
      const dcode = lookup(Math.max(pad.width, pad.height));
      body += `D${dcode}*\nX${coord(abs.x)}Y${coord(abs.y)}D03*\n`;
    }
  }

  for (const via of state.vias) {
    const dcode = lookup(via.size);
    body += `D${dcode}*\nX${coord(via.x)}Y${coord(via.y)}D03*\n`;
  }

  return gerberHeader(layer === 'top' ? 'F.Cu' : 'B.Cu') + apertureDefs(list) + body + 'M02*\n';
}

function outlineGerber(state: PCBState): string {
  const w = state.board.width, h = state.board.height;
  const dcode = 10;
  const body =
    `%ADD${dcode}C,0.1000*%\n` +
    `D${dcode}*\n` +
    `X${coord(0)}Y${coord(0)}D02*\n` +
    `X${coord(w)}Y${coord(0)}D01*\n` +
    `X${coord(w)}Y${coord(h)}D01*\n` +
    `X${coord(0)}Y${coord(h)}D01*\n` +
    `X${coord(0)}Y${coord(0)}D01*\n`;
  return gerberHeader('Edge.Cuts') + body + 'M02*\n';
}

function excellonDrill(state: PCBState): string {
  const holes: { x: number; y: number; drill: number }[] = [];
  for (const comp of state.components) {
    const fp = FOOTPRINTS[comp.footprint];
    if (!fp) continue;
    for (const pad of fp.pads) {
      if (!pad.drill) continue;
      const abs = padAbsolutePos(comp, pad);
      holes.push({ x: abs.x, y: abs.y, drill: pad.drill });
    }
  }
  for (const via of state.vias) {
    holes.push({ x: via.x, y: via.y, drill: via.drill });
  }

  const sizes = Array.from(new Set(holes.map(h => Math.round(h.drill * 1000) / 1000))).sort((a, b) => a - b);
  const toolOf = new Map(sizes.map((s, i) => [s, i + 1]));

  let out = 'M48\n';
  out += 'METRIC,LZ\n';
  sizes.forEach((s, i) => {
    out += `T${String(i + 1).padStart(2, '0')}C${s.toFixed(3)}\n`;
  });
  out += '%\n';
  out += 'G90\n';

  let currentTool = -1;
  for (const hole of holes) {
    const tool = toolOf.get(Math.round(hole.drill * 1000) / 1000)!;
    if (tool !== currentTool) {
      out += `T${String(tool).padStart(2, '0')}\n`;
      currentTool = tool;
    }
    out += `X${hole.x.toFixed(3)}Y${hole.y.toFixed(3)}\n`;
  }
  out += 'M30\n';
  return out;
}

export function exportGerberZip(state: PCBState, fileName = 'pcb_gerbers.zip') {
  const files = [
    { name: 'board.gtl', data: copperLayerGerber(state, 'top') },
    { name: 'board.gbl', data: copperLayerGerber(state, 'bottom') },
    { name: 'board.gko', data: outlineGerber(state) },
    { name: 'board.drl', data: excellonDrill(state) },
    {
      name: 'README.txt',
      data:
        'Generated by ENGINIX PCB Editor.\n\n' +
        'board.gtl  Top copper (RS-274X)\n' +
        'board.gbl  Bottom copper (RS-274X)\n' +
        'board.gko  Board outline / Edge.Cuts (RS-274X)\n' +
        'board.drl  Plated drill holes (Excellon, metric)\n',
    },
  ];

  const blob = buildZip(files);
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  URL.revokeObjectURL(url);
}

// Same Gerber/drill file set as exportGerberZip, returned in-memory instead
// of triggering a download - used by exportFabricationZip below to fold
// them into one combined package alongside BOM/Pick&Place/DRC report.
export function buildGerberFileSet(state: PCBState): { name: string; data: string }[] {
  return [
    { name: 'gerber/board.gtl', data: copperLayerGerber(state, 'top') },
    { name: 'gerber/board.gbl', data: copperLayerGerber(state, 'bottom') },
    { name: 'gerber/board.gko', data: outlineGerber(state) },
    { name: 'gerber/board.drl', data: excellonDrill(state) },
  ];
}
