// @vitest-environment jsdom
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { PCBEngine } from './PCBEngine';
import type { ConvertResult } from './convertFromCircuit';

// PCBEngine drives a render loop off requestAnimationFrame and reads a 2D
// canvas context in its constructor. Neither is exercised by the
// import/net/auto-route logic under test, so both are stubbed out to keep
// these tests fast, deterministic, and free of a real paint loop.
function makeEngine(): PCBEngine {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({} as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  return new PCBEngine(canvas, container);
}

// RES_TH footprint pads are '1' and '2' (see footprints.ts axial2 helper) -
// used below so pins actually resolve to real pad positions. Component
// centers are placed on exact multiples of the 1.27mm routing grid (and
// the RES_TH pad offsets, +/-2.54mm, are themselves grid multiples) so the
// resulting pad positions land exactly on-grid with no snap() rounding -
// otherwise a snapped trace endpoint would sit a hair off the pad and the
// ratsnest would never be satisfied even after routing.
function resistorConvertResult(overrides?: Partial<ConvertResult>): ConvertResult {
  return {
    components: [
      { sourceComponentId: 1, footprint: 'RES_TH', refDes: 'R1', x: 12.7, y: 12.7, rotation: 0, props: {} },
      { sourceComponentId: 2, footprint: 'RES_TH', refDes: 'R2', x: 25.4, y: 12.7, rotation: 0, props: {} },
    ],
    netlist: [
      { id: 1, name: 'VCC', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R2', terminalLabel: '1' }] },
    ],
    unmapped: [],
    ...overrides,
  };
}

describe('PCBEngine simulator-wiring import', () => {
  let engine: PCBEngine;
  beforeEach(() => { engine = makeEngine(); });

  it('creates a PCB net for each imported netlist entry', () => {
    expect(engine.state.netlist).toEqual([]);
    engine.importFromCircuit(resistorConvertResult());
    expect(engine.state.netlist).toHaveLength(1);
  });

  it('preserves the net name from the simulator', () => {
    engine.importFromCircuit(resistorConvertResult());
    expect(engine.state.netlist![0].name).toBe('VCC');
  });

  it('preserves every electrical connection (pin membership) from the simulator', () => {
    engine.importFromCircuit(resistorConvertResult());
    const pins = engine.state.netlist![0].pins.map(p => `${p.refDes}.${p.terminalLabel}`).sort();
    expect(pins).toEqual(['R1.2', 'R2.1']);
  });

  it('appends to (never replaces) an existing netlist on repeated import', () => {
    engine.importFromCircuit(resistorConvertResult());
    const second: ConvertResult = {
      components: [
        { sourceComponentId: 3, footprint: 'RES_TH', refDes: 'R3', x: 30, y: 10, rotation: 0, props: {} },
        { sourceComponentId: 4, footprint: 'RES_TH', refDes: 'R4', x: 40, y: 10, rotation: 0, props: {} },
      ],
      netlist: [
        { id: 2, name: 'GND', pins: [{ refDes: 'R3', terminalLabel: '2' }, { refDes: 'R4', terminalLabel: '1' }] },
      ],
      unmapped: [],
    };
    engine.importFromCircuit(second);
    expect(engine.state.netlist).toHaveLength(2);
    expect(engine.state.netlist!.map(n => n.name).sort()).toEqual(['GND', 'VCC']);
  });

  it('produces a ratsnest line for an imported net with no copper yet', () => {
    engine.importFromCircuit(resistorConvertResult());
    const lines = engine.getRatsnestLines();
    expect(lines).toHaveLength(1);
    expect(lines[0].netId).toBe(1);
  });

  it('auto-router uses the imported nets to draw copper', () => {
    engine.importFromCircuit(resistorConvertResult());
    expect(engine.state.traces).toHaveLength(0);

    const result = engine.autoRoute();

    expect(result.routed).toBe(1);
    expect(engine.state.traces).toHaveLength(1);
  });

  it('auto-router refuses to run when no nets have been imported', () => {
    const result = engine.autoRoute();
    expect(result.routed).toBe(0);
    expect(result.reason).toMatch(/no nets imported/i);
    expect(engine.state.traces).toHaveLength(0);
  });

  it('auto-router is idempotent: a second run finds nothing left to route', () => {
    engine.importFromCircuit(resistorConvertResult());
    engine.autoRoute();
    const secondRun = engine.autoRoute();
    expect(secondRun.routed).toBe(0);
    expect(secondRun.reason).toMatch(/already fully connected/i);
    expect(engine.state.traces).toHaveLength(1);
  });

  it('auto-routed copper satisfies the ratsnest (no dangling line remains for a routed net)', () => {
    engine.importFromCircuit(resistorConvertResult());
    engine.autoRoute();
    expect(engine.getRatsnestLines()).toHaveLength(0);
  });

  it('does not fabricate a connection for pins that reference a missing component', () => {
    const orphanNet: ConvertResult = {
      components: [
        { sourceComponentId: 5, footprint: 'RES_TH', refDes: 'R5', x: 10, y: 10, rotation: 0, props: {} },
      ],
      netlist: [
        // R6 was never placed on the board (e.g. its type was unmapped).
        { id: 3, name: 'SIG', pins: [{ refDes: 'R5', terminalLabel: '1' }, { refDes: 'R6', terminalLabel: '1' }] },
      ],
      unmapped: [],
    };
    engine.importFromCircuit(orphanNet);
    expect(engine.getRatsnestLines()).toHaveLength(0);

    const result = engine.autoRoute();
    expect(result.routed).toBe(0);
    expect(result.reason).toMatch(/missing component\/footprint/i);
  });
});
