// @vitest-environment jsdom
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { PCBEngine } from './PCBEngine';
import type { ConvertResult } from './convertFromCircuit';
import type { Trace } from './types';
import { segmentsIntersect } from './geometry';

function makeEngine(): PCBEngine {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({} as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  return new PCBEngine(canvas, container);
}

// RES_TH pads are '1' (-2.54, 0) and '2' (+2.54, 0) from the component
// center (see footprints.ts axial2 helper). Every x/y below is chosen as a
// multiple of 1.27mm (the routing grid) so snap() never nudges a pad
// position, keeping expected trace endpoints exact.
function resistor(sourceComponentId: number, refDes: string, x: number, y: number): ConvertResult['components'][number] {
  return { sourceComponentId, footprint: 'RES_TH', refDes, x, y, rotation: 0, props: {} };
}

describe('PCBEngine.autoRoute (improved router)', () => {
  let engine: PCBEngine;
  beforeEach(() => { engine = makeEngine(); });

  it('still routes a simple two-pin net and reports no unrouted nets', () => {
    const result: ConvertResult = {
      components: [resistor(1, 'R1', 12.7, 12.7), resistor(2, 'R2', 25.4, 12.7)],
      netlist: [{ id: 1, name: 'VCC', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R2', terminalLabel: '1' }] }],
      unmapped: [],
    };
    engine.importFromCircuit(result);
    const out = engine.autoRoute();
    expect(out.routed).toBe(1);
    expect(out.unrouted).toEqual([]);
    expect(out.reason).toBeUndefined();
  });

  it('picks the elbow orientation that crosses fewer existing traces', () => {
    // R1 at (0,0) -> pad '2' at (2.54, 0). R3 at (19.05,12.7) -> pad '1' at
    // (16.51, 12.7). A horizontal-first elbow's first leg runs along
    // y=0 from x=2.54 to x=16.51, which a pre-placed trace at y=0,
    // x in [5,15] would cross; a vertical-first elbow never touches it.
    const result: ConvertResult = {
      components: [resistor(1, 'R1', 0, 0), resistor(2, 'R3', 19.05, 12.7)],
      netlist: [{ id: 1, name: 'SIG', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R3', terminalLabel: '1' }] }],
      unmapped: [],
    };
    engine.importFromCircuit(result);

    const obstruction: Trace = { id: 999, layer: 'top', width: 0.4, points: [{ x: 5, y: 0 }, { x: 15, y: 0 }] };
    engine.state.traces.push(obstruction);

    const out = engine.autoRoute();
    expect(out.routed).toBe(1);

    const newTrace = engine.state.traces.find(t => t.id !== 999)!;
    expect(newTrace.points).toEqual([
      { x: 2.54, y: 0 },
      { x: 2.54, y: 12.7 },
      { x: 16.51, y: 12.7 },
    ]);
  });

  it('leaves a net unrouted (rather than routing copper through it) when every path is blocked by a foreign pad', () => {
    // R1 pad '2' at (2.54,0); R2 pad '1' at (16.51,0) - straight line
    // along y=0, the only candidate since both pads share y=0. R_OBS sits
    // exactly on that line and is not part of the net.
    const result: ConvertResult = {
      components: [
        resistor(1, 'R1', 0, 0),
        resistor(2, 'R2', 19.05, 0),
        resistor(3, 'R_OBS', 12.54, 0),
      ],
      netlist: [{ id: 1, name: 'BLOCKED', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R2', terminalLabel: '1' }] }],
      unmapped: [],
    };
    engine.importFromCircuit(result);

    const out = engine.autoRoute();
    expect(out.routed).toBe(0);
    expect(out.unrouted).toEqual([{ netId: 1, name: 'BLOCKED' }]);
    expect(out.reason).toMatch(/unrouted/i);
    expect(out.reason).toMatch(/BLOCKED/);
    expect(engine.state.traces).toHaveLength(0);
  });

  it('routes every completable net even when one net is blocked (partial completion, not all-or-nothing)', () => {
    const result: ConvertResult = {
      components: [
        resistor(1, 'R1', 0, 0),
        resistor(2, 'R2', 19.05, 0),
        resistor(3, 'R_OBS', 12.54, 0),
        resistor(4, 'R3', 12.7, 25.4),
        resistor(5, 'R4', 25.4, 25.4),
      ],
      netlist: [
        { id: 1, name: 'BLOCKED', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R2', terminalLabel: '1' }] },
        { id: 2, name: 'CLEAR', pins: [{ refDes: 'R3', terminalLabel: '2' }, { refDes: 'R4', terminalLabel: '1' }] },
      ],
      unmapped: [],
    };
    engine.importFromCircuit(result);

    const out = engine.autoRoute();
    expect(out.routed).toBe(1);
    expect(out.unrouted).toEqual([{ netId: 1, name: 'BLOCKED' }]);
    expect(engine.state.traces).toHaveLength(1);
  });

  it('routes shorter connections before longer ones in the same pass', () => {
    // Long net listed first in the netlist; short net second. If routing
    // still happened in netlist order the long trace would be added
    // first - instead the shorter one should land first.
    const result: ConvertResult = {
      components: [
        resistor(1, 'R_LONG_A', 0, 0),
        resistor(2, 'R_LONG_B', 63.5, 0),      // ~63mm apart
        resistor(3, 'R_SHORT_A', 0, 50.8),
        resistor(4, 'R_SHORT_B', 12.7, 50.8),  // ~7.6mm apart
      ],
      netlist: [
        { id: 1, name: 'LONG', pins: [{ refDes: 'R_LONG_A', terminalLabel: '2' }, { refDes: 'R_LONG_B', terminalLabel: '1' }] },
        { id: 2, name: 'SHORT', pins: [{ refDes: 'R_SHORT_A', terminalLabel: '2' }, { refDes: 'R_SHORT_B', terminalLabel: '1' }] },
      ],
      unmapped: [],
    };
    engine.importFromCircuit(result);

    const out = engine.autoRoute();
    expect(out.routed).toBe(2);
    // Both traces are aligned (straight lines), so each is a single segment.
    const firstTrace = engine.state.traces[0];
    const firstLen = Math.hypot(
      firstTrace.points[firstTrace.points.length - 1].x - firstTrace.points[0].x,
      firstTrace.points[firstTrace.points.length - 1].y - firstTrace.points[0].y,
    );
    const secondTrace = engine.state.traces[1];
    const secondLen = Math.hypot(
      secondTrace.points[secondTrace.points.length - 1].x - secondTrace.points[0].x,
      secondTrace.points[secondTrace.points.length - 1].y - secondTrace.points[0].y,
    );
    expect(firstLen).toBeLessThan(secondLen);
  });

  it('drops an automatic via to hop layers when neither elbow orientation is fully clear on either layer alone', () => {
    // R1 pad '2' at (2.54,0) -> R3 pad '1' at (16.51,12.7): needs an elbow.
    // Four obstruction traces are arranged so that the horizontal-first
    // elbow is blocked on top (its first leg) and on bottom (its second
    // leg), and the vertical-first elbow is likewise blocked on both
    // layers - but the *horizontal-first* elbow with its first leg on
    // bottom and second leg on top is completely clear. Neither "stay on
    // one layer" option works; only a layer hop clears it.
    const result: ConvertResult = {
      components: [resistor(1, 'R1', 0, 0), resistor(2, 'R3', 19.05, 12.7)],
      netlist: [{ id: 1, name: 'SIG', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R3', terminalLabel: '1' }] }],
      unmapped: [],
    };
    engine.importFromCircuit(result);

    engine.state.traces.push(
      // Top: blocks horizontal-first's leg1 (y=0, x 2.54..16.51) and
      // vertical-first's leg2 (y=12.7, x 2.54..16.51).
      { id: 991, layer: 'top', width: 0.4, points: [{ x: 5, y: 0 }, { x: 15, y: 0 }] },
      { id: 992, layer: 'top', width: 0.4, points: [{ x: 5, y: 12.7 }, { x: 15, y: 12.7 }] },
      // Bottom: blocks horizontal-first's leg2 (x=16.51, y 0..12.7) and
      // vertical-first's leg1 (x=2.54, y 0..12.7).
      { id: 993, layer: 'bottom', width: 0.4, points: [{ x: 10, y: 6 }, { x: 20, y: 6 }] },
      { id: 994, layer: 'bottom', width: 0.4, points: [{ x: 0, y: 6 }, { x: 10, y: 6 }] },
    );

    expect(engine.activeLayer).toBe('top');
    const obstructionIds = new Set([991, 992, 993, 994]);
    const out = engine.autoRoute();
    expect(out.routed).toBe(1);
    expect(out.unrouted).toEqual([]);

    // A via should have been dropped, splitting the connection across
    // both layers rather than shorting into any obstruction.
    expect(engine.state.vias).toHaveLength(1);
    const newTraces = engine.state.traces.filter(t => !obstructionIds.has(t.id));
    expect(newTraces).toHaveLength(2);
    expect(new Set(newTraces.map(t => t.layer))).toEqual(new Set(['top', 'bottom']));

    // The via sits at the elbow's bend (16.51, 0), joining the two legs.
    const via = engine.state.vias[0];
    expect({ x: via.x, y: via.y }).toEqual({ x: 16.51, y: 0 });
    const bottomLeg = newTraces.find(t => t.layer === 'bottom')!;
    const topLeg = newTraces.find(t => t.layer === 'top')!;
    expect(bottomLeg.points).toEqual([{ x: 2.54, y: 0 }, { x: 16.51, y: 0 }]);
    expect(topLeg.points).toEqual([{ x: 16.51, y: 0 }, { x: 16.51, y: 12.7 }]);

    // Neither leg crosses any obstruction on its own layer.
    const obstructionsByLayer = engine.state.traces.filter(t => obstructionIds.has(t.id));
    for (const leg of newTraces) {
      for (const obs of obstructionsByLayer.filter(o => o.layer === leg.layer)) {
        expect(segmentsIntersect(leg.points[0], leg.points[1], obs.points[0], obs.points[1])).toBe(false);
      }
    }
  });

  it('leaves a net unrouted when even a layer hop can\'t avoid a foreign pad (vias never route through someone else\'s pin)', () => {
    // Same setup as the foreign-pad test above: R_OBS sits on the only
    // straight-line path. Since R_OBS's pad is a through-hole pad (present
    // on both layers), no layer choice or via can dodge it - it should
    // stay unrouted, exactly like the single-layer case.
    const result: ConvertResult = {
      components: [
        resistor(1, 'R1', 0, 0),
        resistor(2, 'R2', 19.05, 0),
        resistor(3, 'R_OBS', 12.54, 0),
      ],
      netlist: [{ id: 1, name: 'BLOCKED', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R2', terminalLabel: '1' }] }],
      unmapped: [],
    };
    engine.importFromCircuit(result);

    const out = engine.autoRoute();
    expect(out.routed).toBe(0);
    expect(out.unrouted).toEqual([{ netId: 1, name: 'BLOCKED' }]);
    expect(engine.state.vias).toHaveLength(0);
    expect(engine.state.traces).toHaveLength(0);
  });

  it('does not add unnecessary bends for already axis-aligned pads', () => {
    const result: ConvertResult = {
      components: [resistor(1, 'R1', 0, 0), resistor(2, 'R2', 19.05, 0)],
      netlist: [{ id: 1, name: 'FLAT', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R2', terminalLabel: '1' }] }],
      unmapped: [],
    };
    engine.importFromCircuit(result);
    engine.autoRoute();
    expect(engine.state.traces[0].points).toHaveLength(2);
  });
});
