// @vitest-environment jsdom
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { PCBEngine } from './PCBEngine';
import type { ConvertResult } from './convertFromCircuit';

function makeEngine(): PCBEngine {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({} as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  return new PCBEngine(canvas, container);
}

function resistor(sourceComponentId: number, refDes: string, x: number, y: number): ConvertResult['components'][number] {
  return { sourceComponentId, footprint: 'RES_TH', refDes, x, y, rotation: 0, props: {} };
}

// Three independent, non-overlapping nets laid out on separate rows so
// autoRoute() (already covered by its own test suite) produces exactly
// three plain two-point traces to select and delete - this file only
// exercises deleteSelected()/undo()/redo(), not the routing itself.
function threeNetBoard(engine: PCBEngine) {
  const result: ConvertResult = {
    components: [
      resistor(1, 'R1', 0, 0), resistor(2, 'R2', 19.05, 0),
      resistor(3, 'R3', 0, 25.4), resistor(4, 'R4', 19.05, 25.4),
      resistor(5, 'R5', 0, 50.8), resistor(6, 'R6', 19.05, 50.8),
    ],
    netlist: [
      { id: 1, name: 'A', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R2', terminalLabel: '1' }] },
      { id: 2, name: 'B', pins: [{ refDes: 'R3', terminalLabel: '2' }, { refDes: 'R4', terminalLabel: '1' }] },
      { id: 3, name: 'C', pins: [{ refDes: 'R5', terminalLabel: '2' }, { refDes: 'R6', terminalLabel: '1' }] },
    ],
    unmapped: [],
  };
  engine.importFromCircuit(result);
  const out = engine.autoRoute();
  expect(out.routed).toBe(3);
  expect(engine.state.traces).toHaveLength(3);
  return engine.state.traces.map(t => t.id);
}

describe('PCBEngine trace delete / undo / redo', () => {
  let engine: PCBEngine;
  beforeEach(() => { engine = makeEngine(); });

  it('deletes a single selected trace and leaves the others untouched', () => {
    const [idA, idB, idC] = threeNetBoard(engine);

    engine.selectedTraceIds = [idA];
    engine.deleteSelected();

    expect(engine.state.traces.map(t => t.id).sort()).toEqual([idB, idC].sort());
    // Deleting clears the selection so a stale id can't be deleted twice.
    expect(engine.selectedTraceIds).toEqual([]);
  });

  it('multi-deletes several selected traces in one step', () => {
    const [idA, idB, idC] = threeNetBoard(engine);

    engine.selectedTraceIds = [idA, idC];
    engine.deleteSelected();

    expect(engine.state.traces).toHaveLength(1);
    expect(engine.state.traces[0].id).toBe(idB);
  });

  it('is a no-op with nothing selected - no traces removed, no history entry added', () => {
    threeNetBoard(engine);
    const historyIndexBefore = engine.historyIndex;
    const tracesBefore = engine.state.traces.length;

    engine.selectedTraceIds = [];
    engine.deleteSelected();

    expect(engine.state.traces).toHaveLength(tracesBefore);
    expect(engine.historyIndex).toBe(historyIndexBefore);
  });

  it('undo restores a single deleted trace', () => {
    const [idA, idB, idC] = threeNetBoard(engine);

    engine.selectedTraceIds = [idA];
    engine.deleteSelected();
    expect(engine.state.traces).toHaveLength(2);
    expect(engine.canUndo()).toBe(true);

    engine.undo();
    expect(engine.state.traces.map(t => t.id).sort()).toEqual([idA, idB, idC].sort());
  });

  it('redo re-applies the deletion after an undo', () => {
    const [idA, idB, idC] = threeNetBoard(engine);

    engine.selectedTraceIds = [idA];
    engine.deleteSelected();
    engine.undo();
    expect(engine.state.traces).toHaveLength(3);

    expect(engine.canRedo()).toBe(true);
    engine.redo();
    expect(engine.state.traces.map(t => t.id).sort()).toEqual([idB, idC].sort());
  });

  it('undo restores a multi-delete as a single step, and redo removes them all again', () => {
    const [idA, idB, idC] = threeNetBoard(engine);

    engine.selectedTraceIds = [idA, idB];
    engine.deleteSelected();
    expect(engine.state.traces).toHaveLength(1);

    engine.undo();
    expect(engine.state.traces.map(t => t.id).sort()).toEqual([idA, idB, idC].sort());

    engine.redo();
    expect(engine.state.traces).toHaveLength(1);
    expect(engine.state.traces[0].id).toBe(idC);
  });

  it('undo/redo clears any stale selection', () => {
    const [idA] = threeNetBoard(engine);

    engine.selectedTraceIds = [idA];
    engine.deleteSelected();
    engine.undo();
    expect(engine.selectedComponentIds).toEqual([]);
    expect(engine.selectedTraceIds).toEqual([]);
    expect(engine.selectedViaIds).toEqual([]);

    engine.redo();
    expect(engine.selectedTraceIds).toEqual([]);
  });
});
