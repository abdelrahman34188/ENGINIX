/**
 * PCB Editor - core data types
 * All spatial units are millimeters (mm) in board space.
 */

export type PadShape = 'round' | 'square' | 'rect';
export type Side = 'top' | 'bottom';
export type Rotation = 0 | 90 | 180 | 270;

export interface FootprintPad {
  id: string;        // pad number/name, e.g. "1"
  x: number;          // mm offset from footprint origin (unrotated, top-side orientation)
  y: number;
  shape: PadShape;
  width: number;       // mm
  height: number;       // mm
  drill?: number;        // mm — present => plated through-hole pad
}

export type ComponentCategory =
  | 'Passive Components'
  | 'Diodes'
  | 'Transistors'
  | 'ICs'
  | 'Logic'
  | 'Microcontrollers'
  | 'Power'
  | 'Connectors'
  | 'Displays'
  | 'Sensors'
  | 'Motors'
  // Added for parts with no real PCB category of their own (e.g. a
  // prototyping breadboard) — purely additive, does not change any
  // existing category value.
  | 'Other';

export type PropertyFieldType = 'text' | 'select';

export interface PropertyField {
  key: string;            // property key, e.g. 'resistance'
  label: string;           // display label, e.g. 'Resistance'
  type: PropertyFieldType;
  options?: string[];        // for 'select'
  default: string;
}

export interface FootprintDef {
  type: string;                          // key, e.g. 'RES_TH'
  label: string;                          // display name
  category: ComponentCategory;              // palette category
  refPrefix: string;                       // 'R', 'C', 'U', 'D', 'J'...
  pads: FootprintPad[];
  outline: { x: number; y: number }[][];    // silkscreen polylines (local space)
  width: number;                             // bounding box mm, for placement/selection
  height: number;
  properties?: PropertyField[];               // editable component properties
}

export interface PCBComponent {
  id: number;
  footprint: string;   // key into FOOTPRINTS
  refDes: string;        // e.g. "R1"
  x: number;              // mm, board coords (footprint origin)
  y: number;
  rotation: Rotation;
  side: Side;
  props: Record<string, string>;   // editable property values, keyed by PropertyField.key
  // Circuit Simulator Component.id this footprint was generated from, set
  // only by "Convert to PCB" (see src/pcb/convertFromCircuit.ts). Optional
  // and purely informational - absent for footprints placed by hand or via
  // the palette/Sync button. Lets a repeat conversion tell "already
  // converted" apart from "new component in the schematic" without
  // touching anything the user placed manually.
  sourceComponentId?: number;
}

/**
 * One electrical connection point carried over from the Circuit Simulator
 * during a "Convert to PCB" import. Identifies a PCB component by its
 * refDes (stable across the conversion, unlike numeric ids) and the
 * originating Circuit Simulator terminal label (e.g. "A", "K", "+", "-").
 */
export interface NetlistPin {
  refDes: string;
  terminalLabel: string;
}

/**
 * A group of pins that were electrically connected (same net) in the
 * Circuit Simulator. Carried into the PCB Editor purely as data for a
 * future routing/ratsnest pass to consume - "Convert to PCB" itself never
 * draws traces from this.
 */
export interface Netlist {
  id: number;
  pins: NetlistPin[];
  // The Circuit Simulator net label (e.g. "VCC", "GND") that produced this
  // net, when the wires making up the net carried one. Undefined for nets
  // joined purely by point-to-point wiring with no label - purely
  // informational (BOM/DRC/UI display), never affects routing/export.
  name?: string;
}

export interface TracePoint {
  x: number;
  y: number;
}

export interface Trace {
  id: number;
  layer: Side;
  width: number;    // mm
  points: TracePoint[];
}

export interface Via {
  id: number;
  x: number;
  y: number;
  size: number;    // pad diameter, mm
  drill: number;     // drill diameter, mm
}

export interface Board {
  width: number;   // mm
  height: number;
}

export interface PCBState {
  board: Board;
  components: PCBComponent[];
  traces: Trace[];
  vias: Via[];
  nextId: number;
  // Connectivity carried over from the Circuit Simulator via "Convert to
  // PCB". Optional and purely additive - absent on boards built by hand
  // only in the PCB Editor, and never affects rendering, routing tools, or
  // Gerber export. Only a future auto-router / ratsnest overlay would read
  // this.
  netlist?: Netlist[];
}
