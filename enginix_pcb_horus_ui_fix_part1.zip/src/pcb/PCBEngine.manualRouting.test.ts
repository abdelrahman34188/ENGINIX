// @vitest-environment jsdom
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { PCBEngine } from './PCBEngine';
import type { ConvertResult } from './convertFromCircuit';

function makeEngine(): PCBEngine {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({} as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  return new PCBEngine(canvas, container);
}

// jsdom's getBoundingClientRect() defaults to all-zero, so screen px for a
// board-mm point is just worldToScreen(x, y) — no extra rect offset to
// account for.
function down(engine: PCBEngine, xmm: number, ymm: number, opts: Partial<PointerEvent> = {}) {
  const s = engine.worldToScreen(xmm, ymm);
  engine.onPointerDown({ clientX: s.x, clientY: s.y, shiftKey: false, ...opts } as PointerEvent);
}
function move(engine: PCBEngine, xmm: number, ymm: number) {
  const s = engine.worldToScreen(xmm, ymm);
  engine.onPointerMove({ clientX: s.x, clientY: s.y } as PointerEvent);
}
function up(engine: PCBEngine) {
  engine.onPointerUp({} as PointerEvent);
}
function key(engine: PCBEngine, k: string) {
  engine.onKeyDown({ key: k, target: null } as unknown as KeyboardEvent);
}

function resistor(sourceComponentId: number, refDes: string, x: number, y: number): ConvertResult['components'][number] {
  return { sourceComponentId, footprint: 'RES_TH', refDes, x, y, rotation: 0, props: {} };
}

// RES_TH pads are '1' (-2.54,0) and '2' (+2.54,0) from the component
// center. Every coordinate in this file is a multiple of the 1.27mm
// routing grid, so snap() never nudges a plain (non-pad) click point,
// keeping expected trace points exact.
function twoResistors(engine: PCBEngine) {
  const result: ConvertResult = {
    components: [resistor(1, 'R1', 0, 0), resistor(2, 'R2', 19.05, 0)], // 19.05 = 15 * 1.27
    netlist: [],
    unmapped: [],
  };
  engine.importFromCircuit(result);
}

describe('PCBEngine manual routing — draw / finish / snap to pads', () => {
  let engine: PCBEngine;
  beforeEach(() => { engine = makeEngine(); });

  it('draws a trace by clicking successive points on the active layer', () => {
    engine.tool = 'route';
    engine.activeLayer = 'top';
    down(engine, 12.7, 12.7);
    down(engine, 25.4, 12.7);
    down(engine, 25.4, 25.4);
    expect(engine.routing).not.toBeNull();
    expect(engine.routing!.points).toEqual([{ x: 12.7, y: 12.7 }, { x: 25.4, y: 12.7 }, { x: 25.4, y: 25.4 }]);
    expect(engine.routing!.layer).toBe('top');
    expect(engine.state.traces).toHaveLength(0); // not committed yet
  });

  it('finishes the in-progress trace on Enter and adds it to state.traces', () => {
    engine.tool = 'route';
    down(engine, 12.7, 12.7);
    down(engine, 25.4, 12.7);
    key(engine, 'Enter');
    expect(engine.routing).toBeNull();
    expect(engine.state.traces).toHaveLength(1);
    expect(engine.state.traces[0].points).toEqual([{ x: 12.7, y: 12.7 }, { x: 25.4, y: 12.7 }]);
  });

  it('snaps the start and end of a routed trace exactly onto pad centers, auto-finishing on landing', () => {
    twoResistors(engine);
    engine.tool = 'route';
    // R1 pad '2' sits at (2.54, 0); click a bit off from it.
    down(engine, 2.6, 0.1);
    // R2 pad '1' sits at (16.51, 0); landing on a pad with 2+ points
    // queued finishes the trace automatically.
    down(engine, 16.4, -0.1);

    expect(engine.routing).toBeNull();
    expect(engine.state.traces).toHaveLength(1);
    expect(engine.state.traces[0].points).toEqual([{ x: 2.54, y: 0 }, { x: 16.51, y: 0 }]);
  });

  it('Escape cancels an in-progress route without adding a trace', () => {
    engine.tool = 'route';
    down(engine, 12.7, 12.7);
    down(engine, 25.4, 12.7);
    key(engine, 'Escape');
    expect(engine.routing).toBeNull();
    expect(engine.state.traces).toHaveLength(0);
  });
});

describe('PCBEngine manual routing — move a whole trace', () => {
  let engine: PCBEngine;
  beforeEach(() => { engine = makeEngine(); });

  function drawTrace(): number {
    engine.tool = 'route';
    down(engine, 12.7, 12.7);
    down(engine, 25.4, 12.7);
    key(engine, 'Enter');
    engine.tool = 'select';
    return engine.state.traces[0].id;
  }

  it('selects a trace on click and drags it as a rigid translation', () => {
    const id = drawTrace();

    // Click along the trace body (midpoint, not on an endpoint vertex).
    down(engine, 19.05, 12.7);
    expect(engine.selectedTraceIds).toEqual([id]);

    move(engine, 19.05, 19.05); // +0, +6.35 (5 grid steps)
    const trace = engine.state.traces.find(t => t.id === id)!;
    expect(trace.points).toEqual([{ x: 12.7, y: 19.05 }, { x: 25.4, y: 19.05 }]);
  });

  it('pushes exactly one history entry for the whole move; undo restores the original position', () => {
    const id = drawTrace();
    const historyBefore = engine.historyIndex;

    down(engine, 19.05, 12.7);
    move(engine, 19.05, 19.05);
    up(engine);

    expect(engine.historyIndex).toBe(historyBefore + 1);
    engine.undo();
    const restored = engine.state.traces.find(t => t.id === id)!;
    expect(restored.points).toEqual([{ x: 12.7, y: 12.7 }, { x: 25.4, y: 12.7 }]);
  });

  it('moving one selected trace leaves an unselected trace untouched', () => {
    const id = drawTrace();
    const other = { id: 999, layer: 'bottom' as const, width: 0.4, points: [{ x: 38.1, y: 38.1 }, { x: 50.8, y: 38.1 }] };
    engine.state.traces.push(other);

    down(engine, 19.05, 12.7);
    move(engine, 19.05, 19.05);
    up(engine);

    const untouched = engine.state.traces.find(t => t.id === 999)!;
    expect(untouched.points).toEqual([{ x: 38.1, y: 38.1 }, { x: 50.8, y: 38.1 }]);
    expect(engine.state.traces.find(t => t.id === id)!.points).toEqual([{ x: 12.7, y: 19.05 }, { x: 25.4, y: 19.05 }]);
  });
});

describe('PCBEngine manual routing — edit (reshape) a trace vertex', () => {
  let engine: PCBEngine;
  beforeEach(() => { engine = makeEngine(); });

  function drawTrace(): number {
    engine.tool = 'route';
    down(engine, 12.7, 12.7);
    down(engine, 25.4, 12.7);
    key(engine, 'Enter');
    engine.tool = 'select';
    return engine.state.traces[0].id;
  }

  it('does not offer a vertex grab on an unselected trace', () => {
    drawTrace();
    expect(engine.hitTestTraceVertex({ x: 12.7, y: 12.7 })).toBeNull();
  });

  it('offers a vertex grab once the trace is selected', () => {
    const id = drawTrace();
    down(engine, 19.05, 12.7); // select via trace body
    expect(engine.hitTestTraceVertex({ x: 12.7, y: 12.7 })).toEqual({ traceId: id, pointIndex: 0 });
  });

  it('drags an endpoint vertex of a selected trace to reshape it, snapped to grid', () => {
    const id = drawTrace();
    down(engine, 19.05, 12.7); // select the trace
    up(engine);
    expect(engine.selectedTraceIds).toEqual([id]);

    down(engine, 12.7, 12.7); // grab the (12.7,12.7) endpoint vertex
    move(engine, 12.7, 25.4); // drag it straight down
    up(engine);

    const trace = engine.state.traces.find(t => t.id === id)!;
    expect(trace.points).toEqual([{ x: 12.7, y: 25.4 }, { x: 25.4, y: 12.7 }]);
  });

  it('snaps a dragged endpoint exactly onto a pad it is dropped on', () => {
    twoResistors(engine);
    engine.tool = 'route';
    down(engine, 12.7, 12.7);
    down(engine, 25.4, 12.7);
    key(engine, 'Enter');
    engine.tool = 'select';
    const id = engine.state.traces[0].id;

    down(engine, 19.05, 12.7); // select
    up(engine);
    down(engine, 12.7, 12.7); // grab first vertex
    move(engine, 2.6, 0.1); // drag near R1 pad '2' at (2.54, 0)
    up(engine);

    const trace = engine.state.traces.find(t => t.id === id)!;
    expect(trace.points[0]).toEqual({ x: 2.54, y: 0 });
    expect(trace.points[1]).toEqual({ x: 25.4, y: 12.7 }); // untouched
  });

  it('reshaping one trace leaves other traces untouched', () => {
    const id = drawTrace();
    const other = { id: 999, layer: 'bottom' as const, width: 0.4, points: [{ x: 38.1, y: 38.1 }, { x: 50.8, y: 38.1 }] };
    engine.state.traces.push(other);

    down(engine, 19.05, 12.7); // select
    up(engine);
    down(engine, 12.7, 12.7); // grab vertex
    move(engine, 12.7, 25.4);
    up(engine);

    const untouched = engine.state.traces.find(t => t.id === 999)!;
    expect(untouched.points).toEqual([{ x: 38.1, y: 38.1 }, { x: 50.8, y: 38.1 }]);
    expect(engine.state.traces.find(t => t.id === id)!.points[0]).toEqual({ x: 12.7, y: 25.4 });
  });

  it('pushes exactly one history entry for the reshape; undo restores the original vertex', () => {
    const id = drawTrace();
    down(engine, 19.05, 12.7);
    up(engine);
    const historyBefore = engine.historyIndex;

    down(engine, 12.7, 12.7);
    move(engine, 12.7, 25.4);
    up(engine);

    expect(engine.historyIndex).toBe(historyBefore + 1);
    engine.undo();
    expect(engine.state.traces.find(t => t.id === id)!.points).toEqual([{ x: 12.7, y: 12.7 }, { x: 25.4, y: 12.7 }]);
  });
});
