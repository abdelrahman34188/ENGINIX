// Circuit Simulator ↔ PCB Editor sync.
//
// Purely additive: maps every Circuit Simulator ComponentType (see
// src/circuit/types.ts) to the PCB footprint key that represents it (see
// FOOTPRINTS in ./footprints.ts). Used to guarantee every component that
// exists in the Circuit Simulator also exists as a placeable footprint in
// the PCB Editor.
//
// Does not import from, or modify, the Circuit Simulator itself - it only
// needs the *type strings*, which are read off live Component objects at
// call time (see PCBEngine.syncMissingFootprints below). No changes to
// CircuitEditor.ts, simulator.ts, the Arduino runtime, the AI optimizer, or
// the Project Gallery.

/**
 * Circuit Simulator `ComponentType` -> PCB `FOOTPRINTS` key.
 * Every entry in src/circuit/types.ts's ComponentType union (other than
 * 'junction', which is an internal wire-splitting artifact never placed
 * from a palette - see the comment on it in types.ts) must appear here.
 */
export const SIMULATOR_TO_FOOTPRINT: Record<string, string> = {
  battery: 'BATTERY',
  resistor: 'RES_TH',
  capacitor: 'CAP_CER',
  inductor: 'INDUCTOR_TH',
  fuse: 'FUSE',
  polyfuse: 'POLYFUSE',
  transistorNpn: 'NPN_TO92',
  transistorPnp: 'PNP_TO92',
  tip120: 'NPN_TO220',
  tip122: 'NPN_TO220',
  irf520: 'NMOS_TO220',
  irf540: 'NMOS_TO220',
  irlz44n: 'NMOS_TO220',
  switch: 'SWITCH',
  pushButton: 'PUSHBUTTON',
  diode: 'DIODE_TH',
  led: 'LED_TH',
  zenerDiode: 'ZENER_TH',
  variableResistor: 'VARRESISTOR_TH',
  potentiometer: 'POT_TH',
  relay: 'RELAY',
  relayModule: 'RELAY_MODULE',
  solenoidValve: 'SOLENOID_VALVE',
  dcMotor: 'DC_MOTOR',
  waterPump: 'WATER_PUMP',
  servoMotor: 'SERVO_MOTOR',
  stepperMotor: 'STEPPER_MOTOR',
  buzzer: 'BUZZER',
  activeBuzzer: 'BUZZER_ACTIVE',
  passiveBuzzer: 'BUZZER_PASSIVE',
  rgbLed: 'RGB_LED',
  neopixel: 'NEOPIXEL',
  lcd16x2: 'LCD16X2',
  oledSsd1306: 'OLED',
  sevenSegment: 'SEVEN_SEG',
  sevenSegment4: 'SEVEN_SEG4',
  ammeter: 'AMMETER',
  voltmeter: 'VOLTMETER',
  ground: 'GND',
  acSource: 'AC_SOURCE',
  dcCurrentSource: 'DC_CURRENT_SRC',
  transformer: 'TRANSFORMER',
  breadboard: 'BREADBOARD',
  andGate: 'LOGIC_AND',
  orGate: 'LOGIC_OR',
  notGate: 'LOGIC_NOT',
  nandGate: 'LOGIC_NAND',
  norGate: 'LOGIC_NOR',
  xorGate: 'LOGIC_XOR',
  bulb: 'BULB',
  arduino: 'ARDUINO_UNO',
  arduinoMega: 'ARDUINO_MEGA',
  arduinoNano: 'ARDUINO_NANO',
  hcSr04: 'ULTRASONIC',
  lm35: 'TEMP_SENSOR',
  ldr: 'LDR',
  dht11: 'DHT11',
  pirMotion: 'PIR_MOTION',
  irObstacle: 'IR_OBSTACLE',
  mq2Gas: 'MQ2_GAS',
  flameSensor: 'FLAME_SENSOR',
  ne555: 'NE555',
  lm741: 'LM741',
  lm358: 'LM358',
  l293d: 'L293D',
  l298n: 'L298N',
  uln2003: 'ULN2003',
  '74hc595': 'HC74595',
  '74hc165': 'HC74165',
  cd4017: 'CD4017',
  cd4026: 'CD4026',
  pc817: 'PC817',
  barrelJack: 'BARREL_JACK',
  screwTerminal2pin: 'SCREW_TERMINAL',
  jstConnector2pin: 'JST_2PIN',
  uartHeader: 'UART_HEADER',
  hc05: 'BLUETOOTH_UART_6PIN',
  hc06: 'BLUETOOTH_UART_6PIN',
  esp8266: 'ESP8266_8PIN',
  esp32: 'ESP32_6PIN',
  nrf24l01: 'NRF24L01_8PIN',
  rc522: 'RC522_7PIN',
  max485: 'MAX485_8PIN',
  canBusModule: 'CAN_BUS_MODULE_7PIN',
  gpsNeo6m: 'GPS_NEO6M_4PIN',
  i2cHeader: 'I2C_HEADER',
  reg7805: 'REG7805',
  ams1117: 'AMS1117',
  lm317: 'LM317',
  // 'junction' intentionally omitted - never placed from a palette, has no
  // physical PCB representation.
};

/** True if a Circuit Simulator component type has a PCB footprint. */
export function hasFootprintFor(simulatorType: string): boolean {
  return simulatorType in SIMULATOR_TO_FOOTPRINT;
}

/** Footprint key for a Circuit Simulator component type, or undefined. */
export function footprintKeyFor(simulatorType: string): string | undefined {
  return SIMULATOR_TO_FOOTPRINT[simulatorType];
}
