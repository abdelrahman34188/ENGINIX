/**
 * PCB Editor - Design Rule Check (DRC)
 *
 * Pure functions over PCBState - no engine/UI dependency, so this can be
 * run from the toolbar, from export (pre-flight), or from tests alike.
 *
 * Checks implemented:
 *  - Short Circuit Detection: copper belonging to two different electrical
 *    islands that touches or overlaps (distance ~0).
 *  - Clearance Check: copper from two different electrical islands that
 *    comes closer than the configured clearance, without touching.
 *  - Open Net Detection: a netlist (from "Convert to PCB") net whose pins
 *    aren't all joined by copper yet - i.e. still has ratsnest left.
 *
 * "Electrical island" = a set of copper (trace segments, pads, vias) that
 * is physically joined, found via union-find over coincident points, the
 * same technique PCBEngine.getRatsnestLines() uses for connectivity.
 * Through-hole pads and vias bridge top+bottom since their copper is on
 * both layers; SMD pads and traces are single-layer.
 */

import type { PCBState, Side } from './types';
import { FOOTPRINTS } from './footprints';
import { padAbsolutePos, dist, segmentToSegmentDist, distToSegment } from './geometry';

export type DRCIssueType = 'short-circuit' | 'clearance' | 'open-net';
export type DRCSeverity = 'error' | 'warning';

export interface DRCIssue {
  id: string;
  type: DRCIssueType;
  severity: DRCSeverity;
  message: string;
  x?: number;
  y?: number;
  layer?: Side;
}

export interface DRCOptions {
  /** Minimum required copper-to-copper clearance between different nets, mm. */
  clearanceMm: number;
}

export const DEFAULT_DRC_OPTIONS: DRCOptions = { clearanceMm: 0.2 };

export interface DRCReport {
  issues: DRCIssue[];
  shortCircuitCount: number;
  clearanceCount: number;
  openNetCount: number;
  passed: boolean;
  generatedAt: string;
}

// ─── Union-find over coincident copper points ──────────────────────────

class UnionFind {
  private parent = new Map<string, string>();
  find(k: string): string {
    if (!this.parent.has(k)) this.parent.set(k, k);
    let root = k;
    while (this.parent.get(root) !== root) root = this.parent.get(root)!;
    let cur = k;
    while (this.parent.get(cur) !== cur) {
      const next = this.parent.get(cur)!;
      this.parent.set(cur, root);
      cur = next;
    }
    return root;
  }
  union(a: string, b: string) {
    const ra = this.find(a), rb = this.find(b);
    if (ra !== rb) this.parent.set(ra, rb);
  }
}

const ptKey = (layer: Side, x: number, y: number) => `${layer}:${x.toFixed(3)},${y.toFixed(3)}`;

interface CopperPad {
  compId: number;
  refDes: string;
  padId: string;
  x: number;
  y: number;
  radius: number; // mm, approximated from max(width,height)/2
  layers: Side[]; // ['top','bottom'] for THT, else the component's side
}

interface CopperTraceSeg {
  traceId: number;
  layer: Side;
  halfWidth: number;
  a: { x: number; y: number };
  b: { x: number; y: number };
}

interface CopperVia {
  id: number;
  x: number;
  y: number;
  radius: number;
}

function collectCopper(state: PCBState) {
  const pads: CopperPad[] = [];
  for (const comp of state.components) {
    const fp = FOOTPRINTS[comp.footprint];
    if (!fp) continue;
    for (const p of fp.pads) {
      const abs = padAbsolutePos(comp, p);
      pads.push({
        compId: comp.id,
        refDes: comp.refDes,
        padId: p.id,
        x: abs.x,
        y: abs.y,
        radius: Math.max(p.width, p.height) / 2,
        layers: p.drill ? ['top', 'bottom'] : [comp.side],
      });
    }
  }

  const traceSegs: CopperTraceSeg[] = [];
  for (const t of state.traces) {
    for (let i = 0; i < t.points.length - 1; i++) {
      traceSegs.push({
        traceId: t.id,
        layer: t.layer,
        halfWidth: t.width / 2,
        a: t.points[i],
        b: t.points[i + 1],
      });
    }
  }

  const vias: CopperVia[] = state.vias.map(v => ({ id: v.id, x: v.x, y: v.y, radius: v.size / 2 }));

  return { pads, traceSegs, vias };
}

/** Builds electrical islands: maps every copper feature to a group id. */
function buildIslands(state: PCBState) {
  const { pads, traceSegs, vias } = collectCopper(state);
  const uf = new UnionFind();

  // Chain trace segment endpoints within/between traces.
  for (const seg of traceSegs) {
    uf.union(ptKey(seg.layer, seg.a.x, seg.a.y), ptKey(seg.layer, seg.b.x, seg.b.y));
  }
  // Vias bridge top+bottom at their location, and join any trace endpoint there.
  for (const v of vias) {
    uf.union(ptKey('top', v.x, v.y), ptKey('bottom', v.x, v.y));
  }
  // THT pads bridge top+bottom too; SMD pads only touch their own layer.
  for (const p of pads) {
    if (p.layers.length === 2) uf.union(ptKey('top', p.x, p.y), ptKey('bottom', p.x, p.y));
  }

  const groupOf = (layer: Side, x: number, y: number) => uf.find(ptKey(layer, x, y));

  return { pads, traceSegs, vias, groupOf };
}

// ─── Short-circuit / clearance ──────────────────────────────────────────

function checkClearanceAndShorts(state: PCBState, opts: DRCOptions): DRCIssue[] {
  const { pads, traceSegs, vias, groupOf } = buildIslands(state);
  const issues: DRCIssue[] = [];
  const seen = new Set<string>();
  const report = (type: DRCIssueType, layer: Side, x: number, y: number, message: string) => {
    const id = `${type}:${layer}:${x.toFixed(2)}:${y.toFixed(2)}:${message}`;
    if (seen.has(id)) return;
    seen.add(id);
    issues.push({ id, type, severity: type === 'short-circuit' ? 'error' : 'warning', message, x, y, layer });
  };

  const layers: Side[] = ['top', 'bottom'];
  for (const layer of layers) {
    // Build the list of same-layer circular features (pads present on this layer + vias).
    const circles: { x: number; y: number; r: number; group: string; label: string }[] = [];
    for (const p of pads) {
      if (!p.layers.includes(layer)) continue;
      circles.push({ x: p.x, y: p.y, r: p.radius, group: groupOf(layer, p.x, p.y), label: `${p.refDes} pad ${p.padId}` });
    }
    for (const v of vias) {
      circles.push({ x: v.x, y: v.y, r: v.radius, group: groupOf(layer, v.x, v.y), label: `via` });
    }
    const segs = traceSegs.filter(s => s.layer === layer);

    // circle vs circle
    for (let i = 0; i < circles.length; i++) {
      for (let j = i + 1; j < circles.length; j++) {
        const c1 = circles[i], c2 = circles[j];
        if (c1.group === c2.group) continue;
        const d = dist(c1.x, c1.y, c2.x, c2.y) - c1.r - c2.r;
        const mx = (c1.x + c2.x) / 2, my = (c1.y + c2.y) / 2;
        if (d <= 0) report('short-circuit', layer, mx, my, `${c1.label} touches ${c2.label} on ${layer} copper`);
        else if (d < opts.clearanceMm) report('clearance', layer, mx, my, `${c1.label} is ${d.toFixed(3)}mm from ${c2.label} on ${layer} copper (min ${opts.clearanceMm}mm)`);
      }
    }

    // segment vs segment (different traces, or same trace non-adjacent - skip same trace entirely, self-overlap isn't a net conflict)
    for (let i = 0; i < segs.length; i++) {
      for (let j = i + 1; j < segs.length; j++) {
        const s1 = segs[i], s2 = segs[j];
        if (s1.traceId === s2.traceId) continue;
        const g1 = groupOf(layer, s1.a.x, s1.a.y);
        const g2 = groupOf(layer, s2.a.x, s2.a.y);
        if (g1 === g2) continue;
        const raw = segmentToSegmentDist(s1.a, s1.b, s2.a, s2.b);
        const d = raw - s1.halfWidth - s2.halfWidth;
        const mx = (s1.a.x + s1.b.x + s2.a.x + s2.b.x) / 4, my = (s1.a.y + s1.b.y + s2.a.y + s2.b.y) / 4;
        if (d <= 0) report('short-circuit', layer, mx, my, `Trace #${s1.traceId} crosses trace #${s2.traceId} on ${layer} copper`);
        else if (d < opts.clearanceMm) report('clearance', layer, mx, my, `Trace #${s1.traceId} is ${d.toFixed(3)}mm from trace #${s2.traceId} on ${layer} copper (min ${opts.clearanceMm}mm)`);
      }
    }

    // segment vs circle
    for (const seg of segs) {
      for (const c of circles) {
        const g1 = groupOf(layer, seg.a.x, seg.a.y);
        if (g1 === c.group) continue;
        const raw = distToSegment(c.x, c.y, seg.a.x, seg.a.y, seg.b.x, seg.b.y);
        const d = raw - seg.halfWidth - c.r;
        if (d <= 0) report('short-circuit', layer, c.x, c.y, `Trace #${seg.traceId} touches ${c.label} on ${layer} copper`);
        else if (d < opts.clearanceMm) report('clearance', layer, c.x, c.y, `Trace #${seg.traceId} is ${d.toFixed(3)}mm from ${c.label} on ${layer} copper (min ${opts.clearanceMm}mm)`);
      }
    }
  }

  return issues;
}

// ─── Open net detection ─────────────────────────────────────────────────

function checkOpenNets(state: PCBState): DRCIssue[] {
  const netlist = state.netlist;
  if (!netlist || netlist.length === 0) return [];
  const { groupOf } = buildIslands(state);
  const issues: DRCIssue[] = [];

  for (const net of netlist) {
    const resolved = net.pins
      .map(pin => {
        const comp = state.components.find(c => c.refDes === pin.refDes);
        if (!comp) return null;
        const fp = FOOTPRINTS[comp.footprint];
        const pad = fp?.pads.find(pd => pd.id === pin.terminalLabel);
        if (!pad) return null;
        const abs = padAbsolutePos(comp, pad);
        const layer: Side = pad.drill ? 'top' : comp.side;
        return { refDes: pin.refDes, terminalLabel: pin.terminalLabel, ...abs, group: groupOf(layer, abs.x, abs.y) };
      })
      .filter((p): p is NonNullable<typeof p> => p !== null);

    if (resolved.length < 2) continue;
    const groups = new Set(resolved.map(r => r.group));
    if (groups.size <= 1) continue; // fully joined by copper already

    const pinNames = resolved.map(r => `${r.refDes}.${r.terminalLabel}`).join(', ');
    issues.push({
      id: `open-net:${net.id}`,
      type: 'open-net',
      severity: 'error',
      message: `${net.name ? `Net "${net.name}"` : `Net #${net.id}`} (${pinNames}) is not fully connected by copper - ${groups.size} separate islands`,
      x: resolved[0].x,
      y: resolved[0].y,
    });
  }

  return issues;
}

// ─── Entry point ─────────────────────────────────────────────────────────

export function runDRC(state: PCBState, options: Partial<DRCOptions> = {}): DRCReport {
  const opts: DRCOptions = { ...DEFAULT_DRC_OPTIONS, ...options };
  const clearanceAndShorts = checkClearanceAndShorts(state, opts);
  const openNets = checkOpenNets(state);
  const issues = [...clearanceAndShorts, ...openNets];

  const shortCircuitCount = issues.filter(i => i.type === 'short-circuit').length;
  const clearanceCount = issues.filter(i => i.type === 'clearance').length;
  const openNetCount = issues.filter(i => i.type === 'open-net').length;

  return {
    issues,
    shortCircuitCount,
    clearanceCount,
    openNetCount,
    passed: issues.every(i => i.severity !== 'error'),
    generatedAt: new Date().toISOString(),
  };
}
