/**
 * PCB Editor - canvas engine
 * Handles rendering, hit-testing, pointer/keyboard interaction,
 * placement, trace routing, vias and undo/redo — mirrors the
 * interaction model used by the circuit simulator's CircuitEditor.
 */

import type { PCBState, PCBComponent, Trace, Via, TracePoint, Side } from './types';
import { FOOTPRINTS, defaultPropsFor } from './footprints';
import { padAbsolutePos, pointAbsolutePos, footprintBBox, distToSegment, dist, segmentsIntersect } from './geometry';
import { footprintKeyFor } from './simulatorSync';
import type { ConvertResult } from './convertFromCircuit';

// A single dashed "still needs a copper connection" line, in board mm.
export interface RatsnestLine {
  netId: number;
  x1: number; y1: number;
  x2: number; y2: number;
}

// A net autoRoute() could not (fully) complete, surfaced so the caller can
// display it instead of the connection silently staying unrouted.
export interface UnroutedNet {
  netId: number;
  name?: string;
}

// Which board edge (if any) a resize drag started on.
type ResizeHandle = 'e' | 's' | 'se' | null;
const RESIZE_HIT_PX = 10;

export type PCBTool = 'select' | 'pan' | 'place' | 'route' | 'via';

export function createDefaultPCBState(): PCBState {
  return {
    board: { width: 60, height: 40 },
    components: [],
    traces: [],
    vias: [],
    nextId: 1,
    netlist: [],
  };
}

const PAD_HIT_TOLERANCE_PX = 8;
const TRACE_HIT_TOLERANCE_PX = 6;

export class PCBEngine {
  state: PCBState;
  canvas: HTMLCanvasElement;
  container: HTMLElement;
  private ctx: CanvasRenderingContext2D;

  scale = 9;       // px per mm
  offsetX = 60;
  offsetY = 60;

  tool: PCBTool = 'select';
  placingFootprint: string | null = null;
  activeLayer: Side = 'top';
  gridMm = 1.27;
  snapToGrid = true;

  selectedComponentIds: number[] = [];
  selectedTraceIds: number[] = [];
  selectedViaIds: number[] = [];

  routing: { points: TracePoint[]; layer: Side } | null = null;

  history: PCBState[] = [];
  historyIndex = -1;

  mouseX = 0;
  mouseY = 0;
  isMouseDown = false;
  isDragging = false;
  panStartX = 0;
  panStartY = 0;
  panStartOffsetX = 0;
  panStartOffsetY = 0;

  // Rubber-band multi-selection (screen-space rect while dragging).
  marquee: { x0: number; y0: number; x1: number; y1: number } | null = null;
  // Per-component starting positions for the drag in progress, so a
  // multi-selection drags as a rigid group instead of collapsing onto
  // the cursor.
  private dragOrigin: { x: number; y: number } | null = null;
  private dragStartPositions: Map<number, { x: number; y: number }> = new Map();

  // Moving one or more whole selected traces (rigid translation), and
  // reshaping a single vertex of an already-selected trace — the two
  // manual-routing edit gestures, mirroring the component drag pattern
  // above so they get the same "smooth while dragging, snapped on
  // release" feel.
  private isDraggingTrace = false;
  private traceDragOrigin: { x: number; y: number } | null = null;
  private traceDragStartPositions: Map<number, TracePoint[]> = new Map();
  private draggingTraceVertex: { traceId: number; pointIndex: number } | null = null;

  // Board resize-by-drag (edge/corner handles), in addition to the
  // numeric width/height fields in the toolbar.
  resizeHandle: ResizeHandle = null;
  private resizeStartBoard = { width: 0, height: 0 };

  showRatsnest = true;

  onStateChange?: () => void;
  onSelectionChange?: () => void;

  private animFrame = 0;

  constructor(canvas: HTMLCanvasElement, container: HTMLElement) {
    this.canvas = canvas;
    this.container = container;
    this.ctx = canvas.getContext('2d')!;
    this.state = createDefaultPCBState();
    this.pushHistory();
    this.setupEvents();
    this.startLoop();
  }

  private startLoop() {
    const loop = () => {
      this.render();
      this.animFrame = requestAnimationFrame(loop);
    };
    this.animFrame = requestAnimationFrame(loop);
  }

  destroy() {
    cancelAnimationFrame(this.animFrame);
    this.canvas.removeEventListener('pointerdown', this.onPointerDown);
    this.canvas.removeEventListener('pointermove', this.onPointerMove);
    this.canvas.removeEventListener('pointerup', this.onPointerUp);
    this.canvas.removeEventListener('wheel', this.onWheel);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('resize', this.onResize);
  }

  setupEvents() {
    this.canvas.addEventListener('pointerdown', this.onPointerDown);
    this.canvas.addEventListener('pointermove', this.onPointerMove);
    this.canvas.addEventListener('pointerup', this.onPointerUp);
    this.canvas.addEventListener('wheel', this.onWheel, { passive: false });
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('resize', this.onResize);
  }

  onResize = () => this.render();

  resize() {
    this.render();
  }

  // ─── Coordinate transforms ─────────────────────────────────────────
  worldToScreen(xmm: number, ymm: number) {
    return { x: xmm * this.scale + this.offsetX, y: ymm * this.scale + this.offsetY };
  }
  screenToWorld(xpx: number, ypx: number) {
    return { x: (xpx - this.offsetX) / this.scale, y: (ypx - this.offsetY) / this.scale };
  }
  snap(v: number) {
    return this.snapToGrid ? Math.round(v / this.gridMm) * this.gridMm : v;
  }

  // ─── History ────────────────────────────────────────────────────────
  private pushHistory() {
    const snap = JSON.parse(JSON.stringify(this.state));
    this.history = this.history.slice(0, this.historyIndex + 1);
    this.history.push(snap);
    this.historyIndex = this.history.length - 1;
  }

  canUndo() { return this.historyIndex > 0; }
  canRedo() { return this.historyIndex < this.history.length - 1; }

  undo() {
    if (!this.canUndo()) return;
    this.historyIndex--;
    this.state = JSON.parse(JSON.stringify(this.history[this.historyIndex]));
    this.clearSelection();
    this.onStateChange?.();
    this.onSelectionChange?.();
  }

  redo() {
    if (!this.canRedo()) return;
    this.historyIndex++;
    this.state = JSON.parse(JSON.stringify(this.history[this.historyIndex]));
    this.clearSelection();
    this.onStateChange?.();
    this.onSelectionChange?.();
  }

  clearSelection() {
    this.selectedComponentIds = [];
    this.selectedTraceIds = [];
    this.selectedViaIds = [];
  }

  /**
   * Replace the entire board state (board size, components with their
   * position/rotation/side/props, traces, vias, netlist) with a fresh
   * deep copy of `state` — used to restore a saved PCB project exactly.
   * Resets undo/redo history to a single entry (the restored state) and
   * clears selection, matching how a freshly-opened project should behave.
   */
  importState(state: PCBState) {
    this.state = JSON.parse(JSON.stringify(state));
    this.history = [JSON.parse(JSON.stringify(this.state))];
    this.historyIndex = 0;
    this.clearSelection();
    this.onStateChange?.();
    this.onSelectionChange?.();
  }

  // ─── Placement / editing API (used by React toolbar) ───────────────
  setBoardSize(width: number, height: number) {
    this.state.board.width = Math.max(5, width);
    this.state.board.height = Math.max(5, height);
    this.pushHistory();
    this.onStateChange?.();
  }

  nextRefDes(footprintKey: string): string {
    const fp = FOOTPRINTS[footprintKey];
    const prefix = fp?.refPrefix || 'X';
    const existing = this.state.components
      .filter(c => c.footprint === footprintKey)
      .map(c => parseInt(c.refDes.replace(prefix, ''), 10))
      .filter(n => !isNaN(n));
    const next = existing.length ? Math.max(...existing) + 1 : 1;
    return `${prefix}${next}`;
  }

  rotateSelected() {
    if (this.selectedComponentIds.length === 0) return;
    for (const comp of this.state.components) {
      if (this.selectedComponentIds.includes(comp.id)) {
        comp.rotation = ((comp.rotation + 90) % 360) as PCBComponent['rotation'];
      }
    }
    this.pushHistory();
    this.onStateChange?.();
    this.onSelectionChange?.();
  }

  flipSelected() {
    if (this.selectedComponentIds.length === 0) return;
    for (const comp of this.state.components) {
      if (this.selectedComponentIds.includes(comp.id)) {
        comp.side = comp.side === 'top' ? 'bottom' : 'top';
      }
    }
    this.pushHistory();
    this.onStateChange?.();
    this.onSelectionChange?.();
  }

  deleteSelected() {
    const hadSelection =
      this.selectedComponentIds.length > 0 ||
      this.selectedTraceIds.length > 0 ||
      this.selectedViaIds.length > 0;
    if (!hadSelection) return;
    this.state.components = this.state.components.filter(c => !this.selectedComponentIds.includes(c.id));
    this.state.traces = this.state.traces.filter(t => !this.selectedTraceIds.includes(t.id));
    this.state.vias = this.state.vias.filter(v => !this.selectedViaIds.includes(v.id));
    this.clearSelection();
    this.pushHistory();
    this.onStateChange?.();
    this.onSelectionChange?.();
  }

  // ─── Clipboard (copy/paste selected components) ─────────────────────
  clipboard: PCBComponent[] = [];

  copySelected() {
    if (this.selectedComponentIds.length === 0) return;
    this.clipboard = this.state.components
      .filter(c => this.selectedComponentIds.includes(c.id))
      .map(c => JSON.parse(JSON.stringify(c)));
  }

  pasteClipboard() {
    if (this.clipboard.length === 0) return;
    const offset = this.gridMm * 2;
    const newIds: number[] = [];
    for (const src of this.clipboard) {
      const comp: PCBComponent = {
        ...JSON.parse(JSON.stringify(src)),
        id: this.state.nextId++,
        x: this.snap(src.x + offset),
        y: this.snap(src.y + offset),
      };
      comp.refDes = this.nextRefDes(comp.footprint);
      this.state.components.push(comp);
      newIds.push(comp.id);
    }
    this.selectedComponentIds = newIds;
    this.selectedTraceIds = [];
    this.selectedViaIds = [];
  }

  // ─── Circuit Simulator sync ──────────────────────────────────────────
  // Ensures every component type present in the Circuit Simulator also
  // exists in the PCB Editor. For each simulator component type passed in
  // that (a) has a known footprint mapping and (b) isn't already placed on
  // this board, places exactly one instance of its footprint, laid out in
  // a simple grid so nothing overlaps. Returns the list of newly-added
  // component ids and any simulator types that had no footprint mapping
  // (should normally be empty). Purely additive - never removes or moves
  // any existing PCB component, and never touches the Circuit Simulator's
  // own state.
  syncMissingFootprints(simulatorComponentTypes: string[]): { added: PCBComponent[]; unmapped: string[] } {
    const uniqueTypes = Array.from(new Set(simulatorComponentTypes));
    const existingFootprints = new Set(this.state.components.map(c => c.footprint));
    const added: PCBComponent[] = [];
    const unmapped: string[] = [];

    let col = 0;
    let row = 0;
    const stepX = 20;
    const stepY = 20;
    const perRow = 8;
    const startX = 10;
    const startY = 10;

    for (const simType of uniqueTypes) {
      const footprintKey = footprintKeyFor(simType);
      if (!footprintKey) {
        unmapped.push(simType);
        continue;
      }
      if (!FOOTPRINTS[footprintKey]) {
        unmapped.push(simType);
        continue;
      }
      if (existingFootprints.has(footprintKey)) continue; // already exists - skip, per sync rules

      const comp: PCBComponent = {
        id: this.state.nextId++,
        footprint: footprintKey,
        refDes: this.nextRefDes(footprintKey),
        x: this.snap(startX + col * stepX),
        y: this.snap(startY + row * stepY),
        rotation: 0,
        side: 'top',
        props: defaultPropsFor(footprintKey),
      };
      this.state.components.push(comp);
      existingFootprints.add(footprintKey);
      added.push(comp);

      col++;
      if (col >= perRow) { col = 0; row++; }
    }

    if (added.length > 0) {
      this.pushHistory();
      this.onStateChange?.();
    }
    return { added, unmapped };
  }

  // ─── Convert to PCB ───────────────────────────────────────────────────
  // Places every footprint produced by convertCircuitToPCB (see
  // ./convertFromCircuit.ts) onto this board, preserving the position,
  // rotation, ref designator and property values it was given, and merges
  // in the accompanying netlist. Idempotent per source circuit component:
  // a component already converted once (tracked via
  // PCBComponent.sourceComponentId) is skipped on a repeat conversion, so
  // re-running "Convert to PCB" never duplicates footprints or disturbs
  // anything the user has since moved/edited on the board. Draws no
  // traces - routing is left entirely to the user. Returns how many new
  // footprints were actually added.
  importFromCircuit(result: ConvertResult): number {
    const alreadyConverted = new Set(
      this.state.components
        .map(c => c.sourceComponentId)
        .filter((id): id is number => id !== undefined)
    );

    let added = 0;
    for (const c of result.components) {
      if (alreadyConverted.has(c.sourceComponentId)) continue;
      const comp: PCBComponent = {
        id: this.state.nextId++,
        footprint: c.footprint,
        refDes: c.refDes,
        x: c.x,
        y: c.y,
        rotation: c.rotation,
        side: 'top',
        props: c.props,
        sourceComponentId: c.sourceComponentId,
      };
      this.state.components.push(comp);
      alreadyConverted.add(c.sourceComponentId);
      added++;
    }

    if (result.netlist.length > 0) {
      this.state.netlist = [...(this.state.netlist ?? []), ...result.netlist];
    }

    if (added > 0) {
      // Grow the board (never shrink it) so every imported footprint fits
      // with a little breathing room. Purely additive to whatever size the
      // user already had set.
      const margin = 10;
      const maxX = Math.max(...this.state.components.map(c => c.x)) + margin;
      const maxY = Math.max(...this.state.components.map(c => c.y)) + margin;
      this.state.board.width = Math.max(this.state.board.width, maxX);
      this.state.board.height = Math.max(this.state.board.height, maxY);

      this.pushHistory();
      this.onStateChange?.();
    }

    return added;
  }

  duplicateSelected() {
    this.copySelected();
    this.pasteClipboard();
  }

  // ─── Alignment tools (KiCad/EasyEDA-style, act on selected components) ──
  private selectedComps(): PCBComponent[] {
    return this.state.components.filter(c => this.selectedComponentIds.includes(c.id));
  }

  private commitAlign() {
    this.pushHistory();
    this.onStateChange?.();
    this.onSelectionChange?.();
  }

  alignLeft() {
    const comps = this.selectedComps();
    if (comps.length < 2) return;
    const minX = Math.min(...comps.map(c => {
      const fp = FOOTPRINTS[c.footprint];
      const bbox = footprintBBox(fp?.width ?? 0, fp?.height ?? 0, c.rotation);
      return c.x - bbox.w / 2;
    }));
    for (const c of comps) {
      const fp = FOOTPRINTS[c.footprint];
      const bbox = footprintBBox(fp?.width ?? 0, fp?.height ?? 0, c.rotation);
      c.x = this.snap(minX + bbox.w / 2);
    }
    this.commitAlign();
  }

  alignRight() {
    const comps = this.selectedComps();
    if (comps.length < 2) return;
    const maxX = Math.max(...comps.map(c => {
      const fp = FOOTPRINTS[c.footprint];
      const bbox = footprintBBox(fp?.width ?? 0, fp?.height ?? 0, c.rotation);
      return c.x + bbox.w / 2;
    }));
    for (const c of comps) {
      const fp = FOOTPRINTS[c.footprint];
      const bbox = footprintBBox(fp?.width ?? 0, fp?.height ?? 0, c.rotation);
      c.x = this.snap(maxX - bbox.w / 2);
    }
    this.commitAlign();
  }

  alignTop() {
    const comps = this.selectedComps();
    if (comps.length < 2) return;
    const minY = Math.min(...comps.map(c => {
      const fp = FOOTPRINTS[c.footprint];
      const bbox = footprintBBox(fp?.width ?? 0, fp?.height ?? 0, c.rotation);
      return c.y - bbox.h / 2;
    }));
    for (const c of comps) {
      const fp = FOOTPRINTS[c.footprint];
      const bbox = footprintBBox(fp?.width ?? 0, fp?.height ?? 0, c.rotation);
      c.y = this.snap(minY + bbox.h / 2);
    }
    this.commitAlign();
  }

  alignBottom() {
    const comps = this.selectedComps();
    if (comps.length < 2) return;
    const maxY = Math.max(...comps.map(c => {
      const fp = FOOTPRINTS[c.footprint];
      const bbox = footprintBBox(fp?.width ?? 0, fp?.height ?? 0, c.rotation);
      return c.y + bbox.h / 2;
    }));
    for (const c of comps) {
      const fp = FOOTPRINTS[c.footprint];
      const bbox = footprintBBox(fp?.width ?? 0, fp?.height ?? 0, c.rotation);
      c.y = this.snap(maxY - bbox.h / 2);
    }
    this.commitAlign();
  }

  alignCenterH() {
    const comps = this.selectedComps();
    if (comps.length < 2) return;
    const avgX = comps.reduce((s, c) => s + c.x, 0) / comps.length;
    for (const c of comps) c.x = this.snap(avgX);
    this.commitAlign();
  }

  alignCenterV() {
    const comps = this.selectedComps();
    if (comps.length < 2) return;
    const avgY = comps.reduce((s, c) => s + c.y, 0) / comps.length;
    for (const c of comps) c.y = this.snap(avgY);
    this.commitAlign();
  }

  distributeH() {
    const comps = this.selectedComps();
    if (comps.length < 3) return;
    const sorted = [...comps].sort((a, b) => a.x - b.x);
    const minX = sorted[0].x, maxX = sorted[sorted.length - 1].x;
    const step = (maxX - minX) / (sorted.length - 1);
    sorted.forEach((c, i) => { c.x = this.snap(minX + step * i); });
    this.commitAlign();
  }

  distributeV() {
    const comps = this.selectedComps();
    if (comps.length < 3) return;
    const sorted = [...comps].sort((a, b) => a.y - b.y);
    const minY = sorted[0].y, maxY = sorted[sorted.length - 1].y;
    const step = (maxY - minY) / (sorted.length - 1);
    sorted.forEach((c, i) => { c.y = this.snap(minY + step * i); });
    this.commitAlign();
  }

  // ─── Auto Arrange ───────────────────────────────────────────────────
  // Repositions every component on the board into a non-overlapping grid,
  // ordered so that components sharing nets end up near each other -
  // shorter/straighter ratsnest lines mean less copper has to be laid
  // down (and fewer crossings) to connect them, which is the same
  // "reduce routing complexity" goal autoRoute()'s crossing-minimizing
  // elbow choice serves for the traces themselves. Never rotates, flips,
  // renames, deletes or rewires anything - purely a placement pass, so
  // it's safe to re-run and safe to undo() like any other edit.
  //
  // Overlap/spacing is enforced by construction rather than by checking
  // afterwards: every component is placed at the center of a fixed-size
  // grid cell sized to fit the single largest footprint on the board
  // plus AUTO_ARRANGE_SPACING_MM on every side, so no two placed
  // components' bounding boxes can ever touch, regardless of rotation.
  autoArrange(): { moved: number } {
    const comps = this.state.components;
    if (comps.length === 0) return { moved: 0 };

    const AUTO_ARRANGE_SPACING_MM = 2.5;
    const BOARD_MARGIN_MM = 5;

    // Uniform cell size - largest bbox on the board (post-rotation) plus
    // spacing on both sides - guarantees no overlap no matter which
    // component lands in which cell.
    let maxW = 0, maxH = 0;
    for (const c of comps) {
      const fp = FOOTPRINTS[c.footprint];
      const bbox = footprintBBox(fp?.width ?? 0, fp?.height ?? 0, c.rotation);
      maxW = Math.max(maxW, bbox.w);
      maxH = Math.max(maxH, bbox.h);
    }
    const cellW = maxW + AUTO_ARRANGE_SPACING_MM;
    const cellH = maxH + AUTO_ARRANGE_SPACING_MM;

    // Net-derived adjacency: weight(a,b) = number of nets that include a
    // pin on both refDes a and b. Only used to decide *placement order*
    // - never affects which nets exist or how they're routed.
    const netlist = this.state.netlist ?? [];
    const weight = new Map<string, number>();
    const bump = (a: string, b: string) => {
      if (a === b) return;
      const key = a < b ? `${a}|${b}` : `${b}|${a}`;
      weight.set(key, (weight.get(key) ?? 0) + 1);
    };
    for (const net of netlist) {
      const refs = Array.from(new Set(net.pins.map(p => p.refDes)));
      for (let i = 0; i < refs.length; i++) {
        for (let j = i + 1; j < refs.length; j++) bump(refs[i], refs[j]);
      }
    }
    const weightBetween = (a: string, b: string) => {
      const key = a < b ? `${a}|${b}` : `${b}|${a}`;
      return weight.get(key) ?? 0;
    };

    // Deterministic base order (refDes) so runs are reproducible when
    // there's no netlist, or as the tie-break once connectivity is spent.
    const byRefDes = [...comps].sort((a, b) => a.refDes.localeCompare(b.refDes, undefined, { numeric: true }));

    // Greedy connectivity ordering: repeatedly pull whichever unplaced
    // component is most strongly connected to what's already placed, so
    // tightly-networked parts end up next to each other in the eventual
    // spiral. Falls back to refDes order once nothing unplaced has any
    // connection left to the placed set (e.g. disconnected sub-circuits,
    // or no netlist at all).
    const remaining = new Set(byRefDes.map(c => c.refDes));
    const placedOrder: PCBComponent[] = [];
    const byRef = new Map(comps.map(c => [c.refDes, c] as const));
    let next = byRefDes[0];
    while (remaining.size > 0) {
      remaining.delete(next.refDes);
      placedOrder.push(next);
      if (remaining.size === 0) break;
      let best: string | null = null;
      let bestScore = 0;
      for (const refDes of remaining) {
        let score = 0;
        for (const p of placedOrder) score += weightBetween(p.refDes, refDes);
        if (score > bestScore || (score === bestScore && best !== null && refDes.localeCompare(best, undefined, { numeric: true }) < 0)) {
          bestScore = score;
          best = refDes;
        }
      }
      if (best === null || bestScore === 0) {
        // Nothing left is connected to what's placed - resume in refDes
        // order from the first remaining component.
        next = byRefDes.find(c => remaining.has(c.refDes))!;
      } else {
        next = byRef.get(best)!;
      }
    }

    // Square-ish spiral of integer (col,row) offsets from the origin,
    // one per component, walked in ring order - so the most-connected
    // cluster (placed first) lands centrally and later, weaker-linked
    // components ring outward around it instead of trailing off in a
    // single long row.
    const spiralOffsets = (n: number): { col: number; row: number }[] => {
      const out: { col: number; row: number }[] = [{ col: 0, row: 0 }];
      let col = 0, row = 0, step = 1, dir = 0; // 0=right,1=down,2=left,3=up
      const dcol = [1, 0, -1, 0];
      const drow = [0, 1, 0, -1];
      while (out.length < n) {
        for (let leg = 0; leg < 2 && out.length < n; leg++) {
          for (let s = 0; s < step && out.length < n; s++) {
            col += dcol[dir];
            row += drow[dir];
            out.push({ col, row });
          }
          dir = (dir + 1) % 4;
        }
        step++;
      }
      return out;
    };
    const offsets = spiralOffsets(placedOrder.length);

    const minCol = Math.min(...offsets.map(o => o.col));
    const minRow = Math.min(...offsets.map(o => o.row));

    let maxX = 0, maxY = 0;
    placedOrder.forEach((comp, i) => {
      const o = offsets[i];
      const x = this.snap(BOARD_MARGIN_MM + maxW / 2 + (o.col - minCol) * cellW);
      const y = this.snap(BOARD_MARGIN_MM + maxH / 2 + (o.row - minRow) * cellH);
      comp.x = x;
      comp.y = y;
      maxX = Math.max(maxX, x + maxW / 2 + BOARD_MARGIN_MM);
      maxY = Math.max(maxY, y + maxH / 2 + BOARD_MARGIN_MM);
    });

    // Grow the board if the arranged layout no longer fits - mirrors
    // importFromCircuit's "never shrink, only grow to fit" behavior so
    // this can't strand components off-board.
    this.state.board.width = Math.max(this.state.board.width, maxX);
    this.state.board.height = Math.max(this.state.board.height, maxY);

    this.clearSelection();
    this.pushHistory();
    this.onStateChange?.();
    this.onSelectionChange?.();

    return { moved: placedOrder.length };
  }

  // ─── Ratsnest ───────────────────────────────────────────────────────
  // For each imported net, resolves every pin's board position, then uses
  // union-find over existing traces/vias to figure out which pins in that
  // net are ALREADY joined by copper. Only draws a dashed line for pairs
  // still needing a connection (a minimal chain across the unresolved
  // groups) - purely a read of state.netlist/traces/vias, never mutates
  // anything, so it can't affect routing, export, or any existing
  // behavior when netlist is absent (returns []).
  getRatsnestLines(): RatsnestLine[] {
    const netlist = this.state.netlist;
    if (!netlist || netlist.length === 0) return [];

    // Union-find keyed by "x,y" (rounded) board points connected by copper.
    const parent = new Map<string, string>();
    const find = (k: string): string => {
      if (!parent.has(k)) parent.set(k, k);
      let root = k;
      while (parent.get(root) !== root) root = parent.get(root)!;
      let cur = k;
      while (parent.get(cur) !== cur) { const next = parent.get(cur)!; parent.set(cur, root); cur = next; }
      return root;
    };
    const union = (a: string, b: string) => { const ra = find(a), rb = find(b); if (ra !== rb) parent.set(ra, rb); };
    const key = (x: number, y: number) => `${x.toFixed(3)},${y.toFixed(3)}`;

    for (const trace of this.state.traces) {
      for (let i = 0; i < trace.points.length - 1; i++) {
        union(key(trace.points[i].x, trace.points[i].y), key(trace.points[i + 1].x, trace.points[i + 1].y));
      }
    }
    // Vias join whatever copper passes through the same point on any layer -
    // already covered by shared (x,y) keys from touching trace endpoints.

    const lines: RatsnestLine[] = [];
    for (const net of netlist) {
      const pts = net.pins
        .map(p => {
          const comp = this.state.components.find(c => c.refDes === p.refDes);
          if (!comp) return null;
          const fp = FOOTPRINTS[comp.footprint];
          const pad = fp?.pads.find(pd => pd.id === p.terminalLabel);
          if (!pad) return null;
          const abs = padAbsolutePos(comp, pad);
          return { ...abs, k: key(abs.x, abs.y) };
        })
        .filter((p): p is { x: number; y: number; k: string } => p !== null);
      if (pts.length < 2) continue;

      // Group already-joined points, then chain one representative per
      // group so remaining unconnected groups get a rats-nest line.
      const groups = new Map<string, { x: number; y: number }>();
      for (const p of pts) {
        const root = find(p.k);
        if (!groups.has(root)) groups.set(root, p);
      }
      const reps = Array.from(groups.values());
      for (let i = 0; i < reps.length - 1; i++) {
        lines.push({ netId: net.id, x1: reps[i].x, y1: reps[i].y, x2: reps[i + 1].x, y2: reps[i + 1].y });
      }
    }
    return lines;
  }

  // ─── Auto Routing ───────────────────────────────────────────────────
  // Draws copper for as many remaining ratsnest connections (see
  // getRatsnestLines) as it safely can, on the currently active layer,
  // snapped to grid. Reads getRatsnestLines() fresh, which already derives
  // "still needs a connection" from the existing traces via union-find —
  // so it only ever adds copper for gaps that are actually still open,
  // never touches or duplicates a trace that's already there, and is safe
  // to re-run (a second call finds nothing left to route). Purely
  // additive: never moves a component, never rewrites the netlist, so a
  // converted project's placement and connectivity data are untouched
  // either way.
  //
  // Per connection this picks between the two possible Manhattan elbow
  // orientations (horizontal-first vs vertical-first) and keeps whichever
  // crosses fewer already-placed traces, to cut down on visual/electrical
  // crossings rather than always bending the same way. Shorter
  // connections are routed before longer ones so a long trace can't sweep
  // across the board first and box in a short one that would otherwise
  // complete easily. A connection whose only paths would run straight
  // through a pad that isn't one of its own endpoints is left unrouted
  // rather than risk laying copper through it - those nets are reported
  // back via `unrouted` instead of silently disappearing.
  autoRoute(): { routed: number; reason?: string; unrouted: UnroutedNet[] } {
    const netlist = this.state.netlist;
    if (!netlist || netlist.length === 0) {
      return { routed: 0, reason: 'No nets imported — use "Convert to PCB" from the Circuit Simulator first.', unrouted: [] };
    }

    const lines = this.getRatsnestLines();
    if (lines.length === 0) {
      // Distinguish "nothing left to do" from "can't resolve some pins" so
      // a real problem never just silently reports 0 routed.
      let unresolvedNets = 0;
      for (const net of netlist) {
        const resolved = net.pins.filter(p => {
          const comp = this.state.components.find(c => c.refDes === p.refDes);
          const fp = comp ? FOOTPRINTS[comp.footprint] : undefined;
          return !!fp?.pads.find(pd => pd.id === p.terminalLabel);
        }).length;
        if (resolved < 2) unresolvedNets++;
      }
      if (unresolvedNets > 0) {
        return {
          routed: 0,
          reason: `${unresolvedNets} net${unresolvedNets === 1 ? '' : 's'} reference pins that aren't on the board (missing component/footprint) — nothing routable there.`,
          unrouted: [],
        };
      }
      return { routed: 0, reason: 'All imported nets are already fully connected by copper — nothing left to route.', unrouted: [] };
    }

    // Shortest connections first, so a short hop isn't blocked by copper a
    // long connection laid down earlier in the same pass.
    const ordered = [...lines].sort((a, b) => dist(a.x1, a.y1, a.x2, a.y2) - dist(b.x1, b.y1, b.x2, b.y2));

    // Foreign-pad avoidance: for a given net, every pad belonging to a
    // component that isn't one of that net's own endpoints. Approximated
    // as a circle (radius = half the pad's longer dimension) around the
    // pad center - enough to keep a routed trace from cutting straight
    // through an unrelated pin.
    const foreignPads = (netId: number) => {
      const net = netlist.find(n => n.id === netId);
      const ownRefDes = new Set(net?.pins.map(p => p.refDes) ?? []);
      const pads: { x: number; y: number; r: number }[] = [];
      for (const comp of this.state.components) {
        if (ownRefDes.has(comp.refDes)) continue;
        const fp = FOOTPRINTS[comp.footprint];
        if (!fp) continue;
        for (const pad of fp.pads) {
          const abs = padAbsolutePos(comp, pad);
          pads.push({ x: abs.x, y: abs.y, r: Math.max(pad.width, pad.height) / 2 });
        }
      }
      return pads;
    };

    // Segments already committed in this pass, plus everything already on
    // the board - what a new candidate path is scored/checked against.
    const placedSegments: { a: TracePoint; b: TracePoint; layer: Side }[] = [];
    for (const trace of this.state.traces) {
      for (let i = 0; i < trace.points.length - 1; i++) {
        placedSegments.push({ a: trace.points[i], b: trace.points[i + 1], layer: trace.layer });
      }
    }

    // Layer-parameterized so the "try the other layer / hop with a via"
    // fallback below can score a leg against whichever copper layer it
    // would actually land on, not just the active one.
    const crossingsOnLayer = (points: TracePoint[], layer: Side) => {
      let n = 0;
      for (let i = 0; i < points.length - 1; i++) {
        for (const seg of placedSegments) {
          if (seg.layer !== layer) continue;
          if (segmentsIntersect(points[i], points[i + 1], seg.a, seg.b)) n++;
        }
      }
      return n;
    };
    const crossingsAgainstPlaced = (points: TracePoint[]) => crossingsOnLayer(points, this.activeLayer);
    const otherLayer = (layer: Side): Side => (layer === 'top' ? 'bottom' : 'top');
    const AUTO_VIA_SIZE = 1.2;
    const AUTO_VIA_DRILL = 0.6;

    const crossesForeignPad = (points: TracePoint[], pads: { x: number; y: number; r: number }[]) => {
      for (let i = 0; i < points.length - 1; i++) {
        for (const pad of pads) {
          if (distToSegment(pad.x, pad.y, points[i].x, points[i].y, points[i + 1].x, points[i + 1].y) < pad.r) {
            return true;
          }
        }
      }
      return false;
    };

    let routed = 0;
    const unroutedNetIds = new Set<number>();
    for (const line of ordered) {
      const p1 = { x: this.snap(line.x1), y: this.snap(line.y1) };
      const p2 = { x: this.snap(line.x2), y: this.snap(line.y2) };

      let candidates: TracePoint[][];
      if (p1.x === p2.x || p1.y === p2.y) {
        candidates = [[p1, p2]];
      } else {
        // Horizontal-first and vertical-first elbows - same total length,
        // but they bend through different territory on the board.
        candidates = [
          [p1, { x: p2.x, y: p1.y }, p2],
          [p1, { x: p1.x, y: p2.y }, p2],
        ];
      }

      const pads = foreignPads(line.netId);
      const routable = candidates.filter(pts => !crossesForeignPad(pts, pads));
      if (routable.length === 0) {
        unroutedNetIds.add(line.netId);
        continue;
      }

      // Fewest crossings against everything placed so far wins; ties keep
      // the first (horizontal-first) candidate for deterministic output.
      let best = routable[0];
      let bestCrossings = crossingsAgainstPlaced(best);
      for (const pts of routable.slice(1)) {
        const c = crossingsAgainstPlaced(pts);
        if (c < bestCrossings) { best = pts; bestCrossings = c; }
      }

      // The active layer alone still crosses someone else's copper - that's
      // a short circuit waiting to happen, not just a cosmetic overlap.
      // Before settling for it, see whether the other layer (as a whole,
      // or reached by dropping a via at the elbow's bend) gets this
      // connection down clean. Only ever considered as a fallback so every
      // route that was already fine on one layer keeps behaving exactly as
      // before - a via is added only when it's actually needed.
      let bestLayer: Side = this.activeLayer;
      let bestVia: TracePoint | null = null;
      if (bestCrossings > 0) {
        for (const pts of routable) {
          // Whole candidate on the other layer, no via.
          const wholeOther = crossingsOnLayer(pts, otherLayer(this.activeLayer));
          if (wholeOther < bestCrossings) {
            best = pts; bestCrossings = wholeOther; bestLayer = otherLayer(this.activeLayer); bestVia = null;
            if (bestCrossings === 0) break;
          }
          // Hop layers at the bend (only possible for a 3-point elbow) -
          // try starting on the active layer and hopping to the other, and
          // the reverse, since either leg might be the one with a clean
          // path on a given layer.
          if (pts.length === 3) {
            const bend = pts[1];
            const leg1 = [pts[0], pts[1]];
            const leg2 = [pts[1], pts[2]];
            const hopFromActive = crossingsOnLayer(leg1, this.activeLayer) + crossingsOnLayer(leg2, otherLayer(this.activeLayer));
            if (hopFromActive < bestCrossings) {
              best = pts; bestCrossings = hopFromActive; bestLayer = this.activeLayer; bestVia = bend;
              if (bestCrossings === 0) break;
            }
            const hopFromOther = crossingsOnLayer(leg1, otherLayer(this.activeLayer)) + crossingsOnLayer(leg2, this.activeLayer);
            if (hopFromOther < bestCrossings) {
              best = pts; bestCrossings = hopFromOther; bestLayer = otherLayer(this.activeLayer); bestVia = bend;
              if (bestCrossings === 0) break;
            }
          }
        }
      }

      if (bestVia) {
        // Layer hop: two traces (one per layer) joined by a via at the bend.
        const via: Via = { id: this.state.nextId++, x: bestVia.x, y: bestVia.y, size: AUTO_VIA_SIZE, drill: AUTO_VIA_DRILL };
        this.state.vias.push(via);
        const leg1Layer = bestLayer;
        const leg2Layer = otherLayer(bestLayer);
        const trace1: Trace = { id: this.state.nextId++, layer: leg1Layer, width: 0.4, points: [best[0], best[1]] };
        const trace2: Trace = { id: this.state.nextId++, layer: leg2Layer, width: 0.4, points: [best[1], best[2]] };
        this.state.traces.push(trace1, trace2);
        placedSegments.push({ a: best[0], b: best[1], layer: leg1Layer });
        placedSegments.push({ a: best[1], b: best[2], layer: leg2Layer });
      } else {
        const trace: Trace = {
          id: this.state.nextId++,
          layer: bestLayer,
          width: 0.4,
          points: best,
        };
        this.state.traces.push(trace);
        for (let i = 0; i < best.length - 1; i++) {
          placedSegments.push({ a: best[i], b: best[i + 1], layer: bestLayer });
        }
      }
      routed++;
    }

    if (routed > 0) {
      this.pushHistory();
      this.onStateChange?.();
    }

    // Report every net that still has an open ratsnest connection after
    // this pass - covers both nets skipped above and any left over from a
    // still-open net this run never touched.
    const remaining = this.getRatsnestLines();
    for (const line of remaining) unroutedNetIds.add(line.netId);
    const unrouted: UnroutedNet[] = Array.from(unroutedNetIds).map(netId => ({
      netId,
      name: netlist.find(n => n.id === netId)?.name,
    }));

    if (unrouted.length > 0) {
      const label = unrouted.map(u => u.name ?? `net ${u.netId}`).join(', ');
      return { routed, reason: `${unrouted.length} net${unrouted.length === 1 ? '' : 's'} left unrouted: ${label}.`, unrouted };
    }
    return { routed, unrouted };
  }

  // Update one editable property (e.g. resistance, part number) on a component.
  updateComponentProp(id: number, key: string, value: string) {
    const comp = this.state.components.find(c => c.id === id);
    if (!comp) return;
    comp.props = { ...comp.props, [key]: value };
    this.pushHistory();
    this.onStateChange?.();
    this.onSelectionChange?.();
  }

  // Rename a component's reference designator (e.g. "R1" -> "R7").
  renameComponent(id: number, refDes: string) {
    const comp = this.state.components.find(c => c.id === id);
    if (!comp || !refDes.trim()) return;
    comp.refDes = refDes.trim();
    this.pushHistory();
    this.onStateChange?.();
    this.onSelectionChange?.();
  }

  cancelRouting() {
    this.routing = null;
  }

  // ─── Hit testing ─────────────────────────────────────────────────
  hitTestPad(world: { x: number; y: number }): { x: number; y: number } | null {
    const tolMm = PAD_HIT_TOLERANCE_PX / this.scale;
    for (const comp of this.state.components) {
      const fp = FOOTPRINTS[comp.footprint];
      if (!fp) continue;
      for (const pad of fp.pads) {
        const abs = padAbsolutePos(comp, pad);
        if (dist(world.x, world.y, abs.x, abs.y) < Math.max(pad.width, pad.height) / 2 + tolMm) {
          return abs;
        }
      }
    }
    return null;
  }

  hitTestVia(world: { x: number; y: number }): number | null {
    const tolMm = PAD_HIT_TOLERANCE_PX / this.scale;
    for (const via of this.state.vias) {
      if (dist(world.x, world.y, via.x, via.y) < via.size / 2 + tolMm) return via.id;
    }
    return null;
  }

  hitTestComponent(world: { x: number; y: number }): number | null {
    for (let i = this.state.components.length - 1; i >= 0; i--) {
      const comp = this.state.components[i];
      const fp = FOOTPRINTS[comp.footprint];
      if (!fp) continue;
      const bbox = footprintBBox(fp.width, fp.height, comp.rotation);
      if (
        world.x >= comp.x - bbox.w / 2 && world.x <= comp.x + bbox.w / 2 &&
        world.y >= comp.y - bbox.h / 2 && world.y <= comp.y + bbox.h / 2
      ) {
        return comp.id;
      }
    }
    return null;
  }

  hitTestTrace(world: { x: number; y: number }): number | null {
    const tolMm = TRACE_HIT_TOLERANCE_PX / this.scale;
    for (const trace of this.state.traces) {
      for (let i = 0; i < trace.points.length - 1; i++) {
        const a = trace.points[i], b = trace.points[i + 1];
        if (distToSegment(world.x, world.y, a.x, a.y, b.x, b.y) < Math.max(trace.width / 2, 0.2) + tolMm) {
          return trace.id;
        }
      }
    }
    return null;
  }

  // A vertex (endpoint or bend) of an already-selected trace, near enough
  // to the pointer to grab and drag — how a trace gets *edited* (reshaped)
  // rather than moved wholesale. Restricted to selected traces so a plain
  // click elsewhere on the same trace still selects/moves it instead of
  // nudging the nearest point.
  hitTestTraceVertex(world: { x: number; y: number }): { traceId: number; pointIndex: number } | null {
    const tolMm = PAD_HIT_TOLERANCE_PX / this.scale;
    for (const trace of this.state.traces) {
      if (!this.selectedTraceIds.includes(trace.id)) continue;
      for (let i = 0; i < trace.points.length; i++) {
        const p = trace.points[i];
        if (dist(world.x, world.y, p.x, p.y) < tolMm) {
          return { traceId: trace.id, pointIndex: i };
        }
      }
    }
    return null;
  }

  private beginTraceDrag(world: { x: number; y: number }) {
    this.isDraggingTrace = true;
    this.traceDragOrigin = { x: world.x, y: world.y };
    this.traceDragStartPositions.clear();
    for (const trace of this.state.traces) {
      if (this.selectedTraceIds.includes(trace.id)) {
        this.traceDragStartPositions.set(trace.id, trace.points.map(p => ({ x: p.x, y: p.y })));
      }
    }
  }

  // Snap point for routing: prefer landing exactly on a pad or via.
  private routeSnapPoint(world: { x: number; y: number }): { pt: TracePoint; landed: boolean } {
    const pad = this.hitTestPad(world);
    if (pad) return { pt: pad, landed: true };
    const viaId = this.hitTestVia(world);
    if (viaId != null) {
      const via = this.state.vias.find(v => v.id === viaId)!;
      return { pt: { x: via.x, y: via.y }, landed: true };
    }
    return { pt: { x: this.snap(world.x), y: this.snap(world.y) }, landed: false };
  }

  // ─── Pointer handlers ──────────────────────────────────────────────
  onPointerDown = (e: PointerEvent) => {
    const rect = this.canvas.getBoundingClientRect();
    this.mouseX = e.clientX - rect.left;
    this.mouseY = e.clientY - rect.top;
    this.isMouseDown = true;
    const world = this.screenToWorld(this.mouseX, this.mouseY);

    if (this.tool === 'pan') {
      this.panStartX = e.clientX;
      this.panStartY = e.clientY;
      this.panStartOffsetX = this.offsetX;
      this.panStartOffsetY = this.offsetY;
      return;
    }

    if (this.tool === 'place' && this.placingFootprint) {
      const fp = FOOTPRINTS[this.placingFootprint];
      if (!fp) return;
      const comp: PCBComponent = {
        id: this.state.nextId++,
        footprint: this.placingFootprint,
        refDes: this.nextRefDes(this.placingFootprint),
        x: this.snap(world.x),
        y: this.snap(world.y),
        rotation: 0,
        side: 'top',
        props: defaultPropsFor(this.placingFootprint),
      };
      this.state.components.push(comp);
      this.clearSelection();
      this.selectedComponentIds = [comp.id];
      this.tool = 'select';
      this.pushHistory();
      this.onStateChange?.();
      this.onSelectionChange?.();
      return;
    }

    if (this.tool === 'via') {
      const via: Via = { id: this.state.nextId++, x: this.snap(world.x), y: this.snap(world.y), size: 1.2, drill: 0.6 };
      this.state.vias.push(via);
      this.pushHistory();
      this.onStateChange?.();
      return;
    }

    if (this.tool === 'route') {
      const snapRes = this.routeSnapPoint(world);
      if (!this.routing) {
        this.routing = { points: [snapRes.pt], layer: this.activeLayer };
      } else {
        this.routing.points.push(snapRes.pt);
        if (snapRes.landed && this.routing.points.length >= 2) {
          this.finishRoute();
        }
      }
      return;
    }

    // select tool — board edge/corner drag-resize handle takes priority
    // over selection when the pointer starts right on the board edge.
    const handle = this.hitTestResizeHandle(world);
    if (handle) {
      this.resizeHandle = handle;
      this.resizeStartBoard = { width: this.state.board.width, height: this.state.board.height };
      return;
    }

    const shift = e.shiftKey;
    const compId = this.hitTestComponent(world);
    if (compId != null) {
      if (shift) {
        // Shift-click toggles membership without disturbing the rest of
        // the multi-selection.
        this.selectedTraceIds = [];
        this.selectedViaIds = [];
        if (this.selectedComponentIds.includes(compId)) {
          this.selectedComponentIds = this.selectedComponentIds.filter(id => id !== compId);
        } else {
          this.selectedComponentIds = [...this.selectedComponentIds, compId];
        }
        this.onSelectionChange?.();
      } else if (!this.selectedComponentIds.includes(compId)) {
        this.selectedComponentIds = [compId];
        this.selectedTraceIds = [];
        this.selectedViaIds = [];
        this.onSelectionChange?.();
      }
      if (this.selectedComponentIds.includes(compId)) {
        this.beginDrag(world);
      }
      return;
    }
    // A vertex handle on an already-selected trace takes priority over
    // plain trace-body selection, so dragging it reshapes that one point
    // instead of moving (or re-selecting) the whole trace.
    const vertexHit = this.hitTestTraceVertex(world);
    if (vertexHit != null && !shift) {
      this.draggingTraceVertex = vertexHit;
      return;
    }

    const traceId = this.hitTestTrace(world);
    if (traceId != null) {
      this.selectedTraceIds = shift ? Array.from(new Set([...this.selectedTraceIds, traceId])) : [traceId];
      if (!shift) { this.selectedComponentIds = []; this.selectedViaIds = []; }
      this.onSelectionChange?.();
      if (!shift) this.beginTraceDrag(world);
      return;
    }
    const viaId = this.hitTestVia(world);
    if (viaId != null) {
      this.selectedViaIds = shift ? Array.from(new Set([...this.selectedViaIds, viaId])) : [viaId];
      if (!shift) { this.selectedComponentIds = []; this.selectedTraceIds = []; }
      this.onSelectionChange?.();
      return;
    }

    // Nothing hit: start a rubber-band marquee selection instead of
    // clearing immediately, so a drag-select on empty board space picks
    // up every component whose bounding box it crosses.
    if (!shift) this.clearSelection();
    this.marquee = { x0: this.mouseX, y0: this.mouseY, x1: this.mouseX, y1: this.mouseY };
    this.onSelectionChange?.();
  };

  private beginDrag(world: { x: number; y: number }) {
    this.isDragging = true;
    this.dragOrigin = { x: world.x, y: world.y };
    this.dragStartPositions.clear();
    for (const comp of this.state.components) {
      if (this.selectedComponentIds.includes(comp.id)) {
        this.dragStartPositions.set(comp.id, { x: comp.x, y: comp.y });
      }
    }
  }

  // Board width/height edge in screen space, ~RESIZE_HIT_PX wide, for
  // drag-resize. Only active near the right edge, bottom edge, or the
  // bottom-right corner (the KiCad/EasyEDA convention) so it never
  // competes with picking components near the top-left of the board.
  private hitTestResizeHandle(world: { x: number; y: number }): ResizeHandle {
    const tolMm = RESIZE_HIT_PX / this.scale;
    const nearRight = Math.abs(world.x - this.state.board.width) < tolMm && world.y > -tolMm && world.y < this.state.board.height + tolMm;
    const nearBottom = Math.abs(world.y - this.state.board.height) < tolMm && world.x > -tolMm && world.x < this.state.board.width + tolMm;
    if (nearRight && nearBottom) return 'se';
    if (nearRight) return 'e';
    if (nearBottom) return 's';
    return null;
  }

  private finishRoute() {
    if (!this.routing || this.routing.points.length < 2) {
      this.routing = null;
      return;
    }
    const trace: Trace = {
      id: this.state.nextId++,
      layer: this.routing.layer,
      width: 0.4,
      points: this.routing.points,
    };
    this.state.traces.push(trace);
    this.routing = null;
    this.pushHistory();
    this.onStateChange?.();
  }

  onPointerMove = (e: PointerEvent) => {
    const rect = this.canvas.getBoundingClientRect();
    this.mouseX = e.clientX - rect.left;
    this.mouseY = e.clientY - rect.top;

    if (this.tool === 'pan' && this.isMouseDown) {
      this.offsetX = this.panStartOffsetX + (e.clientX - this.panStartX);
      this.offsetY = this.panStartOffsetY + (e.clientY - this.panStartY);
      return;
    }

    if (this.resizeHandle && this.isMouseDown) {
      const world = this.screenToWorld(this.mouseX, this.mouseY);
      if (this.resizeHandle === 'e' || this.resizeHandle === 'se') {
        this.state.board.width = Math.max(5, this.snap(world.x));
      }
      if (this.resizeHandle === 's' || this.resizeHandle === 'se') {
        this.state.board.height = Math.max(5, this.snap(world.y));
      }
      return;
    }

    if (this.marquee) {
      this.marquee = { ...this.marquee, x1: this.mouseX, y1: this.mouseY };
      return;
    }

    if (this.draggingTraceVertex && this.isMouseDown) {
      const world = this.screenToWorld(this.mouseX, this.mouseY);
      const trace = this.state.traces.find(t => t.id === this.draggingTraceVertex!.traceId);
      if (trace) {
        // Same snap-to-pad-or-via-or-grid rule as drawing a new trace, so a
        // reshaped endpoint can re-land exactly on a pad.
        const snapRes = this.routeSnapPoint(world);
        trace.points[this.draggingTraceVertex.pointIndex] = snapRes.pt;
      }
      return;
    }

    if (this.isDraggingTrace && this.traceDragOrigin && this.selectedTraceIds.length > 0) {
      const world = this.screenToWorld(this.mouseX, this.mouseY);
      const dx = world.x - this.traceDragOrigin.x;
      const dy = world.y - this.traceDragOrigin.y;
      for (const trace of this.state.traces) {
        const start = this.traceDragStartPositions.get(trace.id);
        if (start) {
          trace.points = start.map(p => ({ x: p.x + dx, y: p.y + dy }));
        }
      }
      return;
    }

    if (this.isDragging && this.dragOrigin && this.selectedComponentIds.length > 0) {
      const world = this.screenToWorld(this.mouseX, this.mouseY);
      const dx = world.x - this.dragOrigin.x;
      const dy = world.y - this.dragOrigin.y;
      for (const comp of this.state.components) {
        const start = this.dragStartPositions.get(comp.id);
        if (start) {
          comp.x = start.x + dx;
          comp.y = start.y + dy;
        }
      }
    }
  };

  onPointerUp = (_e: PointerEvent) => {
    this.isMouseDown = false;

    if (this.draggingTraceVertex) {
      // Already snapped continuously in onPointerMove (to a pad/via, or to
      // grid) — nothing further to align, just close out the edit.
      this.draggingTraceVertex = null;
      this.pushHistory();
      this.onStateChange?.();
      return;
    }

    if (this.isDraggingTrace) {
      for (const trace of this.state.traces) {
        if (this.selectedTraceIds.includes(trace.id)) {
          trace.points = trace.points.map(p => ({ x: this.snap(p.x), y: this.snap(p.y) }));
        }
      }
      this.isDraggingTrace = false;
      this.traceDragOrigin = null;
      this.traceDragStartPositions.clear();
      this.pushHistory();
      this.onStateChange?.();
      return;
    }

    if (this.resizeHandle) {
      this.resizeHandle = null;
      if (this.state.board.width !== this.resizeStartBoard.width || this.state.board.height !== this.resizeStartBoard.height) {
        this.pushHistory();
        this.onStateChange?.();
      }
      return;
    }

    if (this.marquee) {
      const { x0, y0, x1, y1 } = this.marquee;
      const left = Math.min(x0, x1), right = Math.max(x0, x1);
      const top = Math.min(y0, y1), bottom = Math.max(y0, y1);
      // A negligible drag (a plain click on empty space) just clears
      // selection rather than counting as a zero-size marquee.
      if (Math.abs(right - left) > 3 || Math.abs(bottom - top) > 3) {
        const w0 = this.screenToWorld(left, top);
        const w1 = this.screenToWorld(right, bottom);
        const picked: number[] = [];
        for (const comp of this.state.components) {
          const fp = FOOTPRINTS[comp.footprint];
          if (!fp) continue;
          const bbox = footprintBBox(fp.width, fp.height, comp.rotation);
          const cLeft = comp.x - bbox.w / 2, cRight = comp.x + bbox.w / 2;
          const cTop = comp.y - bbox.h / 2, cBottom = comp.y + bbox.h / 2;
          // Fully enclosed, matching the classic left-to-right drag
          // convention; intersecting selection would surprise anyone
          // used to KiCad/EasyEDA when dragging left of the board.
          if (cLeft >= w0.x && cRight <= w1.x && cTop >= w0.y && cBottom <= w1.y) {
            picked.push(comp.id);
          }
        }
        if (picked.length > 0) {
          this.selectedComponentIds = Array.from(new Set([...this.selectedComponentIds, ...picked]));
        }
      }
      this.marquee = null;
      this.onSelectionChange?.();
    }

    if (this.isDragging) {
      for (const comp of this.state.components) {
        if (this.selectedComponentIds.includes(comp.id)) {
          comp.x = this.snap(comp.x);
          comp.y = this.snap(comp.y);
        }
      }
      this.isDragging = false;
      this.dragOrigin = null;
      this.dragStartPositions.clear();
      this.pushHistory();
      this.onStateChange?.();
    }
  };

  onWheel = (e: WheelEvent) => {
    e.preventDefault();
    const rect = this.canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const worldBefore = this.screenToWorld(mx, my);
    const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
    this.scale = Math.max(2, Math.min(40, this.scale * zoomFactor));
    const worldAfter = this.screenToWorld(mx, my);
    this.offsetX += (worldAfter.x - worldBefore.x) * this.scale;
    this.offsetY += (worldAfter.y - worldBefore.y) * this.scale;
  };

  onKeyDown = (e: KeyboardEvent) => {
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement) return;
    switch (e.key) {
      case 'Delete':
      case 'Backspace':
        this.deleteSelected();
        break;
      case 'Escape':
        this.cancelRouting();
        this.clearSelection();
        this.tool = 'select';
        this.onSelectionChange?.();
        break;
      case 'Enter':
        if (this.routing) this.finishRoute();
        break;
      case 'r':
      case 'R':
        this.rotateSelected();
        break;
      case 'f':
      case 'F':
        this.flipSelected();
        break;
      case 'z':
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          if (e.shiftKey) this.redo(); else this.undo();
        }
        break;
      case 'y':
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          this.redo();
        }
        break;
      case 'c':
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          this.copySelected();
        }
        break;
      case 'v':
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          this.pasteClipboard();
        }
        break;
      case 'd':
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          this.duplicateSelected();
        }
        break;
      case 'a':
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          this.selectedComponentIds = this.state.components.map(c => c.id);
          this.selectedTraceIds = [];
          this.selectedViaIds = [];
          this.onSelectionChange?.();
        }
        break;
    }
  };

  centerView() {
    const rect = this.container.getBoundingClientRect();
    const fitScale = Math.min(
      (rect.width - 80) / this.state.board.width,
      (rect.height - 80) / this.state.board.height
    );
    this.scale = Math.max(2, Math.min(40, fitScale));
    this.offsetX = (rect.width - this.state.board.width * this.scale) / 2;
    this.offsetY = (rect.height - this.state.board.height * this.scale) / 2;
  }

  // ─── Rendering ──────────────────────────────────────────────────────
  render() {
    const rect = this.container.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    if (rect.width === 0 || rect.height === 0) return;
    this.canvas.width = rect.width * dpr;
    this.canvas.height = rect.height * dpr;
    this.canvas.style.width = `${rect.width}px`;
    this.canvas.style.height = `${rect.height}px`;
    const ctx = this.ctx;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, rect.width, rect.height);
    ctx.fillStyle = '#0a0f1e';
    ctx.fillRect(0, 0, rect.width, rect.height);

    // Grid (every 2.54mm, heavier line every 10mm)
    const g0 = this.worldToScreen(0, 0);
    ctx.lineWidth = 1;
    for (let x = 0; x <= this.state.board.width + 20; x += 2.54) {
      const sx = g0.x + x * this.scale;
      if (sx < 0 || sx > rect.width) continue;
      ctx.strokeStyle = Math.round(x) % 10 < 0.5 ? 'rgba(100,130,180,0.18)' : 'rgba(80,100,140,0.08)';
      ctx.beginPath(); ctx.moveTo(sx, 0); ctx.lineTo(sx, rect.height); ctx.stroke();
    }
    for (let y = 0; y <= this.state.board.height + 20; y += 2.54) {
      const sy = g0.y + y * this.scale;
      if (sy < 0 || sy > rect.height) continue;
      ctx.strokeStyle = Math.round(y) % 10 < 0.5 ? 'rgba(100,130,180,0.18)' : 'rgba(80,100,140,0.08)';
      ctx.beginPath(); ctx.moveTo(0, sy); ctx.lineTo(rect.width, sy); ctx.stroke();
    }

    // Board outline
    const b0 = this.worldToScreen(0, 0);
    const b1 = this.worldToScreen(this.state.board.width, this.state.board.height);
    ctx.fillStyle = 'rgba(15,60,45,0.35)';
    ctx.fillRect(b0.x, b0.y, b1.x - b0.x, b1.y - b0.y);
    ctx.strokeStyle = '#facc15';
    ctx.lineWidth = 2;
    ctx.strokeRect(b0.x, b0.y, b1.x - b0.x, b1.y - b0.y);

    // Ratsnest — dashed "still needs routing" lines from the imported
    // netlist, drawn under traces/components so real copper always reads
    // on top of it. Toggle-able; no-op when there's no netlist.
    if (this.showRatsnest) {
      const ratsnest = this.getRatsnestLines();
      if (ratsnest.length > 0) {
        ctx.strokeStyle = 'rgba(226,232,240,0.45)';
        ctx.setLineDash([3, 3]);
        ctx.lineWidth = 1;
        for (const line of ratsnest) {
          const a = this.worldToScreen(line.x1, line.y1);
          const b = this.worldToScreen(line.x2, line.y2);
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        }
        ctx.setLineDash([]);
      }
    }

    // Traces
    for (const trace of this.state.traces) {
      if (trace.points.length < 2) continue;
      const selected = this.selectedTraceIds.includes(trace.id);
      ctx.strokeStyle = selected ? '#fbbf24' : trace.layer === 'top' ? '#f97316' : '#38bdf8';
      ctx.lineWidth = Math.max(1.5, trace.width * this.scale);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      trace.points.forEach((p, i) => {
        const s = this.worldToScreen(p.x, p.y);
        if (i === 0) ctx.moveTo(s.x, s.y); else ctx.lineTo(s.x, s.y);
      });
      ctx.stroke();
    }

    // Vertex handles on selected traces — the grab points for reshaping
    // (see hitTestTraceVertex / draggingTraceVertex).
    for (const trace of this.state.traces) {
      if (!this.selectedTraceIds.includes(trace.id)) continue;
      for (const p of trace.points) {
        const s = this.worldToScreen(p.x, p.y);
        ctx.fillStyle = '#fbbf24';
        ctx.strokeStyle = '#0a0f1e';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(s.x, s.y, 4, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      }
    }

    // Active routing preview
    if (this.routing) {
      ctx.strokeStyle = this.routing.layer === 'top' ? '#fdba74' : '#7dd3fc';
      ctx.setLineDash([4, 3]);
      ctx.lineWidth = 2;
      ctx.beginPath();
      this.routing.points.forEach((p, i) => {
        const s = this.worldToScreen(p.x, p.y);
        if (i === 0) ctx.moveTo(s.x, s.y); else ctx.lineTo(s.x, s.y);
      });
      ctx.lineTo(this.mouseX, this.mouseY);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Vias
    for (const via of this.state.vias) {
      const s = this.worldToScreen(via.x, via.y);
      const selected = this.selectedViaIds.includes(via.id);
      ctx.fillStyle = selected ? '#fde047' : '#eab308';
      ctx.beginPath(); ctx.arc(s.x, s.y, (via.size / 2) * this.scale, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#0a0f1e';
      ctx.beginPath(); ctx.arc(s.x, s.y, (via.drill / 2) * this.scale, 0, Math.PI * 2); ctx.fill();
    }

    // Components
    for (const comp of this.state.components) {
      const fp = FOOTPRINTS[comp.footprint];
      if (!fp) continue;
      const selected = this.selectedComponentIds.includes(comp.id);

      // Silkscreen outline
      ctx.strokeStyle = selected ? '#fde047' : comp.side === 'top' ? '#e2e8f0' : '#94a3b8';
      ctx.lineWidth = selected ? 2 : 1.2;
      for (const poly of fp.outline) {
        ctx.beginPath();
        poly.forEach((pt, i) => {
          const abs = pointAbsolutePos(comp, pt.x, pt.y);
          const s = this.worldToScreen(abs.x, abs.y);
          if (i === 0) ctx.moveTo(s.x, s.y); else ctx.lineTo(s.x, s.y);
        });
        ctx.stroke();
      }

      // Pads
      for (const pad of fp.pads) {
        const abs = padAbsolutePos(comp, pad);
        const s = this.worldToScreen(abs.x, abs.y);
        const w = pad.width * this.scale, h = pad.height * this.scale;
        ctx.fillStyle = pad.drill
          ? '#d97706'
          : comp.side === 'top' ? '#f97316' : '#38bdf8';
        if (pad.shape === 'round') {
          ctx.beginPath(); ctx.arc(s.x, s.y, w / 2, 0, Math.PI * 2); ctx.fill();
        } else {
          ctx.fillRect(s.x - w / 2, s.y - h / 2, w, h);
        }
        if (pad.drill) {
          ctx.fillStyle = '#0a0f1e';
          ctx.beginPath(); ctx.arc(s.x, s.y, (pad.drill / 2) * this.scale, 0, Math.PI * 2); ctx.fill();
        }
      }

      // Reference designator
      const originScreen = this.worldToScreen(comp.x, comp.y);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(comp.refDes, originScreen.x, originScreen.y - (fp.height / 2) * this.scale - 4);
    }

    // Board resize handles (bottom-right corner + edge midpoints)
    if (this.tool === 'select') {
      const handleColor = '#facc15';
      ctx.fillStyle = handleColor;
      const hs = 5;
      const eMid = this.worldToScreen(this.state.board.width, this.state.board.height / 2);
      const sMid = this.worldToScreen(this.state.board.width / 2, this.state.board.height);
      const se = this.worldToScreen(this.state.board.width, this.state.board.height);
      ctx.fillRect(eMid.x - hs / 2, eMid.y - hs / 2, hs, hs);
      ctx.fillRect(sMid.x - hs / 2, sMid.y - hs / 2, hs, hs);
      ctx.fillRect(se.x - hs / 2, se.y - hs / 2, hs, hs);
    }

    // Rubber-band multi-selection marquee
    if (this.marquee) {
      const { x0, y0, x1, y1 } = this.marquee;
      const x = Math.min(x0, x1), y = Math.min(y0, y1);
      const w = Math.abs(x1 - x0), h = Math.abs(y1 - y0);
      ctx.fillStyle = 'rgba(250,204,21,0.10)';
      ctx.strokeStyle = 'rgba(250,204,21,0.7)';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.fillRect(x, y, w, h);
      ctx.strokeRect(x, y, w, h);
      ctx.setLineDash([]);
    }

    // Hover pad indicator while routing
    if (this.tool === 'route') {
      const world = this.screenToWorld(this.mouseX, this.mouseY);
      const pad = this.hitTestPad(world);
      if (pad) {
        const s = this.worldToScreen(pad.x, pad.y);
        ctx.strokeStyle = '#4ade80';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(s.x, s.y, 6, 0, Math.PI * 2); ctx.stroke();
      }
    }
  }
}
