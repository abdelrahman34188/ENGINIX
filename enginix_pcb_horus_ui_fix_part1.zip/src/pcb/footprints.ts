/**
 * PCB Editor - footprint library
 * A broad, "most commonly used" set of through-hole style footprints
 * (the same footprints you'd find backing Fritzing's core parts bin),
 * dimensioned in mm on standard 2.54mm (0.1") pitch grids where applicable.
 *
 * Every entry has: a real pad/outline geometry, a category for the
 * palette, and an editable `properties` schema used by the property
 * panel (value, tolerance, part number, pin count, etc).
 */

import type { FootprintDef, FootprintPad, PropertyField } from './types';

// ─── Small geometry helpers (keep every footprint's pads/outline real) ────

const rectOutline = (hw: number, hh: number) => [
  { x: -hw, y: -hh }, { x: hw, y: -hh }, { x: hw, y: hh }, { x: -hw, y: hh }, { x: -hw, y: -hh },
];

function pad(id: string, x: number, y: number, w = 1.4, h = 1.4, drill = 0.8, shape: FootprintPad['shape'] = 'round'): FootprintPad {
  return { id, x, y, shape, width: w, height: h, drill };
}

// Two-pad axial passive (resistor / diode / fuse style), pitch in mm.
function axial2(pitch: number, bodyHw: number, bodyHh: number, padSize = 1.4, drill = 0.8) {
  return {
    pads: [
      pad('1', -pitch / 2, 0, padSize, padSize, drill, 'square' as const),
      pad('2', pitch / 2, 0, padSize, padSize, drill, 'round' as const),
    ],
    outline: [rectOutline(bodyHw, bodyHh)],
    width: pitch + padSize * 2,
    height: bodyHh * 2,
  };
}

// Radial 2-pad part (capacitor / LED / buzzer style — both legs on one edge).
function radial2(pitch: number, bodyR: number, padSize = 1.3, drill = 0.7, labelA = '1', labelB = '2') {
  return {
    pads: [
      pad(labelA, -pitch / 2, 0, padSize, padSize, drill, 'square' as const),
      pad(labelB, pitch / 2, 0, padSize, padSize, drill, 'round' as const),
    ],
    outline: [
      circlePoly(bodyR, 24),
      [{ x: -bodyR, y: -bodyR * 0.15 }, { x: -bodyR * 0.5, y: -bodyR * 0.15 }], // polarity/marker dash
    ],
    width: Math.max(pitch + padSize * 2, bodyR * 2),
    height: bodyR * 2,
  };
}

function circlePoly(r: number, n: number) {
  const pts = [];
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * Math.PI * 2;
    pts.push({ x: Math.cos(a) * r, y: Math.sin(a) * r });
  }
  return pts;
}

// TO-92 style 3-leg transistor footprint (flat-D outline, legs on 2.54 pitch row).
function to92(l1 = '1', l2 = '2', l3 = '3') {
  return {
    pads: [
      pad(l1, -2.54, 2.2, 1.2, 1.2, 0.7, 'square' as const),
      pad(l2, 0, 2.2, 1.2, 1.2, 0.7, 'round' as const),
      pad(l3, 2.54, 2.2, 1.2, 1.2, 0.7, 'round' as const),
    ],
    outline: [
      circlePoly(2.6, 20).slice(0, 15).map(p => ({ x: p.x, y: p.y - 1 })),
      [{ x: -2.6, y: -1 }, { x: -2.6, y: -3 }, { x: 2.6, y: -3 }, { x: 2.6, y: -1 }],
    ],
    width: 6.5, height: 7,
  };
}

// SOT-223 style 3-lead + tab SMD package (LDO regulators like AMS1117).
// Leads on a 2.3mm pitch along the bottom edge; the wide tab pad at top
// is the package's thermal/4th-lead tab, electrically common with pin 2
// (OUT) on 3-pin SOT-223 regulators - present for solder/thermal area
// only, not tied to a schematic terminal.
function sot223(l1 = '1', l2 = '2', l3 = '3') {
  return {
    pads: [
      pad(l1, -2.3, 3.4, 1.2, 1.6, 0, 'square' as const),
      pad(l2, 0, 3.4, 1.2, 1.6, 0, 'round' as const),
      pad(l3, 2.3, 3.4, 1.2, 1.6, 0, 'round' as const),
      pad('tab', 0, -1.8, 3.2, 2.2, 0, 'round' as const),
    ],
    outline: [rectOutline(3.4, 3.4)],
    width: 7.5, height: 8.4,
  };
}

// TO-220 style 3-pin power package (regulator/MOSFET/transistor).
function to220() {
  return {
    pads: [
      pad('1', -2.54, 3.6, 1.6, 1.6, 0.9, 'square' as const),
      pad('2', 0, 3.6, 1.6, 1.6, 0.9, 'round' as const),
      pad('3', 2.54, 3.6, 1.6, 1.6, 0.9, 'round' as const),
    ],
    outline: [
      rectOutline(5.2, 3.2),
      [{ x: -5.2, y: -3.2 - 2.5 }, { x: 5.2, y: -3.2 - 2.5 }, { x: 5.2, y: -3.2 }, { x: -5.2, y: -3.2 }, { x: -5.2, y: -3.2 - 2.5 }],
      [{ x: -1.2, y: -5.7 }, { x: -1.2, y: -6.6 }],
    ],
    width: 10.6, height: 12.9,
  };
}

// N-pin single-row header, 2.54mm pitch, centered on origin.
function headerRow(n: number, padSize = 1.7, drill = 1.0) {
  const pads: FootprintPad[] = [];
  const startX = -((n - 1) * 2.54) / 2;
  for (let i = 0; i < n; i++) {
    pads.push(pad(String(i + 1), startX + i * 2.54, 0, padSize, padSize, drill, i === 0 ? 'square' : 'round'));
  }
  return {
    pads,
    outline: [rectOutline(-startX + 1.3, 2.2)],
    width: (n - 1) * 2.54 + 4, height: 4.4,
  };
}

// N-per-side dual-row DIP-style IC, 2.54mm pitch along rows, `rowSpacing`mm between rows.
function dip(nPerSide: number, rowSpacing: number) {
  const pads: FootprintPad[] = [];
  const half = rowSpacing / 2;
  const topStartY = -((nPerSide - 1) * 2.54) / 2;
  for (let i = 0; i < nPerSide; i++) {
    pads.push(pad(String(i + 1), -half, topStartY + i * 2.54, 1.6, 1.6, 0.8, i === 0 ? 'square' : 'round'));
  }
  for (let i = 0; i < nPerSide; i++) {
    pads.push(pad(String(nPerSide * 2 - i), half, topStartY + i * 2.54, 1.6, 1.6, 0.8, 'round'));
  }
  const bw = half + 1.2;
  const bh = ((nPerSide - 1) * 2.54) / 2 + 1.2;
  return {
    pads,
    outline: [
      rectOutline(bw, bh),
      [{ x: -bw * 0.35, y: -bh }, { x: 0, y: -bh + 0.9 }, { x: bw * 0.35, y: -bh }],
    ],
    width: bw * 2 + 1, height: bh * 2 + 1,
  };
}

// Double-row 2.54mm header block, e.g. Arduino Nano / ESP32 devkit pin rows.
function dualRowHeader(nPerSide: number, rowSpacing: number) {
  return dip(nPerSide, rowSpacing);
}

// Same physical layout as dip() (pins 1..n down the left side, n+1..2n back
// up the right side), but with each pin's real datasheet label instead of a
// plain number - for ICs whose pinout isn't simple sequential numbering.
// `leftLabels` runs top-to-bottom (pin 1 at the top); `rightLabelsTopDown`
// gives the right-side pins in the same top-to-bottom order as they appear
// physically (i.e. the datasheet's own "continuing counterclockwise back up
// the right side" order, reversed to read top-down) - matching exactly how
// componentDefs.ts lists each IC's terminals.
function dipLabeled(leftLabels: string[], rightLabelsBottomUp: string[], rowSpacing: number, padSize = 1.6, drill = 0.8) {
  const n = leftLabels.length;
  const half = rowSpacing / 2;
  const topStartY = -((n - 1) * 2.54) / 2;
  const pads: FootprintPad[] = [];
  for (let i = 0; i < n; i++) {
    pads.push(pad(leftLabels[i], -half, topStartY + i * 2.54, padSize, padSize, drill, i === 0 ? 'square' : 'round'));
  }
  for (let i = 0; i < n; i++) {
    // rightLabelsBottomUp[0] is physically the bottom-most right pin (pin
    // n+1, adjacent to the last left pin) - same convention dip() uses.
    pads.push(pad(rightLabelsBottomUp[i], half, topStartY + (n - 1 - i) * 2.54, padSize, padSize, drill, 'round'));
  }
  const bw = half + 1.2;
  const bh = ((n - 1) * 2.54) / 2 + 1.2;
  return {
    pads,
    outline: [
      rectOutline(bw, bh),
      [{ x: -bw * 0.35, y: -bh }, { x: 0, y: -bh + 0.9 }, { x: bw * 0.35, y: -bh }],
    ],
    width: bw * 2 + 1, height: bh * 2 + 1,
  };
}

// Single row of labeled pads on 2.54mm pitch, centered on origin - used for
// sensor breakout modules (VCC/GND/signal style) where the pad ids must
// match the Circuit Simulator's terminal labels exactly rather than plain
// numbers.
function labeledRow(labels: string[], pitch = 2.54, padSize = 1.5, drill = 0.9, y = 0) {
  const pads: FootprintPad[] = [];
  const startX = -((labels.length - 1) * pitch) / 2;
  labels.forEach((label, i) => {
    pads.push(pad(label, startX + i * pitch, y, padSize, padSize, drill, i === 0 ? 'square' : 'round'));
  });
  return {
    pads,
    outline: [rectOutline(-startX + 1.5, 3)],
    width: (labels.length - 1) * pitch + 5, height: 8,
  };
}

// Two-pad symbol with explicit (non-numeric) labels, e.g. '+'/'-' or 'L'/'N' -
// same axial layout as axial2() but preserving the simulator's own labels.
function labeledAxial2(labelA: string, labelB: string, pitch: number, bodyHw: number, bodyHh: number, padSize = 1.6, drill = 0.9) {
  return {
    pads: [
      pad(labelA, -pitch / 2, 0, padSize, padSize, drill, 'square' as const),
      pad(labelB, pitch / 2, 0, padSize, padSize, drill, 'round' as const),
    ],
    outline: [rectOutline(bodyHw, bodyHh)],
    width: pitch + padSize * 2, height: bodyHh * 2,
  };
}

// Relabel specific pads (by their current id) after building a generic
// footprint shape - e.g. giving a 14-pin DIP's first few physical pins
// (1, 2, 3...) their real logic-gate names (A, B, Y) without having to
// hand-roll the whole footprint's geometry.
function relabelPads<T extends { pads: FootprintPad[] }>(fp: T, mapping: Record<string, string>): T {
  return { ...fp, pads: fp.pads.map(p => (mapping[p.id] ? { ...p, id: mapping[p.id] } : p)) };
}

// ─── Common property value presets ─────────────────────────────────────

const RESISTANCE_VALUES = ['10Ω', '100Ω', '220Ω', '330Ω', '470Ω', '1kΩ', '2.2kΩ', '4.7kΩ', '10kΩ', '47kΩ', '100kΩ', '1MΩ'];
const CAP_CERAMIC_VALUES = ['10pF', '100pF', '1nF', '10nF', '100nF', '1µF'];
const CAP_ELEC_VALUES = ['1µF', '4.7µF', '10µF', '47µF', '100µF', '220µF', '470µF', '1000µF'];
const VOLTAGE_RATINGS = ['6.3V', '10V', '16V', '25V', '35V', '50V'];

// (kept for potential reuse by callers of this module)
export type { PropertyField };

// ─── Footprint library ─────────────────────────────────────────────────

export const FOOTPRINTS: Record<string, FootprintDef> = {

  // ── Passive Components ────────────────────────────────────────────
  RES_TH: {
    type: 'RES_TH', label: 'Resistor', category: 'Passive Components', refPrefix: 'R',
    ...axial2(5.08, 3.3, 1.2),
    properties: [
      { key: 'resistance', label: 'Resistance', type: 'select', options: RESISTANCE_VALUES, default: '220Ω' },
      { key: 'tolerance', label: 'Tolerance', type: 'select', options: ['±1%', '±5%', '±10%'], default: '±5%' },
      { key: 'power', label: 'Power', type: 'select', options: ['1/8W', '1/4W', '1/2W', '1W'], default: '1/4W' },
    ],
  },
  VARRESISTOR_TH: {
    type: 'VARRESISTOR_TH', label: 'Variable Resistor', category: 'Passive Components', refPrefix: 'RV',
    pads: [
      pad('1', -2.54, 2.2, 1.5, 1.5, 0.8, 'square'),
      pad('W', 0, -1.2, 1.5, 1.5, 0.8, 'round'),
      pad('2', 2.54, 2.2, 1.5, 1.5, 0.8, 'round'),
    ],
    outline: [rectOutline(3.6, 3.6)],
    width: 7.6, height: 7.2,
    properties: [
      { key: 'resistance', label: 'Max Resistance', type: 'select', options: ['1kΩ', '4.7kΩ', '10kΩ', '47kΩ', '100kΩ', '1MΩ'], default: '10kΩ' },
    ],
  },
  POT_TH: {
    type: 'POT_TH', label: 'Potentiometer', category: 'Passive Components', refPrefix: 'RV',
    pads: [
      pad('1', -3.81, 3.2, 1.6, 1.6, 0.9, 'square'),
      pad('W', 0, -2.0, 1.6, 1.6, 0.9, 'round'),
      pad('2', 3.81, 3.2, 1.6, 1.6, 0.9, 'round'),
      pad('M1', -4.5, -3.5, 1.8, 1.8, 1.0, 'round'),
      pad('M2', 4.5, -3.5, 1.8, 1.8, 1.0, 'round'),
    ],
    outline: [circlePoly(5.2, 24), [{ x: -1, y: -5.2 }, { x: 1, y: -5.2 }]],
    width: 10.4, height: 10.4,
    properties: [
      { key: 'resistance', label: 'Resistance', type: 'select', options: ['1kΩ', '10kΩ', '50kΩ', '100kΩ', '1MΩ'], default: '10kΩ' },
      { key: 'taper', label: 'Taper', type: 'select', options: ['Linear', 'Logarithmic'], default: 'Linear' },
    ],
  },
  CAP_CER: {
    type: 'CAP_CER', label: 'Ceramic Capacitor', category: 'Passive Components', refPrefix: 'C',
    pads: [
      pad('1', -1.27, 0, 1.2, 1.2, 0.6, 'square'),
      pad('2', 1.27, 0, 1.2, 1.2, 0.6, 'round'),
    ],
    outline: [circlePoly(1.9, 20)],
    width: 3.8, height: 3.8,
    properties: [
      { key: 'capacitance', label: 'Capacitance', type: 'select', options: CAP_CERAMIC_VALUES, default: '100nF' },
      { key: 'voltage', label: 'Voltage', type: 'select', options: VOLTAGE_RATINGS, default: '50V' },
    ],
  },
  CAP_ELEC: {
    type: 'CAP_ELEC', label: 'Electrolytic Capacitor', category: 'Passive Components', refPrefix: 'C',
    ...radial2(2.0, 2.6, 1.4, 0.8),
    properties: [
      { key: 'capacitance', label: 'Capacitance', type: 'select', options: CAP_ELEC_VALUES, default: '100µF' },
      { key: 'voltage', label: 'Voltage', type: 'select', options: VOLTAGE_RATINGS, default: '16V' },
    ],
  },
  INDUCTOR_TH: {
    type: 'INDUCTOR_TH', label: 'Inductor', category: 'Passive Components', refPrefix: 'L',
    ...axial2(5.08, 3.0, 1.6),
    properties: [
      { key: 'inductance', label: 'Inductance', type: 'select', options: ['1µH', '10µH', '100µH', '1mH', '10mH', '100mH'], default: '100µH' },
    ],
  },

  // ── Diodes ───────────────────────────────────────────────────────
  DIODE_TH: {
    type: 'DIODE_TH', label: 'Diode', category: 'Diodes', refPrefix: 'D',
    pads: [
      pad('K', -2.54, 0, 1.3, 1.3, 0.7, 'square'),
      pad('A', 2.54, 0, 1.3, 1.3, 0.7, 'round'),
    ],
    outline: [rectOutline(2.54, 1.1), [{ x: -1.6, y: -1.1 }, { x: -1.6, y: 1.1 }]],
    width: 6.6, height: 2.6,
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['1N4148', '1N4001', '1N4007', '1N5819'], default: '1N4148' },
    ],
  },
  ZENER_TH: {
    type: 'ZENER_TH', label: 'Zener Diode', category: 'Diodes', refPrefix: 'D',
    pads: [
      pad('K', -2.54, 0, 1.3, 1.3, 0.7, 'square'),
      pad('A', 2.54, 0, 1.3, 1.3, 0.7, 'round'),
    ],
    outline: [
      rectOutline(2.54, 1.1),
      [{ x: -1.6, y: -1.1 }, { x: -1.6, y: 1.1 }],
      [{ x: -1.9, y: -1.1 }, { x: -1.6, y: -1.5 }],
      [{ x: -1.6, y: 1.5 }, { x: -1.3, y: 1.1 }],
    ],
    width: 6.6, height: 3.0,
    properties: [
      { key: 'voltage', label: 'Zener Voltage', type: 'select', options: ['3.3V', '5.1V', '6.2V', '9.1V', '12V', '15V'], default: '5.1V' },
    ],
  },
  LED_TH: {
    type: 'LED_TH', label: 'LED', category: 'Diodes', refPrefix: 'D',
    ...radial2(2.54, 1.9, 1.3, 0.7, 'A', 'K'),
    properties: [
      { key: 'color', label: 'Color', type: 'select', options: ['Red', 'Green', 'Blue', 'Yellow'], default: 'Red' },
    ],
  },

  // ── Transistors ──────────────────────────────────────────────────
  NPN_TO92: {
    type: 'NPN_TO92', label: 'NPN Transistor', category: 'Transistors', refPrefix: 'Q',
    ...to92(),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['2N3904', 'BC547', 'S8050'], default: '2N3904' },
    ],
  },
  PNP_TO92: {
    type: 'PNP_TO92', label: 'PNP Transistor', category: 'Transistors', refPrefix: 'Q',
    ...to92(),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['2N3906', 'BC557', 'S8550'], default: '2N3906' },
    ],
  },
  NPN_TO220: {
    // TO-220, text side facing up, pins down: pin1=B, pin2=C, pin3=E -
    // matches datasheet pinout for TIP120/TIP122 NPN Darlington power
    // transistors.
    type: 'NPN_TO220', label: 'NPN Darlington Transistor', category: 'Transistors', refPrefix: 'Q',
    ...relabelPads(to220(), { '1': 'B', '2': 'C', '3': 'E' }),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['TIP120', 'TIP122'], default: 'TIP120' },
    ],
  },
  NMOS_TO220: {
    type: 'NMOS_TO220', label: 'N-Channel MOSFET', category: 'Transistors', refPrefix: 'Q',
    ...to220(),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['IRF540N', 'IRF520', 'IRLZ44N', '2N7000'], default: 'IRF540N' },
    ],
  },
  PMOS_TO220: {
    type: 'PMOS_TO220', label: 'P-Channel MOSFET', category: 'Transistors', refPrefix: 'Q',
    ...to220(),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['IRF9540N', 'FQP27P06'], default: 'IRF9540N' },
    ],
  },

  // ── ICs ──────────────────────────────────────────────────────────
  NE555: {
    type: 'NE555', label: 'NE555 Timer', category: 'ICs', refPrefix: 'U',
    ...dipLabeled(['GND', 'TRIG', 'OUT', 'RESET'], ['CTRL', 'THRES', 'DISCH', 'VCC'], 7.62),
    properties: [{ key: 'partNumber', label: 'Part Number', type: 'text', default: 'NE555P' }],
  },
  LM358: {
    type: 'LM358', label: 'LM358 Op-Amp', category: 'ICs', refPrefix: 'U',
    ...dipLabeled(['OUT1', 'IN1-', 'IN1+', 'V-'], ['IN2+', 'IN2-', 'OUT2', 'V+'], 7.62),
    properties: [{ key: 'partNumber', label: 'Part Number', type: 'text', default: 'LM358N' }],
  },
  LM324: {
    type: 'LM324', label: 'LM324 Quad Op-Amp', category: 'ICs', refPrefix: 'U',
    ...dip(7, 7.62),
    properties: [{ key: 'partNumber', label: 'Part Number', type: 'text', default: 'LM324N' }],
  },
  REG7805: {
    type: 'REG7805', label: '7805 Voltage Regulator', category: 'ICs', refPrefix: 'U',
    // TO-220, text side facing up, pins down: pin1=IN, pin2=GND, pin3=OUT.
    ...relabelPads(to220(), { '1': 'IN', '2': 'GND', '3': 'OUT' }),
    properties: [{ key: 'outputVoltage', label: 'Output Voltage', type: 'text', default: '5V' }],
  },
  AMS1117: {
    type: 'AMS1117', label: 'AMS1117-3.3 LDO Regulator', category: 'ICs', refPrefix: 'U',
    // SOT-223, pins along the bottom edge: pin1=GND, pin2=OUT, pin3=IN.
    ...relabelPads(sot223(), { '1': 'GND', '2': 'OUT', '3': 'IN' }),
    properties: [{ key: 'outputVoltage', label: 'Output Voltage', type: 'text', default: '3.3V' }],
  },
  LM317: {
    type: 'LM317', label: 'LM317 Adjustable Regulator', category: 'ICs', refPrefix: 'U',
    // TO-220, text side facing up, pins down: pin1=ADJ, pin2=OUT, pin3=IN.
    ...relabelPads(to220(), { '1': 'ADJ', '2': 'OUT', '3': 'IN' }),
    properties: [{ key: 'outputRange', label: 'Output Range', type: 'text', default: '1.25–37V' }],
  },

  // ── Logic ────────────────────────────────────────────────────────
  LOGIC_AND: {
    type: 'LOGIC_AND', label: 'AND Gate', category: 'Logic', refPrefix: 'U',
    ...relabelPads(dip(7, 7.62), { '1': 'A', '2': 'B', '3': 'Y' }),
    properties: [{ key: 'partNumber', label: 'IC Part', type: 'select', options: ['74HC08', '4081'], default: '74HC08' }],
  },
  LOGIC_OR: {
    type: 'LOGIC_OR', label: 'OR Gate', category: 'Logic', refPrefix: 'U',
    ...relabelPads(dip(7, 7.62), { '1': 'A', '2': 'B', '3': 'Y' }),
    properties: [{ key: 'partNumber', label: 'IC Part', type: 'select', options: ['74HC32', '4071'], default: '74HC32' }],
  },
  LOGIC_XOR: {
    type: 'LOGIC_XOR', label: 'XOR Gate', category: 'Logic', refPrefix: 'U',
    ...relabelPads(dip(7, 7.62), { '1': 'A', '2': 'B', '3': 'Y' }),
    properties: [{ key: 'partNumber', label: 'IC Part', type: 'select', options: ['74HC86', '4070'], default: '74HC86' }],
  },
  LOGIC_NAND: {
    type: 'LOGIC_NAND', label: 'NAND Gate', category: 'Logic', refPrefix: 'U',
    ...relabelPads(dip(7, 7.62), { '1': 'A', '2': 'B', '3': 'Y' }),
    properties: [{ key: 'partNumber', label: 'IC Part', type: 'select', options: ['74HC00', '4011'], default: '74HC00' }],
  },
  LOGIC_NOR: {
    type: 'LOGIC_NOR', label: 'NOR Gate', category: 'Logic', refPrefix: 'U',
    ...relabelPads(dip(7, 7.62), { '1': 'A', '2': 'B', '3': 'Y' }),
    properties: [{ key: 'partNumber', label: 'IC Part', type: 'select', options: ['74HC02', '4001'], default: '74HC02' }],
  },
  LOGIC_NOT: {
    type: 'LOGIC_NOT', label: 'NOT Gate (Inverter)', category: 'Logic', refPrefix: 'U',
    ...relabelPads(dip(7, 7.62), { '1': 'A', '2': 'Y' }),
    properties: [{ key: 'partNumber', label: 'IC Part', type: 'select', options: ['74HC04', '4069'], default: '74HC04' }],
  },

  // ── Microcontrollers ─────────────────────────────────────────────
  ARDUINO_UNO: (() => {
    const evenRow = (labels: string[], span: number, y: number) => {
      const n = labels.length;
      const step = n > 1 ? span / (n - 1) : 0;
      return labels.map((label, i) => pad(label, -span / 2 + i * step, y, 1.6, 1.6, 1.0, i === 0 ? 'square' : 'round'));
    };
    const digital14 = Array.from({ length: 14 }, (_, i) => `D${i}`);
    const unoAnalog = Array.from({ length: 6 }, (_, i) => `A${i}`);
    const icsp = ['ICSP_MISO', 'ICSP_VCC', 'ICSP_SCK', 'ICSP_MOSI', 'ICSP_RESET', 'ICSP_GND'];
    return {
      type: 'ARDUINO_UNO', label: 'Arduino Uno', category: 'Microcontrollers' as const, refPrefix: 'MCU',
      pads: [
        ...evenRow(digital14, 33, -21.6),
        ...evenRow(['GND', '5V', '3V3', 'VIN', 'RESET', 'AREF', ...unoAnalog], 33, 21.6),
        ...evenRow(icsp, 12.7, -10),
      ],
      outline: [rectOutline(34.3, 26.7)],
      width: 68.6, height: 53.4,
      properties: [
        { key: 'variant', label: 'Variant', type: 'select' as const, options: ['Uno R3', 'Uno R4 Minima', 'Uno R4 WiFi'], default: 'Uno R3' },
      ],
    };
  })(),
  ARDUINO_NANO: (() => {
    const evenRow = (labels: string[], span: number, y: number) => {
      const n = labels.length;
      const step = n > 1 ? span / (n - 1) : 0;
      return labels.map((label, i) => pad(label, -span / 2 + i * step, y, 1.4, 1.4, 0.8, i === 0 ? 'square' : 'round'));
    };
    const digital14 = Array.from({ length: 14 }, (_, i) => `D${i}`);
    const nanoAnalog = Array.from({ length: 8 }, (_, i) => `A${i}`);
    const icsp = ['ICSP_MISO', 'ICSP_VCC', 'ICSP_SCK', 'ICSP_MOSI', 'ICSP_RESET', 'ICSP_GND'];
    return {
      type: 'ARDUINO_NANO', label: 'Arduino Nano', category: 'Microcontrollers' as const, refPrefix: 'MCU',
      pads: [
        ...evenRow(digital14, 18, -9),
        ...evenRow(['GND', '5V', '3V3', 'VIN', 'RESET', 'AREF', ...nanoAnalog], 18, 9),
        ...evenRow(icsp, 7.5, -4.5),
      ],
      outline: [rectOutline(9.5, 11.5)],
      width: 19, height: 23,
      properties: [
        { key: 'variant', label: 'Variant', type: 'select' as const, options: ['Nano', 'Nano Every', 'Nano 33 IoT'], default: 'Nano' },
      ],
    };
  })(),
  ESP32: {
    type: 'ESP32', label: 'ESP32 Dev Board', category: 'Microcontrollers', refPrefix: 'MCU',
    ...dualRowHeader(19, 22.86),
    properties: [
      { key: 'variant', label: 'Variant', type: 'select', options: ['ESP32-WROOM-32', 'ESP32-S3', 'ESP32-C3'], default: 'ESP32-WROOM-32' },
    ],
  },

  // ── Power ────────────────────────────────────────────────────────
  BATTERY: {
    type: 'BATTERY', label: 'Battery', category: 'Power', refPrefix: 'BT',
    pads: [
      pad('+', -3.81, 0, 2.0, 2.0, 1.1, 'square'),
      pad('-', 3.81, 0, 2.0, 2.0, 1.1, 'round'),
    ],
    outline: [rectOutline(5.5, 2.6), [{ x: -1, y: -2.6 }, { x: -1, y: -3.6 }, { x: 1, y: -3.6 }, { x: 1, y: -2.6 }]],
    width: 11, height: 7.2,
    properties: [
      { key: 'voltage', label: 'Voltage', type: 'select', options: ['1.5V', '3.7V', '9V', '12V'], default: '9V' },
    ],
  },
  DC_POWER_SUPPLY: {
    type: 'DC_POWER_SUPPLY', label: 'DC Power Supply', category: 'Power', refPrefix: 'PS',
    pads: [
      pad('+', -3.81, 0, 2.2, 2.2, 1.2, 'square'),
      pad('-', 3.81, 0, 2.2, 2.2, 1.2, 'round'),
    ],
    outline: [rectOutline(6, 4)],
    width: 12, height: 8,
    properties: [
      { key: 'voltage', label: 'Output Voltage', type: 'select', options: ['3.3V', '5V', '9V', '12V', '24V'], default: '5V' },
    ],
  },
  GND: {
    type: 'GND', label: 'Ground', category: 'Power', refPrefix: 'GND',
    pads: [pad('GND', 0, 0, 1.6, 1.6, 0.9, 'round')],
    outline: [
      [{ x: -2, y: 1 }, { x: 2, y: 1 }],
      [{ x: -1.3, y: 2.2 }, { x: 1.3, y: 2.2 }],
      [{ x: -0.6, y: 3.4 }, { x: 0.6, y: 3.4 }],
    ],
    width: 4, height: 4.4,
    properties: [],
  },
  FUSE: {
    type: 'FUSE', label: 'Fuse', category: 'Power', refPrefix: 'F',
    ...axial2(5.08, 2.6, 1.4),
    properties: [
      { key: 'rating', label: 'Current Rating', type: 'select', options: ['0.5A', '1A', '2A', '5A', '10A'], default: '1A' },
    ],
  },
  POLYFUSE: {
    type: 'POLYFUSE', label: 'Polyfuse (PTC)', category: 'Power', refPrefix: 'F',
    // Real resettable PTC fuses (Littelfuse Nanosmdc/Multifuse) come as a
    // small radial disc on a 2.5-5.08mm lead pitch, unlike the axial
    // cartridge a one-shot Fuse uses - radial2 gives it the right pad
    // layout/outline for that.
    ...radial2(5.08, 3.2),
    properties: [
      { key: 'holdCurrent', label: 'Hold Current', type: 'select', options: ['0.1A', '0.5A', '1A', '1.5A', '2A', '3A', '5A'], default: '1A' },
    ],
  },
  SWITCH: {
    type: 'SWITCH', label: 'Switch', category: 'Power', refPrefix: 'SW',
    pads: [
      pad('1', -3.81, 0, 1.6, 1.6, 0.9, 'square'),
      pad('2', 3.81, 0, 1.6, 1.6, 0.9, 'round'),
    ],
    outline: [rectOutline(5, 2)],
    width: 10, height: 4,
    properties: [
      { key: 'switchType', label: 'Type', type: 'select', options: ['SPST', 'Toggle', 'Slide'], default: 'SPST' },
    ],
  },
  PUSHBUTTON: {
    type: 'PUSHBUTTON', label: 'Push Button', category: 'Power', refPrefix: 'SW',
    pads: [
      pad('1', -3.0, -3.0, 1.6, 1.6, 0.9, 'square'),
      pad('2', 3.0, -3.0, 1.6, 1.6, 0.9, 'round'),
      pad('3', -3.0, 3.0, 1.6, 1.6, 0.9, 'round'),
      pad('4', 3.0, 3.0, 1.6, 1.6, 0.9, 'round'),
    ],
    outline: [rectOutline(3.2, 3.2), circlePoly(2.1, 20)],
    width: 6.4, height: 6.4,
    properties: [],
  },
  SPDT_SWITCH: {
    type: 'SPDT_SWITCH', label: 'SPDT Switch', category: 'Power', refPrefix: 'SW',
    pads: [
      pad('1', -3.81, 0, 1.6, 1.6, 0.9, 'square'),
      pad('C', 0, -2.2, 1.6, 1.6, 0.9, 'round'),
      pad('2', 3.81, 0, 1.6, 1.6, 0.9, 'round'),
    ],
    outline: [rectOutline(5, 3)],
    width: 10, height: 6,
    properties: [],
  },

  // ── Connectors ───────────────────────────────────────────────────
  HEADER_M: {
    type: 'HEADER_M', label: 'Male Header', category: 'Connectors', refPrefix: 'J',
    ...headerRow(4),
    properties: [
      { key: 'pinCount', label: 'Pin Count', type: 'select', options: ['2', '3', '4', '6', '8'], default: '4' },
    ],
  },
  HEADER_F: {
    type: 'HEADER_F', label: 'Female Header', category: 'Connectors', refPrefix: 'J',
    ...headerRow(4, 1.9, 1.1),
    properties: [
      { key: 'pinCount', label: 'Pin Count', type: 'select', options: ['2', '3', '4', '6', '8'], default: '4' },
    ],
  },
  UART_HEADER: {
    // 4-pin, 2.54mm pitch breakout header - VCC/GND/TXD/RXD, matching
    // defaultTerminals.uartHeader order in componentDefs.ts.
    type: 'UART_HEADER', label: 'UART Header', category: 'Connectors', refPrefix: 'J',
    ...relabelPads(headerRow(4), { '1': 'VCC', '2': 'GND', '3': 'TXD', '4': 'RXD' }),
    properties: [],
  },
  BLUETOOTH_UART_6PIN: {
    // 6-pin, 2.54mm pitch breakout header used by HC-05/HC-06 UART
    // Bluetooth modules - matches defaultTerminals.hc05/hc06 order in
    // componentDefs.ts.
    type: 'BLUETOOTH_UART_6PIN', label: 'Bluetooth UART Module (6-pin)', category: 'Connectors', refPrefix: 'U',
    ...relabelPads(headerRow(6), { '1': 'VCC', '2': 'TXD', '3': 'RXD', '4': 'STATE', '5': 'GND', '6': 'EN' }),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['HC-05', 'HC-06'], default: 'HC-05' },
    ],
  },
  ESP8266_8PIN: {
    // 8-pin, 2.54mm pitch breakout - matches the real ESP-01/ESP-01S
    // castellated-edge pinout order and defaultTerminals.esp8266 in
    // componentDefs.ts.
    type: 'ESP8266_8PIN', label: 'ESP8266 Module (ESP-01, 8-pin)', category: 'Connectors', refPrefix: 'U',
    ...relabelPads(headerRow(8), { '1': 'VCC', '2': 'GND', '3': 'TXD', '4': 'RXD', '5': 'CH_PD', '6': 'RST', '7': 'GPIO0', '8': 'GPIO2' }),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['ESP-01', 'ESP-01S'], default: 'ESP-01' },
    ],
  },
  ESP32_6PIN: {
    // 6-pin, 2.54mm pitch UART/programming header - matches
    // defaultTerminals.esp32 order in componentDefs.ts. (A full ESP32
    // DevKit breaks out 30+ GPIOs; this footprint represents the module
    // itself as a mountable part on its own carrier board, same
    // simplification used for BLUETOOTH_UART_6PIN above.)
    type: 'ESP32_6PIN', label: 'ESP32 Module (6-pin)', category: 'Connectors', refPrefix: 'U',
    ...relabelPads(headerRow(6), { '1': 'VCC', '2': 'TXD', '3': 'RXD', '4': 'EN', '5': 'GND', '6': 'IO0' }),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['ESP32-WROOM-32', 'ESP32-S3'], default: 'ESP32-WROOM-32' },
    ],
  },
  RC522_7PIN: {
    // 7-pin, 2.54mm pitch breakout header - matches the standard MFRC522
    // module pinout and defaultTerminals.rc522 order in componentDefs.ts.
    type: 'RC522_7PIN', label: 'RC522 RFID Module (7-pin)', category: 'Connectors', refPrefix: 'U',
    ...relabelPads(headerRow(7), { '1': 'SDA', '2': 'SCK', '3': 'MOSI', '4': 'MISO', '5': 'RST', '6': '3.3V', '7': 'GND' }),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['MFRC522'], default: 'MFRC522' },
    ],
  },
  NRF24L01_8PIN: {
    // 8-pin, 2.54mm pitch 2x4 breakout header - matches the standard
    // NRF24L01(+) module pinout and defaultTerminals.nrf24l01 order in
    // componentDefs.ts.
    type: 'NRF24L01_8PIN', label: 'NRF24L01+ Module (8-pin)', category: 'Connectors', refPrefix: 'U',
    ...relabelPads(headerRow(8), { '1': 'VCC', '2': 'GND', '3': 'CE', '4': 'CSN', '5': 'SCK', '6': 'MOSI', '7': 'MISO', '8': 'IRQ' }),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['NRF24L01', 'NRF24L01+'], default: 'NRF24L01+' },
    ],
  },
  GPS_NEO6M_4PIN: {
    // 4-pin, 2.54mm pitch breakout header - matches the standard NEO-6M
    // GPS module pinout and defaultTerminals.gpsNeo6m order in
    // componentDefs.ts.
    type: 'GPS_NEO6M_4PIN', label: 'GPS NEO-6M Module (4-pin)', category: 'Connectors', refPrefix: 'U',
    ...relabelPads(headerRow(4), { '1': 'VCC', '2': 'TX', '3': 'RX', '4': 'GND' }),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['NEO-6M'], default: 'NEO-6M' },
    ],
  },
  MAX485_8PIN: {
    // 8-pin, 2.54mm pitch breakout - matches defaultTerminals.max485
    // order in componentDefs.ts.
    type: 'MAX485_8PIN', label: 'MAX485 Module (8-pin)', category: 'Connectors', refPrefix: 'U',
    ...relabelPads(headerRow(8), { '1': 'VCC', '2': 'GND', '3': 'RO', '4': 'RE', '5': 'DE', '6': 'DI', '7': 'A', '8': 'B' }),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['MAX485', 'MAX3485'], default: 'MAX485' },
    ],
  },
  CAN_BUS_MODULE_7PIN: {
    // 7-pin, 2.54mm pitch SPI breakout - matches defaultTerminals.canBusModule
    // order in componentDefs.ts.
    type: 'CAN_BUS_MODULE_7PIN', label: 'CAN Bus Module (MCP2515, 7-pin)', category: 'Connectors', refPrefix: 'U',
    ...relabelPads(headerRow(7), { '1': 'VCC', '2': 'GND', '3': 'CS', '4': 'SO', '5': 'SI', '6': 'SCK', '7': 'INT' }),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['MCP2515'], default: 'MCP2515' },
    ],
  },
  I2C_HEADER: {
    // 4-pin, 2.54mm pitch breakout header - VCC/GND/SDA/SCL, matching
    // defaultTerminals.i2cHeader order in componentDefs.ts.
    type: 'I2C_HEADER', label: 'I2C Header', category: 'Connectors', refPrefix: 'J',
    ...relabelPads(headerRow(4), { '1': 'VCC', '2': 'GND', '3': 'SDA', '4': 'SCL' }),
    properties: [],
  },
  SCREW_TERMINAL: {
    type: 'SCREW_TERMINAL', label: 'Screw Terminal', category: 'Connectors', refPrefix: 'J',
    pads: [
      pad('1', -2.54, 0, 2.4, 2.4, 1.3, 'square'),
      pad('2', 2.54, 0, 2.4, 2.4, 1.3, 'round'),
    ],
    outline: [rectOutline(4, 3)],
    width: 8, height: 6,
    properties: [
      { key: 'pinCount', label: 'Pin Count', type: 'select', options: ['2', '3', '4'], default: '2' },
    ],
  },
  BARREL_JACK: {
    type: 'BARREL_JACK', label: 'Barrel Jack', category: 'Connectors', refPrefix: 'J',
    pads: [
      pad('TIP', -3.5, 3, 1.8, 1.8, 1.0, 'square'),
      pad('SLV', 3.5, 3, 1.8, 1.8, 1.0, 'round'),
      pad('SW', 0, -3, 1.8, 1.8, 1.0, 'round'),
    ],
    outline: [rectOutline(5, 6)],
    width: 10, height: 12,
    properties: [],
  },
  JST_2PIN: {
    type: 'JST_2PIN', label: 'JST 2-Pin Connector', category: 'Connectors', refPrefix: 'J',
    pads: [
      pad('1', -1, 0, 1.1, 1.6, 0.7, 'square'),
      pad('2', 1, 0, 1.1, 1.6, 0.7, 'round'),
    ],
    outline: [rectOutline(3.5, 2.5)],
    width: 7, height: 5,
    properties: [],
  },

  // ── Displays ─────────────────────────────────────────────────────
  SEVEN_SEG: {
    type: 'SEVEN_SEG', label: '7-Segment Display', category: 'Displays', refPrefix: 'DS',
    pads: [
      // Bottom row (real 10-pin single-digit pinout, pins 1-5): e, d, COM, c, dp.
      ...['e', 'd', 'COM', 'c', 'dp'].map((n, i) => pad(n, -10.16 + i * 5.08, -7.62, 1.6, 1.6, 0.9, i === 0 ? 'square' : 'round')),
      // Top row (pins 6-10): f, g, COM, a, b. Both COM pins are tied to the
      // same internal common leg, matching the real part's dual COM pins.
      ...['f', 'g', 'COM', 'a', 'b'].map((n, i) => pad(n, -10.16 + i * 5.08, 7.62, 1.6, 1.6, 0.9, 'round')),
    ],
    outline: [rectOutline(10.4, 9.5)],
    width: 20.8, height: 19,
    properties: [
      { key: 'commonType', label: 'Common', type: 'select', options: ['Common Cathode', 'Common Anode'], default: 'Common Cathode' },
    ],
  },
  LCD16X2: {
    type: 'LCD16X2', label: 'LCD 16x2', category: 'Displays', refPrefix: 'LCD',
    pads: (() => {
      // Real HD44780 16-pin header pinout, left to right: VSS(GND), VDD(VCC),
      // V0, RS, RW, E(EN), D0-D3 (unused in 4-bit mode), D4-D7, A, K.
      const labels = ['GND', 'VCC', 'V0', 'RS', 'RW', 'EN', 'D0', 'D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'A', 'K'];
      const startX = -((labels.length - 1) * 1.5) / 2;
      return labels.map((label, i) => pad(label, startX + i * 1.5, 0, 1.5, 1.5, 0.9, i === 0 ? 'square' : 'round'));
    })(),
    outline: [rectOutline(40, 18), rectOutline(6.8, 4)],
    width: 80, height: 36,
    properties: [
      { key: 'backlight', label: 'Backlight', type: 'select', options: ['Blue', 'Green', 'White'], default: 'Blue' },
    ],
  },
  OLED: {
    type: 'OLED', label: 'OLED Display', category: 'Displays', refPrefix: 'OLED',
    pads: [
      pad('GND', -1.905, 12, 1.6, 1.6, 0.9, 'square'),
      pad('VCC', -0.635, 12, 1.6, 1.6, 0.9, 'round'),
      pad('SCL', 0.635, 12, 1.6, 1.6, 0.9, 'round'),
      pad('SDA', 1.905, 12, 1.6, 1.6, 0.9, 'round'),
    ],
    outline: [rectOutline(13.5, 13.5), rectOutline(11, 11)],
    width: 27, height: 27,
    properties: [
      { key: 'size', label: 'Size', type: 'select', options: ['0.91in', '0.96in', '1.3in'], default: '0.96in' },
      { key: 'interface', label: 'Interface', type: 'select', options: ['I2C', 'SPI'], default: 'I2C' },
    ],
  },

  // ── Sensors ──────────────────────────────────────────────────────
  LDR: {
    type: 'LDR', label: 'LDR (Photoresistor)', category: 'Sensors', refPrefix: 'R',
    pads: [
      pad('Pin 1', -3.81, 0, 1.4, 1.4, 0.8, 'square'),
      pad('Pin 2', 3.81, 0, 1.4, 1.4, 0.8, 'round'),
    ],
    outline: [circlePoly(3.6, 22)],
    width: 8.6, height: 7.2,
    properties: [],
  },
  TEMP_SENSOR: {
    type: 'TEMP_SENSOR', label: 'Temperature Sensor', category: 'Sensors', refPrefix: 'U',
    ...to92('VCC', 'OUT', 'GND'),
    properties: [
      { key: 'partNumber', label: 'Part Number', type: 'select', options: ['LM35', 'DS18B20', 'TMP36'], default: 'DS18B20' },
    ],
  },
  ULTRASONIC: {
    type: 'ULTRASONIC', label: 'Ultrasonic Sensor', category: 'Sensors', refPrefix: 'U',
    pads: [
      pad('VCC', -3.81, 8.5, 1.6, 1.6, 0.9, 'square'),
      pad('Trig', -1.27, 8.5, 1.6, 1.6, 0.9, 'round'),
      pad('Echo', 1.27, 8.5, 1.6, 1.6, 0.9, 'round'),
      pad('GND', 3.81, 8.5, 1.6, 1.6, 0.9, 'round'),
    ],
    outline: [
      rectOutline(22.5, 10),
      circlePoly(8, 20).map(p => ({ x: p.x - 12, y: p.y - 5 })),
      circlePoly(8, 20).map(p => ({ x: p.x + 12, y: p.y - 5 })),
    ],
    width: 45, height: 20,
    properties: [
      { key: 'partNumber', label: 'Module', type: 'text', default: 'HC-SR04' },
    ],
  },

  // ── Motors ───────────────────────────────────────────────────────
  DC_MOTOR: {
    type: 'DC_MOTOR', label: 'DC Motor', category: 'Motors', refPrefix: 'M',
    pads: [
      pad('+', -3.81, 0, 2.0, 2.0, 1.1, 'square'),
      pad('-', 3.81, 0, 2.0, 2.0, 1.1, 'round'),
    ],
    outline: [circlePoly(6, 24)],
    width: 12, height: 12,
    properties: [
      { key: 'voltage', label: 'Rated Voltage', type: 'select', options: ['3V', '5V', '6V', '12V'], default: '6V' },
    ],
  },
  SERVO_MOTOR: {
    type: 'SERVO_MOTOR', label: 'Servo Motor', category: 'Motors', refPrefix: 'SV',
    pads: [
      pad('S', -2.54, 0, 1.7, 1.7, 1.0, 'square'),
      pad('+', 0, 0, 1.7, 1.7, 1.0, 'round'),
      pad('GND', 2.54, 0, 1.7, 1.7, 1.0, 'round'),
    ],
    outline: [rectOutline(4.5, 2.2)],
    width: 8.6, height: 4.4,
    properties: [
      { key: 'partNumber', label: 'Model', type: 'select', options: ['SG90', 'MG995', 'MG996R'], default: 'SG90' },
    ],
  },
  RELAY: {
    type: 'RELAY', label: 'Relay', category: 'Motors', refPrefix: 'K',
    pads: [
      pad('C+', -6.35, -3.5, 1.8, 1.8, 1.0, 'square'),
      pad('C-', -6.35, 3.5, 1.8, 1.8, 1.0, 'round'),
      pad('COM', 0, -6.5, 1.8, 1.8, 1.0, 'round'),
      pad('NO', 6.35, -3.5, 1.8, 1.8, 1.0, 'round'),
      pad('NC', 6.35, 3.5, 1.8, 1.8, 1.0, 'round'),
    ],
    outline: [rectOutline(9.5, 7.5)],
    width: 19, height: 15,
    properties: [
      { key: 'coilVoltage', label: 'Coil Voltage', type: 'select', options: ['5V', '12V', '24V'], default: '5V' },
    ],
  },
  BUZZER: {
    type: 'BUZZER', label: 'Buzzer', category: 'Motors', refPrefix: 'BZ',
    pads: [
      pad('+', -3.5, 0, 1.8, 1.8, 1.0, 'square'),
      pad('-', 3.5, 0, 1.8, 1.8, 1.0, 'round'),
    ],
    outline: [circlePoly(6, 24)],
    width: 12, height: 12,
    properties: [
      { key: 'buzzerType', label: 'Type', type: 'select', options: ['Piezo', 'Magnetic'], default: 'Piezo' },
    ],
  },

  // ── Added to sync with Circuit Simulator component types that had no
  // PCB footprint yet. Pad ids/order match each type's defaultTerminals
  // entry in src/circuit/componentDefs.ts exactly (same label strings,
  // same array order), so pin numbering lines up with the simulator.
  // Nothing above this point was modified.

  // relayModule: IN+/IN- (coil) then NC/COM/NO (screw-terminal contacts).
  RELAY_MODULE: {
    type: 'RELAY_MODULE', label: 'Relay Module', category: 'Motors', refPrefix: 'K',
    pads: [
      pad('IN+', -8.89, -3.5, 1.8, 1.8, 1.0, 'square'),
      pad('IN-', -8.89, 3.5, 1.8, 1.8, 1.0, 'round'),
      pad('NC', 8.89, -5.08, 2.0, 2.0, 1.1, 'round'),
      pad('COM', 8.89, 0, 2.0, 2.0, 1.1, 'round'),
      pad('NO', 8.89, 5.08, 2.0, 2.0, 1.1, 'round'),
    ],
    outline: [rectOutline(12.7, 8)],
    width: 25.4, height: 16,
    properties: [
      { key: 'coilVoltage', label: 'Coil Voltage', type: 'select', options: ['5V', '12V', '24V'], default: '5V' },
    ],
  },
  // solenoidValve: coil-only pads (+/-), matching componentDefs' comment
  // that the plumbing side isn't an electrical net.
  SOLENOID_VALVE: {
    type: 'SOLENOID_VALVE', label: 'Solenoid Valve', category: 'Motors', refPrefix: 'SOL',
    ...labeledAxial2('+', '-', 7.62, 4, 3.5),
  },
  WATER_PUMP: {
    type: 'WATER_PUMP', label: 'Water Pump', category: 'Motors', refPrefix: 'PMP',
    pads: [
      pad('+', -3.81, 0, 2.0, 2.0, 1.1, 'square'),
      pad('-', 3.81, 0, 2.0, 2.0, 1.1, 'round'),
    ],
    outline: [circlePoly(7, 24)],
    width: 14, height: 14,
    properties: [
      { key: 'voltage', label: 'Rated Voltage', type: 'select', options: ['3V', '5V', '6V', '12V'], default: '6V' },
    ],
  },
  // stepperMotor: A+/A- then B+/B- (two coil pairs) - same array order as
  // componentDefs.ts so an A4988/ULN2003 driver wiring lines up.
  STEPPER_MOTOR: {
    type: 'STEPPER_MOTOR', label: 'Stepper Motor', category: 'Motors', refPrefix: 'M',
    pads: [
      pad('A+', -3.81, -3.81, 1.8, 1.8, 1.0, 'square'),
      pad('A-', -3.81, 3.81, 1.8, 1.8, 1.0, 'round'),
      pad('B+', 3.81, -3.81, 1.8, 1.8, 1.0, 'round'),
      pad('B-', 3.81, 3.81, 1.8, 1.8, 1.0, 'round'),
    ],
    outline: [circlePoly(8, 28)],
    width: 16, height: 16,
    properties: [],
  },
  BUZZER_ACTIVE: {
    type: 'BUZZER_ACTIVE', label: 'Active Buzzer', category: 'Motors', refPrefix: 'BZ',
    ...labeledAxial2('+', '-', 7, 6, 6),
  },
  BUZZER_PASSIVE: {
    type: 'BUZZER_PASSIVE', label: 'Passive Buzzer', category: 'Motors', refPrefix: 'BZ',
    ...labeledAxial2('+', '-', 7, 6, 6),
  },
  // rgbLed: R, C (common), G, B - same order as componentDefs.ts.
  RGB_LED: {
    type: 'RGB_LED', label: 'RGB LED', category: 'Diodes', refPrefix: 'D',
    ...labeledRow(['R', 'C', 'G', 'B'], 2.0, 1.3, 0.8),
  },
  NEOPIXEL: {
    type: 'NEOPIXEL', label: 'NeoPixel (WS2812)', category: 'Displays', refPrefix: 'U',
    ...labeledRow(['VCC', 'DIN', 'DOUT', 'GND'], 2.0, 1.3, 0.8),
  },
  // sevenSegment4: 8 segment pins (a-g, dp) then 4 digit commons D1-D4,
  // matching componentDefs.ts's array order.
  SEVEN_SEG4: {
    type: 'SEVEN_SEG4', label: '4-Digit 7-Segment Display', category: 'Displays', refPrefix: 'DS',
    pads: [
      ...['a', 'b', 'c', 'd', 'e', 'f', 'g', 'dp'].map((n, i) => pad(n, -8.89 + i * 2.54, -8, 1.4, 1.4, 0.8, i === 0 ? 'square' : 'round')),
      ...['D1', 'D2', 'D3', 'D4'].map((n, i) => pad(n, -7.62 + i * 5.08, 8, 1.6, 1.6, 0.9, 'round')),
    ],
    outline: [rectOutline(18, 16)],
    width: 36, height: 32,
    properties: [
      { key: 'commonType', label: 'Common', type: 'select', options: ['Common Cathode', 'Common Anode'], default: 'Common Cathode' },
    ],
  },
  // ammeter/voltmeter: idealized meters, but real panel-meter modules do
  // mount two solder/screw pins - kept as simple 2-pad symbols so the
  // simulator's inline (ammeter) / parallel (voltmeter) probes have a
  // real-world PCB stand-in.
  AMMETER: {
    type: 'AMMETER', label: 'Ammeter', category: 'Sensors', refPrefix: 'A',
    ...labeledAxial2('1', '2', 7.62, 4, 3),
  },
  VOLTMETER: {
    type: 'VOLTMETER', label: 'Voltmeter', category: 'Sensors', refPrefix: 'V',
    ...labeledAxial2('+', '-', 7.62, 4, 3),
  },
  AC_SOURCE: {
    type: 'AC_SOURCE', label: 'AC Source', category: 'Power', refPrefix: 'AC',
    ...labeledAxial2('L', 'N', 7.62, 4.5, 4),
  },
  DC_CURRENT_SRC: {
    type: 'DC_CURRENT_SRC', label: 'DC Current Source', category: 'Power', refPrefix: 'I',
    ...labeledAxial2('+', '-', 7.62, 4.5, 4),
  },
  // transformer: P1/P2 (primary) then S1/S2 (secondary), matching
  // componentDefs.ts's array order.
  TRANSFORMER: {
    type: 'TRANSFORMER', label: 'Transformer', category: 'Power', refPrefix: 'T',
    pads: [
      pad('P1', -5.08, -3.81, 1.8, 1.8, 1.0, 'square'),
      pad('P2', -5.08, 3.81, 1.8, 1.8, 1.0, 'round'),
      pad('S1', 5.08, -3.81, 1.8, 1.8, 1.0, 'round'),
      pad('S2', 5.08, 3.81, 1.8, 1.8, 1.0, 'round'),
    ],
    outline: [rectOutline(10, 10)],
    width: 20, height: 20,
    properties: [],
  },
  BULB: {
    type: 'BULB', label: 'Light Bulb', category: 'Passive Components', refPrefix: 'LB',
    pads: [
      pad('1', -3.81, 0, 1.6, 1.6, 0.9, 'square'),
      pad('2', 3.81, 0, 1.6, 1.6, 0.9, 'round'),
    ],
    outline: [circlePoly(5, 22)],
    width: 10, height: 10,
    properties: [],
  },
  // breadboard: purely a prototyping surface, not an electrical part - has
  // no terminals in the simulator either (defaultTerminals.breadboard is
  // []), so no pads here. Outline-only so it still exists as a placeable
  // reference/keep-out footprint in the PCB Editor.
  BREADBOARD: {
    type: 'BREADBOARD', label: 'Breadboard', category: 'Other', refPrefix: 'BB',
    pads: [],
    outline: [rectOutline(35, 22.5)],
    width: 70, height: 45,
    properties: [],
  },

  // ── Microcontrollers (added) ────────────────────────────────────────
  // Mega 2560: two 28-pin digital rows, a power/analog row (6 fixed names
  // + 16 analog), and the ICSP 2x3 header - same label lists and same
  // row groupings as componentDefs.ts's arduinoMega, just laid out in mm.
  ARDUINO_MEGA: (() => {
    const evenRow = (labels: string[], span: number, y: number) => {
      const n = labels.length;
      const step = n > 1 ? span / (n - 1) : 0;
      return labels.map((label, i) => pad(label, -span / 2 + i * step, y, 1.4, 1.4, 0.8, 'round'));
    };
    const megaDigital = Array.from({ length: 54 }, (_, i) => `D${i}`);
    const megaAnalog = Array.from({ length: 16 }, (_, i) => `A${i}`);
    const icsp = ['ICSP_MISO', 'ICSP_VCC', 'ICSP_SCK', 'ICSP_MOSI', 'ICSP_RESET', 'ICSP_GND'];
    return {
      type: 'ARDUINO_MEGA', label: 'Arduino Mega 2560', category: 'Microcontrollers' as const, refPrefix: 'MCU',
      pads: [
        ...evenRow(megaDigital.slice(0, 27), 66, -11.43),
        ...evenRow(megaDigital.slice(27), 66, -7.62),
        ...evenRow(['GND', '5V', '3V3', 'VIN', 'RESET', 'AREF', ...megaAnalog], 66, 7.62),
        ...evenRow(icsp, 12.7, -15.24),
      ],
      outline: [rectOutline(45, 27)],
      width: 90, height: 54,
      properties: [
        { key: 'variant', label: 'Variant', type: 'select' as const, options: ['Mega 2560'], default: 'Mega 2560' },
      ],
    };
  })(),

  // ── Sensors (added) ─────────────────────────────────────────────────
  DHT11: {
    type: 'DHT11', label: 'DHT11 Temp/Humidity Sensor', category: 'Sensors', refPrefix: 'U',
    ...labeledRow(['VCC', 'DATA', 'NC', 'GND'], 2.54, 1.5, 0.9),
  },
  PIR_MOTION: {
    type: 'PIR_MOTION', label: 'PIR Motion Sensor', category: 'Sensors', refPrefix: 'U',
    ...labeledRow(['VCC', 'OUT', 'GND'], 2.54, 1.5, 0.9),
  },
  IR_OBSTACLE: {
    type: 'IR_OBSTACLE', label: 'IR Obstacle Sensor', category: 'Sensors', refPrefix: 'U',
    ...labeledRow(['VCC', 'GND', 'OUT'], 2.54, 1.5, 0.9),
  },
  MQ2_GAS: {
    type: 'MQ2_GAS', label: 'MQ-2 Gas Sensor', category: 'Sensors', refPrefix: 'U',
    ...labeledRow(['VCC', 'GND', 'AO', 'DO'], 2.54, 1.5, 0.9),
  },
  FLAME_SENSOR: {
    type: 'FLAME_SENSOR', label: 'Flame Sensor', category: 'Sensors', refPrefix: 'U',
    ...labeledRow(['VCC', 'GND', 'DO', 'AO'], 2.54, 1.5, 0.9),
  },

  // ── ICs (added) ──────────────────────────────────────────────────────
  // All of these reuse dip()'s pad numbering (1..n down the left side,
  // n+1..2n back up the right side) which is exactly the physical DIP pin
  // order componentDefs.ts's comments describe for each part, so array
  // index 0 in the simulator = pad "1" here, etc.
  LM741: {
    type: 'LM741', label: 'LM741 Op-Amp', category: 'ICs', refPrefix: 'U',
    ...dipLabeled(['NC1', 'IN-', 'IN+', 'V-'], ['NC2', 'OUT', 'V+', 'NC'], 7.62),
    properties: [{ key: 'partNumber', label: 'Part Number', type: 'text', default: 'LM741' }],
  },
  L293D: {
    type: 'L293D', label: 'L293D Motor Driver', category: 'ICs', refPrefix: 'U',
    ...dipLabeled(
      ['EN1,2', 'IN1', 'OUT1', 'GND', 'GND', 'OUT2', 'IN2', 'VCC2'],
      ['EN3,4', 'IN3', 'OUT3', 'GND', 'GND', 'OUT4', 'IN4', 'VCC1'],
      7.62,
    ),
    properties: [{ key: 'partNumber', label: 'Part Number', type: 'text', default: 'L293D' }],
  },
  // l298n: real breakout module, not a bare DIP - custom pad layout
  // matching componentDefs.ts's screw-terminal + control-header positions
  // (power block, two motor screw terminals, control header) in the same
  // array order.
  L298N: {
    type: 'L298N', label: 'L298N Motor Driver Module', category: 'ICs', refPrefix: 'U',
    pads: [
      pad('GND', -7.62, -6.35, 1.8, 1.8, 1.0, 'square'),
      pad('12V', -5.08, -6.35, 1.8, 1.8, 1.0, 'round'),
      pad('5V', -2.54, -6.35, 1.8, 1.8, 1.0, 'round'),
      pad('ENA', -7.62, 6.35, 1.6, 1.6, 0.9, 'round'),
      pad('IN1', -5.08, 6.35, 1.6, 1.6, 0.9, 'round'),
      pad('IN2', -2.54, 6.35, 1.6, 1.6, 0.9, 'round'),
      pad('OUT1', -8.89, 0, 2.0, 2.0, 1.1, 'round'),
      pad('OUT2', -8.89, 2.54, 2.0, 2.0, 1.1, 'round'),
      pad('ENB', 2.54, 6.35, 1.6, 1.6, 0.9, 'round'),
      pad('IN3', 5.08, 6.35, 1.6, 1.6, 0.9, 'round'),
      pad('IN4', 7.62, 6.35, 1.6, 1.6, 0.9, 'round'),
      pad('OUT3', 8.89, 0, 2.0, 2.0, 1.1, 'round'),
      pad('OUT4', 8.89, 2.54, 2.0, 2.0, 1.1, 'round'),
    ],
    outline: [rectOutline(11, 8.5)],
    width: 22, height: 17,
    properties: [],
  },
  ULN2003: {
    type: 'ULN2003', label: 'ULN2003 Driver', category: 'ICs', refPrefix: 'U',
    ...dipLabeled(
      ['IN1', 'IN2', 'IN3', 'IN4', 'IN5', 'IN6', 'IN7', 'GND'],
      ['COM', 'OUT7', 'OUT6', 'OUT5', 'OUT4', 'OUT3', 'OUT2', 'OUT1'],
      7.62,
    ),
    properties: [{ key: 'partNumber', label: 'Part Number', type: 'text', default: 'ULN2003A' }],
  },
  HC74595: {
    type: 'HC74595', label: '74HC595 Shift Register', category: 'ICs', refPrefix: 'U',
    ...dipLabeled(
      ['Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6', 'Q7', 'GND'],
      ["Q7'", 'MR', 'SH_CP', 'ST_CP', 'OE', 'DS', 'Q0', 'VCC'],
      7.62,
    ),
    properties: [{ key: 'partNumber', label: 'Part Number', type: 'text', default: '74HC595' }],
  },
  HC74165: {
    type: 'HC74165', label: '74HC165 Shift Register', category: 'ICs', refPrefix: 'U',
    ...dipLabeled(
      ['SH/LD', 'CLK', 'D4', 'D5', 'D6', 'D7', "QH'", 'GND'],
      ['CLK INH', 'SER', 'D0', 'D1', 'D2', 'D3', 'QH', 'VCC'],
      7.62,
    ),
    properties: [{ key: 'partNumber', label: 'Part Number', type: 'text', default: '74HC165' }],
  },
  CD4017: {
    type: 'CD4017', label: 'CD4017 Counter', category: 'ICs', refPrefix: 'U',
    ...dipLabeled(
      ['Q5', 'Q1', 'Q0', 'Q2', 'Q6', 'Q7', 'Q3', 'GND'],
      ['Q8', 'Q9', 'Q4', 'CO', 'CLK INH', 'CLOCK', 'RESET', 'VDD'],
      7.62,
    ),
    properties: [{ key: 'partNumber', label: 'Part Number', type: 'text', default: 'CD4017' }],
  },
  CD4026: {
    type: 'CD4026', label: 'CD4026 Counter', category: 'ICs', refPrefix: 'U',
    ...dipLabeled(
      ['CLOCK', 'CLK INH', 'DEI', 'DEO', 'CO', 'g', 'f', 'GND'],
      ['d', 'a', 'e', 'b', 'c', "C'", 'RESET', 'VDD'],
      7.62,
    ),
    properties: [{ key: 'partNumber', label: 'Part Number', type: 'text', default: 'CD4026' }],
  },
  PC817: {
    type: 'PC817', label: 'PC817 Optocoupler', category: 'ICs', refPrefix: 'U',
    ...dipLabeled(['A', 'K'], ['E', 'C'], 7.62),
    properties: [{ key: 'partNumber', label: 'Part Number', type: 'text', default: 'PC817' }],
  },
};

export type FootprintKey = keyof typeof FOOTPRINTS;

export const CATEGORY_ORDER: string[] = [
  'Passive Components', 'Diodes', 'Transistors', 'ICs', 'Logic',
  'Microcontrollers', 'Power', 'Connectors', 'Displays', 'Sensors', 'Motors',
  'Other',
];

// Build the default `props` map for a newly-placed component of a given footprint.
export function defaultPropsFor(footprintKey: string): Record<string, string> {
  const fp = FOOTPRINTS[footprintKey];
  const out: Record<string, string> = {};
  if (!fp?.properties) return out;
  for (const p of fp.properties) out[p.key] = p.default;
  return out;
}
