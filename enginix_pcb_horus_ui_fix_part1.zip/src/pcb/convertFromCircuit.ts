/**
 * Circuit Simulator -> PCB Editor conversion ("Convert to PCB").
 *
 * Pure, read-only functions: given the Circuit Simulator's live components
 * and wires, produce the PCB footprints + connectivity data to place on the
 * board. Never imports from, mutates, or otherwise touches the Circuit
 * Simulator's own state (CircuitEditor.ts) - it only reads the plain data
 * objects handed to it, plus the already-exported, side-effect-free
 * `buildNets` helper from circuit/simulator.ts (the same union-find the
 * simulator itself uses to group terminals into electrical nets), so net
 * grouping here always matches what the simulator considers connected -
 * including closed switches, relay contacts, and shared net-label joins,
 * not just point-to-point wires.
 *
 * Does NOT generate copper routing. Connections are preserved as a
 * `Netlist[]` (see ./types.ts) for PCBEngine's ratsnest/auto-router to
 * consume - this module only ever produces footprint placements + that
 * connectivity data.
 */

import type { Component, Wire } from '../circuit/types';
import { buildNets } from '../circuit/simulator';
import { footprintKeyFor } from './simulatorSync';
import { FOOTPRINTS, defaultPropsFor } from './footprints';
import type { Netlist, Rotation } from './types';

// 1 Circuit Simulator grid unit -> mm on the PCB board. Matches the classic
// 0.1" (2.54mm) through-hole pitch most of the footprints in footprints.ts
// are drawn around, so a converted layout keeps roughly the same relative
// spacing the schematic had.
export const MM_PER_GRID_UNIT = 2.54;

/** A single footprint to place, produced from one Circuit Simulator Component. */
export interface ConvertedComponent {
  sourceComponentId: number;
  footprint: string;
  refDes: string;
  x: number;
  y: number;
  rotation: Rotation;
  props: Record<string, string>;
}

export interface ConvertResult {
  components: ConvertedComponent[];
  netlist: Netlist[];
  // Circuit Simulator component types encountered with no known PCB
  // footprint mapping (see simulatorSync.ts) - skipped, never guessed at.
  unmapped: string[];
}

function toRotation(steps: number): Rotation {
  const deg = (((Math.round(steps) % 4) + 4) % 4) * 90;
  return deg as Rotation;
}

/** Picks a reference designator for a converted component: the circuit's
 * own label when it has one and it isn't already taken, otherwise the
 * footprint's next free `<prefix><n>`. */
function refDesFor(comp: Component, prefix: string, used: Set<string>): string {
  const label = typeof comp.label === 'string' ? comp.label.trim() : '';
  if (label && !used.has(label)) {
    used.add(label);
    return label;
  }
  let n = 1;
  while (used.has(`${prefix}${n}`)) n++;
  const refDes = `${prefix}${n}`;
  used.add(refDes);
  return refDes;
}

// Must match simulator.ts's buildNets exactly - it keys its union-find by
// `componentId * 10000 + terminalIndex`, and the returned Map is only
// meaningful when queried with that same encoding.
const terminalKey = (compId: number, termIdx: number) => compId * 10000 + termIdx;

/**
 * Reads a complete Circuit Simulator circuit and returns the PCB
 * footprints + netlist to import. Preserves position, rotation, labels
 * (as ref designators), and property values; preserves every electrical
 * connection - direct wires, shared net-label joins, and closed
 * switch/relay contacts alike - as a PCB net, carrying the wire's net
 * label over as the net's name when one was set.
 */
export function convertCircuitToPCB(components: Component[], wires: Wire[]): ConvertResult {
  const used = new Set<string>();
  const converted: ConvertedComponent[] = [];
  const unmapped: string[] = [];
  // Circuit terminal id -> where it landed on the PCB, for netlist building.
  const terminalIndex = new Map<number, { refDes: string; label: string }>();
  // Circuit terminal id -> (componentId, terminalIndex), to query buildNets'
  // synthetic-id map below.
  const terminalPos = new Map<number, { compId: number; idx: number }>();

  for (const comp of components) {
    // Wire junctions are an internal wiring-editor artifact with no
    // physical PCB representation (see the comment on 'junction' in
    // circuit/types.ts) - never placed from a palette, so never converted.
    if (comp.type === 'junction') continue;

    const footprintKey = footprintKeyFor(comp.type);
    if (!footprintKey || !FOOTPRINTS[footprintKey]) {
      unmapped.push(comp.type);
      continue;
    }

    const fp = FOOTPRINTS[footprintKey];
    const refDes = refDesFor(comp, fp.refPrefix, used);

    // Start from the footprint's defaults, then overlay every value the
    // circuit component actually has for a matching property key.
    const props = defaultPropsFor(footprintKey);
    for (const field of fp.properties ?? []) {
      const raw = comp.props[field.key];
      if (raw !== undefined && raw !== null) props[field.key] = String(raw);
    }

    converted.push({
      sourceComponentId: comp.id,
      footprint: footprintKey,
      refDes,
      x: comp.x * MM_PER_GRID_UNIT,
      y: comp.y * MM_PER_GRID_UNIT,
      rotation: toRotation(comp.rotation),
      props,
    });

    comp.terminals.forEach((t, idx) => {
      terminalIndex.set(t.id, { refDes, label: t.label });
      terminalPos.set(t.id, { compId: comp.id, idx });
    });
  }

  // Group every placed terminal by the electrical net the simulator itself
  // would assign it (buildNets already accounts for direct wires, shared
  // net labels, and closed switch/relay contacts - see simulator.ts).
  const netMap = buildNets(components, wires);
  const groups = new Map<number, { refDes: string; terminalLabel: string }[]>();
  for (const [terminalId, pos] of terminalPos) {
    const placed = terminalIndex.get(terminalId);
    if (!placed) continue;
    const simNetId = netMap.get(terminalKey(pos.compId, pos.idx));
    if (simNetId === undefined) continue;
    if (!groups.has(simNetId)) groups.set(simNetId, []);
    groups.get(simNetId)!.push({ refDes: placed.refDes, terminalLabel: placed.label });
  }

  // Net names: the label on any wire whose endpoint resolved into that
  // group (matches buildNets' own trimmed label - first label wins if a
  // net somehow carries more than one, which buildNets itself also merges
  // into a single group).
  const nameBySimNetId = new Map<number, string>();
  for (const wire of wires) {
    const label = wire.netLabel?.trim();
    if (!label) continue;
    const fromPos = terminalPos.get(wire.fromTerminalId);
    if (!fromPos) continue;
    const simNetId = netMap.get(terminalKey(fromPos.compId, fromPos.idx));
    if (simNetId === undefined || nameBySimNetId.has(simNetId)) continue;
    nameBySimNetId.set(simNetId, label);
  }

  const netlist: Netlist[] = [];
  let netId = 1;
  for (const [simNetId, rawPins] of groups) {
    // De-dupe identical (refDes, terminalLabel) pairs - a terminal can be
    // visited more than once if multiple wires touch it.
    const seen = new Set<string>();
    const pins = rawPins.filter(p => {
      const k = `${p.refDes}.${p.terminalLabel}`;
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
    // A net with fewer than 2 surviving pins carries no connection to
    // preserve (e.g. every terminal on it belonged to an unmapped part).
    if (pins.length < 2) continue;
    netlist.push({ id: netId++, pins, name: nameBySimNetId.get(simNetId) });
  }

  return { components: converted, netlist, unmapped };
}
