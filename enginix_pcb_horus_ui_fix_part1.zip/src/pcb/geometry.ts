/**
 * PCB Editor - geometry helpers
 * Cardinal rotations only (0/90/180/270). Bottom-side components are
 * mirrored on X (as they would appear when the board is flipped over).
 */

import type { PCBComponent, FootprintPad, Rotation } from './types';

export function rotatePoint(x: number, y: number, rotation: Rotation): { x: number; y: number } {
  switch (rotation) {
    case 90: return { x: -y, y: x };
    case 180: return { x: -x, y: -y };
    case 270: return { x: y, y: -x };
    default: return { x, y };
  }
}

// Absolute board-space position of a footprint pad, accounting for
// component rotation and top/bottom mirroring.
export function padAbsolutePos(comp: PCBComponent, pad: FootprintPad): { x: number; y: number } {
  const r = rotatePoint(pad.x, pad.y, comp.rotation);
  const mx = comp.side === 'bottom' ? -r.x : r.x;
  return { x: comp.x + mx, y: comp.y + r.y };
}

export function pointAbsolutePos(comp: PCBComponent, px: number, py: number): { x: number; y: number } {
  const r = rotatePoint(px, py, comp.rotation);
  const mx = comp.side === 'bottom' ? -r.x : r.x;
  return { x: comp.x + mx, y: comp.y + r.y };
}

// Effective bounding box (width/height swap on 90/270 rotation).
export function footprintBBox(w: number, h: number, rotation: Rotation): { w: number; h: number } {
  return rotation === 90 || rotation === 270 ? { w: h, h: w } : { w, h };
}

export function dist(x1: number, y1: number, x2: number, y2: number): number {
  return Math.hypot(x2 - x1, y2 - y1);
}

// Shortest distance from point p to segment ab.
export function distToSegment(px: number, py: number, ax: number, ay: number, bx: number, by: number): number {
  const abx = bx - ax, aby = by - ay;
  const apx = px - ax, apy = py - ay;
  const abLen2 = abx * abx + aby * aby;
  let t = abLen2 === 0 ? 0 : (apx * abx + apy * aby) / abLen2;
  t = Math.max(0, Math.min(1, t));
  const cx = ax + abx * t, cy = ay + aby * t;
  return dist(px, py, cx, cy);
}

// True if segments p1-p2 and p3-p4 cross (or touch) anywhere, including
// collinear overlap. Standard orientation-based test.
export function segmentsIntersect(
  p1: { x: number; y: number }, p2: { x: number; y: number },
  p3: { x: number; y: number }, p4: { x: number; y: number },
): boolean {
  const orient = (a: { x: number; y: number }, b: { x: number; y: number }, c: { x: number; y: number }) => {
    const v = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
    return v > 1e-9 ? 1 : v < -1e-9 ? -1 : 0;
  };
  const onSeg = (a: { x: number; y: number }, b: { x: number; y: number }, c: { x: number; y: number }) =>
    Math.min(a.x, b.x) - 1e-9 <= c.x && c.x <= Math.max(a.x, b.x) + 1e-9 &&
    Math.min(a.y, b.y) - 1e-9 <= c.y && c.y <= Math.max(a.y, b.y) + 1e-9;

  const o1 = orient(p1, p2, p3);
  const o2 = orient(p1, p2, p4);
  const o3 = orient(p3, p4, p1);
  const o4 = orient(p3, p4, p2);

  if (o1 !== o2 && o3 !== o4) return true;
  if (o1 === 0 && onSeg(p1, p2, p3)) return true;
  if (o2 === 0 && onSeg(p1, p2, p4)) return true;
  if (o3 === 0 && onSeg(p3, p4, p1)) return true;
  if (o4 === 0 && onSeg(p3, p4, p2)) return true;
  return false;
}

// Shortest distance between segments p1-p2 and p3-p4 (0 if they cross/touch).
export function segmentToSegmentDist(
  p1: { x: number; y: number }, p2: { x: number; y: number },
  p3: { x: number; y: number }, p4: { x: number; y: number },
): number {
  if (segmentsIntersect(p1, p2, p3, p4)) return 0;
  return Math.min(
    distToSegment(p1.x, p1.y, p3.x, p3.y, p4.x, p4.y),
    distToSegment(p2.x, p2.y, p3.x, p3.y, p4.x, p4.y),
    distToSegment(p3.x, p3.y, p1.x, p1.y, p2.x, p2.y),
    distToSegment(p4.x, p4.y, p1.x, p1.y, p2.x, p2.y),
  );
}
