// @vitest-environment jsdom
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { PCBEngine } from './PCBEngine';
import { FOOTPRINTS } from './footprints';
import { footprintBBox } from './geometry';
import type { ConvertResult } from './convertFromCircuit';
import type { PCBComponent } from './types';

function makeEngine(): PCBEngine {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({} as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  return new PCBEngine(canvas, container);
}

function resistor(sourceComponentId: number, refDes: string, x: number, y: number): ConvertResult['components'][number] {
  return { sourceComponentId, footprint: 'RES_TH', refDes, x, y, rotation: 0, props: {} };
}

// AABB overlap test (with a hair of tolerance for float snapping), used to
// assert the "avoid overlap" requirement across every pair of components.
function bbox(comp: PCBComponent) {
  const fp = FOOTPRINTS[comp.footprint];
  const b = footprintBBox(fp?.width ?? 0, fp?.height ?? 0, comp.rotation);
  return { minX: comp.x - b.w / 2, maxX: comp.x + b.w / 2, minY: comp.y - b.h / 2, maxY: comp.y + b.h / 2 };
}
function overlaps(a: PCBComponent, b: PCBComponent, gap = 0): boolean {
  const A = bbox(a), B = bbox(b);
  return A.minX < B.maxX - gap && A.maxX > B.minX + gap && A.minY < B.maxY - gap && A.maxY > B.minY + gap;
}

describe('PCBEngine.autoArrange', () => {
  let engine: PCBEngine;
  beforeEach(() => { engine = makeEngine(); });

  it('does nothing (and reports 0 moved) on an empty board', () => {
    const out = engine.autoArrange();
    expect(out.moved).toBe(0);
    expect(engine.state.components).toEqual([]);
  });

  it('spreads a handful of components placed on top of each other into non-overlapping positions', () => {
    const result: ConvertResult = {
      components: [
        resistor(1, 'R1', 0, 0),
        resistor(2, 'R2', 0, 0),
        resistor(3, 'R3', 0, 0),
        resistor(4, 'R4', 0, 0),
        resistor(5, 'R5', 0, 0),
      ],
      netlist: [],
      unmapped: [],
    };
    engine.importFromCircuit(result);

    const out = engine.autoArrange();
    expect(out.moved).toBe(5);

    const comps = engine.state.components;
    for (let i = 0; i < comps.length; i++) {
      for (let j = i + 1; j < comps.length; j++) {
        expect(overlaps(comps[i], comps[j])).toBe(false);
      }
    }
  });

  it('keeps at least the configured spacing gap between every pair of components', () => {
    const comps: ConvertResult['components'] = [];
    for (let i = 0; i < 8; i++) comps.push(resistor(i + 1, `R${i + 1}`, 5, 5));
    engine.importFromCircuit({ components: comps, netlist: [], unmapped: [] });

    engine.autoArrange();

    const placed = engine.state.components;
    for (let i = 0; i < placed.length; i++) {
      for (let j = i + 1; j < placed.length; j++) {
        // A hair under the real 2.5mm spacing constant to absorb grid
        // snapping, while still catching components left flush together.
        expect(overlaps(placed[i], placed[j], 2)).toBe(false);
      }
    }
  });

  it('keeps every component within the (possibly grown) board bounds', () => {
    const comps: ConvertResult['components'] = [];
    for (let i = 0; i < 12; i++) comps.push(resistor(i + 1, `R${i + 1}`, 100, 100));
    engine.importFromCircuit({ components: comps, netlist: [], unmapped: [] });

    engine.autoArrange();

    for (const c of engine.state.components) {
      const b = bbox(c);
      expect(b.minX).toBeGreaterThanOrEqual(0);
      expect(b.minY).toBeGreaterThanOrEqual(0);
      expect(b.maxX).toBeLessThanOrEqual(engine.state.board.width);
      expect(b.maxY).toBeLessThanOrEqual(engine.state.board.height);
    }
  });

  it('never changes rotation, side, refDes, or footprint of any component', () => {
    const result: ConvertResult = {
      components: [resistor(1, 'R1', 3, 3), resistor(2, 'R2', 3, 3)],
      netlist: [{ id: 1, name: 'SIG', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R2', terminalLabel: '1' }] }],
      unmapped: [],
    };
    engine.importFromCircuit(result);
    engine.state.components.find(c => c.refDes === 'R2')!.rotation = 90;

    const before = engine.state.components.map(c => ({ refDes: c.refDes, footprint: c.footprint, side: c.side, rotation: c.rotation }));
    engine.autoArrange();
    const after = engine.state.components.map(c => ({ refDes: c.refDes, footprint: c.footprint, side: c.side, rotation: c.rotation }));

    expect(after).toEqual(before);
  });

  it('never touches traces, vias, or the netlist', () => {
    const result: ConvertResult = {
      components: [resistor(1, 'R1', 12.7, 12.7), resistor(2, 'R2', 25.4, 12.7)],
      netlist: [{ id: 1, name: 'VCC', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R2', terminalLabel: '1' }] }],
      unmapped: [],
    };
    engine.importFromCircuit(result);
    engine.autoRoute();
    const tracesBefore = JSON.parse(JSON.stringify(engine.state.traces));
    const viasBefore = JSON.parse(JSON.stringify(engine.state.vias));
    const netlistBefore = JSON.parse(JSON.stringify(engine.state.netlist));

    engine.autoArrange();

    expect(engine.state.traces).toEqual(tracesBefore);
    expect(engine.state.vias).toEqual(viasBefore);
    expect(engine.state.netlist).toEqual(netlistBefore);
  });

  it('places components sharing a net closer together than an unrelated component', () => {
    // R1/R2 share a net; R3 shares nothing with either. A connectivity-
    // aware arrangement should end up with R1 and R2 nearer each other
    // than either is to the unconnected R3.
    const result: ConvertResult = {
      components: [resistor(1, 'R1', 0, 0), resistor(2, 'R2', 50, 50), resistor(3, 'R3', 25, 25)],
      netlist: [{ id: 1, name: 'SIG', pins: [{ refDes: 'R1', terminalLabel: '2' }, { refDes: 'R2', terminalLabel: '1' }] }],
      unmapped: [],
    };
    engine.importFromCircuit(result);
    engine.autoArrange();

    const byRef = new Map(engine.state.components.map(c => [c.refDes, c] as const));
    const r1 = byRef.get('R1')!, r2 = byRef.get('R2')!, r3 = byRef.get('R3')!;
    const distR1R2 = Math.hypot(r1.x - r2.x, r1.y - r2.y);
    const distR1R3 = Math.hypot(r1.x - r3.x, r1.y - r3.y);
    const distR2R3 = Math.hypot(r2.x - r3.x, r2.y - r3.y);

    expect(distR1R2).toBeLessThanOrEqual(Math.min(distR1R3, distR2R3));
  });

  it('is idempotent: running it twice in a row does not move components further apart or overlap them', () => {
    const comps: ConvertResult['components'] = [];
    for (let i = 0; i < 6; i++) comps.push(resistor(i + 1, `R${i + 1}`, i * 3, i * 3));
    engine.importFromCircuit({ components: comps, netlist: [], unmapped: [] });

    engine.autoArrange();
    const firstPass = engine.state.components.map(c => ({ x: c.x, y: c.y }));
    engine.autoArrange();
    const secondPass = engine.state.components.map(c => ({ x: c.x, y: c.y }));

    expect(secondPass).toEqual(firstPass);
  });

  it('clears selection and is undoable like other placement edits', () => {
    const result: ConvertResult = {
      components: [resistor(1, 'R1', 0, 0), resistor(2, 'R2', 0, 0)],
      netlist: [],
      unmapped: [],
    };
    engine.importFromCircuit(result);
    engine.selectedComponentIds = [engine.state.components[0].id];

    const before = engine.state.components.map(c => ({ x: c.x, y: c.y }));
    engine.autoArrange();
    expect(engine.selectedComponentIds).toEqual([]);
    expect(engine.canUndo()).toBe(true);

    engine.undo();
    const afterUndo = engine.state.components.map(c => ({ x: c.x, y: c.y }));
    expect(afterUndo).toEqual(before);
  });

  it('handles a single component without error', () => {
    engine.importFromCircuit({ components: [resistor(1, 'R1', 5, 5)], netlist: [], unmapped: [] });
    const out = engine.autoArrange();
    expect(out.moved).toBe(1);
    expect(engine.state.components[0].x).toBeGreaterThanOrEqual(0);
  });
});
