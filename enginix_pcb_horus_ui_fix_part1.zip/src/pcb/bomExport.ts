/**
 * PCB Editor - Bill of Materials (BOM) export
 * Groups placed components by footprint + property values (e.g. every
 * 220Ω 1/4W resistor becomes one BOM line with all its refDes's listed),
 * which is the standard shape manufacturers/assembly houses expect.
 */

import type { PCBState } from './types';
import { FOOTPRINTS } from './footprints';

export interface BOMLine {
  refDesignators: string[];
  quantity: number;
  footprintLabel: string;
  footprintType: string;
  value: string;       // best-effort human value, e.g. "220Ω 1/4W ±5%" or partNumber
  properties: Record<string, string>;
}

function describeValue(props: Record<string, string>): string {
  const parts = Object.values(props).filter(Boolean);
  return parts.length > 0 ? parts.join(' ') : '-';
}

export function buildBOM(state: PCBState): BOMLine[] {
  const groups = new Map<string, BOMLine>();

  for (const comp of state.components) {
    const fp = FOOTPRINTS[comp.footprint];
    if (!fp) continue;
    // Group key: footprint type + sorted property values (distinguishes a
    // 220Ω resistor from a 10kΩ resistor sharing the same footprint).
    const propKey = Object.entries(comp.props).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${k}=${v}`).join(',');
    const key = `${comp.footprint}::${propKey}`;

    let line = groups.get(key);
    if (!line) {
      line = {
        refDesignators: [],
        quantity: 0,
        footprintLabel: fp.label,
        footprintType: fp.type,
        value: describeValue(comp.props),
        properties: { ...comp.props },
      };
      groups.set(key, line);
    }
    line.refDesignators.push(comp.refDes);
    line.quantity += 1;
  }

  return Array.from(groups.values()).sort((a, b) => a.footprintLabel.localeCompare(b.footprintLabel));
}

function csvEscape(v: string): string {
  if (/[",\n]/.test(v)) return `"${v.replace(/"/g, '""')}"`;
  return v;
}

export function bomToCSV(state: PCBState): string {
  const lines = buildBOM(state);
  const header = ['Reference Designators', 'Quantity', 'Footprint', 'Value', 'Part Number'];
  const rows = [header.join(',')];
  for (const line of lines) {
    const sortedRefs = [...line.refDesignators].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
    rows.push([
      csvEscape(sortedRefs.join('; ')),
      String(line.quantity),
      csvEscape(line.footprintLabel),
      csvEscape(line.value),
      csvEscape(line.properties.partNumber ?? ''),
    ].join(','));
  }
  return rows.join('\n') + '\n';
}
