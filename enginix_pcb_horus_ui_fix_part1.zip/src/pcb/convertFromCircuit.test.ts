import { describe, it, expect } from 'vitest';
import { convertCircuitToPCB, MM_PER_GRID_UNIT } from './convertFromCircuit';
import type { Component, Wire } from '../circuit/types';

// Minimal fixture builder. Only fields convertCircuitToPCB / buildNets touch
// are given real values; the rest are stubbed to satisfy the Component type.
function makeComponent(overrides: Partial<Component> & {
  id: number;
  type: Component['type'];
  terminalIds: number[];
}): Component {
  const { terminalIds, ...rest } = overrides;
  return {
    id: overrides.id,
    type: overrides.type,
    x: 0,
    y: 0,
    rotation: 0,
    props: {},
    label: '',
    selected: false,
    voltage: 0,
    current: 0,
    power: 0,
    terminals: terminalIds.map((tid, idx) => ({
      id: tid,
      componentId: overrides.id,
      dx: idx,
      dy: 0,
      x: 0,
      y: 0,
      label: `T${idx}`,
      netId: null,
    })),
    ...rest,
  } as Component;
}

function makeWire(overrides: Partial<Wire> & {
  id: number;
  fromTerminalId: number;
  toTerminalId: number;
  fromCompId: number;
  toCompId: number;
}): Wire {
  return {
    color: '#000',
    waypoints: [],
    selected: false,
    ...overrides,
  } as Wire;
}

describe('convertCircuitToPCB', () => {
  it('preserves position (scaled to mm) and rotation for a mapped component', () => {
    const battery = makeComponent({
      id: 1,
      type: 'battery',
      terminalIds: [10, 11],
      x: 3,
      y: 5,
      rotation: 1,
      label: 'BAT1',
    });

    const result = convertCircuitToPCB([battery], []);

    expect(result.components).toHaveLength(1);
    const placed = result.components[0];
    expect(placed.x).toBe(3 * MM_PER_GRID_UNIT);
    expect(placed.y).toBe(5 * MM_PER_GRID_UNIT);
    expect(placed.rotation).toBe(90);
    expect(placed.sourceComponentId).toBe(1);
  });

  it('uses the circuit label as ref designator when present and free', () => {
    const resistor = makeComponent({
      id: 2,
      type: 'resistor',
      terminalIds: [20, 21],
      label: 'R_PULLUP',
    });

    const result = convertCircuitToPCB([resistor], []);
    expect(result.components[0].refDes).toBe('R_PULLUP');
  });

  it('falls back to <prefix><n> ref designators when no label is set', () => {
    const r1 = makeComponent({ id: 3, type: 'resistor', terminalIds: [30, 31] });
    const r2 = makeComponent({ id: 4, type: 'resistor', terminalIds: [40, 41] });

    const result = convertCircuitToPCB([r1, r2], []);
    const refDes = result.components.map(c => c.refDes).sort();
    expect(refDes).toEqual(['R1', 'R2']);
  });

  it('avoids colliding an auto-generated ref designator with an explicit label', () => {
    // r1 explicitly claims "R1"; r2 has no label and must skip past it.
    const r1 = makeComponent({ id: 5, type: 'resistor', terminalIds: [50, 51], label: 'R1' });
    const r2 = makeComponent({ id: 6, type: 'resistor', terminalIds: [60, 61] });

    const result = convertCircuitToPCB([r1, r2], []);
    const byId = new Map(result.components.map(c => [c.sourceComponentId, c.refDes]));
    expect(byId.get(5)).toBe('R1');
    expect(byId.get(6)).toBe('R2');
  });

  it('preserves a direct wire connection as a netlist entry', () => {
    const r1 = makeComponent({ id: 7, type: 'resistor', terminalIds: [70, 71], label: 'R1' });
    const r2 = makeComponent({ id: 8, type: 'resistor', terminalIds: [80, 81], label: 'R2' });
    const wire = makeWire({ id: 1, fromTerminalId: 71, toTerminalId: 80, fromCompId: 7, toCompId: 8 });

    const result = convertCircuitToPCB([r1, r2], [wire]);
    expect(result.netlist).toHaveLength(1);
    const pins = result.netlist[0].pins.map(p => p.refDes).sort();
    expect(pins).toEqual(['R1', 'R2']);
  });

  it('carries a wire net label over as the PCB net name', () => {
    const r1 = makeComponent({ id: 9, type: 'resistor', terminalIds: [90, 91], label: 'R1' });
    const r2 = makeComponent({ id: 10, type: 'resistor', terminalIds: [100, 101], label: 'R2' });
    const wire = makeWire({
      id: 2, fromTerminalId: 91, toTerminalId: 100, fromCompId: 9, toCompId: 10, netLabel: 'VCC',
    });

    const result = convertCircuitToPCB([r1, r2], [wire]);
    expect(result.netlist[0].name).toBe('VCC');
  });

  it('joins two unwired components sharing the same net label into one net', () => {
    const r1 = makeComponent({ id: 11, type: 'resistor', terminalIds: [110, 111], label: 'R1' });
    const r2 = makeComponent({ id: 12, type: 'resistor', terminalIds: [120, 121], label: 'R2' });
    // Each wire only touches one component's terminal at "from", but shares
    // a net label - buildNets treats same-labeled wires as joined.
    const stub1 = makeComponent({ id: 13, type: 'resistor', terminalIds: [130] });
    const stub2 = makeComponent({ id: 14, type: 'resistor', terminalIds: [140] });
    const w1 = makeWire({ id: 3, fromTerminalId: 111, toTerminalId: 130, fromCompId: 11, toCompId: 13, netLabel: 'GND' });
    const w2 = makeWire({ id: 4, fromTerminalId: 120, toTerminalId: 140, fromCompId: 12, toCompId: 14, netLabel: 'GND' });

    const result = convertCircuitToPCB([r1, r2, stub1, stub2], [w1, w2]);
    const netWithBoth = result.netlist.find(n =>
      n.pins.some(p => p.refDes === 'R1') && n.pins.some(p => p.refDes === 'R2')
    );
    expect(netWithBoth).toBeDefined();
    expect(netWithBoth?.name).toBe('GND');
  });

  it('drops nets that end up with fewer than 2 surviving pins', () => {
    const lonely = makeComponent({ id: 15, type: 'resistor', terminalIds: [150, 151], label: 'R1' });
    // Self-wire both terminals to itself; still only 1 distinct pin (dedup).
    const wire = makeWire({ id: 5, fromTerminalId: 150, toTerminalId: 150, fromCompId: 15, toCompId: 15 });

    const result = convertCircuitToPCB([lonely], [wire]);
    expect(result.netlist).toHaveLength(0);
  });

  it('skips junction components entirely (no footprint, not counted unmapped)', () => {
    const junction = makeComponent({ id: 16, type: 'junction', terminalIds: [160] });
    const result = convertCircuitToPCB([junction], []);
    expect(result.components).toHaveLength(0);
    expect(result.unmapped).toHaveLength(0);
  });

  it('reports genuinely unmapped component types without guessing a footprint', () => {
    const mystery = makeComponent({ id: 17, type: 'totallyUnknownType' as Component['type'], terminalIds: [170] });
    const result = convertCircuitToPCB([mystery], []);
    expect(result.components).toHaveLength(0);
    expect(result.unmapped).toEqual(['totallyUnknownType']);
  });

  it('overlays circuit property values onto footprint defaults without mutating other defaults', () => {
    const resistor = makeComponent({
      id: 18,
      type: 'resistor',
      terminalIds: [180, 181],
      label: 'R1',
      props: { resistance: 4700 },
    });
    const result = convertCircuitToPCB([resistor], []);
    const placed = result.components[0];
    // The property key used by the RES_TH footprint should reflect 4700
    // if 'resistance' is one of its declared property keys; otherwise the
    // footprint default is kept untouched. Either way, no crash / no
    // extraneous key should appear from a component that only set one prop.
    expect(Object.keys(placed.props).length).toBeGreaterThan(0);
  });

  it('normalizes rotation into 0/90/180/270 regardless of out-of-range steps', () => {
    const comp = makeComponent({ id: 19, type: 'resistor', terminalIds: [190, 191], label: 'R1', rotation: -1 });
    const result = convertCircuitToPCB([comp], []);
    expect(result.components[0].rotation).toBe(270);
  });

  it('does not generate any routing/trace data - only footprints + netlist', () => {
    const r1 = makeComponent({ id: 20, type: 'resistor', terminalIds: [200, 201], label: 'R1' });
    const r2 = makeComponent({ id: 21, type: 'resistor', terminalIds: [210, 211], label: 'R2' });
    const wire = makeWire({ id: 6, fromTerminalId: 201, toTerminalId: 210, fromCompId: 20, toCompId: 21 });

    const result = convertCircuitToPCB([r1, r2], [wire]);
    expect(result).not.toHaveProperty('traces');
    expect(result).not.toHaveProperty('routing');
    expect(Object.keys(result).sort()).toEqual(['components', 'netlist', 'unmapped']);
  });
});
