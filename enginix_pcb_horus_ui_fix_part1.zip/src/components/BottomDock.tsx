/**
 * BottomDock - a single VS Code-style bottom dock for the Coding page.
 * One tab strip (Status, Serial Monitor, Pin Mapping, Pin Inspector,
 * Component Map, Compatibility tests - only offered when they have
 * something to show), and one drag handle on the dock's top edge.
 *
 * Every tab's body stays mounted at all times, stacked and toggled via
 * `hidden` rather than swapped in and out of the DOM - so each tab keeps
 * its own independent scroll position and any of its own internal state
 * exactly like a VS Code bottom-panel tab, and switching tabs is just a
 * CSS visibility flip (no re-render of the tab you're switching to).
 *
 * The dock is always visible and always docked below the Code Editor - it
 * has no collapse control by design. Its height defaults to a percentage
 * of the Coding page's own height (measured via `containerRef`) and is
 * clamped to [minHeightPx, containerHeight * maxHeightRatio] on every
 * resize of that container, so the bounds stay correct if the window or
 * layout changes. Once the user drags the handle, that exact height is
 * remembered (via panelLayoutStorage) and stops tracking the percentage.
 *
 * Used only by CodingLab - it doesn't touch anything outside the Coding
 * page.
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { getPanelLayout, savePanelLayout } from '../lib/panelLayoutStorage';

export interface DockTab {
  id: string;
  /** Tab strip label (kept short - badges/counts go in `badge`). */
  label: string;
  /** Optional small badge rendered after the label, e.g. an error count. */
  badge?: React.ReactNode;
  badgeTone?: 'neutral' | 'amber' | 'rose' | 'emerald';
  /** Right-aligned controls shown in the tab strip only while this tab is active (e.g. Serial Monitor's toolbar buttons). */
  headerRight?: React.ReactNode;
  content: React.ReactNode;
}

interface BottomDockProps {
  /** Stable id used as the persistence key for the remembered height. */
  id: string;
  tabs: DockTab[];
  /** Ref to the Coding page's own container - its measured height is what the 30%/60% bounds are relative to. */
  containerRef: React.RefObject<HTMLElement | null>;
  defaultHeightRatio?: number;
  minHeightPx?: number;
  maxHeightRatio?: number;
  /** Called with each tab's own scrollable body element as it mounts (and null on unmount). Lets a caller (e.g. Serial Monitor's auto-scroll) reach a specific tab's body without threading a ref through the tabs array. */
  onTabBodyRef?: (tabId: string, node: HTMLDivElement | null) => void;
}

const badgeToneClass: Record<NonNullable<DockTab['badgeTone']>, string> = {
  neutral: 'bg-slate-700 text-slate-300',
  amber: 'bg-amber-500/20 text-amber-300',
  rose: 'bg-rose-500/20 text-rose-300',
  emerald: 'bg-emerald-500/20 text-emerald-300',
};

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), Math.max(min, max));
}

const BottomDock: React.FC<BottomDockProps> = ({
  id,
  tabs,
  containerRef,
  defaultHeightRatio = 0.3,
  minHeightPx = 180,
  maxHeightRatio = 0.6,
  onTabBodyRef,
}) => {
  const [containerHeight, setContainerHeight] = useState(0);
  // Once the user drags the handle, we remember an exact pixel height and
  // stop recomputing it from the container's percentage on every resize.
  const [userHeight, setUserHeight] = useState<number | null>(() => getPanelLayout(id)?.height ?? null);
  const [dragHeight, setDragHeight] = useState<number | null>(null);
  const [activeTabId, setActiveTabId] = useState<string>(() => tabs[0]?.id ?? '');
  const draggingRef = useRef(false);
  const dragStartRef = useRef({ y: 0, height: 0 });

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    setContainerHeight(el.clientHeight);
    const ro = new ResizeObserver(entries => {
      const h = entries[0]?.contentRect.height ?? el.clientHeight;
      setContainerHeight(h);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [containerRef]);

  // If the previously active tab disappears (e.g. the board is unplugged and
  // Pin Mapping/Inspector/Component Map stop being offered), `activeTab`
  // below falls back to the first still-available tab automatically - no
  // effect needed to correct `activeTabId` itself.

  const minPx = minHeightPx;
  const maxPx = containerHeight > 0 ? Math.max(minPx, containerHeight * maxHeightRatio) : minPx;
  const defaultPx = containerHeight > 0
    ? clamp(containerHeight * defaultHeightRatio, minPx, maxPx)
    : minPx;
  const restingHeight = clamp(userHeight ?? defaultPx, minPx, maxPx);
  const height = dragHeight ?? restingHeight;

  const onHandleMouseDown = useCallback((e: React.MouseEvent) => {
    draggingRef.current = true;
    dragStartRef.current = { y: e.clientY, height: restingHeight };
    setDragHeight(restingHeight);
    document.body.style.cursor = 'row-resize';
    document.body.style.userSelect = 'none';
    e.preventDefault();
  }, [restingHeight]);

  useEffect(() => {
    function onMove(e: MouseEvent) {
      if (!draggingRef.current) return;
      // Handle sits on the dock's TOP edge: dragging up (smaller clientY)
      // should grow the dock, so the delta is inverted versus a bottom edge.
      const delta = dragStartRef.current.y - e.clientY;
      const next = clamp(dragStartRef.current.height + delta, minPx, maxPx);
      setDragHeight(next);
    }
    function onUp() {
      if (!draggingRef.current) return;
      draggingRef.current = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      setDragHeight(current => {
        if (current !== null) {
          setUserHeight(current);
          savePanelLayout(id, { height: current });
        }
        return null;
      });
    }
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, [id, minPx, maxPx]);

  const activeTab = tabs.find(t => t.id === activeTabId) ?? tabs[0];

  if (!activeTab) return null;

  return (
    <div
      className="shrink-0 flex flex-col overflow-hidden rounded-t-md border-t border-x border-slate-700/70 bg-slate-950/60 shadow-[0_-6px_16px_rgba(0,0,0,0.25)]"
      style={{ height }}
    >
      <div
        onMouseDown={onHandleMouseDown}
        title="Drag to resize"
        role="separator"
        aria-orientation="horizontal"
        aria-label="Resize bottom dock"
        className="shrink-0 h-2 cursor-row-resize flex items-center justify-center bg-slate-900/60 transition-colors duration-150 hover:bg-slate-800 active:bg-slate-800 group touch-none"
      >
        <div className="w-8 h-0.5 rounded-full bg-slate-700 transition-colors duration-150 group-hover:bg-amber-400/70" />
      </div>

      <div className="shrink-0 flex items-center gap-1 px-2 pt-1.5 border-b border-slate-800 bg-slate-950/80 overflow-x-auto panel-scroll">
        <div className="flex items-center gap-1 min-w-0">
          {tabs.map(tab => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTabId(tab.id)}
              title={tab.label}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-t text-xs font-semibold uppercase tracking-wide border-b-2 whitespace-nowrap transition-colors duration-150 ${
                tab.id === activeTab.id
                  ? 'bg-slate-900/80 text-amber-300 border-amber-500'
                  : 'text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-900/40'
              }`}
            >
              {tab.label}
              {tab.badge !== undefined && (
                <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-semibold normal-case tracking-normal ${badgeToneClass[tab.badgeTone ?? 'neutral']}`}>
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </div>
        <div className="flex-1" />
        {activeTab.headerRight && (
          <div className="flex items-center gap-1 shrink-0 pb-1.5">{activeTab.headerRight}</div>
        )}
      </div>

      {/* Every tab's body stays mounted (display:none via `hidden` when
          inactive) so each keeps its own scroll position and any of its
          own state - switching tabs is then just a visibility flip, not a
          content swap, so it's both instant and non-destructive. */}
      <div className="relative flex-1 min-h-0">
        {tabs.map(tab => (
          <div
            key={tab.id}
            ref={node => onTabBodyRef?.(tab.id, node)}
            className={`panel-scroll absolute inset-0 overflow-y-auto overflow-x-auto overscroll-contain ${tab.id === activeTab.id ? '' : 'hidden'}`}
            aria-hidden={tab.id !== activeTab.id}
          >
            {tab.content}
          </div>
        ))}
      </div>
    </div>
  );
};

export default BottomDock;
