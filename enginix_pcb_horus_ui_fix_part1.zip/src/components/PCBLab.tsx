/**
 * PCBLab - PCB layout editor
 * Place footprints, route copper traces on top/bottom layers, drop vias,
 * and export a real Gerber + Excellon drill fabrication package.
 */

import React, { useRef, useEffect, useState, useCallback, useMemo, forwardRef, useImperativeHandle } from 'react';
import { PCBEngine, type PCBTool } from '../pcb/PCBEngine';
import { FOOTPRINTS, CATEGORY_ORDER } from '../pcb/footprints';
import { exportGerberZip } from '../pcb/gerberExport';
import { bomToCSV } from '../pcb/bomExport';
import { pickPlaceToCSV } from '../pcb/pickPlaceExport';
import { runDRC, type DRCReport } from '../pcb/drc';
import { exportFabricationZip } from '../pcb/fabricationExport';
import type { PCBComponent, Side } from '../pcb/types';
import type { ConvertResult } from '../pcb/convertFromCircuit';
import {
  savePCBProject, captureCanvasThumbnail,
  type SavedProject, type SavedPCBViewSettings,
} from '../lib/projectStorage';
import {
  MousePointer, Hand, Cable, CircleDot, Undo2, Redo2, Trash2,
  RotateCw, FlipHorizontal2, ZoomIn, ZoomOut, Maximize, Download, Layers,
  Search, ChevronDown, ChevronRight, Copy, ClipboardPaste, RefreshCw,
  AlignStartVertical, AlignCenterVertical, AlignEndVertical,
  AlignStartHorizontal, AlignCenterHorizontal, AlignEndHorizontal,
  AlignHorizontalDistributeCenter, AlignVerticalDistributeCenter, Waypoints, Zap, LayoutGrid,
  Save, Check, ShieldCheck, AlertTriangle, FileSpreadsheet, MapPin, Package,
} from 'lucide-react';

function downloadTextFile(fileName: string, contents: string, mime = 'text/csv') {
  const blob = new Blob([contents], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  URL.revokeObjectURL(url);
}

// A point-in-time snapshot of the currently-open PCB project, used by
// Project Gallery's "Update" action to overwrite that project with live
// edits. `loadedProjectId` is null when the current board was never
// opened from (or saved as) a gallery project.
export interface PCBProjectSaveSnapshot {
  loadedProjectId: string | null;
  name: string;
  description: string;
  boardState: string;
  view: SavedPCBViewSettings;
  layers: Side[];
  componentCount: number;
  traceCount: number;
  viaCount: number;
  thumbnail?: string;
}

// Handle exposed via ref so Project Gallery can pull a live save snapshot
// for its Update action.
export interface PCBLabHandle {
  getSaveSnapshot: () => PCBProjectSaveSnapshot | null;
}

interface PCBLabProps {
  /** Optional accessor for the Circuit Simulator's live component types
   * (e.g. () => editor.state.components.map(c => c.type)). Used only by
   * the "Sync from Circuit Simulator" button - if omitted, that button is
   * simply not shown. Never required, so every existing caller of
   * <PCBLab /> with no props keeps working unchanged. */
  getCircuitComponentTypes?: () => string[];
  /** Footprints + netlist from a "Convert to PCB" click in the Circuit
   * Simulator, imported once on mount then reported back via
   * `onImportConsumed` so the parent clears the pending payload. Optional
   * - every existing caller of <PCBLab /> with no props keeps working
   * unchanged. */
  pendingImport?: ConvertResult | null;
  /** Called right after `pendingImport` has been imported, so the parent
   * can clear it (otherwise re-mounting this tab would try to re-import
   * the same payload - harmless since importFromCircuit is idempotent, but
   * pointless). */
  onImportConsumed?: () => void;
  /** A PCB project the Gallery wants opened — restored on mount when kind
   * is 'pcb'. Optional - every existing caller of <PCBLab /> with no props
   * keeps working unchanged. */
  loadProject?: SavedProject | null;
  /** Called once the requested project has been restored, so the parent
   * can clear the request. */
  onProjectLoaded?: () => void;
}

const PCBLab = forwardRef<PCBLabHandle, PCBLabProps>(({ getCircuitComponentTypes, pendingImport, onImportConsumed, loadProject, onProjectLoaded }, ref) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<PCBEngine | null>(null);

  const [tool, setTool] = useState<PCBTool>('select');
  const [activeLayer, setActiveLayer] = useState<'top' | 'bottom'>('top');
  const [placingFootprint, setPlacingFootprint] = useState<string | null>(null);
  const [selectedComponent, setSelectedComponent] = useState<PCBComponent | null>(null);
  const [selCount, setSelCount] = useState(0);
  const [selCompCount, setSelCompCount] = useState(0);
  const [compCount, setCompCount] = useState(0);
  const [traceCount, setTraceCount] = useState(0);
  const [viaCount, setViaCount] = useState(0);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);
  const [boardW, setBoardW] = useState(60);
  const [boardH, setBoardH] = useState(40);
  const [search, setSearch] = useState('');
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [propTick, setPropTick] = useState(0); // bump to re-render property panel after edits
  const [hasClipboard, setHasClipboard] = useState(false);
  const [showRatsnest, setShowRatsnest] = useState(true);

  // ─── Save / Project Gallery ─────────────────────────────────────────
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [saveProjectName, setSaveProjectName] = useState('');
  const [saveProjectDescription, setSaveProjectDescription] = useState('');
  const [loadedProjectId, setLoadedProjectId] = useState<string | null>(null);
  const [saveConfirmed, setSaveConfirmed] = useState(false);

  // ─── DRC / Fabrication export ───────────────────────────────────────
  const [drcReport, setDrcReport] = useState<DRCReport | null>(null);
  const [showDrcPanel, setShowDrcPanel] = useState(false);

  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;
    const engine = new PCBEngine(canvasRef.current, containerRef.current);
    engineRef.current = engine;

    engine.onStateChange = () => {
      setCompCount(engine.state.components.length);
      setTraceCount(engine.state.traces.length);
      setViaCount(engine.state.vias.length);
      setCanUndo(engine.canUndo());
      setCanRedo(engine.canRedo());
      setBoardW(engine.state.board.width);
      setBoardH(engine.state.board.height);
    };
    engine.onSelectionChange = () => {
      const ids = engine.selectedComponentIds;
      setSelCount(ids.length + engine.selectedTraceIds.length + engine.selectedViaIds.length);
      setSelCompCount(ids.length);
      const comp = ids.length === 1 ? engine.state.components.find(c => c.id === ids[0]) || null : null;
      setSelectedComponent(comp);
      setPropTick(t => t + 1);
      setHasClipboard(engine.clipboard.length > 0);
    };

    // Skip the auto-center below when a saved project is about to be
    // restored — that project carries its own exact camera position (see
    // the "Restore a loaded PCB project" effect below), which centerView()
    // would otherwise overwrite a moment later.
    const hasPendingLoad = !!loadProject && loadProject.kind === 'pcb';
    if (!hasPendingLoad) {
      setTimeout(() => {
        engine.centerView();
      }, 50);
    }

    return () => engine.destroy();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // "Convert to PCB" from the Circuit Simulator: import whatever payload
  // is waiting, then hand back so the parent can clear it. Runs whenever
  // pendingImport (re)appears — not just at mount — since this tab now
  // stays mounted the whole time the Studio is open (so its zoom, camera,
  // selection, and undo history survive switching to Circuit/Coding and
  // back), rather than mounting fresh only when the PCB tab is first
  // opened. No-op for every other way of opening this tab.
  useEffect(() => {
    const engine = engineRef.current;
    if (!engine || !pendingImport) return;
    engine.importFromCircuit(pendingImport);
    onImportConsumed?.();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingImport]);

  // Restore a loaded PCB project: board (size, components with position/
  // rotation/side/props, traces = routing, vias, layers), then the exact
  // camera (scale + pan), active layer, and ratsnest toggle, so the canvas
  // looks exactly as when it was saved.
  useEffect(() => {
    if (!loadProject || loadProject.kind !== 'pcb' || !loadProject.pcb) return;
    const engine = engineRef.current;
    if (!engine) return;

    const restoredState = JSON.parse(loadProject.pcb.boardState);
    engine.importState(restoredState);

    const { scale, offsetX, offsetY, activeLayer: savedActiveLayer, showRatsnest: savedShowRatsnest } = loadProject.pcb.view;
    engine.scale = scale;
    engine.offsetX = offsetX;
    engine.offsetY = offsetY;
    engine.activeLayer = savedActiveLayer;
    engine.showRatsnest = savedShowRatsnest;

    setActiveLayer(savedActiveLayer);
    setShowRatsnest(savedShowRatsnest);
    setBoardW(engine.state.board.width);
    setBoardH(engine.state.board.height);

    // Remember which project this is, and prefill its name/description, so
    // a subsequent Save updates this same project instead of creating a
    // duplicate — Update itself is still only ever triggered from Project
    // Gallery.
    setLoadedProjectId(loadProject.id);
    setSaveProjectName(loadProject.name);
    setSaveProjectDescription(loadProject.description);

    onProjectLoaded?.();
  }, [loadProject, onProjectLoaded]);

  // Expose a live save snapshot so Project Gallery's Update action can
  // overwrite the project this board was opened from with current edits.
  useImperativeHandle(ref, () => ({
    getSaveSnapshot: () => {
      const engine = engineRef.current;
      if (!engine) return null;

      const boardState = JSON.stringify(engine.state);
      const thumbnail = captureCanvasThumbnail(engine.canvas);

      return {
        loadedProjectId,
        name: saveProjectName.trim() || 'Untitled Board',
        description: saveProjectDescription.trim(),
        boardState,
        view: {
          scale: engine.scale,
          offsetX: engine.offsetX,
          offsetY: engine.offsetY,
          activeLayer: engine.activeLayer,
          showRatsnest: engine.showRatsnest,
        },
        layers: ['top', 'bottom'],
        componentCount: engine.state.components.length,
        traceCount: engine.state.traces.length,
        viaCount: engine.state.vias.length,
        thumbnail,
      };
    },
  }), [loadedProjectId, saveProjectName, saveProjectDescription]);

  const handleSaveProject = useCallback(() => {
    if (!saveProjectName.trim() || !engineRef.current) return;
    const engine = engineRef.current;

    const boardState = JSON.stringify(engine.state);
    // Best-effort thumbnail capture — never blocks or breaks the save.
    const thumbnail = captureCanvasThumbnail(engine.canvas);

    const payload = {
      name: saveProjectName.trim(),
      description: saveProjectDescription.trim(),
      boardState,
      view: {
        scale: engine.scale,
        offsetX: engine.offsetX,
        offsetY: engine.offsetY,
        activeLayer: engine.activeLayer,
        showRatsnest: engine.showRatsnest,
      },
      layers: ['top', 'bottom'] as Side[],
      componentCount: engine.state.components.length,
      traceCount: engine.state.traces.length,
      viaCount: engine.state.vias.length,
      thumbnail,
    };

    // Save always creates a brand-new project with a new id and never
    // overwrites the project this board may have been opened from — the
    // original stays untouched. Updating an existing project is only done
    // from Project Gallery's Update action.
    const saved = savePCBProject(payload);
    setLoadedProjectId(saved.id);

    setShowSaveDialog(false);
    setSaveConfirmed(true);
    setTimeout(() => setSaveConfirmed(false), 2000);
  }, [saveProjectName, saveProjectDescription]);

  const handleToolChange = useCallback((t: PCBTool) => {
    setTool(t);
    if (engineRef.current) {
      engineRef.current.tool = t;
      if (t !== 'place') engineRef.current.placingFootprint = null;
      if (t !== 'route') engineRef.current.cancelRouting();
    }
    if (t !== 'place') setPlacingFootprint(null);
  }, []);

  const handlePlaceFootprint = useCallback((key: string) => {
    setPlacingFootprint(key);
    setTool('place');
    if (engineRef.current) {
      engineRef.current.tool = 'place';
      engineRef.current.placingFootprint = key;
    }
  }, []);

  const handleLayerChange = useCallback((layer: 'top' | 'bottom') => {
    setActiveLayer(layer);
    if (engineRef.current) engineRef.current.activeLayer = layer;
  }, []);

  const handleUndo = useCallback(() => engineRef.current?.undo(), []);
  const handleRedo = useCallback(() => engineRef.current?.redo(), []);
  const handleDelete = useCallback(() => engineRef.current?.deleteSelected(), []);
  const handleRotate = useCallback(() => engineRef.current?.rotateSelected(), []);
  const handleFlip = useCallback(() => engineRef.current?.flipSelected(), []);
  const handleCopy = useCallback(() => {
    engineRef.current?.copySelected();
    setHasClipboard(!!engineRef.current && engineRef.current.clipboard.length > 0);
  }, []);
  const handlePaste = useCallback(() => engineRef.current?.pasteClipboard(), []);
  // One-click Duplicate for the Properties panel — composes the existing
  // copy + paste actions (same as Ctrl+C, Ctrl+V) rather than adding new
  // engine behavior.
  const handleDuplicate = useCallback(() => {
    const engine = engineRef.current;
    if (!engine) return;
    engine.copySelected();
    engine.pasteClipboard();
    setHasClipboard(engine.clipboard.length > 0);
  }, []);
  const handleZoomIn = useCallback(() => { if (engineRef.current) engineRef.current.scale = Math.min(40, engineRef.current.scale * 1.25); }, []);
  const handleZoomOut = useCallback(() => { if (engineRef.current) engineRef.current.scale = Math.max(2, engineRef.current.scale / 1.25); }, []);
  const handleZoomFit = useCallback(() => engineRef.current?.centerView(), []);

  const handleAlignLeft = useCallback(() => engineRef.current?.alignLeft(), []);
  const handleAlignCenterH = useCallback(() => engineRef.current?.alignCenterH(), []);
  const handleAlignRight = useCallback(() => engineRef.current?.alignRight(), []);
  const handleAlignTop = useCallback(() => engineRef.current?.alignTop(), []);
  const handleAlignCenterV = useCallback(() => engineRef.current?.alignCenterV(), []);
  const handleAlignBottom = useCallback(() => engineRef.current?.alignBottom(), []);
  const handleDistributeH = useCallback(() => engineRef.current?.distributeH(), []);
  const handleDistributeV = useCallback(() => engineRef.current?.distributeV(), []);

  const handleToggleRatsnest = useCallback(() => {
    setShowRatsnest(prev => {
      const next = !prev;
      if (engineRef.current) engineRef.current.showRatsnest = next;
      return next;
    });
  }, []);

  const handleAutoRoute = useCallback(() => {
    if (!engineRef.current) return;
    const { routed, reason, unrouted } = engineRef.current.autoRoute();
    let message: string;
    if (routed > 0 && unrouted.length > 0) {
      message = `Auto-routed ${routed} connection${routed === 1 ? '' : 's'} — ${reason ?? ''}`;
    } else if (routed > 0) {
      message = `Auto-routed ${routed} connection${routed === 1 ? '' : 's'}.`;
    } else {
      message = reason ?? 'Nothing left to auto-route.';
    }
    setSyncMessage(message);
    window.setTimeout(() => setSyncMessage(null), 5000);
  }, []);

  const handleAutoArrange = useCallback(() => {
    if (!engineRef.current) return;
    const { moved } = engineRef.current.autoArrange();
    setSyncMessage(moved > 0 ? `Auto-arranged ${moved} component${moved === 1 ? '' : 's'}.` : 'No components to arrange.');
    window.setTimeout(() => setSyncMessage(null), 5000);
  }, []);

  const handlePropChange = useCallback((key: string, value: string) => {
    if (!selectedComponent || !engineRef.current) return;
    engineRef.current.updateComponentProp(selectedComponent.id, key, value);
  }, [selectedComponent]);

  const handleRefDesChange = useCallback((value: string) => {
    if (!selectedComponent || !engineRef.current) return;
    engineRef.current.renameComponent(selectedComponent.id, value);
  }, [selectedComponent]);

  const toggleCategory = useCallback((cat: string) => {
    setCollapsed(prev => {
      const next = new Set(prev);
      if (next.has(cat)) next.delete(cat); else next.add(cat);
      return next;
    });
  }, []);

  const groupedFootprints = useMemo(() => {
    const q = search.trim().toLowerCase();
    const groups: { category: string; items: (typeof FOOTPRINTS)[string][] }[] = [];
    for (const cat of CATEGORY_ORDER) {
      const items = Object.values(FOOTPRINTS).filter(fp =>
        fp.category === cat &&
        (q === '' || fp.label.toLowerCase().includes(q) || fp.refPrefix.toLowerCase().includes(q) || cat.toLowerCase().includes(q))
      );
      if (items.length > 0) groups.push({ category: cat, items });
    }
    return groups;
  }, [search]);

  const handleBoardResize = useCallback((w: number, h: number) => {
    setBoardW(w);
    setBoardH(h);
    engineRef.current?.setBoardSize(w, h);
  }, []);

  const handleExport = useCallback(() => {
    if (engineRef.current) exportGerberZip(engineRef.current.state);
  }, []);

  const handleRunDRC = useCallback(() => {
    if (!engineRef.current) return;
    setDrcReport(runDRC(engineRef.current.state));
    setShowDrcPanel(true);
  }, []);

  const handleExportBOM = useCallback(() => {
    if (!engineRef.current) return;
    downloadTextFile('bom.csv', bomToCSV(engineRef.current.state));
  }, []);

  const handleExportPickPlace = useCallback(() => {
    if (!engineRef.current) return;
    downloadTextFile('pick_and_place.csv', pickPlaceToCSV(engineRef.current.state));
  }, []);

  const handleExportFabricationPackage = useCallback((allowWithErrors = false) => {
    if (!engineRef.current) return;
    const result = exportFabricationZip(engineRef.current.state, { allowWithErrors });
    setDrcReport(result.drc);
    if (!result.exported) setShowDrcPanel(true);
  }, []);

  const handleSyncFromCircuit = useCallback(() => {
    if (!engineRef.current || !getCircuitComponentTypes) return;
    const types = getCircuitComponentTypes();
    const { added, unmapped } = engineRef.current.syncMissingFootprints(types);
    const parts: string[] = [];
    if (added.length > 0) parts.push(`Added ${added.length} footprint${added.length === 1 ? '' : 's'}.`);
    else parts.push('Nothing to add - already in sync.');
    if (unmapped.length > 0) parts.push(`No footprint mapping for: ${Array.from(new Set(unmapped)).join(', ')}.`);
    setSyncMessage(parts.join(' '));
    window.setTimeout(() => setSyncMessage(null), 5000);
  }, [getCircuitComponentTypes]);

  return (
    <div className="relative flex flex-col h-full bg-[#0f1729] border border-slate-700/50 rounded-lg overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center gap-1 px-3 py-2 bg-slate-900/80 border-b border-slate-700/50 flex-wrap">
        <div className="flex items-center gap-0.5 bg-slate-800/50 rounded p-0.5">
          <ToolBtn icon={<MousePointer size={14} />} label="Select (Esc)" active={tool === 'select'} onClick={() => handleToolChange('select')} />
          <ToolBtn icon={<Hand size={14} />} label="Pan" active={tool === 'pan'} onClick={() => handleToolChange('pan')} />
          <ToolBtn icon={<Cable size={14} />} label="Route trace (Enter to end, Esc to cancel)" active={tool === 'route'} onClick={() => handleToolChange('route')} />
          <ToolBtn icon={<CircleDot size={14} />} label="Add via" active={tool === 'via'} onClick={() => handleToolChange('via')} />
        </div>

        <div className="w-px h-5 bg-slate-700/50 mx-1" />

        <div className="flex items-center gap-0.5 bg-slate-800/50 rounded p-0.5">
          <button
            onClick={() => handleLayerChange('top')}
            title="Route on top copper"
            className={`flex items-center gap-1 px-2 py-1 text-[10px] font-mono font-semibold rounded transition-colors ${activeLayer === 'top' ? 'bg-orange-500/20 text-orange-400' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Layers size={12} /> TOP
          </button>
          <button
            onClick={() => handleLayerChange('bottom')}
            title="Route on bottom copper"
            className={`flex items-center gap-1 px-2 py-1 text-[10px] font-mono font-semibold rounded transition-colors ${activeLayer === 'bottom' ? 'bg-sky-500/20 text-sky-400' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Layers size={12} /> BOTTOM
          </button>
        </div>

        <div className="w-px h-5 bg-slate-700/50 mx-1" />

        <div className="flex items-center gap-0.5 bg-slate-800/50 rounded p-0.5">
          <ToolBtn icon={<Undo2 size={14} />} label="Undo (Ctrl+Z)" disabled={!canUndo} onClick={handleUndo} />
          <ToolBtn icon={<Redo2 size={14} />} label="Redo (Ctrl+Shift+Z)" disabled={!canRedo} onClick={handleRedo} />
          <ToolBtn icon={<RotateCw size={14} />} label="Rotate (R)" disabled={selCount === 0} onClick={handleRotate} />
          <ToolBtn icon={<FlipHorizontal2 size={14} />} label="Flip side (F)" disabled={selCount === 0} onClick={handleFlip} />
          <ToolBtn icon={<Copy size={14} />} label="Copy (Ctrl+C)" disabled={selCount === 0} onClick={handleCopy} />
          <ToolBtn icon={<ClipboardPaste size={14} />} label="Paste (Ctrl+V)" disabled={!hasClipboard} onClick={handlePaste} />
          <ToolBtn icon={<Trash2 size={14} />} label="Delete (Del)" disabled={selCount === 0} onClick={handleDelete} />
        </div>

        <div className="w-px h-5 bg-slate-700/50 mx-1" />

        <div className="flex items-center gap-0.5 bg-slate-800/50 rounded p-0.5">
          <ToolBtn icon={<ZoomOut size={14} />} label="Zoom out" onClick={handleZoomOut} />
          <ToolBtn icon={<ZoomIn size={14} />} label="Zoom in" onClick={handleZoomIn} />
          <ToolBtn icon={<Maximize size={14} />} label="Fit board" onClick={handleZoomFit} />
        </div>

        <div className="w-px h-5 bg-slate-700/50 mx-1" />

        <div className="flex items-center gap-0.5 bg-slate-800/50 rounded p-0.5">
          <ToolBtn icon={<AlignStartVertical size={14} />} label="Align left" disabled={selCompCount < 2} onClick={handleAlignLeft} />
          <ToolBtn icon={<AlignCenterVertical size={14} />} label="Align center (horizontal)" disabled={selCompCount < 2} onClick={handleAlignCenterH} />
          <ToolBtn icon={<AlignEndVertical size={14} />} label="Align right" disabled={selCompCount < 2} onClick={handleAlignRight} />
          <ToolBtn icon={<AlignStartHorizontal size={14} />} label="Align top" disabled={selCompCount < 2} onClick={handleAlignTop} />
          <ToolBtn icon={<AlignCenterHorizontal size={14} />} label="Align middle (vertical)" disabled={selCompCount < 2} onClick={handleAlignCenterV} />
          <ToolBtn icon={<AlignEndHorizontal size={14} />} label="Align bottom" disabled={selCompCount < 2} onClick={handleAlignBottom} />
          <ToolBtn icon={<AlignHorizontalDistributeCenter size={14} />} label="Distribute horizontally" disabled={selCompCount < 3} onClick={handleDistributeH} />
          <ToolBtn icon={<AlignVerticalDistributeCenter size={14} />} label="Distribute vertically" disabled={selCompCount < 3} onClick={handleDistributeV} />
        </div>

        <div className="w-px h-5 bg-slate-700/50 mx-1" />

        <ToolBtn icon={<Waypoints size={14} />} label="Toggle ratsnest lines" active={showRatsnest} onClick={handleToggleRatsnest} />
        <button
          onClick={handleAutoArrange}
          disabled={compCount === 0}
          title="Arrange all components into a non-overlapping, connectivity-clustered grid"
          className="flex items-center gap-1 px-2 py-1.5 text-[10px] font-mono font-semibold rounded bg-slate-800/50 text-slate-300 hover:text-amber-400 hover:bg-slate-800 transition-colors disabled:opacity-40 disabled:pointer-events-none"
        >
          <LayoutGrid size={13} /> AUTO ARRANGE
        </button>
        <button
          onClick={handleAutoRoute}
          title="Auto-route every remaining ratsnest connection on the active layer"
          className="flex items-center gap-1 px-2 py-1.5 text-[10px] font-mono font-semibold rounded bg-slate-800/50 text-slate-300 hover:text-amber-400 hover:bg-slate-800 transition-colors"
        >
          <Zap size={13} /> AUTO ROUTE
        </button>

        {getCircuitComponentTypes && (
          <>
            <div className="w-px h-5 bg-slate-700/50 mx-1" />
            <button
              onClick={handleSyncFromCircuit}
              title="Add any Circuit Simulator component that doesn't have a footprint on this board yet"
              className="flex items-center gap-1 px-2 py-1.5 text-[10px] font-mono font-semibold rounded bg-slate-800/50 text-slate-300 hover:text-amber-400 hover:bg-slate-800 transition-colors"
            >
              <RefreshCw size={13} /> SYNC FROM CIRCUIT
            </button>
          </>
        )}

        <div className="flex-1" />

        <button
          onClick={() => setShowSaveDialog(true)}
          title={saveConfirmed ? 'Saved ✓' : 'Save Project'}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold font-mono rounded transition-colors mr-2 ${
            saveConfirmed
              ? 'bg-emerald-500 text-slate-900'
              : 'bg-slate-800/50 text-slate-300 hover:text-amber-400 hover:bg-slate-800'
          }`}
        >
          {saveConfirmed ? <Check size={13} /> : <Save size={13} />}
          {saveConfirmed ? 'Saved ✓' : 'Save'}
        </button>

        <div className="flex items-center gap-0.5 bg-slate-800/50 rounded p-0.5 mr-2">
          <ToolBtn
            icon={drcReport ? (drcReport.issues.length === 0 ? <ShieldCheck size={14} className="text-emerald-400" /> : <AlertTriangle size={14} className="text-red-400" />) : <ShieldCheck size={14} />}
            label="Run Design Rule Check"
            onClick={handleRunDRC}
          />
          <ToolBtn icon={<FileSpreadsheet size={14} />} label="Export BOM (.csv)" onClick={handleExportBOM} />
          <ToolBtn icon={<MapPin size={14} />} label="Export Pick & Place (.csv)" onClick={handleExportPickPlace} />
        </div>

        <button
          onClick={handleExport}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/50 text-slate-300 text-xs font-bold font-mono rounded hover:bg-slate-800 hover:text-amber-400 transition-colors mr-2"
          title="Gerber + drill only, no DRC or BOM"
        >
          <Download size={13} /> Gerber (.zip)
        </button>

        <button
          onClick={() => handleExportFabricationPackage(false)}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 text-slate-900 text-xs font-bold font-mono rounded hover:bg-amber-400 transition-colors"
          title="DRC + Gerber + Drill + BOM + Pick & Place, bundled"
        >
          <Package size={13} /> Export Fabrication Package
        </button>
      </div>

      {/* Main area */}
      <div className="flex flex-1 min-h-0">
        {/* Footprint palette */}
        <div className="w-64 bg-slate-900/80 border-r border-slate-700/50 overflow-y-auto p-3 flex-shrink-0">
          <h3 className="text-[10px] font-mono uppercase tracking-wider text-slate-500 mb-2">Component Library</h3>

          <div className="relative mb-2">
            <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search components…"
              className="w-full bg-slate-800 border border-slate-700 rounded pl-6 pr-2 py-1.5 text-xs font-mono text-slate-200 outline-none focus:border-amber-400"
            />
          </div>

          {groupedFootprints.length === 0 && (
            <p className="text-xs text-slate-500 mt-2">No components match "{search}".</p>
          )}

          <div className="space-y-1">
            {groupedFootprints.map(group => {
              const isCollapsed = collapsed.has(group.category) && search.trim() === '';
              return (
                <div key={group.category} className="border border-slate-800 rounded overflow-hidden">
                  <button
                    onClick={() => toggleCategory(group.category)}
                    className="w-full flex items-center justify-between px-2 py-1.5 bg-slate-800/60 hover:bg-slate-800 transition-colors"
                  >
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">{group.category}</span>
                    <span className="flex items-center gap-1 text-slate-500">
                      <span className="text-[9px]">{group.items.length}</span>
                      {isCollapsed ? <ChevronRight size={12} /> : <ChevronDown size={12} />}
                    </span>
                  </button>
                  {!isCollapsed && (
                    <div className="p-1 space-y-0.5">
                      {group.items.map(fp => (
                        <button
                          key={fp.type}
                          onClick={() => handlePlaceFootprint(fp.type)}
                          title={fp.label}
                          className={`w-full text-left px-2 py-1.5 rounded text-[11px] font-mono transition-colors ${
                            placingFootprint === fp.type
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                              : 'bg-slate-800/40 text-slate-300 border border-transparent hover:bg-slate-800 hover:text-slate-100'
                          }`}
                        >
                          {fp.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <p className="text-[10px] text-slate-500 mt-3 leading-relaxed">
            Click a component, then click the board to place it. Drag to move, R to rotate, F to flip side, Ctrl+C/Ctrl+V to copy/paste. Shift-click or drag a box to multi-select, Ctrl+A to select all. Drag the board's bottom-right handle to resize.
          </p>

          <h3 className="text-[10px] font-mono uppercase tracking-wider text-slate-500 mt-4 mb-2">Board size (mm)</h3>
          <div className="flex items-center gap-2">
            <input
              type="number"
              value={boardW}
              onChange={e => handleBoardResize(Number(e.target.value) || boardW, boardH)}
              className="w-16 bg-slate-800 border border-slate-700 rounded px-1.5 py-1 text-xs font-mono text-slate-200 outline-none focus:border-amber-400"
            />
            <span className="text-slate-500 text-xs">×</span>
            <input
              type="number"
              value={boardH}
              onChange={e => handleBoardResize(boardW, Number(e.target.value) || boardH)}
              className="w-16 bg-slate-800 border border-slate-700 rounded px-1.5 py-1 text-xs font-mono text-slate-200 outline-none focus:border-amber-400"
            />
          </div>
        </div>

        {/* Canvas */}
        <div ref={containerRef} className="flex-1 relative overflow-hidden cursor-crosshair">
          <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" style={{ touchAction: 'none' }} />
        </div>

        {/* Properties panel */}
        <div className="w-64 bg-slate-900/80 border-l border-slate-700/50 overflow-y-auto flex-shrink-0 p-3">
          <h3 className="text-[10px] font-mono uppercase tracking-wider text-slate-500 mb-2">Selection</h3>
          {selectedComponent ? (
            <div key={`${selectedComponent.id}-${propTick}`} className="space-y-3 text-xs">
              {/* Actions — same engine calls as the toolbar buttons/shortcuts above */}
              <div className="grid grid-cols-4 gap-1.5">
                <button
                  onClick={handleRotate}
                  title="Rotate (R)"
                  className="px-1.5 py-1.5 text-[10px] bg-slate-800 text-slate-300 border border-slate-700 rounded hover:bg-slate-700 transition-colors font-mono"
                >
                  ↻
                </button>
                <button
                  onClick={handleFlip}
                  title="Flip side (F)"
                  className="px-1.5 py-1.5 text-[10px] bg-slate-800 text-slate-300 border border-slate-700 rounded hover:bg-slate-700 transition-colors font-mono"
                >
                  ⇋
                </button>
                <button
                  onClick={handleDuplicate}
                  title="Duplicate"
                  className="px-1.5 py-1.5 text-[10px] bg-slate-800 text-slate-300 border border-slate-700 rounded hover:bg-slate-700 transition-colors font-mono"
                >
                  ⧉
                </button>
                <button
                  onClick={handleDelete}
                  title="Delete (Del)"
                  className="px-1.5 py-1.5 text-[10px] bg-red-500/10 text-red-400 border border-red-500/20 rounded hover:bg-red-500/20 transition-colors font-mono"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Ref Des</span>
                  <input
                    type="text"
                    defaultValue={selectedComponent.refDes}
                    onBlur={e => handleRefDesChange(e.target.value)}
                    className="w-24 bg-slate-800 border border-slate-700 rounded px-1.5 py-1 text-xs font-mono text-amber-300 outline-none focus:border-amber-400 text-right"
                  />
                </div>
                <div className="flex justify-between"><span className="text-slate-500">Component</span><span className="text-slate-200 font-mono text-right">{FOOTPRINTS[selectedComponent.footprint]?.label}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Category</span><span className="text-slate-200 font-mono text-right">{FOOTPRINTS[selectedComponent.footprint]?.category}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Rotation</span><span className="text-slate-200 font-mono">{selectedComponent.rotation}°</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Side</span><span className="text-slate-200 font-mono uppercase">{selectedComponent.side}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">X, Y (mm)</span><span className="text-slate-200 font-mono">{selectedComponent.x.toFixed(2)}, {selectedComponent.y.toFixed(2)}</span></div>
              </div>

              {(FOOTPRINTS[selectedComponent.footprint]?.properties?.length ?? 0) > 0 && (
                <div className="pt-2 border-t border-slate-800 space-y-2">
                  <h4 className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Properties</h4>
                  {FOOTPRINTS[selectedComponent.footprint].properties!.map(field => (
                    <div key={field.key} className="flex items-center justify-between gap-2">
                      <span className="text-slate-500 flex-shrink-0">{field.label}</span>
                      {field.type === 'select' ? (
                        <select
                          value={selectedComponent.props[field.key] ?? field.default}
                          onChange={e => handlePropChange(field.key, e.target.value)}
                          className="flex-1 min-w-0 bg-slate-800 border border-slate-700 rounded px-1.5 py-1 text-[11px] font-mono text-slate-200 outline-none focus:border-amber-400"
                        >
                          {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                        </select>
                      ) : (
                        <input
                          type="text"
                          defaultValue={selectedComponent.props[field.key] ?? field.default}
                          onBlur={e => handlePropChange(field.key, e.target.value)}
                          className="flex-1 min-w-0 bg-slate-800 border border-slate-700 rounded px-1.5 py-1 text-[11px] font-mono text-slate-200 outline-none focus:border-amber-400 text-right"
                        />
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : selCount > 0 ? (
            <p className="text-xs text-slate-400">{selCount} item(s) selected.</p>
          ) : (
            <p className="text-xs text-slate-500">Nothing selected.</p>
          )}

          <h3 className="text-[10px] font-mono uppercase tracking-wider text-slate-500 mt-4 mb-2">Board stats</h3>
          <div className="space-y-1 text-[11px] text-slate-400 font-mono">
            <div>{compCount} components</div>
            <div>{traceCount} traces</div>
            <div>{viaCount} vias</div>
          </div>
        </div>
      </div>

      {/* Status bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-900/80 border-t border-slate-700/50">
        <span className="text-[10px] text-slate-500 font-mono">
          {syncMessage ? (
            <span className="text-amber-400">{syncMessage}</span>
          ) : (
            <>
              {tool === 'select' && 'Click to select • Drag to move • Drag a trace\'s yellow points to reshape it'}
              {tool === 'pan' && 'Drag to pan the canvas'}
              {tool === 'place' && placingFootprint && `Click to place ${FOOTPRINTS[placingFootprint]?.label}`}
              {tool === 'route' && `Routing on ${activeLayer.toUpperCase()} — click pads/points, Enter to end, Esc to cancel`}
              {tool === 'via' && 'Click to place a via'}
            </>
          )}
        </span>
        <span className="text-[10px] text-slate-500 font-mono">Board {boardW}×{boardH}mm</span>
      </div>

      {/* Save Project dialog — always creates a new project in Project Gallery */}
      {showSaveDialog && (
        <div className="absolute inset-0 bg-slate-900/95 flex items-center justify-center z-50 p-4 sm:p-8">
          <div className="max-w-md w-full">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-amber-400 font-mono flex items-center gap-2">
                <Save size={16} /> Save PCB Project
              </h2>
              <button onClick={() => setShowSaveDialog(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <label className="block text-xs font-mono text-slate-400 mb-1.5">Project Name</label>
            <input
              type="text"
              value={saveProjectName}
              onChange={(e) => setSaveProjectName(e.target.value)}
              placeholder="e.g. Sensor Board Rev A"
              className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm text-slate-200 outline-none focus:border-amber-400 transition-colors"
            />

            <label className="block text-xs font-mono text-slate-400 mb-1.5 mt-4">
              Description <span className="text-slate-600">(optional)</span>
            </label>
            <textarea
              value={saveProjectDescription}
              onChange={(e) => setSaveProjectDescription(e.target.value)}
              rows={3}
              placeholder="What is this board for?"
              className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm text-slate-200 outline-none focus:border-amber-400 transition-colors resize-none"
            />

            <p className="text-[10px] text-slate-500 mt-3">
              Saving always creates a new project in Project Gallery. To overwrite an existing one, use Update from Project Gallery instead.
            </p>

            <div className="flex gap-2 mt-4">
              <button
                onClick={() => setShowSaveDialog(false)}
                className="flex-1 py-2 text-xs font-mono font-semibold rounded border border-slate-700 text-slate-300 hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveProject}
                disabled={!saveProjectName.trim()}
                className={`flex-1 py-2 text-xs font-mono font-semibold rounded transition-colors ${
                  !saveProjectName.trim()
                    ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                    : 'bg-amber-500 text-slate-900 hover:bg-amber-400'
                }`}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DRC results panel */}
      {showDrcPanel && drcReport && (
        <div className="absolute inset-0 bg-slate-900/95 flex items-center justify-center z-50 p-4 sm:p-8">
          <div className="max-w-lg w-full bg-slate-900 border border-slate-700 rounded-lg p-4 max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold font-mono flex items-center gap-2">
                {drcReport.issues.length === 0 ? (
                  <span className="text-emerald-400 flex items-center gap-2"><ShieldCheck size={18} /> DRC Passed</span>
                ) : (
                  <span className={drcReport.passed ? 'text-amber-400 flex items-center gap-2' : 'text-red-400 flex items-center gap-2'}>
                    <AlertTriangle size={18} /> DRC {drcReport.passed ? 'Passed with warnings' : 'Failed'}
                  </span>
                )}
              </h2>
              <button onClick={() => setShowDrcPanel(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="flex gap-3 text-[11px] font-mono text-slate-400 mb-3">
              <span>{drcReport.shortCircuitCount} short{drcReport.shortCircuitCount === 1 ? '' : 's'}</span>
              <span>{drcReport.clearanceCount} clearance</span>
              <span>{drcReport.openNetCount} open net{drcReport.openNetCount === 1 ? '' : 's'}</span>
            </div>

            {drcReport.issues.length === 0 ? (
              <p className="text-xs text-slate-400">No shorts, clearance violations, or open nets. Safe to export.</p>
            ) : (
              <div className="overflow-y-auto flex-1 space-y-1.5">
                {drcReport.issues.map(issue => (
                  <div
                    key={issue.id}
                    className={`text-[11px] font-mono px-2 py-1.5 rounded border ${
                      issue.severity === 'error' ? 'border-red-500/30 bg-red-500/10 text-red-300' : 'border-amber-500/30 bg-amber-500/10 text-amber-300'
                    }`}
                  >
                    <span className="uppercase font-bold">{issue.type.replace('-', ' ')}</span> — {issue.message}
                  </div>
                ))}
              </div>
            )}

            <div className="flex gap-2 mt-4">
              <button
                onClick={() => setShowDrcPanel(false)}
                className="flex-1 py-2 text-xs font-mono font-semibold rounded border border-slate-700 text-slate-300 hover:bg-slate-800 transition-colors"
              >
                Close
              </button>
              {!drcReport.passed && (
                <button
                  onClick={() => { setShowDrcPanel(false); handleExportFabricationPackage(true); }}
                  className="flex-1 py-2 text-xs font-mono font-semibold rounded bg-red-500/80 text-slate-900 hover:bg-red-500 transition-colors"
                  title="Export the fabrication package anyway, despite unresolved DRC errors"
                >
                  Export Anyway
                </button>
              )}
              {drcReport.passed && (
                <button
                  onClick={() => { setShowDrcPanel(false); handleExportFabricationPackage(false); }}
                  className="flex-1 py-2 text-xs font-mono font-semibold rounded bg-amber-500 text-slate-900 hover:bg-amber-400 transition-colors"
                >
                  Export Fabrication Package
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
});

PCBLab.displayName = 'PCBLab';

const ToolBtn: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; disabled?: boolean; onClick: () => void }> = ({ icon, label, active, disabled, onClick }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    title={label}
    className={`p-1.5 rounded transition-all ${
      active ? 'bg-amber-500/20 text-amber-400' : disabled ? 'text-slate-600 cursor-not-allowed' : 'text-slate-400 hover:bg-slate-700 hover:text-slate-200'
    }`}
  >
    {icon}
  </button>
);

export default PCBLab;
