/**
 * ElectricalLab - Main Circuit Simulator Component
 * Professional 2D circuit schematic editor with real-time simulation
 */

import React, { useRef, useEffect, useState, useCallback, forwardRef, useImperativeHandle } from 'react';
import { CircuitEditor } from '../circuit/CircuitEditor';
import { ComponentPalette } from '../circuit/ComponentPalette';
import { PropertyPanel } from '../circuit/PropertyPanel';
import type { ComponentType, Component, Wire } from '../circuit/types';
import type { CircuitError } from '../circuit/errorDetector';
import { optimizeCircuit, type CircuitOptimizationFocus } from '../services/OptimizationEngine';
import {
  parseCircuitOptimizationResponse,
  applyCircuitOptimization,
  type CircuitOptimizationChange,
} from '../circuit/ClaudeCircuitOptimizer';
import type { Language } from './CodingLab';
import { saveProject, captureCanvasThumbnail, type SavedProject, type SavedProjectSimulationSettings } from '../lib/projectStorage';
import { convertCircuitToPCB, type ConvertResult } from '../pcb/convertFromCircuit';
import { useWorkspacePanel } from '../hooks/useWorkspacePanel';
import { circuitToolBridge } from '../horus/tools/CircuitToolBridge';
import {
  MousePointer, Hand, GitBranch, ZoomIn, ZoomOut, Maximize,
  Undo2, Redo2, Trash2, RotateCw, Copy, Play, Pause, Grid3X3,
  Download, Upload, Lightbulb, Info, AlertTriangle, AlertOctagon, X,
  ChevronDown, SquarePen, Loader2, Zap, Save, Check, Cpu, LayoutGrid,
  PanelLeftClose, PanelLeftOpen, PanelRightClose, PanelRightOpen, GripVertical
} from 'lucide-react';

// A point-in-time snapshot of the currently-open project, used by Project
// Gallery's "Update" action to overwrite that project with live edits.
// `loadedProjectId` is null when the current circuit was never opened from
// (or saved as) a gallery project.
export interface ProjectSaveSnapshot {
  loadedProjectId: string | null;
  name: string;
  description: string;
  circuit: string;
  simulationSettings: SavedProjectSimulationSettings;
  componentCount: number;
  wireCount: number;
  thumbnail?: string;
}

// Handle exposed via ref so sibling tabs (e.g. the Coding tab) can read
// components from / drive updates into this same circuit instance, and so
// Project Gallery can pull a live snapshot for its Update action.
export interface ElectricalLabHandle {
  getEditor: () => CircuitEditor | null;
  getSaveSnapshot: () => ProjectSaveSnapshot | null;
}

interface ElectricalLabProps {
  /**
   * Requests that the parent open the Coding tab. When `payload` is given
   * (from the AI Electrical Engineer), the parent should also insert that
   * code into the Coding tab's editor and switch to the matching language.
   */
  onOpenCoding?: (payload?: { language: Language; code: string }) => void;
  /** A project the Gallery wants opened — restored on mount / when it changes. */
  loadProject?: SavedProject | null;
  /** Called once the requested project has been restored, so the parent can clear the request. */
  onProjectLoaded?: () => void;
  /**
   * Requests that the parent open the PCB tab and import the given
   * "Convert to PCB" payload there. Optional - if omitted, the Convert to
   * PCB button simply isn't shown, so every existing caller of
   * <ElectricalLab /> with no props keeps working unchanged.
   */
  onConvertToPCB?: (payload: ConvertResult) => void;
}

const ElectricalLab = forwardRef<ElectricalLabHandle, ElectricalLabProps>(({ onOpenCoding, loadProject, onProjectLoaded, onConvertToPCB }, ref) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const editorRef = useRef<CircuitEditor | null>(null);

  const [selectedTool, setSelectedTool] = useState('select');
  const [selectedComponents, setSelectedComponents] = useState<Component[]>([]);
  const [selectedWires, setSelectedWires] = useState<Wire[]>([]);
  const [zoom, setZoom] = useState(100);
  const [showGrid, setShowGrid] = useState(true);
  const [simRunning, setSimRunning] = useState(true);
  const [showHelp, setShowHelp] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [saveProjectName, setSaveProjectName] = useState('');
  const [saveProjectDescription, setSaveProjectDescription] = useState('');
  const [loadedProjectId, setLoadedProjectId] = useState<string | null>(null);
  const [saveConfirmed, setSaveConfirmed] = useState(false);
  const [circuitErrors, setCircuitErrors] = useState<CircuitError[]>([]);
  const [showErrors, setShowErrors] = useState(false);
  const [compCount, setCompCount] = useState(0);
  const [wireCount, setWireCount] = useState(0);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  // Coding dropdown (Manual Coding)
  const [showCodingMenu, setShowCodingMenu] = useState(false);

  // Optimize Circuit (AI) modal
  const [showOptimizeModal, setShowOptimizeModal] = useState(false);
  const [optimizeFocus, setOptimizeFocus] = useState<Record<CircuitOptimizationFocus, boolean>>({
    circuit: true, wiring: true, power: true, componentValues: true,
  });
  const [optimizeThinking, setOptimizeThinking] = useState(false);
  const [optimizeError, setOptimizeError] = useState<string | null>(null);
  const [optimizeSummary, setOptimizeSummary] = useState<string | null>(null);
  const [optimizePowerSavings, setOptimizePowerSavings] = useState<number>(0);
  const [optimizeChanges, setOptimizeChanges] = useState<CircuitOptimizationChange[]>([]);
  const [optimizeSelectedIds, setOptimizeSelectedIds] = useState<Set<number>>(new Set());
  const [optimizeWiringSuggestions, setOptimizeWiringSuggestions] = useState<string[]>([]);
  const [optimizeWarnings, setOptimizeWarnings] = useState<string[]>([]);
  const [optimizeApplied, setOptimizeApplied] = useState(false);

  // Workspace Mode: resizable/collapsible side panels, persisted per-panel.
  const leftPanel = useWorkspacePanel({
    storageKey: 'enginix.workspace.electrical.leftPanel',
    defaultWidth: 208, // matches previous fixed w-52
    minWidth: 160,
    maxWidth: 400,
    side: 'left',
  });
  const rightPanel = useWorkspacePanel({
    storageKey: 'enginix.workspace.electrical.rightPanel',
    defaultWidth: 224, // matches previous fixed w-56
    minWidth: 200,
    maxWidth: 480,
    side: 'right',
  });

  useImperativeHandle(ref, () => ({
    getEditor: () => editorRef.current,
    getSaveSnapshot: () => {
      const editor = editorRef.current;
      if (!editor) return null;

      const circuitJson = editor.exportCircuit();
      const { components, wires } = JSON.parse(circuitJson) as { components: unknown[]; wires: unknown[] };
      const editorState = editor.state;
      const thumbnail = captureCanvasThumbnail(editor.canvas);

      return {
        loadedProjectId,
        name: saveProjectName.trim() || 'Untitled Project',
        description: saveProjectDescription.trim(),
        circuit: circuitJson,
        simulationSettings: {
          zoom,
          showGrid,
          simRunning,
          scale: editorState.scale,
          offsetX: editorState.offsetX,
          offsetY: editorState.offsetY,
        },
        componentCount: components.length,
        wireCount: wires.length,
        thumbnail,
      };
    },
  }), [loadedProjectId, saveProjectName, saveProjectDescription, zoom, showGrid, simRunning]);

  // Initialize editor
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const editor = new CircuitEditor(canvasRef.current, containerRef.current);
    editorRef.current = editor;

    // Register this exact editor instance as HORUS's read source, so
    // every AI prompt reflects what's actually on the canvas instead of
    // an always-empty circuit. Unregistered on unmount below.
    circuitToolBridge.register(editor);

    editor.onStateChange = () => {
      setCompCount(editor.state.components.length);
      setWireCount(editor.state.wires.length);
      setZoom(Math.round(editor.state.scale * 100));
      setCanUndo(editor.state.historyIndex > 0);
      setCanRedo(editor.state.historyIndex < editor.state.history.length - 1);
    };

    editor.onSelectionChange = () => {
      const comps = editor.state.components.filter(c =>
        editor.state.selectedComponentIds.includes(c.id)
      );
      setSelectedComponents(comps);
      const wires = editor.state.wires.filter(w =>
        editor.state.selectedWireIds.includes(w.id)
      );
      setSelectedWires(wires);
      setCanUndo(editor.state.historyIndex > 0);
      setCanRedo(editor.state.historyIndex < editor.state.history.length - 1);
    };

    editor.onErrorsChange = (errors) => {
      setCircuitErrors(errors);
    };

    // Center view on init — but not when a saved project is about to be
    // restored, since that project carries its own exact camera position
    // (see the "Restore a loaded project" effect below) which this would
    // otherwise overwrite a moment later.
    const hasPendingLoad = !!loadProject;
    setTimeout(() => {
      if (!hasPendingLoad) editor.centerView();
      editor.resize();
    }, 100);

    return () => {
      circuitToolBridge.unregister(editor);
      editor.destroy();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      editorRef.current?.resize();
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Restore a loaded project: circuit (components/wires/values/positions/
  // rotation) via the editor's own import, then the exact camera (scale +
  // pan) and simulation state, so the canvas looks exactly as when it was
  // saved.
  useEffect(() => {
    if (!loadProject) return;
    const editor = editorRef.current;
    if (!editor) return;

    editor.importCircuit(loadProject.circuit);

    const { scale, offsetX, offsetY, showGrid: savedShowGrid, simRunning: savedSimRunning } = loadProject.simulationSettings;
    editor.state.scale = scale;
    editor.state.offsetX = offsetX;
    editor.state.offsetY = offsetY;
    editor.state.showGrid = savedShowGrid;
    editor.setSimulating(savedSimRunning);

    setZoom(Math.round(scale * 100));
    setShowGrid(savedShowGrid);
    setSimRunning(savedSimRunning);

    // Remember which project this is, and prefill its name/description, so
    // a subsequent Save updates this same project instead of creating a
    // duplicate.
    setLoadedProjectId(loadProject.id);
    setSaveProjectName(loadProject.name);
    setSaveProjectDescription(loadProject.description);

    onProjectLoaded?.();
  }, [loadProject, onProjectLoaded]);

  const handleToolChange = useCallback((tool: string) => {
    setSelectedTool(tool);
    editorRef.current?.setTool(tool);
  }, []);

  const handleAddComponent = useCallback((type: ComponentType) => {
    editorRef.current?.addComponent(type);
    setSelectedTool('select');
    editorRef.current?.setTool('select');
  }, []);

  const handleUpdateProperty = useCallback((compId: number, key: string, value: number | string | boolean) => {
    editorRef.current?.updateComponentProperty(compId, key, value);
  }, []);

  const handleRename = useCallback((compId: number, label: string) => {
    editorRef.current?.renameComponent(compId, label);
  }, []);

  const handleToggleSwitch = useCallback((compId: number) => {
    editorRef.current?.toggleSwitch(compId);
  }, []);

  const handleDelete = useCallback(() => {
    editorRef.current?.deleteSelected();
  }, []);

  const handleRotate = useCallback(() => {
    editorRef.current?.rotateSelected();
  }, []);

  const handleDuplicate = useCallback(() => {
    editorRef.current?.duplicateSelected();
  }, []);

  const handleAutoArrange = useCallback(() => {
    editorRef.current?.autoArrangeCircuit();
  }, []);

  const handleSetWireColor = useCallback((color: string) => {
    const editor = editorRef.current;
    if (!editor) return;
    editor.setWireColor(editor.state.selectedWireIds, color);
  }, []);

  const handleSetWireNetLabel = useCallback((label: string) => {
    const editor = editorRef.current;
    if (!editor) return;
    editor.setWireNetLabel(editor.state.selectedWireIds, label);
  }, []);

  const handleCleanWireRouting = useCallback(() => {
    const editor = editorRef.current;
    if (!editor) return;
    editor.cleanWireRouting(editor.state.selectedWireIds);
  }, []);

  const handleUndo = useCallback(() => {
    editorRef.current?.undo();
  }, []);

  const handleRedo = useCallback(() => {
    editorRef.current?.redo();
  }, []);

  const handleZoomIn = useCallback(() => {
    if (!editorRef.current) return;
    editorRef.current.state.scale = Math.min(5, editorRef.current.state.scale * 1.25);
    setZoom(Math.round(editorRef.current.state.scale * 100));
  }, []);

  const handleZoomOut = useCallback(() => {
    if (!editorRef.current) return;
    editorRef.current.state.scale = Math.max(0.2, editorRef.current.state.scale / 1.25);
    setZoom(Math.round(editorRef.current.state.scale * 100));
  }, []);

  const handleZoomFit = useCallback(() => {
    editorRef.current?.centerView();
    setZoom(Math.round((editorRef.current?.state.scale || 1) * 100));
  }, []);

  const handleToggleGrid = useCallback(() => {
    if (!editorRef.current) return;
    editorRef.current.state.showGrid = !editorRef.current.state.showGrid;
    setShowGrid(editorRef.current.state.showGrid);
  }, []);

  const handleToggleSim = useCallback(() => {
    if (!editorRef.current) return;
    const next = !editorRef.current.state.simulating;
    editorRef.current.setSimulating(next);
    setSimRunning(next);
  }, []);

  const handleExport = useCallback(() => {
    const json = editorRef.current?.exportCircuit();
    if (json) {
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'circuit.json';
      a.click();
      URL.revokeObjectURL(url);
    }
  }, []);

  const handleImport = useCallback(() => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (ev) => {
          editorRef.current?.importCircuit(ev.target?.result as string);
        };
        reader.readAsText(file);
      }
    };
    input.click();
  }, []);

  const handleClear = useCallback(() => {
    if (confirm('Clear all components and wires?')) {
      editorRef.current?.clearAll();
    }
  }, []);

  // Convert to PCB: reads the current circuit (never modifies it - see
  // convertCircuitToPCB) and hands the resulting footprints + netlist up
  // to the parent, which opens the PCB tab and imports them there.
  const handleConvertToPCB = useCallback(() => {
    const editor = editorRef.current;
    if (!editor || !onConvertToPCB) return;
    const result = convertCircuitToPCB(editor.state.components, editor.state.wires);
    onConvertToPCB(result);
  }, [onConvertToPCB]);

  const handleSaveProject = useCallback(() => {
    if (!saveProjectName.trim() || !editorRef.current) return;

    const circuitJson = editorRef.current.exportCircuit();
    const { components, wires } = JSON.parse(circuitJson) as { components: unknown[]; wires: unknown[] };
    const editorState = editorRef.current.state;

    // Best-effort thumbnail capture — never blocks or breaks the save.
    const thumbnail = captureCanvasThumbnail(editorRef.current.canvas);

    const payload = {
      name: saveProjectName.trim(),
      description: saveProjectDescription.trim(),
      circuit: circuitJson,
      simulationSettings: {
        zoom,
        showGrid,
        simRunning,
        scale: editorState.scale,
        offsetX: editorState.offsetX,
        offsetY: editorState.offsetY,
      },
      componentCount: components.length,
      wireCount: wires.length,
      thumbnail,
    };

    // Save always creates a brand-new project with a new id and never
    // overwrites the project this circuit may have been opened from — the
    // original stays untouched. Updating an existing project is only done
    // from Project Gallery's Update action.
    const saved = saveProject(payload);
    setLoadedProjectId(saved.id);

    setShowSaveDialog(false);
    setSaveConfirmed(true);
    setTimeout(() => setSaveConfirmed(false), 2000);
  }, [saveProjectName, saveProjectDescription, zoom, showGrid, simRunning, loadedProjectId]);

  const handleManualCoding = useCallback(() => {
    setShowCodingMenu(false);
    onOpenCoding?.();
  }, [onOpenCoding]);

  const handleOpenOptimizeModal = useCallback(() => {
    setShowCodingMenu(false);
    setOptimizeError(null);
    setOptimizeSummary(null);
    setOptimizePowerSavings(0);
    setOptimizeChanges([]);
    setOptimizeSelectedIds(new Set());
    setOptimizeWiringSuggestions([]);
    setOptimizeWarnings([]);
    setOptimizeApplied(false);
    setShowOptimizeModal(true);
  }, []);

  const handleToggleOptimizeFocus = useCallback((focus: CircuitOptimizationFocus) => {
    setOptimizeFocus((prev) => ({ ...prev, [focus]: !prev[focus] }));
  }, []);

  const handleRunOptimize = useCallback(async () => {
    if (optimizeThinking || !editorRef.current) return;
    const editor = editorRef.current;

    if (editor.state.components.length === 0) {
      setOptimizeError('Add some components to the circuit before optimizing.');
      return;
    }

    const selectedFocus = (Object.keys(optimizeFocus) as CircuitOptimizationFocus[]).filter((f) => optimizeFocus[f]);
    if (selectedFocus.length === 0) {
      setOptimizeError('Pick at least one thing to optimize.');
      return;
    }

    setOptimizeThinking(true);
    setOptimizeError(null);
    setOptimizeApplied(false);

    const result = await optimizeCircuit(editor.exportCircuit(), selectedFocus);
    if (!result.ok) {
      setOptimizeError(result.error);
      setOptimizeThinking(false);
      return;
    }

    const parsed = parseCircuitOptimizationResponse(result.text, editor.state.components);
    if (!parsed.ok) {
      setOptimizeError(`Couldn't understand Claude's response: ${parsed.error}`);
      setOptimizeThinking(false);
      return;
    }

    if (!parsed.data.success) {
      const reason = (parsed.data.errors && parsed.data.errors.length > 0) ? parsed.data.errors.join(' ') : 'Claude reported it could not optimize this circuit.';
      setOptimizeError(reason);
      setOptimizeThinking(false);
      return;
    }

    const changes = parsed.data.componentChanges || [];
    setOptimizeSummary(parsed.data.summary || 'Optimization complete.');
    setOptimizePowerSavings(parsed.data.estimatedPowerSavingsPercent || 0);
    setOptimizeChanges(changes);
    setOptimizeSelectedIds(new Set(changes.map((_, i) => i)));
    setOptimizeWiringSuggestions(parsed.data.wiringSuggestions || []);
    setOptimizeWarnings(parsed.data.warnings || []);
    setOptimizeThinking(false);
  }, [optimizeFocus, optimizeThinking]);

  const handleToggleOptimizeChange = useCallback((index: number) => {
    setOptimizeSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index); else next.add(index);
      return next;
    });
  }, []);

  const handleApplyOptimizeChanges = useCallback(() => {
    if (!editorRef.current) return;
    const toApply = optimizeChanges.filter((_, i) => optimizeSelectedIds.has(i));
    const result = applyCircuitOptimization(editorRef.current, toApply);
    if (!result.ok) {
      setOptimizeError(result.error);
      return;
    }
    setOptimizeApplied(true);
    setOptimizeWarnings((prev) => [...prev, ...result.warnings]);
  }, [optimizeChanges, optimizeSelectedIds]);

  return (
    <div className="flex flex-col h-full bg-[#0f1729] border border-slate-700/50 rounded-lg overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center gap-1 px-3 py-2 bg-slate-900/80 border-b border-slate-700/50 flex-wrap">
        {/* Tools */}
        <div className="flex items-center gap-0.5 bg-slate-800/50 rounded p-0.5">
          <ToolbarButton
            icon={<MousePointer size={14} />}
            label="Select (V)"
            active={selectedTool === 'select'}
            onClick={() => handleToolChange('select')}
          />
          <ToolbarButton
            icon={<Hand size={14} />}
            label="Pan (H)"
            active={selectedTool === 'pan'}
            onClick={() => handleToolChange('pan')}
          />
          <ToolbarButton
            icon={<GitBranch size={14} />}
            label="Wire (W)"
            active={selectedTool === 'wire'}
            onClick={() => handleToolChange('wire')}
          />
        </div>

        <div className="w-px h-6 bg-slate-700/50 mx-1" />

        {/* Edit */}
        <div className="flex items-center gap-0.5 bg-slate-800/50 rounded p-0.5">
          <ToolbarButton icon={<Undo2 size={14} />} label="Undo" onClick={handleUndo} disabled={!canUndo} />
          <ToolbarButton icon={<Redo2 size={14} />} label="Redo" onClick={handleRedo} disabled={!canRedo} />
          <ToolbarButton icon={<Trash2 size={14} />} label="Delete" onClick={handleDelete} />
          <ToolbarButton icon={<RotateCw size={14} />} label="Rotate (R)" onClick={handleRotate} />
          <ToolbarButton icon={<Copy size={14} />} label="Duplicate (Ctrl+D)" onClick={handleDuplicate} />
          <ToolbarButton icon={<LayoutGrid size={14} />} label="Auto Arrange" onClick={handleAutoArrange} />
        </div>

        <div className="w-px h-6 bg-slate-700/50 mx-1" />

        {/* View */}
        <div className="flex items-center gap-0.5 bg-slate-800/50 rounded p-0.5">
          <ToolbarButton icon={<ZoomIn size={14} />} label="Zoom In" onClick={handleZoomIn} />
          <span className="text-[10px] text-slate-400 font-mono w-10 text-center">{zoom}%</span>
          <ToolbarButton icon={<ZoomOut size={14} />} label="Zoom Out" onClick={handleZoomOut} />
          <ToolbarButton icon={<Maximize size={14} />} label="Fit" onClick={handleZoomFit} />
          <ToolbarButton icon={<Grid3X3 size={14} />} label="Grid" active={showGrid} onClick={handleToggleGrid} />
        </div>

        <div className="w-px h-6 bg-slate-700/50 mx-1" />

        {/* Simulation */}
        <div className="flex items-center gap-0.5 bg-slate-800/50 rounded p-0.5">
          <ToolbarButton
            icon={simRunning ? <Pause size={14} /> : <Play size={14} />}
            label={simRunning ? 'Pause Sim' : 'Run Sim'}
            active={simRunning}
            onClick={handleToggleSim}
          />
        </div>

        <div className="w-px h-6 bg-slate-700/50 mx-1" />

        {/* Coding dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowCodingMenu(v => !v)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono font-semibold rounded transition-colors ${
              showCodingMenu ? 'bg-amber-500/20 text-amber-400' : 'text-slate-400 hover:bg-slate-700 hover:text-slate-200'
            }`}
          >
            <span>💻 Coding</span>
            <ChevronDown size={12} />
          </button>

          {showCodingMenu && (
            <>
              {/* Backdrop to close the menu on outside click */}
              <div className="fixed inset-0 z-40" onClick={() => setShowCodingMenu(false)} />
              <div className="absolute left-0 top-full mt-1 w-56 bg-slate-900 border border-slate-700/50 rounded-lg shadow-xl z-50 overflow-hidden">
                <button
                  onClick={handleManualCoding}
                  className="w-full flex items-center gap-2.5 px-3 py-2.5 text-xs text-left text-slate-300 hover:bg-slate-800 hover:text-amber-400 transition-colors"
                >
                  <SquarePen size={14} className="flex-shrink-0" />
                  <span>
                    <span className="block font-semibold">Manual Coding</span>
                    <span className="block text-[10px] text-slate-500">Open the code editor</span>
                  </span>
                </button>
                <div className="h-px bg-slate-700/50" />
                <button
                  onClick={handleOpenOptimizeModal}
                  className="w-full flex items-center gap-2.5 px-3 py-2.5 text-xs text-left text-slate-300 hover:bg-slate-800 hover:text-amber-400 transition-colors"
                >
                  <Zap size={14} className="flex-shrink-0" />
                  <span>
                    <span className="block font-semibold">Optimize Circuit (AI)</span>
                    <span className="block text-[10px] text-slate-500">Better values, wiring & power use</span>
                  </span>
                </button>
              </div>
            </>
          )}
        </div>

        <div className="w-px h-6 bg-slate-700/50 mx-1" />

        {/* File */}
        <div className="flex items-center gap-0.5 bg-slate-800/50 rounded p-0.5">
          <ToolbarButton
            icon={saveConfirmed ? <Check size={14} /> : <Save size={14} />}
            label={saveConfirmed ? 'Saved ✓' : 'Save Project'}
            active={saveConfirmed}
            onClick={() => setShowSaveDialog(true)}
          />
          <ToolbarButton icon={<Download size={14} />} label="Export" onClick={handleExport} />
          <ToolbarButton icon={<Upload size={14} />} label="Import" onClick={handleImport} />
          <ToolbarButton icon={<Trash2 size={14} />} label="Clear" onClick={handleClear} />
          {onConvertToPCB && (
            <ToolbarButton icon={<Cpu size={14} />} label="Convert to PCB" onClick={handleConvertToPCB} />
          )}
        </div>

        <div className="flex-1" />

        {/* Info */}
        <div className="flex items-center gap-3 text-[10px] text-slate-500 font-mono">
          <span>{compCount} components</span>
          <span>{wireCount} wires</span>
          <button
            onClick={() => setShowErrors(!showErrors)}
            title="Circuit errors"
            className={`relative flex items-center transition-colors ${
              circuitErrors.some(e => e.severity === 'critical')
                ? 'text-red-400 hover:text-red-300'
                : circuitErrors.length > 0
                  ? 'text-amber-400 hover:text-amber-300'
                  : 'text-slate-500 hover:text-amber-400'
            }`}
          >
            <AlertTriangle size={14} />
            {circuitErrors.length > 0 && (
              <span className="ml-1">{circuitErrors.length}</span>
            )}
          </button>
          <button onClick={() => setShowHelp(!showHelp)} className="hover:text-amber-400 transition-colors">
            <Info size={14} />
          </button>
        </div>
      </div>

      {/* Main area */}
      <div className="flex flex-1 min-h-0">
        {/* Component Palette */}
        <div
          className="relative bg-slate-900/80 border-r border-slate-700/50 flex-shrink-0 transition-[width] duration-150 ease-out"
          style={{ width: leftPanel.collapsed ? 0 : leftPanel.width }}
        >
          <button
            onClick={leftPanel.toggleCollapsed}
            title={leftPanel.collapsed ? 'Show component palette' : 'Hide component palette'}
            className={`absolute top-1/2 -translate-y-1/2 z-10 flex items-center justify-center w-4 h-10 rounded-r bg-slate-800/90 border border-l-0 border-slate-700/50 text-slate-400 hover:text-amber-400 hover:bg-slate-800 transition-colors ${
              leftPanel.collapsed ? 'left-0' : '-right-4'
            }`}
          >
            {leftPanel.collapsed ? <PanelLeftOpen size={12} /> : <PanelLeftClose size={12} />}
          </button>

          {!leftPanel.collapsed && (
            <>
              <div className="h-full overflow-y-auto p-3">
                <ComponentPalette
                  onSelectComponent={handleAddComponent}
                  selectedTool={selectedTool}
                />
              </div>
              {/* Drag handle to resize */}
              <div
                {...leftPanel.dragHandleProps}
                className="absolute top-0 right-0 h-full w-1.5 cursor-col-resize group flex items-center justify-center touch-none"
              >
                <div className="w-px h-full bg-transparent group-hover:bg-amber-400/50 transition-colors" />
                <GripVertical size={10} className="absolute text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </>
          )}
        </div>

        {/* Canvas */}
        <div ref={containerRef} className="flex-1 relative overflow-hidden cursor-crosshair">
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full"
            style={{ touchAction: 'none' }}
          />

          {/* Error detector panel */}
          {showErrors && (
            <div className="absolute top-2 right-2 w-72 max-h-[70%] bg-slate-900/95 border border-slate-700/50 rounded-lg shadow-xl z-40 flex flex-col overflow-hidden">
              <div className="flex items-center justify-between px-3 py-2 border-b border-slate-700/50 flex-shrink-0">
                <h3 className="text-xs font-bold text-amber-400 font-mono uppercase tracking-wider">
                  Error Detector
                </h3>
                <button onClick={() => setShowErrors(false)} className="text-slate-400 hover:text-white">
                  <X size={14} />
                </button>
              </div>
              <div className="overflow-y-auto p-2 space-y-1.5">
                {circuitErrors.length === 0 ? (
                  <p className="text-[11px] text-slate-400 px-1 py-2">
                    No issues detected — circuit looks healthy.
                  </p>
                ) : (
                  circuitErrors.map(err => (
                    <div
                      key={err.id}
                      className={`flex items-start gap-2 rounded p-2 text-[11px] leading-snug ${
                        err.severity === 'critical'
                          ? 'bg-red-950/40 text-red-300 border border-red-900/50'
                          : 'bg-amber-950/30 text-amber-300 border border-amber-900/40'
                      }`}
                    >
                      {err.severity === 'critical' ? (
                        <AlertOctagon size={13} className="flex-shrink-0 mt-0.5" />
                      ) : (
                        <AlertTriangle size={13} className="flex-shrink-0 mt-0.5" />
                      )}
                      <span>{err.message}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Optimize Circuit (AI) overlay */}
          {showOptimizeModal && (
            <div className="absolute inset-0 bg-slate-900/95 flex items-center justify-center z-50 p-8">
              <div className="max-w-lg w-full max-h-full overflow-y-auto">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-amber-400 font-mono flex items-center gap-2">
                    <Zap size={16} /> Optimize Circuit (AI)
                  </h2>
                  <button onClick={() => setShowOptimizeModal(false)} className="text-slate-400 hover:text-white">
                    ✕
                  </button>
                </div>

                <p className="text-xs text-slate-400 mb-3">
                  Claude will review the current circuit and suggest improvements. Pick what to focus on:
                </p>

                <div className="grid grid-cols-2 gap-2 mb-3">
                  {([
                    ['circuit', 'Circuit design'],
                    ['wiring', 'Wiring'],
                    ['power', 'Power consumption'],
                    ['componentValues', 'Component values'],
                  ] as Array<[CircuitOptimizationFocus, string]>).map(([key, label]) => (
                    <label key={key} className="flex items-center gap-2 text-xs text-slate-300 bg-slate-800/50 rounded px-2 py-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={optimizeFocus[key]}
                        onChange={() => handleToggleOptimizeFocus(key)}
                        className="accent-amber-500"
                      />
                      {label}
                    </label>
                  ))}
                </div>

                <button
                  onClick={handleRunOptimize}
                  disabled={optimizeThinking}
                  className={`w-full flex items-center justify-center gap-2 py-2 text-xs font-mono font-semibold rounded transition-colors ${
                    optimizeThinking
                      ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                      : 'bg-amber-500 text-slate-900 hover:bg-amber-400'
                  }`}
                >
                  {optimizeThinking ? <Loader2 size={13} className="animate-spin" /> : <Zap size={13} />}
                  {optimizeThinking ? 'Analyzing circuit...' : 'Analyze & Optimize'}
                </button>

                {optimizeError && (
                  <p className="mt-3 text-xs text-red-400 leading-relaxed">{optimizeError}</p>
                )}

                {optimizeSummary && (
                  <div className="mt-4 border-t border-slate-700/50 pt-4">
                    <p className="text-xs text-slate-300 leading-relaxed">{optimizeSummary}</p>
                    {optimizePowerSavings > 0 && (
                      <p className="text-xs text-green-400 mt-1">Estimated power savings: ~{optimizePowerSavings}%</p>
                    )}

                    {optimizeChanges.length > 0 && (
                      <div className="mt-3 space-y-1.5 max-h-48 overflow-y-auto">
                        {optimizeChanges.map((change, i) => (
                          <label key={i} className="flex items-start gap-2 text-[11px] text-slate-300 bg-slate-800/50 rounded p-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={optimizeSelectedIds.has(i)}
                              onChange={() => handleToggleOptimizeChange(i)}
                              className="accent-amber-500 mt-0.5"
                            />
                            <span>
                              <span className="block font-mono text-amber-400">
                                {change.componentType} #{change.id}.{change.prop}: {String(change.oldValue)} → {String(change.newValue)}
                              </span>
                              <span className="block text-slate-400">{change.reason}</span>
                            </span>
                          </label>
                        ))}
                      </div>
                    )}

                    {optimizeWiringSuggestions.length > 0 && (
                      <div className="mt-3">
                        <h3 className="text-[10px] font-bold text-amber-400 font-mono uppercase tracking-wider mb-1">Wiring suggestions</h3>
                        <ul className="text-[11px] text-slate-400 list-disc list-inside space-y-0.5">
                          {optimizeWiringSuggestions.map((s, i) => <li key={i}>{s}</li>)}
                        </ul>
                      </div>
                    )}

                    {optimizeWarnings.length > 0 && (
                      <div className="mt-3 space-y-0.5">
                        {optimizeWarnings.map((w, i) => (
                          <p key={i} className="text-[11px] text-amber-400">⚠ {w}</p>
                        ))}
                      </div>
                    )}

                    {optimizeChanges.length > 0 && (
                      <button
                        onClick={handleApplyOptimizeChanges}
                        disabled={optimizeApplied || optimizeSelectedIds.size === 0}
                        className={`w-full mt-3 py-2 text-xs font-mono font-semibold rounded transition-colors ${
                          optimizeApplied || optimizeSelectedIds.size === 0
                            ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                            : 'bg-green-600/30 text-green-400 hover:bg-green-600/40'
                        }`}
                      >
                        {optimizeApplied ? 'Changes applied ✓' : `Apply ${optimizeSelectedIds.size} selected change${optimizeSelectedIds.size === 1 ? '' : 's'}`}
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Help overlay */}
          {showHelp && (
            <div className="absolute inset-0 bg-slate-900/95 flex items-center justify-center z-50 p-8">
              <div className="max-w-lg w-full">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-amber-400 font-mono">Circuit Simulator Help</h2>
                  <button onClick={() => setShowHelp(false)} className="text-slate-400 hover:text-white">
                    ✕
                  </button>
                </div>
                <div className="space-y-3 text-xs text-slate-300">
                  <HelpSection title="Tools">
                    <HelpItem key="s" shortcut="V" desc="Select tool - click to select, drag to move" />
                    <HelpItem shortcut="H" desc="Pan tool - drag to pan the view" />
                    <HelpItem shortcut="W" desc="Wire tool - click two terminals to connect" />
                    <HelpItem shortcut="Shift+Click" desc="On a terminal to start wiring" />
                  </HelpSection>
                  <HelpSection title="Editing">
                    <HelpItem shortcut="Delete" desc="Delete selected components/wires" />
                    <HelpItem shortcut="R" desc="Rotate selected components" />
                    <HelpItem shortcut="Ctrl+D" desc="Duplicate selection" />
                    <HelpItem shortcut="Ctrl+A" desc="Select all" />
                    <HelpItem shortcut="Ctrl+Z" desc="Undo" />
                    <HelpItem shortcut="Ctrl+Shift+Z" desc="Redo" />
                    <HelpItem shortcut="Escape" desc="Cancel action / deselect" />
                  </HelpSection>
                  <HelpSection title="View">
                    <HelpItem shortcut="Scroll" desc="Zoom in/out" />
                    <HelpItem shortcut="Middle-drag" desc="Pan view" />
                  </HelpSection>
                  <HelpSection title="Tips">
                    <p className="text-slate-400">Click on a component in the palette to place it. Click on terminals to create wires. Double-click switches to toggle them. The simulation runs in real-time as you edit.</p>
                  </HelpSection>
                </div>
              </div>
            </div>
          )}

          {/* Save Project dialog — always creates a new project in Project Gallery */}
          {showSaveDialog && (
            <div className="absolute inset-0 bg-slate-900/95 flex items-center justify-center z-50 p-4 sm:p-8">
              <div className="max-w-md w-full">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-amber-400 font-mono flex items-center gap-2">
                    <Save size={16} /> Save Project
                  </h2>
                  <button onClick={() => setShowSaveDialog(false)} className="text-slate-400 hover:text-white">
                    ✕
                  </button>
                </div>

                <label className="block text-xs font-mono text-slate-400 mb-1.5">Project Name</label>
                <input
                  type="text"
                  value={saveProjectName}
                  onChange={(e) => setSaveProjectName(e.target.value)}
                  placeholder="e.g. Solar Tracking Panel Array"
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm text-slate-200 outline-none focus:border-amber-400 transition-colors"
                />

                <label className="block text-xs font-mono text-slate-400 mb-1.5 mt-4">
                  Description <span className="text-slate-600">(optional)</span>
                </label>
                <textarea
                  value={saveProjectDescription}
                  onChange={(e) => setSaveProjectDescription(e.target.value)}
                  rows={3}
                  placeholder="What does this circuit do?"
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm text-slate-200 outline-none focus:border-amber-400 transition-colors resize-none"
                />

                <div className="flex gap-2 mt-5">
                  <button
                    onClick={() => setShowSaveDialog(false)}
                    className="flex-1 py-2 text-xs font-mono font-semibold rounded border border-slate-700 text-slate-300 hover:bg-slate-800 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveProject}
                    disabled={!saveProjectName.trim()}
                    className={`flex-1 py-2 text-xs font-mono font-semibold rounded transition-colors ${
                      !saveProjectName.trim()
                        ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                        : 'bg-amber-500 text-slate-900 hover:bg-amber-400'
                    }`}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Properties Panel */}
        <div
          className="relative bg-slate-900/80 border-l border-slate-700/50 flex-shrink-0 transition-[width] duration-150 ease-out"
          style={{ width: rightPanel.collapsed ? 0 : rightPanel.width }}
        >
          <button
            onClick={rightPanel.toggleCollapsed}
            title={rightPanel.collapsed ? 'Show properties panel' : 'Hide properties panel'}
            className={`absolute top-1/2 -translate-y-1/2 z-10 flex items-center justify-center w-4 h-10 rounded-l bg-slate-800/90 border border-r-0 border-slate-700/50 text-slate-400 hover:text-amber-400 hover:bg-slate-800 transition-colors ${
              rightPanel.collapsed ? 'right-0' : '-left-4'
            }`}
          >
            {rightPanel.collapsed ? <PanelRightOpen size={12} /> : <PanelRightClose size={12} />}
          </button>

          {!rightPanel.collapsed && (
            <div
              {...rightPanel.dragHandleProps}
              className="absolute top-0 left-0 h-full w-1.5 cursor-col-resize group flex items-center justify-center touch-none z-10"
            >
              <div className="w-px h-full bg-transparent group-hover:bg-amber-400/50 transition-colors" />
              <GripVertical size={10} className="absolute text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          )}

          {!rightPanel.collapsed && (
          <div className="h-full overflow-y-auto">
          <PropertyPanel
            selectedComponents={selectedComponents}
            selectedWires={selectedWires}
            onUpdateProperty={handleUpdateProperty}
            onRename={handleRename}
            onToggleSwitch={handleToggleSwitch}
            onDelete={handleDelete}
            onRotate={handleRotate}
            onDuplicate={handleDuplicate}
            onSetWireColor={handleSetWireColor}
            onSetWireNetLabel={handleSetWireNetLabel}
            onCleanWireRouting={handleCleanWireRouting}
          />
          </div>
          )}
        </div>
      </div>

      {/* Status bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-900/80 border-t border-slate-700/50">
        <div className="flex items-center gap-3">
          <StatusDot color={simRunning ? 'green' : 'amber'} text={simRunning ? 'Simulating' : 'Paused'} />
          <span className="text-[10px] text-slate-500 font-mono">
            {selectedTool === 'select' && 'Click to select • Drag to move'}
            {selectedTool === 'pan' && 'Drag to pan the canvas'}
            {selectedTool === 'wire' && 'Click two terminals to connect'}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Lightbulb size={12} className="text-amber-400" />
          <span className="text-[10px] text-slate-400 font-mono">
            Drag components from palette • Click terminals to wire
          </span>
        </div>
      </div>
    </div>
  );
});

ElectricalLab.displayName = 'ElectricalLab';

const ToolbarButton: React.FC<{
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  disabled?: boolean;
  onClick: () => void;
}> = ({ icon, label, active, disabled, onClick }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    title={label}
    className={`p-1.5 rounded transition-all ${
      active
        ? 'bg-amber-500/20 text-amber-400'
        : disabled
          ? 'text-slate-600 cursor-not-allowed'
          : 'text-slate-400 hover:bg-slate-700 hover:text-slate-200'
    }`}
  >
    {icon}
  </button>
);

const StatusDot: React.FC<{ color: string; text: string }> = ({ color, text }) => (
  <div className="flex items-center gap-1.5">
    <span className={`w-2 h-2 rounded-full ${
      color === 'green' ? 'bg-green-500' : color === 'amber' ? 'bg-amber-500' : 'bg-red-500'
    }`} />
    <span className="text-[10px] text-slate-400 font-mono">{text}</span>
  </div>
);

const HelpSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="border-b border-slate-700/50 pb-3 last:border-0">
    <h3 className="text-amber-400 font-mono text-xs mb-2 uppercase tracking-wider">{title}</h3>
    <div className="space-y-1">{children}</div>
  </div>
);

const HelpItem: React.FC<{ shortcut?: string; desc: string }> = ({ shortcut, desc }) => (
  <div className="flex items-start gap-2">
    {shortcut && (
      <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-[10px] font-mono text-amber-400 flex-shrink-0 min-w-[3rem] text-center">
        {shortcut}
      </kbd>
    )}
    <span className="text-slate-400">{desc}</span>
  </div>
);

export default ElectricalLab;
