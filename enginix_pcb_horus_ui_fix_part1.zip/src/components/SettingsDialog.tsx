import React, { useEffect, useState } from 'react';
import {
  AI_PROVIDERS,
  DEFAULT_PROVIDER_CONFIG,
  getProviderConfig,
  setProviderConfig,
  clearProviderConfig,
} from '../lib/aiProviderSettings';
import type { AIProviderConfig, AIProviderId } from '../lib/aiProviderSettings';
import { AIConfiguration } from '../horus/core/AIConfiguration';
import { GeminiClient } from '../horus/provider/GeminiClient';
import { GeminiProvider } from '../horus/provider/GeminiProvider';

interface SettingsDialogProps {
  open: boolean;
  onClose: () => void;
}

/** Connection status shown for the currently selected provider. */
type ConnectionStatus = 'connected' | 'disconnected' | 'invalid_api_key' | 'network_error' | 'provider_error';

const STATUS_DISPLAY: Record<ConnectionStatus, { icon: string; label: string; className: string }> = {
  connected: { icon: '✓', label: 'Connected', className: 'text-emerald-400' },
  disconnected: { icon: '○', label: 'Disconnected', className: 'text-slate-400' },
  invalid_api_key: { icon: '✗', label: 'Invalid API Key', className: 'text-red-400' },
  network_error: { icon: '✗', label: 'Network Error', className: 'text-red-400' },
  provider_error: { icon: '✗', label: 'Provider Error', className: 'text-red-400' },
};

// HORUS Gemini connection test wiring. Stateless besides AIConfiguration's
// in-memory store, so a single instance per module is fine — it just
// mirrors whatever API key was last pushed into it below.
const horusAIConfiguration = new AIConfiguration();
const horusGeminiProvider = new GeminiProvider(new GeminiClient(), horusAIConfiguration);

type TestState =
  | { phase: 'idle' }
  | { phase: 'testing' }
  | { phase: 'done'; status: ConnectionStatus };

/**
 * Settings dialog. Multi-provider AI configuration panel: pick a provider,
 * configure its API key / model / temperature / max tokens, and
 * save/test/reset that provider's config independently of the others.
 *
 * "Test Connection" runs a real HORUS connection test for Gemini (via
 * `GeminiProvider.testConnection()`, a lightweight, no-prompt reachability/
 * credential check against Gemini's API — see that file). Every other
 * provider still keeps the old presence-only stub check (does an API key
 * exist?) until its HORUS adapter exists.
 */
function SettingsDialog({ open, onClose }: SettingsDialogProps) {
  const [selectedProvider, setSelectedProvider] = useState<AIProviderId>('gemini');
  const [config, setConfig] = useState<AIProviderConfig>(DEFAULT_PROVIDER_CONFIG);
  const [testState, setTestState] = useState<TestState>({ phase: 'idle' });

  // Load the saved config for the selected provider whenever the dialog
  // opens, or the user switches providers.
  useEffect(() => {
    if (open) {
      setConfig(getProviderConfig(selectedProvider));
      setTestState({ phase: 'idle' });
    }
  }, [open, selectedProvider]);

  if (!open) return null;

  const handleClose = () => {
    onClose();
  };

  // Reset any stale test result whenever a field changes.
  const updateConfig = (patch: Partial<AIProviderConfig>) => {
    setConfig((prev) => ({ ...prev, ...patch }));
    if (testState.phase !== 'idle') {
      setTestState({ phase: 'idle' });
    }
  };

  const handleSave = () => {
    setProviderConfig(selectedProvider, config);
  };

  const handleTestConnection = async () => {
    setTestState({ phase: 'testing' });

    // Only Gemini has a real HORUS connection test wired up so far (see
    // `horus/provider/GeminiProvider.ts`). Other providers keep the old
    // presence-only stub check until their adapters exist.
    if (selectedProvider !== 'gemini') {
      await new Promise((resolve) => setTimeout(resolve, 400));
      const status: ConnectionStatus = config.apiKey.trim() ? 'connected' : 'disconnected';
      setTestState({ phase: 'done', status });
      return;
    }

    // AIConfiguration is the single source of truth GeminiProvider reads
    // the API key from — push the currently entered (not necessarily
    // saved) key into it before testing.
    horusAIConfiguration.setProviderConfiguration('gemini', { apiKey: config.apiKey });
    const result = await horusGeminiProvider.testConnection();

    let status: ConnectionStatus;
    if (result.ok) {
      status = 'connected';
    } else if (result.error.code === 'network_error') {
      status = 'network_error';
    } else if (result.error.code === 'missing_credentials' || result.error.code === 'invalid_credentials') {
      status = 'invalid_api_key';
    } else {
      status = 'provider_error';
    }
    setTestState({ phase: 'done', status });
  };

  const handleReset = () => {
    clearProviderConfig(selectedProvider);
    setConfig({ ...DEFAULT_PROVIDER_CONFIG });
    setTestState({ phase: 'idle' });
  };

  const selectedLabel = AI_PROVIDERS.find((p) => p.id === selectedProvider)?.label ?? selectedProvider;

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-lg p-8 max-w-md w-full relative">
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 text-slate-500 hover:text-slate-300"
        >
          ✕
        </button>

        <h3 className="text-lg font-bold text-slate-100 mb-1">Settings</h3>

        <div className="mt-6">
          <h4 className="text-xs font-mono text-amber-400 uppercase tracking-wider mb-3">
            AI Provider
          </h4>

          <label htmlFor="ai-provider-select" className="block text-xs font-mono text-slate-400 mb-1.5">
            Provider
          </label>
          <select
            id="ai-provider-select"
            value={selectedProvider}
            onChange={(e) => setSelectedProvider(e.target.value as AIProviderId)}
            className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-slate-200 focus:border-amber-400 outline-none"
          >
            {AI_PROVIDERS.map((provider) => (
              <option key={provider.id} value={provider.id}>
                {provider.label}
              </option>
            ))}
          </select>

          <h4 className="text-xs font-mono text-amber-400 uppercase tracking-wider mb-3 mt-5">
            {selectedLabel} Configuration
          </h4>

          <div className="space-y-3">
            <div>
              <label htmlFor="provider-api-key" className="block text-xs font-mono text-slate-400 mb-1.5">
                API Key
              </label>
              <input
                id="provider-api-key"
                type="password"
                value={config.apiKey}
                onChange={(e) => updateConfig({ apiKey: e.target.value })}
                placeholder="Enter API key…"
                autoComplete="off"
                className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-slate-200 focus:border-amber-400 outline-none"
              />
            </div>

            <div>
              <label htmlFor="provider-model" className="block text-xs font-mono text-slate-400 mb-1.5">
                Model
              </label>
              <input
                id="provider-model"
                type="text"
                value={config.model}
                onChange={(e) => updateConfig({ model: e.target.value })}
                placeholder="Model name…"
                autoComplete="off"
                className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-slate-200 focus:border-amber-400 outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="provider-temperature" className="block text-xs font-mono text-slate-400 mb-1.5">
                  Temperature
                </label>
                <input
                  id="provider-temperature"
                  type="number"
                  min={0}
                  max={2}
                  step={0.1}
                  value={config.temperature}
                  onChange={(e) => updateConfig({ temperature: Number(e.target.value) })}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-slate-200 focus:border-amber-400 outline-none"
                />
              </div>

              <div>
                <label htmlFor="provider-max-tokens" className="block text-xs font-mono text-slate-400 mb-1.5">
                  Max Tokens
                </label>
                <input
                  id="provider-max-tokens"
                  type="number"
                  min={1}
                  step={1}
                  value={config.maxTokens}
                  onChange={(e) => updateConfig({ maxTokens: Number(e.target.value) })}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-slate-200 focus:border-amber-400 outline-none"
                />
              </div>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <button
              onClick={handleTestConnection}
              disabled={testState.phase === 'testing'}
              className="px-3 py-1.5 border border-slate-600 text-slate-300 text-xs font-bold font-mono rounded hover:border-amber-400 hover:text-amber-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {testState.phase === 'testing' ? 'Testing…' : 'Test Connection'}
            </button>

            <span
              className={`text-xs font-mono ${
                testState.phase === 'done'
                  ? STATUS_DISPLAY[testState.status].className
                  : STATUS_DISPLAY.disconnected.className
              }`}
            >
              {testState.phase === 'done'
                ? `${STATUS_DISPLAY[testState.status].icon} ${STATUS_DISPLAY[testState.status].label}`
                : `${STATUS_DISPLAY.disconnected.icon} ${STATUS_DISPLAY.disconnected.label}`}
            </span>
          </div>
        </div>

        <div className="flex justify-end gap-3 mt-8">
          <button
            onClick={handleReset}
            className="px-4 py-2 border border-slate-600 text-slate-300 text-xs font-bold font-mono rounded hover:border-slate-500 transition-colors"
          >
            Reset
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-amber-500 text-slate-900 text-xs font-bold font-mono rounded hover:bg-amber-400 transition-colors"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

export default SettingsDialog;
