/**
 * CodeEditor - Monaco Editor wrapper for the Coding workspace.
 *
 * Thin, self-contained wrapper around @monaco-editor/react. Kept separate
 * from CodingLab.tsx so the editor's own concerns (theme, markers, toolbar
 * actions like Go To Line / minimap toggle) don't get tangled up with the
 * Arduino runtime wiring in CodingLab. CodingLab still owns the `code`
 * string itself (via value/onChange) exactly as it did with the previous
 * plain <textarea> - nothing about that contract changed, so nothing
 * downstream (compile-on-Run, insertCode imperative handle, etc.) needed
 * to change either.
 */

import React, { forwardRef, useCallback, useEffect, useImperativeHandle, useRef, useState } from 'react';
import Editor, { type OnMount } from '@monaco-editor/react';
import type { editor as MonacoEditorNS } from 'monaco-editor';
import { Map, Locate } from 'lucide-react';
import type { Diagnostic } from '../arduino/types';

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  /** Compile/runtime diagnostics to surface as inline squiggles + the gutter. */
  diagnostics?: Diagnostic[];
  /** Monaco's built-in language id (e.g. 'cpp', 'python', 'java', 'javascript').
   * Drives syntax highlighting and that language's built-in auto-completion
   * suggestions. Arduino sketches use 'cpp' - same as Standard C++ - since
   * Arduino sketches are C++; Monaco's built-in 'cpp' grammar covers the
   * standard keywords, string/char literals, comments, and preprocessor
   * directives (#include) sketches use. Arduino-specific identifiers
   * (pinMode, HIGH, Servo, etc.) aren't reserved words in real C++ either -
   * Monaco (and every other standard C++ editor) highlights those as plain
   * identifiers/functions, matching how they'd render in, say, VS Code's
   * own C/C++ extension. Defaults to 'cpp' for backward compatibility with
   * any existing call site that doesn't pass one. */
  language?: string;
}

export interface CodeEditorHandle {
  gotoLine: () => void;
  toggleMinimap: () => void;
  /** Moves the cursor to and scrolls a specific line/column into view (used
   * by the diagnostics list below the editor: clicking an error/warning
   * jumps straight to it). Never throws — a no-op if the editor isn't
   * mounted yet or the line is out of range. */
  revealLine: (line: number, column?: number) => void;
}

const CodeEditor = forwardRef<CodeEditorHandle, CodeEditorProps>(({ value, onChange, diagnostics = [], language = 'cpp' }, ref) => {
  const editorRef = useRef<MonacoEditorNS.IStandaloneCodeEditor | null>(null);
  const monacoRef = useRef<typeof import('monaco-editor') | null>(null);
  const [minimapEnabled, setMinimapEnabled] = useState(false);

  const handleMount: OnMount = useCallback((editorInstance, monacoInstance) => {
    editorRef.current = editorInstance;
    monacoRef.current = monacoInstance;

    // --- Paste isolation --------------------------------------------------
    // Monaco pastes by listening for the browser's native 'paste' ClipboardEvent
    // on its own hidden <textarea> (see monaco-editor's textAreaInput.js) - that
    // native event only fires as the textarea's *default action* for a Ctrl+V/
    // Cmd+V keydown, and a browser cancels that default action entirely the
    // moment ANY handler in the keydown's dispatch chain calls
    // event.preventDefault() on it - even a handler on `window`, even one that
    // runs after Monaco's own (correctly) sees and ignores the keystroke.
    //
    // The Simulator and PCB engines each register their own Ctrl+V/Cmd+V
    // shortcut ("paste copied component") via `window.addEventListener('keydown', ...)`,
    // and this app keeps every lab tab mounted (just hidden) instead of
    // unmounting the inactive ones - so those listeners stay live on `window`
    // for the whole session, including while working in this tab. They already
    // guard against real text-input targets, but that guard is the only thing
    // standing between "typing works" and "paste does nothing": nothing about
    // this editor's own DOM should ever depend on another module's target-type
    // check to keep working.
    //
    // Fixed here, in the Coding page only: once Monaco's own inputarea has
    // handled the keydown (this listener sits on an *ancestor* of that
    // textarea, so it only ever runs after Monaco's own target-phase
    // handling), stop the paste chord from bubbling any further. That's the
    // only thing this does - it never calls preventDefault itself, so the
    // browser still performs its native default action (dispatching the
    // 'paste' event Monaco listens for) exactly as it would with no other
    // listeners on the page at all; it just can no longer be cancelled by
    // anything outside the editor. Right-click -> Paste and mobile
    // long-press -> Paste don't go through 'keydown' at all - they trigger
    // that same native 'paste' event directly - so they're unaffected by (and
    // unprotected-by-need-of) this listener.
    const domNode = editorInstance.getDomNode();
    if (domNode) {
      const isolatePasteChord = (e: KeyboardEvent) => {
        const isPasteChord = (e.ctrlKey || e.metaKey) && !e.altKey && e.key.toLowerCase() === 'v';
        if (isPasteChord) e.stopPropagation();
      };
      domNode.addEventListener('keydown', isolatePasteChord);
      editorInstance.onDidDispose(() => domNode.removeEventListener('keydown', isolatePasteChord));
    }
  }, []);

  // Push compile/runtime diagnostics into Monaco's marker system so errors
  // and warnings show up as the usual red/yellow squiggles + gutter dots +
  // Problems-style hover tooltips, on top of the existing text list already
  // rendered below the editor in CodingLab (that list is untouched).
  useEffect(() => {
    const monacoInstance = monacoRef.current;
    const editorInstance = editorRef.current;
    if (!monacoInstance || !editorInstance) return;
    const model = editorInstance.getModel();
    if (!model) return;
    const markers: MonacoEditorNS.IMarkerData[] = diagnostics.map(d => ({
      startLineNumber: Math.max(1, d.line),
      startColumn: Math.max(1, d.column),
      endLineNumber: Math.max(1, d.line),
      endColumn: Math.max(1, d.column) + 1,
      message: d.message,
      severity: d.severity === 'error'
        ? monacoInstance.MarkerSeverity.Error
        : monacoInstance.MarkerSeverity.Warning,
    }));
    monacoInstance.editor.setModelMarkers(model, 'arduino-coding-core', markers);
  }, [diagnostics]);

  const gotoLine = useCallback(() => {
    editorRef.current?.getAction('editor.action.gotoLine')?.run();
    editorRef.current?.focus();
  }, []);

  const toggleMinimap = useCallback(() => {
    setMinimapEnabled(prev => {
      const next = !prev;
      editorRef.current?.updateOptions({ minimap: { enabled: next } });
      return next;
    });
  }, []);

  const revealLine = useCallback((line: number, column: number = 1) => {
    // Defensive: this is reachable from a diagnostics-list click at any
    // point, including before the editor has mounted or with a stale line
    // number from a previous compile - never let it throw and break the tab.
    try {
      const editorInstance = editorRef.current;
      if (!editorInstance) return;
      const model = editorInstance.getModel();
      const lineCount = model ? model.getLineCount() : 1;
      const safeLine = Math.min(Math.max(1, Math.floor(line) || 1), Math.max(1, lineCount));
      const safeColumn = Math.max(1, Math.floor(column) || 1);
      editorInstance.revealLineInCenter(safeLine);
      editorInstance.setPosition({ lineNumber: safeLine, column: safeColumn });
      editorInstance.focus();
    } catch {
      // never let a jump-to-line click crash the editor
    }
  }, []);

  useImperativeHandle(ref, () => ({ gotoLine, toggleMinimap, revealLine }), [gotoLine, toggleMinimap, revealLine]);

  return (
    <div className="flex-1 min-h-[200px] flex flex-col rounded-md overflow-hidden border border-slate-700 focus-within:border-amber-500">
      <div className="flex items-center justify-end gap-1 bg-slate-900 border-b border-slate-700 px-1.5 py-1">
        <button
          type="button"
          onClick={toggleMinimap}
          title="Toggle minimap"
          aria-pressed={minimapEnabled}
          className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] ${
            minimapEnabled ? 'bg-slate-700 text-amber-400' : 'bg-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Map size={11} /> Minimap
        </button>
        <button
          type="button"
          onClick={gotoLine}
          title="Go to line (Ctrl+G)"
          className="flex items-center gap-1 px-2 py-0.5 rounded text-[11px] bg-slate-800 text-slate-400 hover:text-slate-200"
        >
          <Locate size={11} /> Go to line
        </button>
      </div>
      <div className="flex-1 min-h-[180px]">
        <Editor
          language={language}
          theme="vs-dark"
          value={value}
          onChange={v => onChange(v ?? '')}
          onMount={handleMount}
          options={{
            fontSize: 13,
            fontFamily: "'JetBrains Mono', ui-monospace, monospace",
            minimap: { enabled: minimapEnabled },
            lineNumbers: 'on',
            folding: true,
            autoIndent: 'full',
            autoClosingBrackets: 'always',
            autoClosingQuotes: 'always',
            matchBrackets: 'always',
            bracketPairColorization: { enabled: true },
            renderWhitespace: 'selection',
            scrollBeyondLastLine: false,
            smoothScrolling: true,
            wordWrap: 'off',
            tabSize: 2,
            insertSpaces: true,
            multiCursorModifier: 'alt',
            find: { addExtraSpaceOnTop: false },
            automaticLayout: true,
          }}
        />
      </div>
    </div>
  );
});

CodeEditor.displayName = 'CodeEditor';

export default CodeEditor;
