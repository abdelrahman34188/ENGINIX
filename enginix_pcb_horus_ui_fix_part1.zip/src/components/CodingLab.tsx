/**
 * CodingLab - Arduino Coding tab for the Electrical Lab
 *
 * Hosts the sketch editor and connects the Arduino Coding Core
 * (ArduinoRuntime, see /src/arduino) to whatever Arduino/Mega/Nano board
 * component is currently placed on the Circuit Simulator canvas, via
 * CircuitPinIO. Everything simulator-side (rendering, the electrical
 * solve, component visuals) is untouched - this tab only drives pin state
 * on the board component; CircuitEditor's own per-frame loop picks up those
 * changes and reflects them everywhere else (LEDs, motors, servos, etc.)
 * automatically.
 */

import React, {
  forwardRef, useImperativeHandle, useEffect, useRef, useState, useCallback, useMemo,
} from 'react';
import { Wrench, Play, Square, RotateCcw, CheckCircle2, XCircle, Cpu, Plug, PlugZap, Download, FileCode, FilePlus, FolderOpen, Save, PencilLine, Trash2, X, Copy, Pause, Clock, ArrowDownToLine } from 'lucide-react';
import type { CircuitEditor } from '../circuit/CircuitEditor';
import type { Component } from '../circuit/types';
import { buildPinMapping, type PinMappingEntry } from '../circuit/pinMapping';
import { buildComponentMapping, type ComponentMapEntry } from '../circuit/componentMapping';
import { buildPinLiveStates, type PinLiveState } from '../circuit/pinState';
import { ArduinoRuntime } from '../arduino/ArduinoRuntime';
import { CircuitPinIO, type BoardLike } from '../arduino/CircuitPinIO';
import type { Diagnostic, RuntimeStatus, SerialEntry } from '../arduino/types';
import { runSimulatorCompatibilitySuite } from '../arduino/testing/simulatorCompatibility';
import CodeEditor, { type CodeEditorHandle } from './CodeEditor';
import BottomDock, { type DockTab } from './BottomDock';
import { LANGUAGE_DEFS, LANGUAGE_ORDER, type Language } from './codeTemplates';
import {
  type CodeFile,
  getCodeFiles,
  getCodeFile,
  createCodeFile,
  saveCodeFile,
  renameCodeFile,
  deleteCodeFile,
  isNameTaken,
  getCodeSession,
  saveCodeSession,
} from '../lib/codeFileStorage';

export type { Language };

interface CodingLabProps {
  /** Returns the live CircuitEditor instance from the Circuit Simulator tab, if mounted. */
  getEditor: () => CircuitEditor | null;
  /** Whether this tab is currently the visible one. */
  active: boolean;
}

export interface CodingLabHandle {
  insertCode: (language: Language, code: string) => void;
}

/**
 * A single open editor tab. `fileId` is null for a file that has never been
 * saved yet (a fresh "New File"); once Save/Save As succeeds it's linked to
 * a persisted CodeFile. `dirty` tracks unsaved edits since the last save.
 */
interface Tab {
  tabId: string;
  fileId: string | null;
  name: string;
  code: string;
  dirty: boolean;
}

function makeUntitledTab(language: Language): Tab {
  const def = LANGUAGE_DEFS[language];
  return {
    tabId: `untitled-${language}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    fileId: null,
    name: `untitled${def.extension}`,
    code: def.template,
    dirty: false,
  };
}

/** Rebuilds tabs per language from remembered saved-file ids in the session
 * (see codeFileStorage's "remember opened files"). Falls back to a fresh
 * untitled tab for any language with nothing to restore. Each language's
 * tabs only ever come from files of that same language, which is what
 * keeps Arduino sketches independent from the other four languages. */
function buildInitialTabs(): Record<Language, Tab[]> {
  const session = getCodeSession();
  const result = {} as Record<Language, Tab[]>;
  for (const lang of LANGUAGE_ORDER) {
    const ids = session.openFileIds[lang] ?? [];
    const restored: Tab[] = [];
    for (const id of ids) {
      const file = getCodeFile(id);
      if (file) restored.push({ tabId: file.id, fileId: file.id, name: file.name, code: file.code, dirty: false });
    }
    result[lang] = restored.length > 0 ? restored : [makeUntitledTab(lang)];
  }
  return result;
}

function buildInitialActiveTabId(tabs: Record<Language, Tab[]>): Record<Language, string> {
  const session = getCodeSession();
  const result = {} as Record<Language, string>;
  for (const lang of LANGUAGE_ORDER) {
    const wantedFileId = session.activeFileId[lang];
    const found = tabs[lang].find(t => t.fileId === wantedFileId);
    result[lang] = (found ?? tabs[lang][0]).tabId;
  }
  return result;
}

/** Joins serial entries into the exact text Serial.print/println would have
 * produced (print has no separator, println's own '\n' is embedded in its
 * entry's text) - preserves that concatenation regardless of how many
 * separate print() calls built up one visual line. When timestamps are on,
 * a "[Nms] " prefix is inserted only at the start of each line (tracked via
 * whether the previous entry ended in '\n'), not per print() call. */
function buildSerialText(entries: SerialEntry[], showTimestamps: boolean): string {
  if (!showTimestamps) return entries.map(e => e.text).join('');
  let out = '';
  let atLineStart = true;
  for (const e of entries) {
    if (atLineStart) out += `[${e.atMillis}ms] `;
    out += e.text;
    atLineStart = e.text.endsWith('\n');
  }
  return out;
}

const BOARD_TYPES = new Set(['arduino', 'arduinoMega', 'arduinoNano']);

/** Friendly names for the board selector, falling back to the raw type. */
const BOARD_TYPE_NAMES: Record<string, string> = {
  arduino: 'Arduino Uno',
  arduinoMega: 'Arduino Mega',
  arduinoNano: 'Arduino Nano',
};

const CodingLab = forwardRef<CodingLabHandle, CodingLabProps>(({ getEditor, active }, ref) => {
  const [language, setLanguage] = useState<Language>('arduino');
  // Every language keeps its own independent set of open file tabs - same
  // guarantee the old single-buffer-per-language state gave, just extended
  // to multiple files per language instead of exactly one.
  const [tabsByLanguage, setTabsByLanguage] = useState<Record<Language, Tab[]>>(buildInitialTabs);
  const [activeTabId, setActiveTabId] = useState<Record<Language, string>>(() => buildInitialActiveTabId(tabsByLanguage));
  const [autosave, setAutosave] = useState<boolean>(() => getCodeSession().autosave);
  const [showOpenDialog, setShowOpenDialog] = useState(false);
  const activeTabIdRef = useRef(activeTabId);
  useEffect(() => { activeTabIdRef.current = activeTabId; }, [activeTabId]);

  const activeTabs = tabsByLanguage[language];
  const activeTab = activeTabs.find(t => t.tabId === activeTabId[language]) ?? activeTabs[0];
  // The buffer for whichever tab is currently active. Arduino's Run/Compile
  // flow below reads this exactly as it read the old single `code` state -
  // when `language === 'arduino'` (the default), this *is* the active
  // Arduino sketch's buffer, so nothing about Arduino execution changed.
  const code = activeTab.code;
  const setCode = useCallback((next: string) => {
    setTabsByLanguage(prev => ({
      ...prev,
      [language]: prev[language].map(t => t.tabId === activeTab.tabId ? { ...t, code: next, dirty: true } : t),
    }));
  }, [language, activeTab.tabId]);
  const [status, setStatus] = useState<RuntimeStatus>('idle');
  const [diagnostics, setDiagnostics] = useState<Diagnostic[]>([]);
  // Serial Monitor state. `serialRaw` mirrors the interpreter's own capped
  // log (live output, handles large output smoothly since it's bounded by
  // ArduinoRuntime's serialBufferLimit and only replaces state when new
  // data actually arrived). `clearedSeq` implements Clear without touching
  // the interpreter's internal log - see buildSerialText/SerialEntry.seq.
  const [serialRaw, setSerialRaw] = useState<SerialEntry[]>([]);
  const [clearedSeq, setClearedSeq] = useState(0);
  const [serialPaused, setSerialPaused] = useState(false);
  const [serialAutoScroll, setSerialAutoScroll] = useState(true);
  const [serialShowTimestamps, setSerialShowTimestamps] = useState(false);
  const [serialCopied, setSerialCopied] = useState(false);
  const serialRawRef = useRef<SerialEntry[]>([]);
  const serialScrollRef = useRef<HTMLDivElement>(null);
  const [boardLabel, setBoardLabel] = useState<string | null>(null);
  // All Uno/Nano/Mega boards currently on the canvas, and which one (if any)
  // is selected as the Coding tab's target. Auto-detection logic:
  //   0 boards  -> selectedBoardId null, "No board detected on canvas"
  //   1 board   -> auto-selected, no picker shown
  //   2+ boards -> a picker is shown; selection persists across updates as
  //                long as that board still exists, otherwise defaults to
  //                the first board found.
  const [boardsOnCanvas, setBoardsOnCanvas] = useState<Component[]>([]);
  const [selectedBoardId, setSelectedBoardId] = useState<number | null>(null);
  // Live pin map for the currently-selected board — recomputed alongside
  // board detection (same instant listener + safety-net poll), since it's
  // just as cheap a read and needs to react to the same wiring changes.
  const [pinMapping, setPinMapping] = useState<PinMappingEntry[]>([]);
  // Live component map: which actual simulator components are wired to
  // each of the selected board's pins. Recomputed alongside pinMapping.
  const [componentMapping, setComponentMapping] = useState<ComponentMapEntry[]>([]);
  // Live per-pin values (HIGH/LOW, PWM duty, analog reading) for the Pin
  // Inspector. Refreshed on its own lightweight loop (see effect below),
  // independent of whether a sketch is currently running, since the
  // simulator itself keeps solving/updating pin state every frame
  // regardless of Run/Stop.
  const [pinLiveStates, setPinLiveStates] = useState<PinLiveState[]>([]);
  const [testResults, setTestResults] = useState<Array<{ name: string; passed: boolean; message?: string }> | null>(null);
  // Compiler summary shown above the diagnostics list — success/warning
  // message after a compile, cleared on Reset or once a new compile starts.
  const [compileMessage, setCompileMessage] = useState<{ text: string; kind: 'success' | 'warning' } | null>(null);

  const codeEditorRef = useRef<CodeEditorHandle>(null);

  const runtimeRef = useRef<ArduinoRuntime | null>(null);
  const pinIORef = useRef<CircuitPinIO | null>(null);
  const boardIdRef = useRef<number | null>(null);
  const rafRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  const inspectorRafRef = useRef<number>(0);
  const inspectorLastRefreshRef = useRef<number>(0);

  useImperativeHandle(ref, () => ({
    insertCode: (insertedLanguage: Language, insertedCode: string) => {
      setLanguage(insertedLanguage);
      setTabsByLanguage(prev => {
        const tabs = prev[insertedLanguage];
        const activeId = activeTabIdRef.current[insertedLanguage];
        return {
          ...prev,
          [insertedLanguage]: tabs.map(t => t.tabId === activeId ? { ...t, code: insertedCode, dirty: true } : t),
        };
      });
    },
  }), []);

  const findBoard = useCallback((): BoardLike | undefined => {
    const editor = getEditor();
    if (!editor) return undefined;
    if (boardIdRef.current !== null) {
      const held = editor.state.components.find(c => c.id === boardIdRef.current);
      if (held) return held as unknown as BoardLike;
    }
    const found = editor.state.components.find(c => BOARD_TYPES.has(c.type));
    if (found) boardIdRef.current = found.id;
    return found as unknown as BoardLike | undefined;
  }, [getEditor]);

  // Re-scan the canvas for boards and update auto-detection/selector state.
  // Called both on an instant state-change notification (component
  // added/removed/moved) and on a lightweight interval as a safety net, so
  // detection stays correct even if a future change bypasses notifyStateChange.
  const rescanBoards = useCallback(() => {
    const editor = getEditor();
    const boards = editor?.state.components.filter(c => BOARD_TYPES.has(c.type)) ?? [];
    setBoardsOnCanvas(boards);

    setSelectedBoardId(prevSelected => {
      let nextId: number | null;
      if (boards.length === 0) {
        nextId = null;
      } else if (boards.length === 1) {
        nextId = boards[0].id; // exactly one board: always auto-connect to it
      } else if (prevSelected !== null && boards.some(b => b.id === prevSelected)) {
        nextId = prevSelected; // keep the user's existing choice if it still exists
      } else {
        nextId = boards[0].id; // default pick until the user chooses via the selector
      }
      boardIdRef.current = nextId;
      const board = boards.find(b => b.id === nextId);
      setBoardLabel(board ? board.label || BOARD_TYPE_NAMES[board.type] || board.type : null);
      setPinMapping(board ? buildPinMapping(board, editor?.state.lastResult?.netTerminalCounts) : []);
      setComponentMapping(board ? buildComponentMapping(board, editor?.state.components ?? [], editor?.state.lastResult?.netTerminalCounts) : []);
      setPinLiveStates(board ? buildPinLiveStates(board) : []);
      return nextId;
    });
  }, [getEditor]);

  // Pin Inspector's own refresh: independent of the sketch-run loop below
  // (rafRef), so pin values stay live whether or not a sketch is currently
  // running - the simulator itself keeps re-solving every frame regardless.
  // Throttled to ~10Hz: plenty to look "live" to a human without adding
  // per-frame render churn (keeps the panel lightweight/non-intrusive).
  useEffect(() => {
    if (!active) return;
    const REFRESH_INTERVAL_MS = 100;
    const loop = (time: number) => {
      if (time - inspectorLastRefreshRef.current >= REFRESH_INTERVAL_MS) {
        inspectorLastRefreshRef.current = time;
        const editor = getEditor();
        const board = boardIdRef.current !== null
          ? editor?.state.components.find(c => c.id === boardIdRef.current)
          : undefined;
        setPinLiveStates(board ? buildPinLiveStates(board) : []);
      }
      inspectorRafRef.current = requestAnimationFrame(loop);
    };
    inspectorRafRef.current = requestAnimationFrame(loop);
    return () => {
      if (inspectorRafRef.current) cancelAnimationFrame(inspectorRafRef.current);
      inspectorRafRef.current = 0;
    };
  }, [active, getEditor]);

  // Instant updates: subscribe to the editor's state-change notifications
  // (fires on component add/remove/move/etc.) without touching the existing
  // single-slot onStateChange used elsewhere. Falls back to a short poll as
  // well, purely as a safety net in case the editor instance isn't available
  // yet when this effect first runs (e.g. tab mounted before the canvas).
  useEffect(() => {
    if (!active) return;
    rescanBoards();
    const editor = getEditor();
    const unsubscribe = editor?.addStateChangeListener(rescanBoards);
    const id = window.setInterval(rescanBoards, 1000);
    return () => {
      unsubscribe?.();
      window.clearInterval(id);
    };
  }, [active, getEditor, rescanBoards]);

  const stopLoop = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = 0;
  }, []);

  const refreshRuntimeUI = useCallback(() => {
    const rt = runtimeRef.current;
    if (!rt) return;
    setStatus(rt.getStatus());
    setDiagnostics(rt.getDiagnostics());
    if (!serialPaused) {
      const raw = rt.getSerialLog();
      const prev = serialRawRef.current;
      const lastPrevSeq = prev.length > 0 ? prev[prev.length - 1].seq : -1;
      const lastNewSeq = raw.length > 0 ? raw[raw.length - 1].seq : -1;
      // Only touch React state when the log actually changed (new entries,
      // or old ones trimmed off the front) - avoids a state update + render
      // every single animation frame when the sketch hasn't printed anything.
      if (raw.length !== prev.length || lastNewSeq !== lastPrevSeq) {
        const snapshot = raw.slice();
        serialRawRef.current = snapshot;
        setSerialRaw(snapshot);
      }
    }
  }, [serialPaused]);

  const handleStop = useCallback(() => {
    stopLoop();
    runtimeRef.current?.stop();
    setStatus(runtimeRef.current?.getStatus() ?? 'stopped');
  }, [stopLoop]);

  const handleRun = useCallback(() => {
    // Execution only ever exists for Arduino C++ (ArduinoRuntime only knows
    // how to compile/run Arduino sketches) - the other four languages are
    // editor-only (highlighting + auto completion + their own template).
    // The Run button itself is also disabled for non-Arduino languages
    // below, so this is a safety net, not the primary gate.
    if (language !== 'arduino') return;
    setCompileMessage(null);
    const board = findBoard();
    if (!board) {
      setDiagnostics([{ line: 1, column: 1, severity: 'error', message: 'No Arduino/Mega/Nano board found on the Circuit Simulator canvas. Place one and wire it up first.' }]);
      setStatus('error');
      return;
    }

    stopLoop();
    const rt = new ArduinoRuntime();
    let compiled;
    try {
      compiled = rt.compile(code);
    } catch (e) {
      // ArduinoRuntime.compile() is itself guarded and shouldn't throw, but
      // this is the top-level Run action, so it gets its own safety net too
      // - a compiler bug should surface as an error message, never a crash.
      setDiagnostics([{ line: 1, column: 1, severity: 'error', message: `Internal compiler error: ${(e as Error).message}` }]);
      setStatus('error');
      return;
    }
    setDiagnostics(compiled.errors);
    if (!compiled.success) {
      setStatus('error');
      return;
    }
    const warningCount = compiled.errors.filter(d => d.severity === 'warning').length;
    setCompileMessage(
      warningCount > 0
        ? { text: `Compiled with ${warningCount} warning${warningCount === 1 ? '' : 's'}.`, kind: 'warning' }
        : { text: 'Compiled successfully — no errors.', kind: 'success' }
    );

    const pinIO = new CircuitPinIO(
      () => findBoard(),
      () => {
        const editor = getEditor();
        if (!editor) return undefined;
        return { components: editor.state.components, netTerminalCounts: editor.state.lastResult?.netTerminalCounts, nodeVoltages: editor.state.lastResult?.nodeVoltages };
      },
    );
    rt.attachPinIO(pinIO);
    rt.start();
    runtimeRef.current = rt;
    pinIORef.current = pinIO;
    setStatus(rt.getStatus());
    serialRawRef.current = [];
    setSerialRaw([]);
    setClearedSeq(0);

    lastTimeRef.current = performance.now();
    const loop = (time: number) => {
      const dt = time - lastTimeRef.current;
      lastTimeRef.current = time;
      // Board component removed/undo mid-run: keep ticking (CircuitPinIO's
      // getBoard() is re-resolved every call, so it degrades to a harmless
      // no-op rather than crashing) so the user can re-place it and resume.
      rt.tick(Math.min(dt, 100)); // clamp huge dt spikes (tab backgrounded) so delay()-timed loops don't jump wildly
      refreshRuntimeUI();
      if (rt.getStatus() === 'running') {
        rafRef.current = requestAnimationFrame(loop);
      } else {
        stopLoop();
      }
    };
    rafRef.current = requestAnimationFrame(loop);
  }, [code, language, findBoard, stopLoop, refreshRuntimeUI]);

  const handleReset = useCallback(() => {
    stopLoop();
    runtimeRef.current?.reset();
    runtimeRef.current = null;
    pinIORef.current = null;
    setStatus('idle');
    setDiagnostics([]);
    serialRawRef.current = [];
    setSerialRaw([]);
    setClearedSeq(0);
    setCompileMessage(null);
  }, [stopLoop]);

  const handleSelfTest = useCallback(() => {
    setTestResults(runSimulatorCompatibilitySuite());
  }, []);

  // Clear only moves the "cleared up to here" marker (by seq, immune to the
  // underlying log array shifting once it hits its cap) - it never touches
  // the interpreter's own serial log, so Pause/Resume and a running sketch
  // are unaffected by clearing the view.
  const handleClearSerial = useCallback(() => {
    const raw = serialRawRef.current;
    setClearedSeq(raw.length > 0 ? raw[raw.length - 1].seq : 0);
  }, []);

  const handleCopySerial = useCallback(async () => {
    const text = buildSerialText(serialRawRef.current.filter(e => e.seq > clearedSeq), serialShowTimestamps);
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        // Fallback for environments without the async Clipboard API.
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setSerialCopied(true);
      window.setTimeout(() => setSerialCopied(false), 1500);
    } catch {
      // Copy is a nice-to-have - never let a clipboard failure disrupt the editor.
    }
  }, [clearedSeq, serialShowTimestamps]);

  // Clicking a diagnostic in the list below jumps the editor to that
  // line/column. Guarded so a stale or out-of-range line from a previous
  // compile can never crash the tab - CodeEditor.revealLine clamps and
  // no-ops safely on its own end too.
  const handleDiagnosticClick = useCallback((d: Diagnostic) => {
    try {
      codeEditorRef.current?.revealLine(d.line, d.column);
    } catch {
      // never let a jump-to-line click crash the editor
    }
  }, []);

  // Switching away from Arduino doesn't stop a sketch already running (the
  // running ArduinoRuntime instance is untouched - it keeps ticking against
  // the Arduino buffer regardless of which language is currently shown in
  // the editor) - it only clears the stale error/warning list left over
  // from the previous language's last compile, since those no longer apply
  // to whatever's now on screen.
  const handleLanguageChange = useCallback((next: Language) => {
    setLanguage(next);
    setDiagnostics([]);
    setCompileMessage(null);
  }, []);

  const handleDownload = useCallback(() => {
    const def = LANGUAGE_DEFS[language];
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeTab.name || `sketch${def.extension}`;
    a.click();
    URL.revokeObjectURL(url);
  }, [code, language, activeTab.name]);

  // --- File management (New/Open/Save/Save As/Rename/Delete/Close tab) ---

  const handleNewFile = useCallback(() => {
    const newTab = makeUntitledTab(language);
    setTabsByLanguage(prev => ({ ...prev, [language]: [...prev[language], newTab] }));
    setActiveTabId(prev => ({ ...prev, [language]: newTab.tabId }));
  }, [language]);

  const handleSaveAs = useCallback(() => {
    const def = LANGUAGE_DEFS[language];
    const suggested = activeTab.name.replace(new RegExp(`\\${def.extension}$`), '');
    const input = window.prompt(`Save ${def.label} file as:`, suggested || 'untitled');
    if (input === null) return;
    const trimmed = input.trim();
    if (!trimmed) return;
    const fileName = trimmed.endsWith(def.extension) ? trimmed : `${trimmed}${def.extension}`;

    if (isNameTaken(language, fileName, activeTab.fileId ?? undefined)) {
      if (!window.confirm(`A file named "${fileName}" already exists for ${def.label}. Overwrite it?`)) return;
      const existing = getCodeFiles(language).find(f => f.name === fileName);
      if (existing) {
        saveCodeFile(existing.id, activeTab.code);
        setTabsByLanguage(prev => ({
          ...prev,
          [language]: prev[language]
            .filter(t => t.fileId !== existing.id || t.tabId === activeTab.tabId) // drop any other tab already open on the file we're overwriting
            .map(t => t.tabId === activeTab.tabId ? { ...t, fileId: existing.id, name: fileName, dirty: false } : t),
        }));
        return;
      }
    }

    const file = createCodeFile(language, fileName, activeTab.code);
    setTabsByLanguage(prev => ({
      ...prev,
      [language]: prev[language].map(t => t.tabId === activeTab.tabId ? { ...t, fileId: file.id, name: file.name, dirty: false } : t),
    }));
  }, [language, activeTab]);

  const handleSave = useCallback(() => {
    if (!activeTab.fileId) {
      handleSaveAs();
      return;
    }
    saveCodeFile(activeTab.fileId, activeTab.code);
    setTabsByLanguage(prev => ({
      ...prev,
      [language]: prev[language].map(t => t.tabId === activeTab.tabId ? { ...t, dirty: false } : t),
    }));
  }, [activeTab, language, handleSaveAs]);

  const handleRenameFile = useCallback(() => {
    if (!activeTab.fileId) {
      handleSaveAs();
      return;
    }
    const def = LANGUAGE_DEFS[language];
    const suggested = activeTab.name.replace(new RegExp(`\\${def.extension}$`), '');
    const input = window.prompt('Rename file:', suggested);
    if (input === null) return;
    const trimmed = input.trim();
    if (!trimmed) return;
    const fileName = trimmed.endsWith(def.extension) ? trimmed : `${trimmed}${def.extension}`;
    if (isNameTaken(language, fileName, activeTab.fileId)) {
      window.alert(`A file named "${fileName}" already exists for ${def.label}.`);
      return;
    }
    renameCodeFile(activeTab.fileId, fileName);
    setTabsByLanguage(prev => ({
      ...prev,
      [language]: prev[language].map(t => t.fileId === activeTab.fileId ? { ...t, name: fileName } : t),
    }));
  }, [activeTab, language, handleSaveAs]);

  const handleCloseTab = useCallback((tabId: string) => {
    setTabsByLanguage(prev => {
      const tabs = prev[language];
      const tab = tabs.find(t => t.tabId === tabId);
      if (tab?.dirty && !window.confirm(`Discard unsaved changes in "${tab.name}"?`)) return prev;

      const remaining = tabs.filter(t => t.tabId !== tabId);
      const finalTabs = remaining.length > 0 ? remaining : [makeUntitledTab(language)];
      if (activeTabId[language] === tabId) {
        setActiveTabId(prev2 => ({ ...prev2, [language]: finalTabs[finalTabs.length - 1].tabId }));
      }
      return { ...prev, [language]: finalTabs };
    });
  }, [language, activeTabId]);

  const handleDeleteFile = useCallback(() => {
    if (!activeTab.fileId) {
      handleCloseTab(activeTab.tabId);
      return;
    }
    if (!window.confirm(`Delete "${activeTab.name}"? This cannot be undone.`)) return;
    deleteCodeFile(activeTab.fileId);
    setTabsByLanguage(prev => {
      const remaining = prev[language].filter(t => t.tabId !== activeTab.tabId);
      const finalTabs = remaining.length > 0 ? remaining : [makeUntitledTab(language)];
      setActiveTabId(p => ({ ...p, [language]: finalTabs[finalTabs.length - 1].tabId }));
      return { ...prev, [language]: finalTabs };
    });
  }, [activeTab, language, handleCloseTab]);

  const handleOpenFileSelect = useCallback((file: CodeFile) => {
    const lang = file.language as Language;
    setLanguage(lang);
    setTabsByLanguage(prev => {
      const tabs = prev[lang] ?? [];
      const existing = tabs.find(t => t.fileId === file.id);
      if (existing) {
        setActiveTabId(p => ({ ...p, [lang]: existing.tabId }));
        return prev;
      }
      const newTab: Tab = { tabId: file.id, fileId: file.id, name: file.name, code: file.code, dirty: false };
      setActiveTabId(p => ({ ...p, [lang]: newTab.tabId }));
      return { ...prev, [lang]: [...tabs, newTab] };
    });
    setShowOpenDialog(false);
  }, []);

  const handleDeleteFromDialog = useCallback((file: CodeFile) => {
    if (!window.confirm(`Delete "${file.name}"? This cannot be undone.`)) return;
    deleteCodeFile(file.id);
    const lang = file.language as Language;
    setTabsByLanguage(prev => {
      const remaining = prev[lang].filter(t => t.fileId !== file.id);
      const finalTabs = remaining.length > 0 ? remaining : [makeUntitledTab(lang)];
      if (!remaining.some(t => t.tabId === activeTabIdRef.current[lang])) {
        setActiveTabId(p => ({ ...p, [lang]: finalTabs[finalTabs.length - 1].tabId }));
      }
      return { ...prev, [lang]: finalTabs };
    });
  }, []);

  // Remember opened (saved) files + active tab + autosave setting, per
  // language, across reloads. Untitled/never-saved tabs aren't persisted
  // here since there's no file on disk yet to reopen them from.
  useEffect(() => {
    const openFileIds: Record<string, string[]> = {};
    const activeFileId: Record<string, string | null> = {};
    for (const lang of LANGUAGE_ORDER) {
      const savedTabs = tabsByLanguage[lang].filter(t => t.fileId);
      openFileIds[lang] = savedTabs.map(t => t.fileId as string);
      const active = tabsByLanguage[lang].find(t => t.tabId === activeTabId[lang]);
      activeFileId[lang] = active?.fileId ?? null;
    }
    saveCodeSession({ openFileIds, activeFileId, autosave });
  }, [tabsByLanguage, activeTabId, autosave]);

  // Autosave: debounced write-through to the active tab's saved file, only
  // once it's actually been saved at least once (Save/Save As gives it a
  // fileId) - a never-saved tab has nowhere to autosave to yet.
  useEffect(() => {
    if (!autosave || !activeTab.fileId || !activeTab.dirty) return;
    const fileId = activeTab.fileId;
    const tabId = activeTab.tabId;
    const lang = language;
    const pendingCode = activeTab.code;
    const timer = window.setTimeout(() => {
      saveCodeFile(fileId, pendingCode);
      setTabsByLanguage(prev => ({
        ...prev,
        [lang]: prev[lang].map(t => t.tabId === tabId ? { ...t, dirty: false } : t),
      }));
    }, 800);
    return () => window.clearTimeout(timer);
  }, [autosave, activeTab.fileId, activeTab.dirty, activeTab.code, activeTab.tabId, language]);

  useEffect(() => () => stopLoop(), [stopLoop]);

  const errorCount = diagnostics.filter(d => d.severity === 'error').length;
  const warningCount = diagnostics.filter(d => d.severity === 'warning').length;
  const currentLanguageDef = LANGUAGE_DEFS[language];

  const displayedSerialEntries = useMemo(
    () => serialRaw.filter(e => e.seq > clearedSeq),
    [serialRaw, clearedSeq]
  );
  const displayedSerialText = useMemo(
    () => buildSerialText(displayedSerialEntries, serialShowTimestamps),
    [displayedSerialEntries, serialShowTimestamps]
  );

  // Auto-scroll: only runs when new content actually rendered (and the
  // panel isn't paused, since paused content doesn't change), so it never
  // fights a user who's manually scrolled up to read older output while live.
  useEffect(() => {
    if (!serialAutoScroll || serialPaused) return;
    const el = serialScrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [displayedSerialText, serialAutoScroll, serialPaused]);

  const dockTabs = useMemo<DockTab[]>(() => {
    const list: DockTab[] = [];

    list.push({
      id: 'status',
      label: 'Status',
      badge: (errorCount + warningCount) > 0 ? errorCount + warningCount : undefined,
      badgeTone: errorCount > 0 ? 'rose' : warningCount > 0 ? 'amber' : 'neutral',
      content: (
        <div className="px-3.5 py-2.5 space-y-1 leading-relaxed font-mono text-xs">
          <div className="flex items-center gap-1 flex-wrap text-slate-400 pb-1">
            Status: <span className={status === 'error' ? 'text-rose-400' : status === 'running' ? 'text-emerald-400' : 'text-slate-300'}>{status}</span>
            {errorCount > 0 && <span className="text-rose-400">({errorCount} error{errorCount === 1 ? '' : 's'})</span>}
            {warningCount > 0 && <span className="text-amber-400">({warningCount} warning{warningCount === 1 ? '' : 's'})</span>}
          </div>
          {compileMessage && (
            <div className={`flex items-center gap-1.5 rounded px-1.5 py-1 -mx-1.5 ${compileMessage.kind === 'success' ? 'text-emerald-400' : 'text-amber-400'}`}>
              {compileMessage.kind === 'success' ? <CheckCircle2 size={12} className="shrink-0" /> : <XCircle size={12} className="shrink-0" />}
              <span className="break-words">{compileMessage.text}</span>
            </div>
          )}
          {diagnostics.map((d, i) => (
            <button
              key={i}
              type="button"
              onClick={() => handleDiagnosticClick(d)}
              title="Click to jump to this line"
              className={`block w-full text-left rounded px-1.5 py-1 -mx-1.5 break-words transition-colors duration-150 hover:bg-slate-900/70 hover:underline ${d.severity === 'error' ? 'text-rose-400' : 'text-amber-400'}`}
            >
              Line {d.line}: {d.message}
            </button>
          ))}
        </div>
      ),
    });

    list.push({
      id: 'serial-monitor',
      label: 'Serial Monitor',
      badge: serialPaused ? 'paused' : undefined,
      badgeTone: 'amber',
      headerRight: (
        <>
          <button
            type="button"
            onClick={() => setSerialShowTimestamps(v => !v)}
            title="Toggle timestamps"
            aria-pressed={serialShowTimestamps}
            className={`flex items-center gap-0.5 px-1.5 py-0.5 rounded transition-colors duration-150 ${serialShowTimestamps ? 'bg-slate-700 text-amber-400' : 'bg-slate-800 text-slate-400 hover:bg-slate-700/70 hover:text-slate-200'}`}
          >
            <Clock size={11} />
          </button>
          <button
            type="button"
            onClick={() => setSerialAutoScroll(v => !v)}
            title="Toggle auto-scroll"
            aria-pressed={serialAutoScroll}
            className={`flex items-center gap-0.5 px-1.5 py-0.5 rounded transition-colors duration-150 ${serialAutoScroll ? 'bg-slate-700 text-amber-400' : 'bg-slate-800 text-slate-400 hover:bg-slate-700/70 hover:text-slate-200'}`}
          >
            <ArrowDownToLine size={11} />
          </button>
          <button
            type="button"
            onClick={() => setSerialPaused(v => !v)}
            title={serialPaused ? 'Resume live output' : 'Pause live output'}
            aria-pressed={serialPaused}
            className={`flex items-center gap-0.5 px-1.5 py-0.5 rounded transition-colors duration-150 ${serialPaused ? 'bg-slate-700 text-amber-400' : 'bg-slate-800 text-slate-400 hover:bg-slate-700/70 hover:text-slate-200'}`}
          >
            {serialPaused ? <Play size={11} /> : <Pause size={11} />}
          </button>
          <button
            type="button"
            onClick={handleCopySerial}
            title="Copy output"
            className="flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 transition-colors duration-150 hover:bg-slate-700/70 hover:text-slate-200"
          >
            <Copy size={11} />{serialCopied ? ' Copied' : ''}
          </button>
          <button
            type="button"
            onClick={handleClearSerial}
            title="Clear output"
            className="flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 transition-colors duration-150 hover:bg-slate-700/70 hover:text-rose-400"
          >
            <Trash2 size={11} />
          </button>
        </>
      ),
      content: (
        <pre className="whitespace-pre-wrap break-words text-slate-200 font-mono px-3.5 py-2.5 leading-relaxed tracking-tight text-xs">
          {displayedSerialText || '(no output yet)'}
        </pre>
      ),
    });

    if (selectedBoardId !== null && pinMapping.length > 0) {
      const wired = pinMapping.filter(p => p.connected).length;
      list.push({
        id: 'pin-mapping',
        label: 'Pin Mapping',
        badge: `${wired}/${pinMapping.length}`,
        badgeTone: wired > 0 ? 'emerald' : 'neutral',
        content: (
          <div className="px-3.5 py-2.5 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-x-3 gap-y-1 leading-relaxed">
              {pinMapping.map(p => (
                <div
                  key={p.label}
                  className={`flex items-center gap-1 min-w-0 rounded px-1.5 py-0.5 -mx-1.5 transition-colors duration-150 hover:bg-slate-900/70 ${p.connected ? 'text-emerald-400' : 'text-slate-500'}`}
                  title={`${p.label} — ${p.category}${p.connected ? ' (wired)' : ' (not connected)'}`}
                >
                  {p.connected ? <PlugZap size={11} className="shrink-0" /> : <Plug size={11} className="shrink-0" />}
                  <span className="font-mono break-all">{p.label}</span>
                  <span className="text-slate-500 break-words">({p.category})</span>
                </div>
              ))}
            </div>
          </div>
        ),
      });
    }

    if (selectedBoardId !== null && pinLiveStates.length > 0) {
      list.push({
        id: 'pin-inspector',
        label: 'Pin Inspector',
        content: (
          <div className="px-3.5 py-2.5 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-x-3 gap-y-1 font-mono leading-relaxed">
              {pinLiveStates.map(p => {
                const valueText = p.category === 'analog'
                  ? `${p.analog}`
                  : p.mode === 'PWM'
                    ? `PWM ${p.pwm}`
                    : p.digital ? 'HIGH' : 'LOW';
                const active = p.category === 'analog' ? (p.analog ?? 0) > 0 : (p.mode === 'PWM' ? (p.pwm ?? 0) > 0 : !!p.digital);
                return (
                  <div
                    key={p.label}
                    className={`break-words rounded px-1.5 py-0.5 -mx-1.5 transition-colors duration-150 hover:bg-slate-900/70 ${active ? 'text-emerald-400' : 'text-slate-500'}`}
                    title={`${p.label}${p.mode ? ` (${p.mode})` : ''}`}
                  >
                    {p.label}: {valueText}
                  </div>
                );
              })}
            </div>
          </div>
        ),
      });
    }

    if (selectedBoardId !== null && componentMapping.some(p => p.components.length > 0)) {
      list.push({
        id: 'component-map',
        label: 'Component Map',
        content: (
          <div className="px-3.5 py-2.5 space-y-1 leading-relaxed text-xs">
            {componentMapping.filter(p => p.components.length > 0).map(p => (
              <div key={p.label} className="flex items-start gap-1.5 text-slate-300 flex-wrap rounded px-1.5 py-0.5 -mx-1.5 transition-colors duration-150 hover:bg-slate-900/70">
                <span className="font-mono text-emerald-400 shrink-0">{p.label}</span>
                <span className="text-slate-500 shrink-0">→</span>
                <span className="break-words">
                  {p.components.map((c, i) => (
                    <span key={i}>
                      {i > 0 && ', '}
                      {c.label} ({c.terminal})
                    </span>
                  ))}
                </span>
              </div>
            ))}
          </div>
        ),
      });
    }

    if (testResults) {
      const passed = testResults.filter(t => t.passed).length;
      list.push({
        id: 'compatibility-tests',
        label: 'Compatibility Tests',
        badge: `${passed}/${testResults.length}`,
        badgeTone: passed === testResults.length ? 'emerald' : 'rose',
        content: (
          <div className="px-3.5 py-2.5 space-y-1 leading-relaxed text-xs">
            {testResults.map((t, i) => (
              <div key={i} className={`flex items-center gap-1.5 rounded px-1.5 py-0.5 -mx-1.5 transition-colors duration-150 hover:bg-slate-900/70 ${t.passed ? 'text-emerald-400' : 'text-rose-400'}`}>
                {t.passed ? <CheckCircle2 size={12} className="shrink-0" /> : <XCircle size={12} className="shrink-0" />}
                <span>{t.name}</span>
                {!t.passed && t.message && <span className="text-slate-400 break-words">— {t.message}</span>}
              </div>
            ))}
          </div>
        ),
      });
    }

    return list;
  }, [
    status, errorCount, warningCount, compileMessage, diagnostics, handleDiagnosticClick,
    serialPaused, serialShowTimestamps, serialAutoScroll, serialCopied, displayedSerialText,
    handleCopySerial, handleClearSerial,
    selectedBoardId, pinMapping, pinLiveStates, componentMapping, testResults,
  ]);

  const codingPageRef = useRef<HTMLDivElement>(null);

  return (
    <div ref={codingPageRef} className="h-full flex flex-col gap-3 p-3 bg-slate-900/60 border border-slate-700/50 rounded-lg overflow-hidden">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2 text-slate-300 text-sm">
          <FileCode size={16} className="text-amber-400" />
          <select
            value={language}
            onChange={e => handleLanguageChange(e.target.value as Language)}
            title="Editor language"
            className="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-slate-200 text-sm focus:outline-none focus:border-amber-500"
          >
            {LANGUAGE_ORDER.map(lang => (
              <option key={lang} value={lang}>{LANGUAGE_DEFS[lang].label}</option>
            ))}
          </select>
          <span className="font-mono text-xs text-slate-500" title="Current file name">
            {activeTab.name}{activeTab.dirty ? '*' : ''}
          </span>
          <button
            onClick={handleNewFile}
            title="New file"
            className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700"
          >
            <FilePlus size={12} /> New
          </button>
          <button
            onClick={() => setShowOpenDialog(true)}
            title="Open a saved file"
            className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700"
          >
            <FolderOpen size={12} /> Open
          </button>
          <button
            onClick={handleSave}
            title="Save"
            className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700"
          >
            <Save size={12} /> Save
          </button>
          <button
            onClick={handleSaveAs}
            title="Save As"
            className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700"
          >
            <Save size={12} /> Save As
          </button>
          <button
            onClick={handleRenameFile}
            title="Rename file"
            className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700"
          >
            <PencilLine size={12} /> Rename
          </button>
          <button
            onClick={handleDeleteFile}
            title="Delete file"
            className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-slate-800 text-slate-400 hover:text-rose-400 border border-slate-700"
          >
            <Trash2 size={12} /> Delete
          </button>
          <label className="flex items-center gap-1 px-2 py-1 rounded text-xs text-slate-400 border border-slate-700" title="Autosave the current file periodically while editing">
            <input type="checkbox" checked={autosave} onChange={e => setAutosave(e.target.checked)} className="accent-amber-500" />
            Autosave
          </label>
          <button
            onClick={handleDownload}
            title={`Download as ${activeTab.name}`}
            className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700"
          >
            <Download size={12} /> Download
          </button>
        </div>
      </div>

      <div className="flex items-center gap-1 flex-wrap border-b border-slate-700/50 pb-1">
        {activeTabs.map(tab => (
          <div
            key={tab.tabId}
            onClick={() => setActiveTabId(prev => ({ ...prev, [language]: tab.tabId }))}
            className={`flex items-center gap-1 px-2 py-1 rounded-t text-xs cursor-pointer border-b-2 ${
              tab.tabId === activeTab.tabId
                ? 'bg-slate-800 text-amber-300 border-amber-500'
                : 'bg-slate-900/40 text-slate-400 border-transparent hover:text-slate-200'
            }`}
            title={tab.name}
          >
            <span className="font-mono">{tab.name}{tab.dirty ? '*' : ''}</span>
            <button
              onClick={e => { e.stopPropagation(); handleCloseTab(tab.tabId); }}
              title="Close tab"
              className="hover:text-rose-400"
            >
              <X size={11} />
            </button>
          </div>
        ))}
      </div>

      {showOpenDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60" onClick={() => setShowOpenDialog(false)}>
          <div
            className="bg-slate-900 border border-slate-700 rounded-lg p-4 w-full max-w-md max-h-[70vh] flex flex-col gap-2"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-slate-200 text-sm font-semibold">Open {currentLanguageDef.label} file</h3>
              <button onClick={() => setShowOpenDialog(false)} className="text-slate-400 hover:text-slate-200">
                <X size={16} />
              </button>
            </div>
            <div className="overflow-y-auto flex flex-col gap-1">
              {getCodeFiles(language).length === 0 && (
                <div className="text-slate-500 text-xs py-4 text-center">No saved {currentLanguageDef.label} files yet.</div>
              )}
              {getCodeFiles(language).map(file => (
                <div key={file.id} className="flex items-center justify-between gap-2 px-2 py-1.5 rounded hover:bg-slate-800 text-sm">
                  <button onClick={() => handleOpenFileSelect(file)} className="flex-1 text-left text-slate-200 font-mono truncate" title={file.name}>
                    {file.name}
                  </button>
                  <span className="text-slate-500 text-[10px]">{new Date(file.updatedAt).toLocaleDateString()}</span>
                  <button onClick={() => handleDeleteFromDialog(file)} title="Delete" className="text-slate-500 hover:text-rose-400">
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2 text-slate-300 text-sm">
          <Cpu size={16} className="text-amber-400" />
          {boardsOnCanvas.length > 1 ? (
            <select
              value={selectedBoardId ?? ''}
              onChange={e => {
                const id = Number(e.target.value);
                boardIdRef.current = id;
                setSelectedBoardId(id);
                const board = boardsOnCanvas.find(b => b.id === id);
                setBoardLabel(board ? board.label || BOARD_TYPE_NAMES[board.type] || board.type : null);
                const editor = getEditor();
                setPinMapping(board ? buildPinMapping(board, editor?.state.lastResult?.netTerminalCounts) : []);
                setComponentMapping(board ? buildComponentMapping(board, editor?.state.components ?? [], editor?.state.lastResult?.netTerminalCounts) : []);
                setPinLiveStates(board ? buildPinLiveStates(board) : []);
              }}
              className="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-slate-200 text-sm focus:outline-none focus:border-amber-500"
            >
              {boardsOnCanvas.map(b => (
                <option key={b.id} value={b.id}>
                  {b.label || BOARD_TYPE_NAMES[b.type] || b.type}
                </option>
              ))}
            </select>
          ) : (
            <span>{boardLabel ? `Target: ${boardLabel}` : 'No board detected on canvas'}</span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleRun}
            disabled={status === 'running' || language !== 'arduino'}
            title={language !== 'arduino' ? 'Execution is only available for Arduino C++ sketches' : undefined}
            className="flex items-center gap-1 px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-sm"
          >
            <Play size={14} /> Run
          </button>
          <button
            onClick={handleStop}
            disabled={status !== 'running'}
            className="flex items-center gap-1 px-3 py-1.5 rounded bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white text-sm"
          >
            <Square size={14} /> Stop
          </button>
          <button
            onClick={handleReset}
            className="flex items-center gap-1 px-3 py-1.5 rounded bg-slate-700 hover:bg-slate-600 text-white text-sm"
          >
            <RotateCcw size={14} /> Reset
          </button>
          <button
            onClick={handleSelfTest}
            className="flex items-center gap-1 px-3 py-1.5 rounded bg-sky-700 hover:bg-sky-600 text-white text-sm"
          >
            <Wrench size={14} /> Run compatibility tests
          </button>
        </div>
      </div>

      <CodeEditor
        ref={codeEditorRef}
        value={code}
        onChange={setCode}
        diagnostics={diagnostics}
        language={currentLanguageDef.monacoLanguage}
      />

      <BottomDock
        id="coding-bottom-dock"
        tabs={dockTabs}
        containerRef={codingPageRef}
        defaultHeightRatio={0.3}
        minHeightPx={180}
        maxHeightRatio={0.6}
        onTabBodyRef={(tabId, node) => {
          if (tabId === 'serial-monitor') serialScrollRef.current = node;
        }}
      />
    </div>
  );
});

CodingLab.displayName = 'CodingLab';

export default CodingLab;
