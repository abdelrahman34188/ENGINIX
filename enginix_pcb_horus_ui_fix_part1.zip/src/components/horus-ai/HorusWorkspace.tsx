/**
 * HorusWorkspace - the 👁 HORUS Workspace tab
 *
 * Chat UI with left/right message layout for HORUS vs. the user, wired
 * to the real HORUS pipeline: Send -> ConversationManager -> HORUSBrain
 * -> AIGateway -> active provider (Gemini), via `sendChatMessage()` in
 * `horus/runtime.ts` (the same composition root/entry point HORUS's
 * other real flow already uses). Nothing about the Gemini provider
 * implementation is touched here — this file only calls the existing
 * entry point and renders whatever it returns.
 */

import React, { useState, useRef, useEffect } from 'react';
import { Send, Wrench } from 'lucide-react';
import { sendChatMessage } from '../../horus/runtime';
import { SafeMarkdownMessage } from './MarkdownMessage';
import { horusActionRegistry, type HorusActionId } from '../../horus/registry/HorusActionRegistry';
import type { ConvertResult } from '../../pcb/convertFromCircuit';

/** Shape produced by `buildAnalyzeCircuitResult`. */
interface AnalyzeProblem {
  id: string;
  type: string;
  severity: string;
  message: string;
  componentIds: number[];
}
interface AnalyzeCircuitOutput {
  components: { id: number; type: string; label: string }[];
  valid: boolean;
  problems: AnalyzeProblem[];
  recommendations: string[];
}

/** Shape produced by `buildExplainComponentResult` (success case). */
interface ExplainComponentOutput {
  error?: string;
  name?: string;
  type?: string;
  function?: string;
  terminals?: { index: number; label: string }[];
  properties?: { name: string; unit?: string; currentValue: unknown }[];
}

/** Shape produced by `buildFixErrorsResult`. */
interface FixErrorsOutput {
  errors: AnalyzeProblem[];
  status: string;
  note: string;
}

/** Shape produced by `buildGenerateArduinoResult` (see HorusActionResults.ts).
 *  Read here only to decide how to render it — never to reimplement it. */
interface GenerateArduinoOutput {
  available: boolean;
  reason?: string;
  language?: string;
  code?: string;
}

/** Shape produced by `buildConvertPcbResult` — the real `ConvertResult`
 *  plus the `warnings` it already adds (e.g. empty circuit, unmapped
 *  component types). Read here only to decide how to render it. */
interface ConvertPcbOutput extends ConvertResult {
  warnings: string[];
}

// Local copy of the Eye of Horus mark used elsewhere in the app (App.tsx),
// duplicated here so this component has no dependency on App.tsx internals.
const EyeOfHorusIcon = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M1.5 12C1.5 12 5.5 6.5 12 6.5C18.5 6.5 22.5 12 22.5 12C22.5 12 18.5 14.5 12 14.5C5.5 14.5 1.5 12 1.5 12Z"
      stroke="#fbbf24"
      strokeWidth="1.4"
      strokeLinejoin="round"
    />
    <circle cx="12" cy="12" r="2.4" stroke="#fbbf24" strokeWidth="1.4" />
    <circle cx="12" cy="12" r="0.9" fill="#fbbf24" />
  </svg>
);

// Thinking indicator — "HORUS is thinking..." with an animated loader.
// Shown while `isThinking` is true: from the moment Send fires the real
// `sendChatMessage()` call until HORUS Brain's reply (or error) comes
// back.
const ThinkingIndicator = ({ label = 'HORUS is thinking...' }: { label?: string }) => (
  <div className="flex items-end gap-2 justify-start">
    <div className="w-6 h-6 rounded-full bg-slate-800 border border-amber-500/30 flex items-center justify-center shrink-0">
      <EyeOfHorusIcon size={13} />
    </div>
    <div className="flex items-center gap-2 max-w-[75%] rounded-lg px-3 py-2 bg-slate-800/80 border border-slate-700/60 text-slate-300 text-sm">
      <span className="flex items-center gap-1">
        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce [animation-delay:-0.3s]" />
        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce [animation-delay:-0.15s]" />
        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce" />
      </span>
      <span className="font-mono text-xs text-amber-300">{label}</span>
    </div>
  </div>
);

interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'horus';
  /** Marks a HORUS message as a failed result (tool error or send
   *  error) so it renders with error styling instead of looking like
   *  a normal successful reply — never a "fake success". */
  isError?: boolean;
  /** Optional follow-up action shown under a HORUS message (e.g. "Open
   *  in PCB Lab" after a Convert Circuit to PCB result). Purely a UI
   *  affordance to reach an existing surface — never a second copy of
   *  any engine's logic. */
  action?: { label: string; onClick: () => void };
  /** The tool's real, unmodified `ToolExecutionResult.output`, kept
   *  alongside the friendly rendered `text` in case something else
   *  needs the underlying data — but never itself rendered in the
   *  chat UI. Present only for tool-action results, not free-text
   *  chat replies. */
  rawOutput?: unknown;
}

// A single message bubble — right-aligned for the user, left-aligned
// (with a small HORUS mark) for HORUS.
const MessageBubble = ({ message }: { message: ChatMessage }) => {
  const isUser = message.sender === 'user';
  const [copied, setCopied] = useState(false);
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Clipboard access can fail (permissions/unsupported environment);
      // there's nothing useful to do beyond not crashing the chat.
    }
  };
  return (
    <div className={`flex items-end gap-2 ${isUser ? 'justify-end' : 'justify-start'}`}>
      {!isUser && (
        <div
          className={`w-6 h-6 rounded-full bg-slate-800 border flex items-center justify-center shrink-0 ${
            message.isError ? 'border-red-500/40' : 'border-amber-500/30'
          }`}
        >
          <EyeOfHorusIcon size={13} />
        </div>
      )}
      <div
        className={`max-w-[75%] rounded-lg px-3 py-2 text-sm break-words ${
          isUser
            ? 'bg-amber-500/10 border border-amber-500/30 text-slate-100 whitespace-pre-wrap'
            : message.isError
              ? 'bg-red-500/10 border border-red-500/40 text-red-200'
              : 'bg-slate-800/80 border border-slate-700/60 text-slate-200'
        }`}
      >
        {/* User input stays plain text. HORUS replies go through the
            Markdown + LaTeX renderer so formulas like \frac / \Omega /
            $$...$$ show up as readable math instead of raw source. Tool
            results render as prose/lists here too — the raw JSON on
            `message.rawOutput` (if any) is intentionally never passed
            to this renderer. */}
        {isUser ? message.text : <SafeMarkdownMessage content={message.text} />}
        {!isUser && message.rawOutput !== undefined && (
          <button
            type="button"
            onClick={handleCopy}
            className="mt-2 flex items-center gap-1.5 px-2 py-1 text-[11px] font-mono rounded border border-slate-600/60 text-slate-400 hover:text-amber-300 hover:border-amber-500/40 transition-colors"
          >
            {copied ? 'Copied' : 'Copy result'}
          </button>
        )}
        {!isUser && message.action && (
          <button
            type="button"
            onClick={message.action.onClick}
            className="mt-2 flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-semibold rounded-md border border-amber-500/40 text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 transition-colors"
          >
            {message.action.label}
          </button>
        )}
      </div>
    </div>
  );
};

// Compact "Tools" menu — lists the five existing HORUS actions from
// `horusActionRegistry` (the single source of truth already wired to
// `IntentRouter` -> `IntentToolBridge` -> `ToolExecutor`) and triggers
// whichever one the user picks via `onSelect`. Pure presentation: it
// does not call any action itself, just reads the registry's labels
// and reports back the chosen action's id.
const ToolsMenu = ({
  onSelect,
  disabled,
}: {
  onSelect: (id: HorusActionId) => void;
  disabled?: boolean;
}) => {
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);
  const actions = horusActionRegistry.listActions();

  useEffect(() => {
    if (!open) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [open]);

  return (
    <div ref={menuRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen(v => !v)}
        disabled={disabled}
        aria-haspopup="menu"
        aria-expanded={open}
        title="Tools"
        className="flex items-center justify-center w-9 h-9 rounded-md border border-slate-700/60 text-slate-300 bg-slate-800/80 hover:bg-slate-800 hover:text-amber-400 disabled:opacity-40 disabled:cursor-not-allowed transition-colors shrink-0"
      >
        <Wrench size={15} />
      </button>

      {open && (
        <div
          role="menu"
          className="absolute bottom-full left-0 mb-2 w-52 rounded-md border border-slate-700/60 bg-slate-900/95 shadow-lg shadow-black/40 py-1 z-10"
        >
          {actions.map(action => (
            <button
              key={action.id}
              role="menuitem"
              type="button"
              onClick={() => {
                setOpen(false);
                onSelect(action.id);
              }}
              className="w-full text-left px-3 py-2 text-xs font-mono text-slate-200 hover:bg-amber-500/10 hover:text-amber-400 transition-colors"
            >
              {action.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export interface HorusWorkspaceProps {
  /** When this HORUS instance sits inside ENGINIX Studio (where the PCB
   *  Designer is mounted) or can reach it, this imports a Convert
   *  Circuit to PCB result into the existing PCB interface and switches
   *  to it — the exact same `handleConvertToPCB` path the Circuit
   *  Simulator's own "Convert to PCB" button already uses. Omitted (e.g.
   *  no PCB surface reachable from this HORUS instance) means the
   *  Convert Circuit to PCB result is shown without an "Open" action. */
  onOpenPCB?: (result: ConvertResult) => void;
}

export default function HorusWorkspace({ onOpenPCB }: HorusWorkspaceProps = {}) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState('');
  // Drives the ThinkingIndicator while a real HORUS reply is in flight
  // (both for free-text sends and for a running Tools-menu action —
  // `thinkingLabel` distinguishes which so the indicator reflects
  // what's actually running).
  const [isThinking, setIsThinking] = useState(false);
  const [thinkingLabel, setThinkingLabel] = useState('HORUS is thinking...');
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  // Stable id for this tab's conversation, so ConversationManager can
  // keep accumulating turns across multiple sends in the same session.
  const conversationIdRef = useRef<string>(`horus-workspace-${Date.now()}`);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ block: 'end' });
  }, [messages.length, isThinking]);

  const handleSend = async () => {
    const text = draft.trim();
    if (!text || isThinking) return;
    setMessages(prev => [...prev, { id: `${Date.now()}-${prev.length}`, text, sender: 'user' }]);
    setDraft('');
    setThinkingLabel('HORUS is thinking...');
    setIsThinking(true);
    try {
      // For circuit-edit requests, `sendChatMessage()` now executes the
      // edit through CircuitToolBridge immediately and returns a short
      // confirmation (e.g. "LED added successfully.") instead of an AI
      // reply — displayed the same way any other HORUS reply is.
      const result = await sendChatMessage(conversationIdRef.current, text);
      setMessages(prev => [
        ...prev,
        {
          id: `${Date.now()}-${prev.length}`,
          text: result.ok ? result.text : `HORUS couldn't respond: ${result.error}`,
          sender: 'horus',
          isError: !result.ok,
        },
      ]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          id: `${Date.now()}-${prev.length}`,
          text: `HORUS couldn't respond: ${err instanceof Error ? err.message : String(err)}`,
          sender: 'horus',
          isError: true,
        },
      ]);
    } finally {
      setIsThinking(false);
    }
  };

  // Format a `ToolExecutionResult.output` payload for display in the
  // chat as prose — never as a raw JSON block. This is the fallback
  // used by any HORUS tool that doesn't have a dedicated renderer
  // below (see analyze_circuit/explain_component/convert_pcb/
  // fix_errors). It only decides how to *print* whatever shape the
  // real tool output already is — it never invents fields that aren't
  // there, and it never hides real data by silently dropping it: an
  // object's fields all become lines, objects/arrays become nested
  // sections/lists.
  const titleCase = (key: string) => key.replace(/([A-Z])/g, ' $1').replace(/^./, c => c.toUpperCase()).trim();

  const formatValue = (value: unknown, depth: number): string => {
    const indent = '  '.repeat(depth);
    if (value === null || value === undefined) return `${indent}—`;
    if (typeof value !== 'object') return `${indent}${String(value)}`;
    if (Array.isArray(value)) {
      if (value.length === 0) return `${indent}(none)`;
      return value
        .map((item) => {
          if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            // Prefer a short label/name/message for each row when the
            // object has one, falling back to a compact key: value list.
            const obj = item as Record<string, unknown>;
            const short = obj.label ?? obj.name ?? obj.message ?? obj.type;
            if (typeof short === 'string') return `${indent}- ${short}`;
            return `${indent}- ${Object.entries(obj).map(([k, v]) => `${titleCase(k)}: ${v}`).join(', ')}`;
          }
          return `${indent}- ${formatValue(item, 0).trim()}`;
        })
        .join('\n');
    }
    const entries = Object.entries(value as Record<string, unknown>);
    if (entries.length === 0) return `${indent}(none)`;
    return entries
      .map(([k, v]) => {
        if (v !== null && typeof v === 'object') {
          return `${indent}**${titleCase(k)}:**\n${formatValue(v, depth + 1)}`;
        }
        return `${indent}**${titleCase(k)}:** ${v ?? '—'}`;
      })
      .join('\n');
  };

  const formatToolOutputFriendly = (output: unknown): string => {
    if (output === undefined) return '';
    if (typeof output === 'string') return output;
    try {
      return formatValue(output, 0);
    } catch {
      return 'Result received, but could not be displayed.';
    }
  };

  // Triggered by picking an item from the Tools menu. Calls the exact
  // same `horusActionRegistry.invoke()` path the registry's own tests
  // exercise (-> IntentRouter -> IntentToolBridge -> ToolExecutor) —
  // no action logic is reimplemented here, this only renders whatever
  // that call returns as a HORUS message in the same chat/history.
  // Loading state mirrors `handleSend`'s (`isThinking` + the shared
  // ThinkingIndicator), and a failed/undefined result is rendered as
  // an error message (`isError: true`), never a fake success.
  const handleToolAction = async (id: HorusActionId) => {
    if (isThinking) return;
    const action = horusActionRegistry.getAction(id);
    const label = action?.label ?? id;
    setMessages(prev => [...prev, { id: `${Date.now()}-${prev.length}`, text: `[Tool] ${label}`, sender: 'user' }]);
    setThinkingLabel(`Running ${label}...`);
    setIsThinking(true);
    try {
      // `invoke()` is synchronous today (skeleton ToolExecutor) but is
      // awaited defensively so this keeps working if it becomes async
      // without any change needed here.
      const result = await Promise.resolve(horusActionRegistry.invoke(id, { conversationId: conversationIdRef.current }));
      if (!result) {
        setMessages(prev => [
          ...prev,
          { id: `${Date.now()}-${prev.length}`, text: `**${label}** could not be triggered: action not found.`, sender: 'horus', isError: true },
        ]);
        return;
      }
      if (result.status === 'error') {
        setMessages(prev => [
          ...prev,
          { id: `${Date.now()}-${prev.length}`, text: `**${label}** failed: ${result.error ?? 'Unknown error.'}`, sender: 'horus', isError: true },
        ]);
        return;
      }

      // Each of the five actions gets a dedicated, human-readable
      // rendering of the exact same `result.output` the tool returned —
      // the real object is kept on `rawOutput` (never shown) so a
      // "Copy result" affordance and any future consumer still has it,
      // but the visible chat text is never a JSON dump.
      if (id === 'analyze_circuit') {
        const output = result.output as AnalyzeCircuitOutput;
        const count = output?.components?.length ?? 0;
        const lines = [`**${label}**`, ''];
        if (count === 0) {
          lines.push('The circuit is empty — nothing to analyze.');
        } else {
          lines.push(`**Status:** ${output.valid ? '✅ Electrically valid' : '⚠️ Issues found'}`);
          lines.push(`**Components:** ${count}`);
          if (output.problems?.length) {
            lines.push('', '**Warnings / Errors:**');
            for (const p of output.problems) {
              const affected = p.componentIds?.length ? ` (affects: ${p.componentIds.map(id2 => `#${id2}`).join(', ')})` : '';
              lines.push(`- [${p.severity}] ${p.message}${affected}`);
            }
          }
          if (output.recommendations?.length) {
            lines.push('', '**Recommendations:**');
            for (const r of output.recommendations) lines.push(`- ${r}`);
          }
        }
        setMessages(prev => [...prev, { id: `${Date.now()}-${prev.length}`, text: lines.join('\n'), sender: 'horus', rawOutput: output }]);
        return;
      }

      if (id === 'explain_component') {
        const output = result.output as ExplainComponentOutput;
        if (output?.error) {
          setMessages(prev => [...prev, { id: `${Date.now()}-${prev.length}`, text: `**${label}**\n\n${output.error}`, sender: 'horus', isError: true, rawOutput: output }]);
          return;
        }
        const lines = [
          `**${label}** — ${output?.name ?? output?.type ?? 'Component'}`,
          '',
          `**Type:** ${output?.type ?? '—'}`,
          `**Function:** ${output?.function ?? '—'}`,
        ];
        if (output?.terminals?.length) {
          lines.push('', '**Terminals / Pins:**');
          for (const t of output.terminals) lines.push(`- Pin ${t.index}: ${t.label}`);
        }
        if (output?.properties?.length) {
          lines.push('', '**Properties:**');
          for (const p of output.properties) lines.push(`- ${p.name}: ${p.currentValue}${p.unit ? ` ${p.unit}` : ''}`);
        }
        setMessages(prev => [...prev, { id: `${Date.now()}-${prev.length}`, text: lines.join('\n'), sender: 'horus', rawOutput: output }]);
        return;
      }

      if (id === 'fix_errors') {
        const output = result.output as FixErrorsOutput;
        const errCount = output?.errors?.length ?? 0;
        const lines = [`**${label}**`, '', `${errCount === 0 ? 'No errors detected.' : `${errCount} issue(s) found.`} ${output?.note ?? ''}`.trim()];
        if (output?.errors?.length) {
          lines.push('', '**Issues:**');
          for (const e of output.errors) {
            const affected = e.componentIds?.length ? ` (affects: ${e.componentIds.map(id2 => `#${id2}`).join(', ')})` : '';
            lines.push(`- [${e.severity}] ${e.message}${affected}`);
          }
        }
        setMessages(prev => [...prev, { id: `${Date.now()}-${prev.length}`, text: lines.join('\n'), sender: 'horus', rawOutput: output }]);
        return;
      }

      // Generate Arduino Code gets dedicated rendering (clear
      // "unavailable" notice, or a proper code block with Copy if a
      // real engine is ever wired in) instead of the generic
      // human-friendly-object rendering every other action uses.
      if (id === 'generate_arduino') {
        const output = result.output as GenerateArduinoOutput;
        const text = output?.available
          ? `**${label}**\n\n\`\`\`${output.language ?? 'arduino'}\n${output.code ?? ''}\n\`\`\``
          : `**${label}** — not available.\n\n${output?.reason ?? 'No existing HORUS engine produces a sketch from the live circuit.'}`;
        setMessages(prev => [...prev, { id: `${Date.now()}-${prev.length}`, text, sender: 'horus', rawOutput: output }]);
        return;
      }

      if (id === 'convert_pcb') {
        const output = result.output as ConvertPcbOutput;
        const placed = output?.components?.length ?? 0;
        const nets = output?.netlist?.length ?? 0;
        const warnings = output?.warnings ?? [];
        const lines = [`**${label}**`, ''];
        if (placed === 0) {
          lines.push('Nothing to place — the circuit is empty.');
        } else {
          lines.push(`${placed} footprint(s) placed across ${nets} net(s).`, '', '**Footprints:**');
          for (const c of output.components) lines.push(`- ${c.refDes} — ${c.footprint}`);
        }
        if (warnings.length) {
          lines.push('', '**Warnings:**');
          for (const w of warnings) lines.push(`- ${w}`);
        }
        setMessages(prev => [
          ...prev,
          {
            id: `${Date.now()}-${prev.length}`,
            text: lines.join('\n'),
            sender: 'horus',
            rawOutput: output,
            action:
              placed > 0 && onOpenPCB
                ? { label: 'Open in PCB Lab', onClick: () => onOpenPCB(output) }
                : undefined,
          },
        ]);
        return;
      }

      // Generic fallback for any other HORUS tool: same principle,
      // human-readable text built straight from the real output,
      // never a JSON dump.
      const outputText = formatToolOutputFriendly(result.output);
      const text = `**${label}**${outputText ? `\n\n${outputText}` : ' — done.'}`;
      setMessages(prev => [...prev, { id: `${Date.now()}-${prev.length}`, text, sender: 'horus', rawOutput: result.output }]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          id: `${Date.now()}-${prev.length}`,
          text: `**${label}** failed: ${err instanceof Error ? err.message : String(err)}`,
          sender: 'horus',
          isError: true,
        },
      ]);
    } finally {
      setIsThinking(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="h-full flex flex-col bg-slate-900/60 border border-slate-700/60 rounded-lg overflow-hidden">
      {/* Chat area header — logo + status label */}
      <div className="flex items-center gap-2.5 px-4 py-3 border-b border-slate-700/60 bg-slate-900/90">
        <EyeOfHorusIcon size={22} />
        <div className="flex flex-col leading-tight">
          <span className="text-sm font-mono font-bold tracking-wider text-amber-400">HORUS</span>
          <span className="text-[10px] font-mono text-slate-500">CHAT</span>
        </div>
        <span className="ml-auto flex items-center gap-1.5 px-2.5 py-1 text-[10px] font-mono font-semibold rounded-full border border-emerald-500/40 text-emerald-400 bg-emerald-500/10">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          Ready
        </span>
      </div>

      {/* Messages container */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-3">
        {messages.length === 0 && !isThinking ? (
          <div className="h-full flex flex-col items-center justify-center text-center gap-2 text-slate-500">
            <EyeOfHorusIcon size={32} />
            <p className="text-xs font-mono">HORUS is ready to help.</p>
          </div>
        ) : (
          <>
            {messages.map(m => (
              <MessageBubble key={m.id} message={m} />
            ))}
            {isThinking && <ThinkingIndicator label={thinkingLabel} />}
          </>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input box + send button */}
      <div className="flex items-end gap-2 px-3 py-3 border-t border-slate-700/60 bg-slate-900/90">
        <ToolsMenu onSelect={handleToolAction} disabled={isThinking} />
        <textarea
          value={draft}
          onChange={e => setDraft(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type a message…"
          rows={1}
          className="flex-1 resize-none bg-slate-800/80 border border-slate-700/60 rounded-md px-3 py-2 text-sm text-slate-100 placeholder-slate-500 font-mono focus:outline-none focus:border-amber-500/60"
        />
        <button
          onClick={handleSend}
          disabled={!draft.trim() || isThinking}
          className="flex items-center gap-1.5 px-4 py-2 text-xs font-mono font-semibold rounded-md border border-amber-500/40 text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
        >
          <Send size={13} /> Send
        </button>
      </div>
    </div>
  );
}
