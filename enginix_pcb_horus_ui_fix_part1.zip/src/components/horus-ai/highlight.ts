/**
 * HORUS AI Assistant — minimal syntax highlighter.
 *
 * Deliberately dependency-free: a small regex tokenizer covering the
 * languages most relevant to ENGINIX (JS/TS, Python, C/C++/Arduino, JSON,
 * Bash) plus a plain-text fallback. Good enough for readable code blocks
 * in chat; not a full-blown grammar.
 */

export type SyntaxTokenType =
  | 'keyword'
  | 'string'
  | 'comment'
  | 'number'
  | 'function'
  | 'plain';

export interface SyntaxToken {
  text: string;
  type: SyntaxTokenType;
}

const KEYWORDS_BY_LANGUAGE: Record<string, string[]> = {
  javascript: ['const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'class', 'import', 'export', 'from', 'default', 'new', 'this', 'async', 'await', 'try', 'catch', 'finally', 'throw', 'switch', 'case', 'break', 'continue', 'extends', 'typeof', 'instanceof', 'null', 'undefined', 'true', 'false'],
  typescript: ['const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'class', 'import', 'export', 'from', 'default', 'new', 'this', 'async', 'await', 'try', 'catch', 'finally', 'throw', 'switch', 'case', 'break', 'continue', 'extends', 'implements', 'interface', 'type', 'enum', 'public', 'private', 'protected', 'readonly', 'void', 'null', 'undefined', 'true', 'false'],
  python: ['def', 'return', 'if', 'elif', 'else', 'for', 'while', 'class', 'import', 'from', 'as', 'try', 'except', 'finally', 'with', 'lambda', 'pass', 'break', 'continue', 'yield', 'None', 'True', 'False', 'and', 'or', 'not', 'in', 'is', 'raise'],
  cpp: ['int', 'float', 'double', 'char', 'void', 'if', 'else', 'for', 'while', 'return', 'class', 'struct', 'public', 'private', 'protected', 'const', 'static', 'new', 'delete', 'namespace', 'template', 'typename', 'bool', 'true', 'false', 'NULL', 'nullptr'],
  arduino: ['int', 'float', 'double', 'char', 'void', 'if', 'else', 'for', 'while', 'return', 'const', 'static', 'bool', 'true', 'false', 'setup', 'loop', 'pinMode', 'digitalWrite', 'digitalRead', 'analogRead', 'analogWrite', 'delay', 'HIGH', 'LOW', 'INPUT', 'OUTPUT', 'INPUT_PULLUP'],
  bash: ['if', 'then', 'else', 'elif', 'fi', 'for', 'do', 'done', 'while', 'echo', 'export', 'function', 'return', 'in'],
  json: [],
};

export function normalizeLanguage(lang: string | undefined): string {
  const l = (lang || '').trim().toLowerCase();
  if (l === 'ts' || l === 'tsx') return 'typescript';
  if (l === 'js' || l === 'jsx') return 'javascript';
  if (l === 'py') return 'python';
  if (l === 'c' || l === 'cpp' || l === 'c++' || l === 'h' || l === 'hpp') return 'cpp';
  if (l === 'ino' || l === 'arduino') return 'arduino';
  if (l === 'sh' || l === 'shell' || l === 'bash') return 'bash';
  if (l === 'json') return 'json';
  return l || 'plain';
}

const TOKEN_PATTERN = /(\/\/.*$)|(#.*$)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|`(?:[^`\\]|\\.)*`)|(\b\d+\.?\d*\b)|([A-Za-z_$][A-Za-z0-9_$]*)|(\s+)|(.)/gm;

/** Tokenize a single line of code for the given (normalized) language. */
export function tokenizeLine(line: string, language: string): SyntaxToken[] {
  const keywords = new Set(KEYWORDS_BY_LANGUAGE[language] || []);
  const tokens: SyntaxToken[] = [];
  let match: RegExpExecArray | null;
  TOKEN_PATTERN.lastIndex = 0;

  while ((match = TOKEN_PATTERN.exec(line)) !== null) {
    const [, lineComment, hashComment, str, num, word, ws, other] = match;
    if (lineComment !== undefined || (hashComment !== undefined && language !== 'json')) {
      tokens.push({ text: (lineComment ?? hashComment) as string, type: 'comment' });
    } else if (str !== undefined) {
      tokens.push({ text: str, type: 'string' });
    } else if (num !== undefined) {
      tokens.push({ text: num, type: 'number' });
    } else if (word !== undefined) {
      if (keywords.has(word)) {
        tokens.push({ text: word, type: 'keyword' });
      } else {
        tokens.push({ text: word, type: 'plain' });
      }
    } else if (ws !== undefined) {
      tokens.push({ text: ws, type: 'plain' });
    } else if (other !== undefined) {
      tokens.push({ text: other, type: 'plain' });
    }
    if (match[0].length === 0) {
      TOKEN_PATTERN.lastIndex++;
    }
  }

  return tokens;
}

export const SYNTAX_TOKEN_CLASS: Record<SyntaxTokenType, string> = {
  keyword: 'text-amber-400',
  string: 'text-teal-400',
  comment: 'text-slate-500 italic',
  number: 'text-orange-300',
  function: 'text-sky-300',
  plain: 'text-slate-300',
};
