/**
 * HORUS AI Assistant — static placeholder content.
 *
 * Everything here is fixed, hardcoded content for demonstrating the new
 * UI (conversation history rows, a welcome message showcasing markdown +
 * syntax highlighting). None of it is generated, and nothing here talks
 * to the HORUS AI architecture (src/horus/) or any provider — that
 * wiring is explicitly out of scope for this page-only UI pass.
 */

export interface HorusConversationSummary {
  id: string;
  title: string;
  preview: string;
  updatedLabel: string;
}

export const DEMO_CONVERSATIONS: HorusConversationSummary[] = [
  { id: 'c1', title: 'LED current-limiting resistor', preview: 'What resistor do I need for a 5mm red LED on 5V?', updatedLabel: 'Today' },
  { id: 'c2', title: 'Half-bridge motor driver notes', preview: 'Comparing L298N vs a discrete MOSFET H-bridge...', updatedLabel: 'Yesterday' },
  { id: 'c3', title: 'BOQ template for grad project', preview: 'Structure a bill of quantities by phase', updatedLabel: '3 days ago' },
];

export const WELCOME_MESSAGE = `# Welcome to HORUS AI

I'm your **Electrical Engineering Copilot** — once connected, I'll help with circuit design, component selection, Arduino code, and calculations.

This preview shows how responses will be formatted:

- Markdown text with **bold**, *italic*, and \`inline code\`
- Fenced code blocks with syntax highlighting and a Copy button
- Ordered and unordered lists

\`\`\`cpp
// Example: blink an LED on pin 13
void setup() {
  pinMode(13, OUTPUT);
}

void loop() {
  digitalWrite(13, HIGH);
  delay(500);
  digitalWrite(13, LOW);
  delay(500);
}
\`\`\`

HORUS AI Core is not connected yet — this is a UI preview only.`;
