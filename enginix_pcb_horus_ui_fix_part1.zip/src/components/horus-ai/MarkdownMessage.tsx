/**
 * HORUS AI Assistant — markdown message renderer.
 *
 * Self-contained (no external markdown/highlight libraries): supports the
 * subset of markdown chat messages actually need — headers, bold/italic,
 * inline code, fenced code blocks (with the syntax highlighter from
 * ./highlight.ts and a Copy button), links, and ordered/unordered lists.
 * Not a full CommonMark implementation by design.
 */

import { useState, Component, type ReactNode } from 'react';
import { Check, Copy, Sigma } from 'lucide-react';
import { normalizeLanguage, tokenizeLine, SYNTAX_TOKEN_CLASS } from './highlight';
import { containsLatex, convertLatex } from './mathRender';

function CodeBlock({ code, language }: { code: string; language?: string }) {
  const [copied, setCopied] = useState(false);
  const lang = normalizeLanguage(language);
  const lines = code.replace(/\n$/, '').split('\n');

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      // Clipboard API unavailable (e.g. insecure context) — fail silently.
    }
  };

  return (
    <div className="my-2 rounded-lg border border-slate-700 bg-slate-950/80 overflow-hidden">
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-900 border-b border-slate-700">
        <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500">{lang}</span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1 text-[10px] font-mono text-slate-400 hover:text-amber-400 transition-colors"
        >
          {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre className="p-3 overflow-x-auto text-xs leading-relaxed font-mono">
        <code>
          {lines.map((line, i) => (
            <div key={i}>
              {line.length === 0
                ? '\u00A0'
                : tokenizeLine(line, lang).map((tok, j) => (
                    <span key={j} className={SYNTAX_TOKEN_CLASS[tok.type]}>{tok.text}</span>
                  ))}
            </div>
          ))}
        </code>
      </pre>
    </div>
  );
}

/** A LaTeX calculation rendered as a standalone, readable block (from $$...$$ or \[...\]). */
function MathBlock({ tex }: { tex: string }) {
  const readable = convertLatex(tex);
  const lines = readable.split('\n').filter((l) => l.length > 0);
  return (
    <div className="my-2 rounded-lg border border-slate-700 bg-slate-950/60 px-3 py-2">
      <div className="flex items-center gap-1.5 mb-1 text-[10px] font-mono uppercase tracking-wider text-slate-500">
        <Sigma size={11} />
        <span>Calculation</span>
      </div>
      <div className="font-mono text-[13px] leading-relaxed text-slate-100 space-y-0.5">
        {lines.map((line, i) => (
          <div key={i}>{line}</div>
        ))}
      </div>
    </div>
  );
}

/** A LaTeX expression rendered inline within a sentence (from $...$ or \(...\)). */
function InlineMath({ tex }: { tex: string }) {
  return (
    <span className="font-mono text-[11px] px-0.5 text-teal-300">{convertLatex(tex)}</span>
  );
}

// Inline markdown: math ($..$, \(..\)), **bold**, *italic*/_italic_, `code`, [text](url).
// Math alternatives are matched first so formula underscores/braces never get
// misread as markdown italics before conversion.
const INLINE_PATTERN = /(\$([^$\n]+?)\$)|(\\\(([\s\S]+?)\\\))|(\*\*(.+?)\*\*)|(\*(.+?)\*|_(.+?)_)|(`([^`]+?)`)|(\[(.+?)\]\((.+?)\))/g;

function renderInline(text: string, keyPrefix: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let i = 0;
  INLINE_PATTERN.lastIndex = 0;

  while ((match = INLINE_PATTERN.exec(text)) !== null) {
    if (match.index > lastIndex) {
      nodes.push(text.slice(lastIndex, match.index));
    }
    const key = `${keyPrefix}-${i++}`;
    if (match[2] !== undefined) {
      nodes.push(<InlineMath key={key} tex={match[2]} />);
    } else if (match[4] !== undefined) {
      nodes.push(<InlineMath key={key} tex={match[4]} />);
    } else if (match[6] !== undefined) {
      nodes.push(<strong key={key} className="font-semibold text-slate-100">{match[6]}</strong>);
    } else if (match[8] !== undefined || match[9] !== undefined) {
      nodes.push(<em key={key}>{match[8] ?? match[9]}</em>);
    } else if (match[11] !== undefined) {
      nodes.push(
        <code key={key} className="px-1 py-0.5 rounded bg-slate-800 border border-slate-700 text-teal-300 text-[11px] font-mono">
          {match[11]}
        </code>
      );
    } else if (match[13] !== undefined && match[14] !== undefined) {
      nodes.push(
        <a key={key} href={match[14]} target="_blank" rel="noreferrer" className="text-amber-400 underline underline-offset-2 hover:text-amber-300">
          {match[13]}
        </a>
      );
    }
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < text.length) {
    nodes.push(text.slice(lastIndex));
  }
  return nodes;
}

interface Block {
  type: 'code' | 'text' | 'math';
  language?: string;
  content: string;
}

function splitCodeBlocks(markdown: string): Block[] {
  const blocks: Block[] = [];
  const fenceRe = /```(\w*)\n([\s\S]*?)```/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = fenceRe.exec(markdown)) !== null) {
    if (match.index > lastIndex) {
      blocks.push({ type: 'text', content: markdown.slice(lastIndex, match.index) });
    }
    blocks.push({ type: 'code', language: match[1], content: match[2] });
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < markdown.length) {
    blocks.push({ type: 'text', content: markdown.slice(lastIndex) });
  }
  return blocks;
}

// Block-level display math: $$...$$ or \[...\]. Split out of a text block so
// it renders as its own formula card instead of a paragraph full of LaTeX.
function splitMathBlocks(text: string): Block[] {
  const blocks: Block[] = [];
  const mathRe = /\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = mathRe.exec(text)) !== null) {
    if (match.index > lastIndex) {
      blocks.push({ type: 'text', content: text.slice(lastIndex, match.index) });
    }
    blocks.push({ type: 'math', content: match[1] ?? match[2] ?? '' });
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < text.length) {
    blocks.push({ type: 'text', content: text.slice(lastIndex) });
  }
  return blocks;
}

function renderTextBlock(content: string, keyPrefix: string): ReactNode[] {
  const lines = content.split('\n');
  const nodes: ReactNode[] = [];
  let listItems: string[] = [];
  let listOrdered = false;
  let paragraph: string[] = [];
  let idx = 0;

  const flushParagraph = () => {
    if (paragraph.length === 0) return;
    const joined = paragraph.join(' ');
    // Fallback for LaTeX that leaked out without $ / \[ \] delimiters (e.g.
    // a bare "\frac{V_source - V_LED}{I}" line) — still render it as a
    // readable formula rather than raw backslash commands.
    if (!joined.includes('$') && containsLatex(joined)) {
      nodes.push(
        <p key={`${keyPrefix}-p-${idx++}`} className="mb-2 last:mb-0 font-mono text-[13px] text-slate-100">
          {convertLatex(joined)}
        </p>
      );
    } else {
      nodes.push(
        <p key={`${keyPrefix}-p-${idx++}`} className="mb-2 last:mb-0">
          {renderInline(joined, `${keyPrefix}-p-${idx}`)}
        </p>
      );
    }
    paragraph = [];
  };

  const flushList = () => {
    if (listItems.length === 0) return;
    const ListTag = listOrdered ? 'ol' : 'ul';
    nodes.push(
      <ListTag key={`${keyPrefix}-l-${idx++}`} className={`mb-2 last:mb-0 pl-5 space-y-0.5 ${listOrdered ? 'list-decimal' : 'list-disc'}`}>
        {listItems.map((item, i) => (
          <li key={i}>{renderInline(item, `${keyPrefix}-li-${i}`)}</li>
        ))}
      </ListTag>
    );
    listItems = [];
  };

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();
    const headerMatch = /^(#{1,6})\s+(.*)$/.exec(line);
    const ulMatch = /^[-*]\s+(.*)$/.exec(line);
    const olMatch = /^\d+\.\s+(.*)$/.exec(line);

    if (headerMatch) {
      flushParagraph();
      flushList();
      const level = headerMatch[1].length;
      const sizeClass = level <= 2 ? 'text-sm font-bold text-slate-100' : 'text-xs font-bold text-slate-200';
      nodes.push(
        <div key={`${keyPrefix}-h-${idx++}`} className={`${sizeClass} mt-3 mb-1 first:mt-0`}>
          {renderInline(headerMatch[2], `${keyPrefix}-h-${idx}`)}
        </div>
      );
    } else if (ulMatch) {
      flushParagraph();
      if (listOrdered) flushList();
      listOrdered = false;
      listItems.push(ulMatch[1]);
    } else if (olMatch) {
      flushParagraph();
      if (!listOrdered) flushList();
      listOrdered = true;
      listItems.push(olMatch[1]);
    } else if (line.trim() === '') {
      flushParagraph();
      flushList();
    } else {
      flushList();
      paragraph.push(line.trim());
    }
  }
  flushParagraph();
  flushList();

  return nodes;
}

export function MarkdownMessage({ content }: { content: string }) {
  const blocks = splitCodeBlocks(content);
  return (
    <div className="text-xs leading-relaxed">
      {blocks.map((block, i) => {
        if (block.type === 'code') {
          return <CodeBlock key={i} code={block.content} language={block.language} />;
        }
        // Text blocks may still contain $$...$$ / \[...\] display-math
        // segments — pull those out into their own formula cards.
        const subBlocks = splitMathBlocks(block.content);
        return (
          <div key={i}>
            {subBlocks.map((sub, j) =>
              sub.type === 'math' ? (
                <MathBlock key={`${i}-${j}`} tex={sub.content} />
              ) : (
                <div key={`${i}-${j}`}>{renderTextBlock(sub.content, `b${i}-${j}`)}</div>
              )
            )}
          </div>
        );
      })}
    </div>
  );
}

// Formatting is best-effort against free-form AI output, which can contain
// unbalanced braces/delimiters (e.g. a truncated response, or LaTeX the
// model got slightly wrong). If parsing that ever throws, fall back to the
// raw message text instead of taking down the whole chat.
interface BoundaryState {
  hasError: boolean;
}

class MarkdownErrorBoundary extends Component<{ raw: string; children: ReactNode }, BoundaryState> {
  state: BoundaryState = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch() {
    // Rendering fell back to plain text below; nothing else to do here.
  }

  render() {
    if (this.state.hasError) {
      return <div className="text-xs leading-relaxed whitespace-pre-wrap break-words">{this.props.raw}</div>;
    }
    return this.props.children;
  }
}

/**
 * Safe entry point for chat messages: renders Markdown + LaTeX, and if
 * anything in that pipeline throws, falls back to the plain message text
 * so a malformed formula can never break the chat.
 */
export function SafeMarkdownMessage({ content }: { content: string }) {
  return (
    <MarkdownErrorBoundary raw={content}>
      <MarkdownMessage content={content} />
    </MarkdownErrorBoundary>
  );
}
