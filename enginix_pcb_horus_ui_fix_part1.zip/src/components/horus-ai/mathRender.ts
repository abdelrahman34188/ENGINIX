/**
 * HORUS AI Assistant — LaTeX-to-readable-math converter.
 *
 * HORUS's calculation responses come back as raw LaTeX (\frac{}{}, \text{},
 * $$...$$, Greek-letter commands, etc). The chat UI has no LaTeX engine, so
 * that markup was showing up verbatim instead of a readable formula.
 *
 * This module is display-only: it turns LaTeX source into a clean plain-text
 * math string (e.g. "\frac{V_{source}-V_{LED}}{I}" -> "(V_source - V_LED)/I")
 * that MarkdownMessage renders inline or as a block. It does not touch
 * circuit logic, the simulator, or AI behavior — it only reformats text that
 * is about to be displayed.
 */

// Command name -> unicode symbol, for common LaTeX macros seen in HORUS output.
const SYMBOL_MAP: Record<string, string> = {
  times: '×', cdot: '·', div: '÷', pm: '±', mp: '∓',
  leq: '≤', geq: '≥', neq: '≠', approx: '≈', equiv: '≡', propto: '∝', sim: '∼',
  infty: '∞', partial: '∂', nabla: '∇', degree: '°', circ: '°',
  rightarrow: '→', leftarrow: '←', Rightarrow: '⇒', Leftarrow: '⇐', to: '→', leftrightarrow: '↔',
  sum: 'Σ', prod: 'Π', int: '∫',
  Omega: 'Ω', omega: 'ω',
  Delta: 'Δ', delta: 'δ',
  pi: 'π', Pi: 'Π',
  alpha: 'α', beta: 'β', gamma: 'γ', Gamma: 'Γ',
  theta: 'θ', Theta: 'Θ',
  mu: 'μ', nu: 'ν',
  sigma: 'σ', Sigma: 'Σ',
  lambda: 'λ', Lambda: 'Λ',
  phi: 'φ', Phi: 'Φ',
  rho: 'ρ', tau: 'τ', chi: 'χ', psi: 'ψ', Psi: 'Ψ',
  eta: 'η', xi: 'ξ', Xi: 'Ξ', zeta: 'ζ', kappa: 'κ', iota: 'ι', upsilon: 'υ',
};

/** True if a string contains LaTeX markup worth converting. */
export function containsLatex(text: string): boolean {
  return /\\[a-zA-Z]+|\$\$?[^$]+\$\$?|\\\(|\\\)|\\\[|\\\]/.test(text);
}

/** Repeatedly apply a replacer until the string stops changing (handles nesting one layer at a time). */
function replaceUntilStable(input: string, pattern: RegExp, replacer: (...args: string[]) => string): string {
  let prev = input;
  let current = input.replace(pattern, replacer as (substring: string, ...args: string[]) => string);
  let guard = 0;
  while (current !== prev && guard < 50) {
    prev = current;
    current = current.replace(pattern, replacer as (substring: string, ...args: string[]) => string);
    guard++;
  }
  return current;
}

/**
 * Convert a chunk of LaTeX source into readable plain-text math notation.
 * e.g. "\frac{V_{source} - V_{LED}}{I}" -> "(V_source - V_LED)/I"
 *      "R = 350\,\Omega"                -> "R = 350 Ω"
 */
export function convertLatex(raw: string): string {
  let s = raw;

  // Strip math-mode delimiters ($$...$$, $...$, \[...\], \(...\)).
  s = s.trim();
  s = s.replace(/^\$\$([\s\S]*)\$\$$/, '$1');
  s = s.replace(/^\$([\s\S]*)\$$/, '$1');
  s = s.replace(/^\\\[([\s\S]*)\\\]$/, '$1');
  s = s.replace(/^\\\(([\s\S]*)\\\)$/, '$1');

  // Resolve subscript/superscript braces first (V_{source} -> V_source) so
  // that a \frac{...}{...} whose arguments contain subscripted variables
  // (very common: \frac{V_{source}-V_{LED}}{I}) doesn't look like it has
  // unbalanced nested braces to the simple frac matcher below.
  s = replaceUntilStable(s, /_\{([^{}]*)\}/g, (_m, a) => `_${a}`);
  s = replaceUntilStable(s, /\^\{([^{}]*)\}/g, (_m, a) => `^${a}`);

  // \frac{a}{b} -> a / b, parenthesizing each side only when it's a compound
  // expression (contains an operator) rather than a single term.
  const wrapFracSide = (side: string) => {
    const t = side.trim();
    return /[-+*/]/.test(t) ? `(${t})` : t;
  };
  s = replaceUntilStable(
    s,
    /\\d?frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g,
    (_m, a, b) => `${wrapFracSide(a)} / ${wrapFracSide(b)}`
  );

  // \sqrt{x} -> √(x)
  s = replaceUntilStable(s, /\\sqrt\s*\{([^{}]*)\}/g, (_m, a) => `√(${a})`);

  // \text{...}, \mathrm{...}, \mathbf{...} -> plain contents.
  s = replaceUntilStable(s, /\\(?:text|mathrm|mathbf|mathit|operatorname)\s*\{([^{}]*)\}/g, (_m, a) => a);

  // Drop sizing/decoration commands that carry no readable content.
  s = s.replace(/\\left|\\right/g, '');

  // Any remaining braces are just grouping (subscripts/superscripts, etc) — drop them.
  s = s.replace(/[{}]/g, '');

  // Named symbol/greek-letter commands, e.g. \Omega -> Ω. Must run after the
  // structural commands above so \frac/\text/\sqrt are already consumed.
  s = s.replace(/\\([a-zA-Z]+)/g, (_m, name: string) => (name in SYMBOL_MAP ? SYMBOL_MAP[name] : name));

  // Spacing commands and line breaks.
  s = s.replace(/\\,|\\;|\\:|\\!|\\ /g, ' ');
  s = s.replace(/\\\\/g, '\n');
  s = s.replace(/\\%/g, '%');

  // Collapse whitespace within a line, but keep intentional newlines.
  s = s
    .split('\n')
    .map((line) => line.replace(/\s+/g, ' ').trim())
    .join('\n')
    .trim();

  return s;
}
