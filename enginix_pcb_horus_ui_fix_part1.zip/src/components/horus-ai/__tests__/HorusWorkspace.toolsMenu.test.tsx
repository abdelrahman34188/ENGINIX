/**
 * Verifies the HORUS chat's Tools menu (Part 2 requirement): clicking
 * each of the five existing HORUS actions runs the existing action
 * handler (via `horusActionRegistry` -> `IntentRouter` ->
 * `IntentToolBridge` -> `ToolExecutor` — untouched) and renders its
 * result as a HORUS message inside the same chat/history, with
 * loading shown meanwhile and failures rendered as errors rather than
 * a fake success.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { createRoot, type Root } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import HorusWorkspace from '../HorusWorkspace';
import { horusActionRegistry } from '../../../horus/registry/HorusActionRegistry';

const ACTION_LABELS = [
  'Analyze Circuit',
  'Generate Arduino Code',
  'Fix Circuit Errors',
  'Convert Circuit to PCB',
  'Explain Component',
];

let container: HTMLDivElement;
let root: Root;

beforeEach(() => {
  // jsdom doesn't implement scrollIntoView; HorusWorkspace calls it on
  // every message-list update, so polyfill a no-op for the test env.
  if (!Element.prototype.scrollIntoView) {
    Element.prototype.scrollIntoView = () => {};
  }
  container = document.createElement('div');
  document.body.appendChild(container);
  act(() => {
    root = createRoot(container);
    root.render(<HorusWorkspace />);
  });
});

function click(el: Element | null) {
  if (!el) throw new Error('element not found');
  act(() => {
    el.dispatchEvent(new MouseEvent('click', { bubbles: true }));
  });
}

function openToolsMenu() {
  const toolsButton = container.querySelector('button[title="Tools"]');
  click(toolsButton);
}

function chatText(): string {
  return container.querySelector('.overflow-y-auto')?.textContent ?? '';
}

describe('HORUS Tools menu -> chat rendering', () => {
  it('lists all five existing actions in the menu', () => {
    openToolsMenu();
    const items = Array.from(container.querySelectorAll('[role="menuitem"]')).map(el => el.textContent);
    expect(items.sort()).toEqual([...ACTION_LABELS].sort());
  });

  it.each(ACTION_LABELS)('running "%s" reuses the existing handler, shows loading, and never renders a raw JSON code block', async (label) => {
    const invokeSpy = vi.spyOn(horusActionRegistry, 'invoke');

    openToolsMenu();
    const item = Array.from(container.querySelectorAll('[role="menuitem"]')).find(el => el.textContent === label);
    click(item ?? null);

    // Loading state shown immediately (isThinking), Tools button disabled meanwhile.
    expect(chatText()).toContain(`Running ${label}...`);
    expect(container.querySelector('button[title="Tools"]')?.hasAttribute('disabled')).toBe(true);

    // Flush the awaited invoke() -> state update microtask.
    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });

    // The existing registry/handler path was called — not reimplemented.
    expect(invokeSpy).toHaveBeenCalledTimes(1);
    expect(invokeSpy.mock.calls[0][0]).toBe(horusActionRegistry.getActionByLabel(label)?.id);

    // Result now rendered as a HORUS message in the same conversation,
    // and the [Tool] trigger + result both remain in the DOM/history —
    // but never as a raw JSON code block (the ```json fence Prism/
    // MarkdownMessage would otherwise render as a <pre>/<code> block).
    const text = chatText();
    expect(text).toContain(`[Tool] ${label}`);
    expect(text).not.toContain('Running');
    expect(text).not.toContain('```json');
    expect(container.querySelector('pre code.language-json')).toBeNull();

    invokeSpy.mockRestore();
  });

  it('renders Explain Component with name, type, function, and a clean terminals list (no JSON)', async () => {
    openToolsMenu();
    click(Array.from(container.querySelectorAll('[role="menuitem"]')).find(el => el.textContent === 'Explain Component') ?? null);
    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });

    const text = chatText();
    expect(text).toContain('[Tool] Explain Component');
    // Empty circuit in this test's default state -> the real "no
    // component" message from buildExplainComponentResult, in prose.
    expect(text).toContain('select or add a component');
    expect(text).not.toContain('{');
    expect(text).not.toContain('```');
  });

  it('renders Analyze Circuit with validity, component count, and warnings (no JSON)', async () => {
    openToolsMenu();
    click(Array.from(container.querySelectorAll('[role="menuitem"]')).find(el => el.textContent === 'Analyze Circuit') ?? null);
    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });

    const text = chatText();
    expect(text).toContain('[Tool] Analyze Circuit');
    expect(text).toContain('nothing to analyze');
    expect(text).not.toContain('{');
    expect(text).not.toContain('```');
  });

  it('renders Fix Circuit Errors (the other working tool) as prose, no JSON', async () => {
    openToolsMenu();
    click(Array.from(container.querySelectorAll('[role="menuitem"]')).find(el => el.textContent === 'Fix Circuit Errors') ?? null);
    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });

    const text = chatText();
    expect(text).toContain('[Tool] Fix Circuit Errors');
    expect(text).toContain('No errors detected');
    expect(text).not.toContain('{');
    expect(text).not.toContain('```');
  });

  it('renders Generate Arduino Code as clearly unavailable, not a fake success', async () => {
    openToolsMenu();
    const item = Array.from(container.querySelectorAll('[role="menuitem"]')).find(el => el.textContent === 'Generate Arduino Code');
    click(item ?? null);

    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });

    const text = chatText();
    expect(text).toContain('[Tool] Generate Arduino Code');
    expect(text).toContain('Generate Arduino Code — not available');
    expect(text).not.toContain('Generate Arduino Code result');
    // No engine exists, so nothing here should look like a generated sketch.
    expect(text).not.toContain('```arduino');
  });

  it('renders Convert Circuit to PCB as a summary with an Open in PCB Lab action', async () => {
    openToolsMenu();
    const item = Array.from(container.querySelectorAll('[role="menuitem"]')).find(el => el.textContent === 'Convert Circuit to PCB');
    click(item ?? null);

    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });

    const text = chatText();
    expect(text).toContain('[Tool] Convert Circuit to PCB');
    expect(text).toContain('Nothing to place');
    // Empty circuit in this test's default state -> nothing to place,
    // no Open action should be offered.
    expect(text).toContain('empty');
    expect(container.textContent).not.toContain('Open in PCB Lab');
  });

  it('shows an Open in PCB Lab action when a non-empty circuit converts and onOpenPCB is provided, and wires it to the callback', async () => {
    const fakeOutput = {
      components: [{ sourceComponentId: 1, footprint: 'R', refDes: 'R1', x: 0, y: 0, rotation: 0 }],
      netlist: [{ id: 1, pads: [] }],
      unmapped: [],
      warnings: [],
    };
    const invokeSpy = vi.spyOn(horusActionRegistry, 'invoke').mockReturnValue({
      status: 'success',
      toolName: 'PCBTool',
      output: fakeOutput,
    } as ReturnType<typeof horusActionRegistry.invoke>);

    const onOpenPCB = vi.fn();
    act(() => {
      root.unmount();
      root = createRoot(container);
      root.render(<HorusWorkspace onOpenPCB={onOpenPCB} />);
    });

    try {
      openToolsMenu();
      const item = Array.from(container.querySelectorAll('[role="menuitem"]')).find(el => el.textContent === 'Convert Circuit to PCB');
      click(item ?? null);

      await act(async () => {
        await Promise.resolve();
        await Promise.resolve();
      });

      const button = Array.from(container.querySelectorAll('button')).find(b => b.textContent === 'Open in PCB Lab');
      expect(button).toBeTruthy();
      click(button ?? null);
      expect(onOpenPCB).toHaveBeenCalledWith(fakeOutput);
    } finally {
      invokeSpy.mockRestore();
    }
  });

  it('Copy result button copies the friendly rendered text, not raw JSON', async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.assign(navigator, { clipboard: { writeText } });

    openToolsMenu();
    click(Array.from(container.querySelectorAll('[role="menuitem"]')).find(el => el.textContent === 'Analyze Circuit') ?? null);
    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });

    const copyButton = Array.from(container.querySelectorAll('button')).find(b => b.textContent === 'Copy result');
    expect(copyButton).toBeTruthy();
    click(copyButton ?? null);

    expect(writeText).toHaveBeenCalledTimes(1);
    const copiedText = writeText.mock.calls[0][0] as string;
    expect(copiedText).toContain('nothing to analyze');
    expect(copiedText).not.toContain('```json');
    expect(copiedText).not.toContain('{');
  });

  it('renders a failed action as an error, not a fake success', async () => {
    const invokeSpy = vi.spyOn(horusActionRegistry, 'invoke').mockReturnValue({
      status: 'error',
      toolName: 'CircuitTool',
      error: 'Simulated failure for test',
    });

    try {
      openToolsMenu();
      const item = Array.from(container.querySelectorAll('[role="menuitem"]')).find(el => el.textContent === 'Analyze Circuit');
      click(item ?? null);

      await act(async () => {
        await Promise.resolve();
        await Promise.resolve();
      });

      const text = chatText();
      expect(text).toContain('failed: Simulated failure for test');
      expect(text).not.toContain('result:');

      const errorBubble = container.querySelector('.border-red-500\\/40');
      expect(errorBubble).not.toBeNull();
    } finally {
      invokeSpy.mockRestore();
    }
  });

  it('preserves both the trigger and result across multiple tool runs (conversation history)', async () => {
    openToolsMenu();
    click(Array.from(container.querySelectorAll('[role="menuitem"]')).find(el => el.textContent === 'Explain Component') ?? null);
    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });

    openToolsMenu();
    click(Array.from(container.querySelectorAll('[role="menuitem"]')).find(el => el.textContent === 'Analyze Circuit') ?? null);
    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });

    const text = chatText();
    expect(text).toContain('[Tool] Explain Component');
    expect(text).toContain('select or add a component');
    expect(text).toContain('[Tool] Analyze Circuit');
    expect(text).toContain('nothing to analyze');
  });
});
