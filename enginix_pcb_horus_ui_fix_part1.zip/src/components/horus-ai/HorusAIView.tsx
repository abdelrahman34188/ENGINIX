/**
 * HORUS AI Assistant page.
 *
 * UI-only: the five action cards that used to sit here are gone from
 * this page's markup only — `IntentRouter`, the intents themselves,
 * and every handler/API they route to are untouched and still exist
 * exactly as before. The freed space is now occupied by the existing
 * `HorusWorkspace` chat component (the same one already used inside
 * the Electrical Lab's own HORUS tab) — reused here as-is, not a new
 * or modified chat implementation.
 */

import HorusWorkspace, { type HorusWorkspaceProps } from './HorusWorkspace';

export default function HorusAIView({ onOpenPCB }: HorusWorkspaceProps = {}) {
  return (
    <div className="flex flex-col items-center px-6 py-6 h-full min-h-0">
      <h1 className="text-3xl font-bold text-slate-100 tracking-tight text-center">HORUS</h1>
      <p className="mt-2 text-sm text-amber-400 font-mono text-center">Electrical Engineering Copilot</p>

      <div className="mt-6 w-full max-w-5xl flex-1 min-h-0">
        <HorusWorkspace onOpenPCB={onOpenPCB} />
      </div>
    </div>
  );
}
