/**
 * ResizablePanel - a VS Code / Visual Studio style bottom panel: a fixed
 * header (title + optional right-aligned controls) above a scrollable body
 * that can be collapsed via the header chevron and resized by dragging its
 * bottom edge. Height and collapsed state are remembered per `id` via
 * panelLayoutStorage, so panels reopen the way the user last left them.
 *
 * Used only by CodingLab's bottom panels (Status, Serial Monitor, Pin
 * Mapping, Pin Inspector, Component Map, Compatibility tests) - it doesn't
 * touch anything outside the Coding page.
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ChevronDown, GripHorizontal } from 'lucide-react';
import { getPanelLayout, savePanelLayout } from '../lib/panelLayoutStorage';

interface ResizablePanelProps {
  /** Stable id used as the persistence key for remembered height/collapsed state. */
  id: string;
  /** Header label content (left side, after the collapse chevron). */
  title: React.ReactNode;
  /** Optional right-aligned header controls (buttons etc.) - rendered exactly as passed, never reordered. */
  headerRight?: React.ReactNode;
  defaultHeight?: number;
  minHeight?: number;
  maxHeight?: number;
  className?: string;
  /** Ref to the scrollable body element, for callers that need to control scroll position (e.g. Serial Monitor auto-scroll). */
  bodyRef?: React.Ref<HTMLDivElement>;
  children: React.ReactNode;
}

const ResizablePanel: React.FC<ResizablePanelProps> = ({
  id,
  title,
  headerRight,
  defaultHeight = 180,
  minHeight = 72,
  maxHeight = 560,
  className = '',
  bodyRef,
  children,
}) => {
  const [height, setHeight] = useState<number>(() => getPanelLayout(id)?.height ?? defaultHeight);
  const [collapsed, setCollapsed] = useState<boolean>(() => getPanelLayout(id)?.collapsed ?? false);
  // Tracks an in-progress drag so the body's height transition (used for the
  // collapse/expand animation) can be suspended while resizing - otherwise
  // every pixel of drag movement would animate instead of tracking the
  // pointer 1:1.
  const [isDragging, setIsDragging] = useState(false);
  const draggingRef = useRef(false);
  const dragStartRef = useRef({ y: 0, height });

  const toggleCollapsed = useCallback(() => {
    setCollapsed(prev => {
      const next = !prev;
      savePanelLayout(id, { height, collapsed: next });
      return next;
    });
  }, [id, height]);

  const onHandleMouseDown = useCallback((e: React.MouseEvent) => {
    draggingRef.current = true;
    dragStartRef.current = { y: e.clientY, height };
    setIsDragging(true);
    document.body.style.cursor = 'row-resize';
    document.body.style.userSelect = 'none';
    e.preventDefault();
  }, [height]);

  useEffect(() => {
    function onMove(e: MouseEvent) {
      if (!draggingRef.current) return;
      const delta = e.clientY - dragStartRef.current.y;
      const next = Math.min(maxHeight, Math.max(minHeight, dragStartRef.current.height + delta));
      setHeight(next);
    }
    function onUp() {
      if (!draggingRef.current) return;
      draggingRef.current = false;
      setIsDragging(false);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      setHeight(current => {
        savePanelLayout(id, { height: current, collapsed });
        return current;
      });
    }
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, [id, collapsed, minHeight, maxHeight]);

  return (
    <div
      className={`flex flex-col overflow-hidden rounded-md border border-slate-700/70 bg-slate-950/60 text-xs shadow-sm shadow-black/20 transition-colors duration-150 hover:border-slate-600/80 ${className}`}
    >
      <div className="shrink-0 flex items-center justify-between gap-1 flex-wrap px-3 py-2 border-b border-slate-800 bg-slate-950/80 transition-colors duration-150">
        <div className="flex items-center gap-2 min-w-0">
          <button
            type="button"
            onClick={toggleCollapsed}
            title={collapsed ? 'Expand panel' : 'Collapse panel'}
            aria-expanded={!collapsed}
            className="flex items-center justify-center shrink-0 w-5 h-5 -ml-1 rounded text-slate-500 transition-all duration-150 hover:bg-slate-800 hover:text-amber-400"
          >
            <ChevronDown
              size={13}
              className="transition-transform duration-200 ease-out"
              style={{ transform: collapsed ? 'rotate(-90deg)' : 'rotate(0deg)' }}
            />
          </button>
          <div className="flex items-center gap-1 min-w-0 text-slate-400 font-semibold uppercase tracking-wide text-[10.5px] flex-wrap">
            {title}
          </div>
        </div>
        {headerRight && <div className="flex items-center gap-1 shrink-0">{headerRight}</div>}
      </div>

      {/* Collapse/expand is animated via the classic grid-template-rows
          0fr -> 1fr trick: the body stays mounted (so height transitions
          smoothly instead of popping), and min-h-0 + overflow-hidden on the
          inner wrapper let the grid track actually shrink to zero. */}
      <div
        className="grid transition-[grid-template-rows] duration-200 ease-out"
        style={{ gridTemplateRows: collapsed ? '0fr' : '1fr' }}
      >
        <div className="min-h-0 overflow-hidden">
          <div
            ref={bodyRef}
            className="panel-scroll overflow-y-auto overflow-x-auto overscroll-contain"
            style={{ height, transition: isDragging ? 'none' : 'height 150ms ease-out' }}
          >
            {children}
          </div>
          <div
            onMouseDown={onHandleMouseDown}
            title="Drag to resize"
            role="separator"
            aria-orientation="horizontal"
            className="shrink-0 h-2.5 cursor-row-resize flex items-center justify-center bg-slate-900/60 border-t border-slate-800 transition-colors duration-150 hover:bg-slate-800 active:bg-slate-800 group touch-none"
          >
            <GripHorizontal size={12} className="text-slate-600 transition-colors duration-150 group-hover:text-amber-400/70 pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResizablePanel;
