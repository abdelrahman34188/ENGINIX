/**
 * codeTemplates - per-language definitions for the Coding workspace.
 *
 * Kept separate from CodingLab.tsx so adding/adjusting a language's
 * template, Monaco grammar, or file extension never touches the Arduino
 * runtime wiring. Only the 'arduino' entry is ever fed to ArduinoRuntime
 * (see CodingLab's handleRun) - the other four are editor-only (syntax
 * highlighting + auto completion + their own template), same as any other
 * language a general-purpose code editor supports without an execution
 * backend for it.
 */

export type Language = 'arduino' | 'cpp' | 'python' | 'java' | 'javascript';

export interface LanguageDef {
  /** Shown in the language selector. */
  label: string;
  /** Monaco's built-in language id, drives syntax highlighting + auto completion. */
  monacoLanguage: string;
  /** File extension (including the dot) shown next to the selector and used for Download. */
  extension: string;
  /** This language's own independent starter code - switching languages never mixes buffers. */
  template: string;
}

const ARDUINO_TEMPLATE = `// Blink the LED wired to pin 13
void setup() {
  pinMode(13, OUTPUT);
}

void loop() {
  digitalWrite(13, HIGH);
  delay(500);
  digitalWrite(13, LOW);
  delay(500);
}
`;

const CPP_TEMPLATE = `#include <iostream>

int main() {
    std::cout << "Hello, world!" << std::endl;
    return 0;
}
`;

const PYTHON_TEMPLATE = `def main():
    print("Hello, world!")


if __name__ == "__main__":
    main()
`;

const JAVA_TEMPLATE = `public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}
`;

const JAVASCRIPT_TEMPLATE = `function main() {
  console.log("Hello, world!");
}

main();
`;

export const LANGUAGE_DEFS: Record<Language, LanguageDef> = {
  arduino: { label: 'Arduino C++', monacoLanguage: 'cpp', extension: '.ino', template: ARDUINO_TEMPLATE },
  cpp: { label: 'Standard C++', monacoLanguage: 'cpp', extension: '.cpp', template: CPP_TEMPLATE },
  python: { label: 'Python', monacoLanguage: 'python', extension: '.py', template: PYTHON_TEMPLATE },
  java: { label: 'Java', monacoLanguage: 'java', extension: '.java', template: JAVA_TEMPLATE },
  javascript: { label: 'JavaScript', monacoLanguage: 'javascript', extension: '.js', template: JAVASCRIPT_TEMPLATE },
};

export const LANGUAGE_ORDER: Language[] = ['arduino', 'cpp', 'python', 'java', 'javascript'];
