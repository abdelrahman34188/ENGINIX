import { describe, it, expect } from 'vitest';

/**
 * Regression coverage for the Coding page paste bug: Monaco Editor only
 * receives pasted content via the browser's native 'paste' ClipboardEvent,
 * which the browser only dispatches as the *default action* of a Ctrl+V/
 * Cmd+V keydown once that keydown finishes bubbling with nothing having
 * called preventDefault() on it anywhere along the way - even Monaco's own
 * target-phase handling running first ("typing works") doesn't stop a
 * later ancestor/global listener from still cancelling that default action.
 * CodeEditor.tsx now stops that keydown from propagating past the editor's
 * own DOM node once Monaco has had first crack at it, so nothing outside
 * the editor - now or added later - can ever suppress the native paste.
 */
describe('CodeEditor paste isolation', () => {
  it('preventDefault() from an ancestor listener (after the target already ran) still cancels the browser default action', () => {
    const container = document.createElement('div');
    const textarea = document.createElement('textarea');
    container.appendChild(textarea);
    document.body.appendChild(container);

    let targetSawIt = false;
    textarea.addEventListener('keydown', () => {
      targetSawIt = true;
    });

    let outerSawIt = false;
    window.addEventListener('keydown', (e) => {
      outerSawIt = true;
      e.preventDefault();
    });

    const event = new KeyboardEvent('keydown', { key: 'v', ctrlKey: true, bubbles: true, cancelable: true });
    textarea.dispatchEvent(event);

    expect(targetSawIt).toBe(true);
    expect(outerSawIt).toBe(true);
    expect(event.defaultPrevented).toBe(true);

    document.body.removeChild(container);
  });

  it('stopping propagation at an ancestor of the target prevents any outer listener from ever seeing (or cancelling) the event', () => {
    const container = document.createElement('div');
    const textarea = document.createElement('textarea');
    container.appendChild(textarea);
    document.body.appendChild(container);

    container.addEventListener('keydown', (e) => {
      const isPasteChord = (e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v';
      if (isPasteChord) e.stopPropagation();
    });

    let outerSawIt = false;
    window.addEventListener('keydown', (e) => {
      outerSawIt = true;
      e.preventDefault();
    });

    const event = new KeyboardEvent('keydown', { key: 'v', ctrlKey: true, bubbles: true, cancelable: true });
    textarea.dispatchEvent(event);

    expect(outerSawIt).toBe(false);
    expect(event.defaultPrevented).toBe(false);

    document.body.removeChild(container);
  });
});
