/**
 * useWorkspacePanel
 *
 * Shared logic for a resizable, collapsible side panel whose width and
 * collapsed state persist across reloads. Used by Workspace Mode to give
 * the Component Palette / Property Panel an EasyEDA/KiCad-style feel
 * without duplicating drag/persist logic in every consumer.
 *
 * Purely additive: existing fixed-width panels keep working exactly as
 * before if this hook isn't used.
 */
import { useCallback, useEffect, useRef, useState } from 'react';

interface UseWorkspacePanelOptions {
  /** localStorage key prefix, e.g. "enginix.workspace.leftPanel" */
  storageKey: string;
  defaultWidth: number;
  minWidth?: number;
  maxWidth?: number;
  /** 'left' panels grow the drag handle to the right edge, 'right' to the left edge */
  side: 'left' | 'right';
}

interface PersistedPanelState {
  width: number;
  collapsed: boolean;
}

function readPersisted(storageKey: string, fallback: PersistedPanelState): PersistedPanelState {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(storageKey);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    if (typeof parsed.width === 'number' && typeof parsed.collapsed === 'boolean') {
      return parsed;
    }
    return fallback;
  } catch {
    return fallback;
  }
}

export function useWorkspacePanel({
  storageKey,
  defaultWidth,
  minWidth = 160,
  maxWidth = 480,
  side,
}: UseWorkspacePanelOptions) {
  const [{ width, collapsed }, setState] = useState<PersistedPanelState>(() =>
    readPersisted(storageKey, { width: defaultWidth, collapsed: false })
  );
  const isDragging = useRef(false);
  const dragStartX = useRef(0);
  const dragStartWidth = useRef(defaultWidth);

  // Persist on every change (debounced via microtask is unnecessary here —
  // writes are cheap and infrequent).
  useEffect(() => {
    try {
      window.localStorage.setItem(storageKey, JSON.stringify({ width, collapsed }));
    } catch {
      // Storage may be unavailable (private mode, quota) — fail silently,
      // panel just won't remember its size this session.
    }
  }, [storageKey, width, collapsed]);

  const clampWidth = useCallback(
    (w: number) => Math.min(maxWidth, Math.max(minWidth, w)),
    [minWidth, maxWidth]
  );

  const onDragStart = useCallback(
    (e: React.PointerEvent) => {
      isDragging.current = true;
      dragStartX.current = e.clientX;
      dragStartWidth.current = width;
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    },
    [width]
  );

  const onDragMove = useCallback(
    (e: React.PointerEvent) => {
      if (!isDragging.current) return;
      const delta = e.clientX - dragStartX.current;
      const signedDelta = side === 'left' ? delta : -delta;
      setState(prev => ({ ...prev, width: clampWidth(dragStartWidth.current + signedDelta) }));
    },
    [clampWidth, side]
  );

  const onDragEnd = useCallback((e: React.PointerEvent) => {
    isDragging.current = false;
    (e.target as HTMLElement).releasePointerCapture(e.pointerId);
  }, []);

  const toggleCollapsed = useCallback(() => {
    setState(prev => ({ ...prev, collapsed: !prev.collapsed }));
  }, []);

  return {
    width,
    collapsed,
    toggleCollapsed,
    dragHandleProps: {
      onPointerDown: onDragStart,
      onPointerMove: onDragMove,
      onPointerUp: onDragEnd,
    },
  };
}
