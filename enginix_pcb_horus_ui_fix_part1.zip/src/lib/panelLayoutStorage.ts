/**
 * panelLayoutStorage — remembers per-panel height + collapsed/expanded state
 * for the Coding page's bottom panels (Status, Serial Monitor, Pin Mapping,
 * Pin Inspector, Component Map, Compatibility tests).
 *
 * Stored locally in localStorage, separate from codeFileStorage.ts (which
 * persists source files/tabs, not panel layout). Scoped entirely to the
 * Coding page — nothing else reads or writes this key.
 */

const KEY = 'enginix_coding_panel_layout';

export interface PanelLayoutEntry {
  /** Panel body height in pixels. */
  height: number;
  /** Whether the panel is currently collapsed. Omit for panels with no collapsed state (e.g. the always-visible Bottom Dock). */
  collapsed?: boolean;
}

type PanelLayout = Record<string, PanelLayoutEntry>;

function readLayout(): PanelLayout {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function writeLayout(layout: PanelLayout): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(layout));
  } catch {
    // localStorage unavailable (e.g. private browsing) — fail silently
  }
}

/** Remembered height/collapsed state for one panel, or null if never set. */
export function getPanelLayout(id: string): PanelLayoutEntry | null {
  const entry = readLayout()[id];
  return entry ?? null;
}

/** Persists a panel's height/collapsed state, leaving other panels untouched. */
export function savePanelLayout(id: string, entry: PanelLayoutEntry): void {
  const layout = readLayout();
  layout[id] = entry;
  writeLayout(layout);
}
