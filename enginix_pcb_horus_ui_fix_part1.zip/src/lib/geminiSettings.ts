/**
 * Gemini AI settings — persistence for the Gemini API key.
 * Stored in localStorage so it survives page reloads.
 */

const GEMINI_API_KEY_STORAGE_KEY = 'enginix_gemini_api_key';

/** Read the saved Gemini API key from localStorage (empty string if none). */
export function getGeminiApiKey(): string {
  try {
    return localStorage.getItem(GEMINI_API_KEY_STORAGE_KEY) ?? '';
  } catch {
    return '';
  }
}

/** Save (or clear, if empty) the Gemini API key to localStorage. */
export function setGeminiApiKey(apiKey: string): void {
  try {
    if (apiKey) {
      localStorage.setItem(GEMINI_API_KEY_STORAGE_KEY, apiKey);
    } else {
      localStorage.removeItem(GEMINI_API_KEY_STORAGE_KEY);
    }
  } catch {
    // localStorage unavailable (e.g. private browsing) — fail silently
  }
}
