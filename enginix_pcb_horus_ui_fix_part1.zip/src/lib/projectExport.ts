/**
 * Project export/import — builds a download payload for a saved project
 * and validates/parses files produced by that export. Contains circuit
 * components, connections, properties, simulation settings, and metadata
 * only. No AI-related data.
 */

import type { SavedProject, SavedProjectSimulationSettings } from './projectStorage';

export type ExportFormat = 'json' | 'enginix';

/**
 * Build the exported project object for a saved project.
 * Component properties are already embedded on each component
 * (component.props), so they travel with `components` — no
 * separate properties block is needed to satisfy that requirement.
 */
function buildExportPayload(project: SavedProject, format: ExportFormat) {
  let components: unknown[] = [];
  let connections: unknown[] = [];

  try {
    const parsed = JSON.parse(project.circuit);
    components = Array.isArray(parsed.components) ? parsed.components : [];
    connections = Array.isArray(parsed.wires) ? parsed.wires : [];
  } catch {
    // Malformed/empty circuit — export empty component/connection lists.
  }

  return {
    metadata: {
      format: format === 'enginix' ? 'ENGINIX Project File' : 'JSON',
      name: project.name,
      description: project.description,
      createdAt: project.createdAt,
      updatedAt: project.updatedAt,
      exportedAt: new Date().toISOString(),
    },
    components,
    connections,
    simulationSettings: project.simulationSettings,
  };
}

function slugifyFilename(name: string): string {
  const trimmed = name.trim();
  return trimmed.length > 0 ? trimmed.replace(/[\\/:*?"<>|]+/g, '_') : 'circuit-project';
}

function downloadBlob(filename: string, content: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Export a saved project as a file download in the given format.
 * - 'json': plain .json file
 * - 'enginix': .enginix ENGINIX Project File (same structure, distinct extension/type marker)
 */
export function exportProject(project: SavedProject, format: ExportFormat): void {
  const payload = buildExportPayload(project, format);
  const content = JSON.stringify(payload, null, 2);
  const base = slugifyFilename(project.name);

  if (format === 'json') {
    downloadBlob(`${base}.json`, content, 'application/json');
  } else {
    downloadBlob(`${base}.enginix`, content, 'application/vnd.enginix.project+json');
  }
}

/**
 * Error thrown when an imported file fails validation. `message` is
 * always safe to show directly to the user.
 */
export class ProjectImportError extends Error {}

const SIMULATION_SETTING_KEYS: Array<keyof SavedProjectSimulationSettings> = [
  'zoom', 'showGrid', 'simRunning', 'scale', 'offsetX', 'offsetY',
];

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function validateSimulationSettings(value: unknown): SavedProjectSimulationSettings {
  if (!isPlainObject(value)) {
    throw new ProjectImportError('The file is missing simulation settings.');
  }
  for (const key of SIMULATION_SETTING_KEYS) {
    if (!(key in value)) {
      throw new ProjectImportError(`The file's simulation settings are missing "${key}".`);
    }
  }
  const { zoom, showGrid, simRunning, scale, offsetX, offsetY } = value as Record<string, unknown>;
  if (typeof zoom !== 'number' || typeof scale !== 'number' || typeof offsetX !== 'number' || typeof offsetY !== 'number') {
    throw new ProjectImportError('The file has invalid simulation settings values.');
  }
  if (typeof showGrid !== 'boolean' || typeof simRunning !== 'boolean') {
    throw new ProjectImportError('The file has invalid simulation settings values.');
  }
  return { zoom, showGrid, simRunning, scale, offsetX, offsetY };
}

/**
 * Validate and parse the text content of an imported project file
 * (as produced by exportProject, either .json or .enginix).
 * Throws ProjectImportError with a user-readable message on any
 * validation failure. Never throws anything else — unexpected errors
 * are wrapped into a ProjectImportError.
 */
export function parseImportedProject(fileText: string): {
  name: string;
  description: string;
  circuit: string;
  simulationSettings: SavedProjectSimulationSettings;
  componentCount: number;
  wireCount: number;
} {
  let data: unknown;
  try {
    data = JSON.parse(fileText);
  } catch {
    throw new ProjectImportError('This file is not valid JSON and could not be read.');
  }

  try {
    if (!isPlainObject(data)) {
      throw new ProjectImportError('This file does not contain a valid ENGINIX project.');
    }

    const { metadata, components, connections, simulationSettings } = data as Record<string, unknown>;

    if (!isPlainObject(metadata)) {
      throw new ProjectImportError('The file is missing project metadata.');
    }
    const name = typeof metadata.name === 'string' && metadata.name.trim() ? metadata.name.trim() : 'Imported Project';
    const description = typeof metadata.description === 'string' ? metadata.description : '';

    if (!Array.isArray(components)) {
      throw new ProjectImportError('The file is missing its component list.');
    }
    if (!Array.isArray(connections)) {
      throw new ProjectImportError('The file is missing its connection list.');
    }

    const validatedSettings = validateSimulationSettings(simulationSettings);

    const circuit = JSON.stringify({ components, wires: connections });

    return {
      name,
      description,
      circuit,
      simulationSettings: validatedSettings,
      componentCount: components.length,
      wireCount: connections.length,
    };
  } catch (e) {
    if (e instanceof ProjectImportError) throw e;
    throw new ProjectImportError('This file could not be read as a valid ENGINIX project.');
  }
}
