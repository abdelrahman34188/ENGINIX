/**
 * codeFileStorage — persistence for Coding Lab source files (New/Open/Save/
 * Save As/Rename/Delete, remembered open tabs, autosave setting).
 *
 * Stored locally in localStorage (no cloud/backend), separate from
 * projectStorage.ts (which persists whole circuit projects, not code files).
 *
 * Files are tagged with a `language` string matching CodingLab's Language
 * union ('arduino' | 'cpp' | 'python' | 'java' | 'javascript'). Every read
 * that lists files can be filtered by language, which is what keeps Arduino
 * sketches independent from the other languages — they're simply never
 * mixed into the same list, the same way each language already keeps its
 * own independent in-memory buffer today.
 */

const FILES_KEY = 'enginix_code_files';
const SESSION_KEY = 'enginix_code_session';

export interface CodeFile {
  id: string;
  language: string;
  name: string;
  code: string;
  createdAt: string;
  updatedAt: string;
}

/** Per-language remembered open tabs + active tab + the autosave toggle. */
export interface CodeSession {
  /** Ordered list of saved file ids that were open as tabs, per language. */
  openFileIds: Record<string, string[]>;
  /** Which file id (if any) was the active tab, per language. */
  activeFileId: Record<string, string | null>;
  autosave: boolean;
}

function generateFileId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  return `file_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

function readFiles(): CodeFile[] {
  try {
    const raw = localStorage.getItem(FILES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeFiles(files: CodeFile[]): void {
  try {
    localStorage.setItem(FILES_KEY, JSON.stringify(files));
  } catch {
    // localStorage unavailable (e.g. private browsing) — fail silently
  }
}

/** All saved files for a language, newest-updated first. Omit `language` for every file. */
export function getCodeFiles(language?: string): CodeFile[] {
  const files = readFiles().sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  return language ? files.filter(f => f.language === language) : files;
}

export function getCodeFile(id: string): CodeFile | null {
  return readFiles().find(f => f.id === id) ?? null;
}

/** True if `name` is already used by another saved file of the same language. */
export function isNameTaken(language: string, name: string, excludeId?: string): boolean {
  return readFiles().some(f => f.language === language && f.name === name && f.id !== excludeId);
}

export function createCodeFile(language: string, name: string, code: string): CodeFile {
  const now = new Date().toISOString();
  const file: CodeFile = { id: generateFileId(), language, name, code, createdAt: now, updatedAt: now };
  const files = readFiles();
  files.push(file);
  writeFiles(files);
  return file;
}

/** Save (overwrite) an existing file's code. Returns null if the id doesn't exist. */
export function saveCodeFile(id: string, code: string): CodeFile | null {
  const files = readFiles();
  const index = files.findIndex(f => f.id === id);
  if (index === -1) return null;
  files[index] = { ...files[index], code, updatedAt: new Date().toISOString() };
  writeFiles(files);
  return files[index];
}

export function renameCodeFile(id: string, name: string): CodeFile | null {
  const files = readFiles();
  const index = files.findIndex(f => f.id === id);
  if (index === -1) return null;
  files[index] = { ...files[index], name, updatedAt: new Date().toISOString() };
  writeFiles(files);
  return files[index];
}

export function deleteCodeFile(id: string): boolean {
  const files = readFiles();
  const next = files.filter(f => f.id !== id);
  if (next.length === files.length) return false;
  writeFiles(next);
  return true;
}

const DEFAULT_SESSION: CodeSession = { openFileIds: {}, activeFileId: {}, autosave: false };

export function getCodeSession(): CodeSession {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return { ...DEFAULT_SESSION, openFileIds: {}, activeFileId: {} };
    const parsed = JSON.parse(raw);
    return {
      openFileIds: parsed.openFileIds ?? {},
      activeFileId: parsed.activeFileId ?? {},
      autosave: !!parsed.autosave,
    };
  } catch {
    return { ...DEFAULT_SESSION, openFileIds: {}, activeFileId: {} };
  }
}

export function saveCodeSession(session: CodeSession): void {
  try {
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  } catch {
    // fail silently
  }
}
