/**
 * Multi-provider AI settings — persistence for per-provider configuration
 * (API key, model, temperature, max tokens). Stored in localStorage, one
 * entry per provider, so each provider's config survives page reloads
 * independently of the others.
 *
 * Frontend only: this module does not call any AI API. It just stores and
 * retrieves whatever the user has typed into the Settings panel.
 */

export type AIProviderId =
  | 'gemini'
  | 'claude'
  | 'openai'
  | 'deepseek'
  | 'grok'
  | 'openrouter';

export interface AIProviderConfig {
  apiKey: string;
  model: string;
  temperature: number;
  maxTokens: number;
}

export const AI_PROVIDERS: { id: AIProviderId; label: string }[] = [
  { id: 'gemini', label: 'Gemini' },
  { id: 'claude', label: 'Claude' },
  { id: 'openai', label: 'OpenAI' },
  { id: 'deepseek', label: 'DeepSeek' },
  { id: 'grok', label: 'Grok' },
  { id: 'openrouter', label: 'OpenRouter' },
];

export const DEFAULT_PROVIDER_CONFIG: AIProviderConfig = {
  apiKey: '',
  model: '',
  temperature: 0.7,
  maxTokens: 2048,
};

const STORAGE_PREFIX = 'enginix_ai_provider_config_';

/** Read the saved config for a provider from localStorage (defaults if none). */
export function getProviderConfig(providerId: AIProviderId): AIProviderConfig {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + providerId);
    if (!raw) return { ...DEFAULT_PROVIDER_CONFIG };
    const parsed = JSON.parse(raw);
    return {
      apiKey: typeof parsed.apiKey === 'string' ? parsed.apiKey : '',
      model: typeof parsed.model === 'string' ? parsed.model : '',
      temperature:
        typeof parsed.temperature === 'number'
          ? parsed.temperature
          : DEFAULT_PROVIDER_CONFIG.temperature,
      maxTokens:
        typeof parsed.maxTokens === 'number'
          ? parsed.maxTokens
          : DEFAULT_PROVIDER_CONFIG.maxTokens,
    };
  } catch {
    return { ...DEFAULT_PROVIDER_CONFIG };
  }
}

/** Save a provider's config to localStorage. */
export function setProviderConfig(providerId: AIProviderId, config: AIProviderConfig): void {
  try {
    localStorage.setItem(STORAGE_PREFIX + providerId, JSON.stringify(config));
  } catch {
    // localStorage unavailable (e.g. private browsing) — fail silently
  }
}

/** Clear a provider's saved config back to defaults. */
export function clearProviderConfig(providerId: AIProviderId): void {
  try {
    localStorage.removeItem(STORAGE_PREFIX + providerId);
  } catch {
    // localStorage unavailable — fail silently
  }
}
