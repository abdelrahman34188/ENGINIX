/**
 * Project storage — persistence for saved circuit and PCB projects.
 * Stored locally in localStorage (no cloud storage / backend).
 */

import type { Side } from '../pcb/types';

const PROJECTS_STORAGE_KEY = 'enginix_saved_projects';

export interface SavedProjectSimulationSettings {
  zoom: number;
  showGrid: boolean;
  simRunning: boolean;
  scale: number;
  offsetX: number;
  offsetY: number;
}

/** Distinguishes which lab a saved project belongs to. Projects saved
 * before this field existed have no `kind` in storage — getSavedProjects()
 * treats those as `'circuit'` for backward compatibility. */
export type ProjectKind = 'circuit' | 'pcb';

/** Camera/view state for a saved PCB project, so reopening it looks
 * exactly as it did when saved. */
export interface SavedPCBViewSettings {
  scale: number;
  offsetX: number;
  offsetY: number;
  activeLayer: Side;
  showRatsnest: boolean;
}

/** Everything needed to restore a PCB board exactly. */
export interface SavedPCBData {
  /** Raw JSON.stringify(engine.state) — board size, components (position,
   * rotation, side, props), traces (routing), vias, and netlist. */
  boardState: string;
  view: SavedPCBViewSettings;
  /** The board's copper layer set (e.g. ['top', 'bottom']). */
  layers: Side[];
}

export interface SavedProject {
  id: string;
  /** 'circuit' when absent (see ProjectKind). */
  kind?: ProjectKind;
  name: string;
  description: string;
  /** Raw exportCircuit() JSON string — components, wires, values, positions, rotation.
   * Present for `kind: 'circuit'` projects. */
  circuit?: string;
  simulationSettings?: SavedProjectSimulationSettings;
  componentCount: number;
  wireCount?: number;
  /** Present for `kind: 'pcb'` projects. */
  pcb?: SavedPCBData;
  traceCount?: number;
  viaCount?: number;
  /** Compressed canvas snapshot (~300x200 data URL). Absent if capture failed. */
  thumbnail?: string;
  createdAt: string;
  updatedAt: string;
}

function generateProjectId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  return `proj_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

const THUMBNAIL_WIDTH = 300;
const THUMBNAIL_HEIGHT = 200;

/**
 * Downscale a canvas into a compressed ~300x200 JPEG data URL for use as
 * a project thumbnail. Returns undefined (never throws) if capture fails
 * for any reason, so callers can fall back to the placeholder.
 */
export function captureCanvasThumbnail(source: HTMLCanvasElement): string | undefined {
  try {
    if (!source.width || !source.height) return undefined;

    const off = document.createElement('canvas');
    off.width = THUMBNAIL_WIDTH;
    off.height = THUMBNAIL_HEIGHT;
    const ctx = off.getContext('2d');
    if (!ctx) return undefined;

    // Letterbox-fit the source canvas into the thumbnail box, preserving aspect ratio.
    const scale = Math.min(THUMBNAIL_WIDTH / source.width, THUMBNAIL_HEIGHT / source.height);
    const drawW = source.width * scale;
    const drawH = source.height * scale;
    const dx = (THUMBNAIL_WIDTH - drawW) / 2;
    const dy = (THUMBNAIL_HEIGHT - drawH) / 2;

    ctx.fillStyle = '#0f172a'; // matches gallery card background (slate-900-ish)
    ctx.fillRect(0, 0, THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT);
    ctx.drawImage(source, 0, 0, source.width, source.height, dx, dy, drawW, drawH);

    return off.toDataURL('image/jpeg', 0.6);
  } catch {
    return undefined;
  }
}

/** Read all saved projects from localStorage (newest first). */
export function getSavedProjects(): SavedProject[] {
  try {
    const raw = localStorage.getItem(PROJECTS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    // Projects saved before `kind` existed are circuit projects.
    return (parsed as SavedProject[]).map(p => ({ kind: 'circuit' as ProjectKind, ...p }));
  } catch {
    return [];
  }
}

function writeSavedProjects(projects: SavedProject[]): void {
  try {
    localStorage.setItem(PROJECTS_STORAGE_KEY, JSON.stringify(projects));
  } catch {
    // localStorage unavailable (e.g. private browsing) — fail silently
  }
}

/**
 * Save a new project locally. Generates a unique ID and timestamps.
 * Returns the stored project (including its new id).
 */
export function saveProject(input: {
  name: string;
  description: string;
  circuit: string;
  simulationSettings: SavedProjectSimulationSettings;
  componentCount: number;
  wireCount: number;
  thumbnail?: string;
}): SavedProject {
  const now = new Date().toISOString();
  const project: SavedProject = {
    id: generateProjectId(),
    kind: 'circuit',
    name: input.name,
    description: input.description,
    circuit: input.circuit,
    simulationSettings: input.simulationSettings,
    componentCount: input.componentCount,
    wireCount: input.wireCount,
    thumbnail: input.thumbnail,
    createdAt: now,
    updatedAt: now,
  };

  const projects = getSavedProjects();
  projects.unshift(project);
  writeSavedProjects(projects);

  return project;
}

/**
 * Save a new PCB project locally. Generates a unique ID and timestamps.
 * Mirrors saveProject() but for PCB boards (kind: 'pcb'). Always creates a
 * brand-new project — never overwrites an existing one. Returns the stored
 * project (including its new id).
 */
export function savePCBProject(input: {
  name: string;
  description: string;
  boardState: string;
  view: SavedPCBViewSettings;
  layers: Side[];
  componentCount: number;
  traceCount: number;
  viaCount: number;
  thumbnail?: string;
}): SavedProject {
  const now = new Date().toISOString();
  const project: SavedProject = {
    id: generateProjectId(),
    kind: 'pcb',
    name: input.name,
    description: input.description,
    pcb: {
      boardState: input.boardState,
      view: input.view,
      layers: input.layers,
    },
    componentCount: input.componentCount,
    traceCount: input.traceCount,
    viaCount: input.viaCount,
    thumbnail: input.thumbnail,
    createdAt: now,
    updatedAt: now,
  };

  const projects = getSavedProjects();
  projects.unshift(project);
  writeSavedProjects(projects);

  return project;
}

/**
 * Update an existing saved project by id — same id and createdAt are kept,
 * only the content and updatedAt change. Returns null if no project with
 * that id exists (nothing is created in that case).
 */
export function updateProject(
  id: string,
  input: {
    name: string;
    description: string;
    circuit: string;
    simulationSettings: SavedProjectSimulationSettings;
    componentCount: number;
    wireCount: number;
    thumbnail?: string;
  }
): SavedProject | null {
  const projects = getSavedProjects();
  const index = projects.findIndex(p => p.id === id);
  if (index === -1) return null;

  const updated: SavedProject = {
    ...projects[index],
    name: input.name,
    description: input.description,
    circuit: input.circuit,
    simulationSettings: input.simulationSettings,
    componentCount: input.componentCount,
    wireCount: input.wireCount,
    // Keep the previous thumbnail if this save didn't produce a new one.
    thumbnail: input.thumbnail ?? projects[index].thumbnail,
    updatedAt: new Date().toISOString(),
  };

  projects[index] = updated;
  writeSavedProjects(projects);

  return updated;
}

/**
 * Update an existing saved PCB project by id — same id and createdAt are
 * kept, only the content and updatedAt change. Mirrors updateProject() but
 * for PCB boards. Returns null if no project with that id exists (nothing
 * is created in that case). This is the ONLY way an existing PCB project
 * is ever overwritten — it is called exclusively from Project Gallery's
 * Update action, never automatically.
 */
export function updatePCBProject(
  id: string,
  input: {
    name: string;
    description: string;
    boardState: string;
    view: SavedPCBViewSettings;
    layers: Side[];
    componentCount: number;
    traceCount: number;
    viaCount: number;
    thumbnail?: string;
  }
): SavedProject | null {
  const projects = getSavedProjects();
  const index = projects.findIndex(p => p.id === id);
  if (index === -1) return null;

  const updated: SavedProject = {
    ...projects[index],
    kind: 'pcb',
    name: input.name,
    description: input.description,
    pcb: {
      boardState: input.boardState,
      view: input.view,
      layers: input.layers,
    },
    componentCount: input.componentCount,
    traceCount: input.traceCount,
    viaCount: input.viaCount,
    // Keep the previous thumbnail if this save didn't produce a new one.
    thumbnail: input.thumbnail ?? projects[index].thumbnail,
    updatedAt: new Date().toISOString(),
  };

  projects[index] = updated;
  writeSavedProjects(projects);

  return updated;
}

/**
 * Delete a saved project by id. Returns true if a project was removed,
 * false if no project with that id existed.
 */
export function deleteProject(id: string): boolean {
  const projects = getSavedProjects();
  const next = projects.filter(p => p.id !== id);
  if (next.length === projects.length) return false;

  writeSavedProjects(next);
  return true;
}

/**
 * Rename a saved project by id (updates name only, bumps updatedAt).
 * Returns the updated project, or null if no project with that id exists.
 */
export function renameProject(id: string, name: string): SavedProject | null {
  const projects = getSavedProjects();
  const index = projects.findIndex(p => p.id === id);
  if (index === -1) return null;

  const updated: SavedProject = {
    ...projects[index],
    name,
    updatedAt: new Date().toISOString(),
  };

  projects[index] = updated;
  writeSavedProjects(projects);

  return updated;
}

/**
 * Duplicate a saved project by id. The copy gets a new id, fresh
 * createdAt/updatedAt timestamps, and "(Copy)" appended to its name.
 * Returns the new project, or null if no project with that id exists.
 */
export function duplicateProject(id: string): SavedProject | null {
  const projects = getSavedProjects();
  const sourceIndex = projects.findIndex(p => p.id === id);
  if (sourceIndex === -1) return null;

  const now = new Date().toISOString();
  const copy: SavedProject = {
    ...projects[sourceIndex],
    id: generateProjectId(),
    name: `${projects[sourceIndex].name} (Copy)`,
    createdAt: now,
    updatedAt: now,
  };

  // Insert right after the source project, matching newest-first ordering.
  projects.splice(sourceIndex + 1, 0, copy);
  writeSavedProjects(projects);

  return copy;
}
