/**
 * ENGINIX - Engineering Platform
 * Complete React application with all original features plus upgraded circuit simulator
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import ElectricalLab, { type ElectricalLabHandle, type ProjectSaveSnapshot } from './components/ElectricalLab';
import PCBLab, { type PCBLabHandle, type PCBProjectSaveSnapshot } from './components/PCBLab';
import type { ConvertResult } from './pcb/convertFromCircuit';
import CodingLab, { type CodingLabHandle, type Language } from './components/CodingLab';
import SettingsDialog from './components/SettingsDialog';
import HorusAIView from './components/horus-ai/HorusAIView';
import HorusWorkspace from './components/horus-ai/HorusWorkspace';
import { getSavedProjects, saveProject, updateProject, updatePCBProject, deleteProject, renameProject, duplicateProject, type SavedProject } from './lib/projectStorage';
import { exportProject, parseImportedProject, ProjectImportError, type ExportFormat } from './lib/projectExport';
import {
  LayoutDashboard, FolderOpen, Briefcase,
  Cpu, Users, User, Shield, LogOut, Menu, X, Settings,
  Sun, Moon, Zap, ArrowRight, Radio, Gauge, Network, ShieldCheck,
  BrainCircuit, Calculator, Workflow, BookOpen, FileBarChart,
  Linkedin, Twitter, Github, Mail, Calendar, Clock, Image as ImageIcon,
  MoreVertical, Pencil, Copy, Trash2, Check, Download, ChevronRight, Upload, AlertTriangle,
  RefreshCw, Layers,
} from 'lucide-react';
import heroLight from './assets/enginix-hero-light.jpeg';
import heroDark from './assets/enginix-hero-dark.jpeg';

// ─── Icons ───────────────────────────────────────────────────────────
const EyeOfHorusIcon = ({ size = 16 }: { size?: number }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M1.5 12C1.5 12 5.5 6.5 12 6.5C18.5 6.5 22.5 12 22.5 12C22.5 12 18.5 14.5 12 14.5C5.5 14.5 1.5 12 1.5 12Z"
      stroke="#fbbf24"
      strokeWidth="1.4"
      strokeLinejoin="round"
    />
    <circle cx="12" cy="12" r="2.4" stroke="#fbbf24" strokeWidth="1.4" />
    <circle cx="12" cy="12" r="0.9" fill="#fbbf24" />
    <path
      d="M9.6 14.3L7.6 19.2C7.3 20 6.4 20.4 5.7 20L4.6 19.3"
      stroke="#fbbf24"
      strokeWidth="1.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M17.8 9.3L19.6 5.6"
      stroke="#fbbf24"
      strokeWidth="1.4"
      strokeLinecap="round"
    />
  </svg>
);

// ─── Types ───────────────────────────────────────────────────────────
interface User {
  email: string;
  password: string;
  full_name: string;
  role: 'student' | 'engineer' | 'professor' | 'company' | 'admin';
  bio: string;
  skills: string[];
}

interface Job {
  title: string;
  company: string;
  type: 'job' | 'internship';
  location: string;
  remote: boolean;
  desc: string;
  applicants: number;
}

interface Thread {
  title: string;
  club: string;
  replies: number;
  views: number;
  snippet: string;
}

// ─── Mock Data ───────────────────────────────────────────────────────
const MOCK_USERS: User[] = [
  { email: 'sara@example.com', password: 'demo1234', full_name: 'Sara Fathy', role: 'student',
    bio: 'Final-year Mechatronics student at Ain Shams University, focused on embedded systems and renewable energy projects.',
    skills: ['Embedded C', 'IoT', 'Solidworks', 'Python'] },
  { email: 'admin@enginix.io', password: 'demo1234', full_name: 'Nourhan Adel', role: 'admin',
    bio: 'Platform operations lead.', skills: ['Moderation', 'Analytics'] },
  { email: 'co@enginix.io', password: 'demo1234', full_name: 'Karim Youssef', role: 'company',
    bio: 'Talent acquisition at Delta Infrastructure Co.', skills: ['Hiring', 'Civil Engineering'] },
];

const JOBS: Job[] = [
  { title: 'Junior Structural Engineer', company: 'Delta Infrastructure Co.', type: 'job', location: 'Cairo, Egypt', remote: false, desc: 'Support design calculations and drawing review for mid-rise residential projects across Greater Cairo.', applicants: 23 },
  { title: 'Embedded Systems Intern', company: 'NileTech Robotics', type: 'internship', location: 'Giza, Egypt', remote: false, desc: 'Work alongside our firmware team on sensor integration for agricultural IoT devices.', applicants: 41 },
  { title: 'AI/ML Engineer (Remote)', company: 'Waha Analytics', type: 'job', location: 'Remote', remote: true, desc: 'Build and deploy computer vision models for industrial quality inspection.', applicants: 57 },
  { title: 'Renewable Energy Research Intern', company: 'Sun Delta Energy', type: 'internship', location: 'Alexandria, Egypt', remote: false, desc: 'Assist in field testing of solar tracking prototypes and data collection for efficiency reports.', applicants: 18 },
];

const THREADS: Thread[] = [
  { title: 'Best FEA software for a student budget?', club: 'Mechanical', replies: 14, views: 412, snippet: 'Comparing free/student licenses for FEA before committing to a final-year project.' },
  { title: 'GUC Robotics Club — Fall competition sign-ups open', club: 'Clubs', replies: 6, views: 203, snippet: 'We are forming teams for the regional robotics competition next semester.' },
  { title: 'How do you structure a BOQ for a small residential project?', club: 'Civil', replies: 22, views: 889, snippet: 'Looking for a template or worked example for a bill of quantities on a 3-floor building.' },
  { title: 'AI Engineering Assistant — feature request thread', club: 'Platform', replies: 9, views: 301, snippet: 'Would love CAD file preview support inside the AI summarizer.' },
];

// ─── Helper functions ────────────────────────────────────────────────
function initials(name: string) {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

// ─── Toast ───────────────────────────────────────────────────────────
function useToast() {
  const [toast, setToast] = useState<{ msg: string; show: boolean }>({ msg: '', show: false });
  const showToast = useCallback((msg: string) => {
    setToast({ msg, show: true });
    setTimeout(() => setToast(prev => ({ ...prev, show: false })), 2200);
  }, []);
  return { toast, showToast };
}

// ─── Main App ────────────────────────────────────────────────────────
function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [view, setView] = useState('overview');
  const [authMode, setAuthMode] = useState<'login' | 'register' | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [projectToLoad, setProjectToLoad] = useState<SavedProject | null>(null);
  // Workspace Mode: hides the Home Dashboard chrome (header + sidebar) and
  // expands the Circuit Simulator / PCB Designer editor to nearly the full
  // browser window, without unmounting or reloading anything. Editor state
  // (project, zoom, camera, selection) lives inside ElectricalLab/PCBLab and
  // those components stay mounted throughout, so toggling this flag is a
  // pure layout change.
  const [workspaceMode, setWorkspaceMode] = useState(false);
  const electricalLabViewRef = useRef<ElectricalLabViewHandle | null>(null);
  const { toast, showToast } = useToast();

  // The canvas-based editors size themselves off their container and only
  // re-measure on the browser's native 'resize' event (see ElectricalLab's
  // and PCBLab's resize handlers). Firing one after the layout change makes
  // the canvas fill the newly expanded (or restored) space immediately.
  useEffect(() => {
    const id = requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
    return () => cancelAnimationFrame(id);
  }, [workspaceMode]);

  // Leaving the Studio entirely (e.g. via sidebar nav or sign out) should
  // always drop Workspace Mode so the dashboard chrome comes back.
  useEffect(() => {
    if (view !== 'electrical' && view !== 'ai' && workspaceMode) setWorkspaceMode(false);
  }, [view, workspaceMode]);

  // ─── Auth ──────────────────────────────────────────────────────────
  const handleLogin = (email: string, password: string): boolean => {
    const match = MOCK_USERS.find(u => u.email === email && u.password === password);
    if (!match) return false;
    setCurrentUser(match);
    setAuthMode(null);
    return true;
  };

  const handleRegister = (user: Omit<User, 'bio' | 'skills'>) => {
    const newUser: User = { ...user, bio: 'New ENGINIX member.', skills: [] };
    MOCK_USERS.push(newUser);
    setCurrentUser(newUser);
    setAuthMode(null);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setView('overview');
  };

  // ─── Landing page ─────────────────────────────────────────────────
  if (!currentUser) {
    return (
      <LandingPage
        onLogin={() => setAuthMode('login')}
        onRegister={() => setAuthMode('register')}
        authMode={authMode}
        onCloseAuth={() => setAuthMode(null)}
        onLoginSubmit={handleLogin}
        onRegisterSubmit={handleRegister}
        toast={toast}
      />
    );
  }

  // ─── App Shell ────────────────────────────────────────────────────
  const navItems = [
    { id: 'overview', label: 'Overview', icon: <LayoutDashboard size={16} />, num: '01' },
    { id: 'gallery', label: 'Project Gallery', icon: <FolderOpen size={16} />, num: '02' },
    { id: 'jobs', label: 'Jobs', icon: <Briefcase size={16} />, num: '03' },
    { id: 'ai', label: 'HORUS', icon: <EyeOfHorusIcon size={16} />, num: '04' },
    { id: 'electrical', label: 'ENGINIX STUDIO', icon: <Cpu size={16} />, num: '05' },
    { id: 'community', label: 'Community', icon: <Users size={16} />, num: '06' },
    { id: 'profile', label: 'Profile', icon: <User size={16} />, num: '07' },
  ];

  if (currentUser.role === 'admin') {
    navItems.push({ id: 'admin', label: 'Admin Panel', icon: <Shield size={16} />, num: '08' });
  }

  return (
    <div className="min-h-screen bg-[#0f1729] text-slate-200">
      {/* Header — part of the Home Dashboard chrome, hidden in Workspace Mode */}
      <header className={`${workspaceMode ? 'hidden' : 'flex'} items-center justify-between px-6 py-3 border-b border-slate-700/50 bg-slate-900/80`}>
        <div className="flex items-center gap-3">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-slate-400 hover:text-slate-200">
            {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
          <span className="font-bold text-lg tracking-tight text-amber-400 font-mono">ENGINIX</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            <span className="text-slate-300">{currentUser.full_name}</span>
            <span className="text-slate-500">· {currentUser.role}</span>
          </div>
          <button
            onClick={() => setSettingsOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono border border-slate-600 rounded hover:border-amber-500 hover:text-amber-400 transition-colors"
          >
            <Settings size={12} /> Settings
          </button>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono border border-slate-600 rounded hover:border-amber-500 hover:text-amber-400 transition-colors"
          >
            <LogOut size={12} /> Sign out
          </button>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar — part of the Home Dashboard chrome, hidden in Workspace Mode */}
        <aside className={`${workspaceMode ? 'hidden' : sidebarOpen ? 'w-56' : 'w-16'} flex-shrink-0 border-r border-slate-700/50 bg-slate-900/60 min-h-[calc(100vh-52px)] transition-all`}>
          <nav className="p-2 space-y-0.5">
            <div className="px-3 py-2 text-[10px] text-slate-600 font-mono uppercase tracking-wider">
              {sidebarOpen && 'Workspace'}
            </div>
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => {
                  setView(item.id);
                  if (item.id === 'ai') setWorkspaceMode(true);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-xs transition-all ${
                  view === item.id
                    ? 'text-amber-400 bg-amber-500/10 border-l-2 border-amber-400'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border-l-2 border-transparent'
                }`}
              >
                {item.icon}
                {sidebarOpen && <span className="font-medium">{item.label}</span>}
              </button>
            ))}
          </nav>
        </aside>

        {/* Content */}
        <main className={workspaceMode ? 'flex-1 overflow-auto' : 'flex-1 p-6 overflow-auto'}>
          {view === 'overview' && <OverviewView user={currentUser} />}
          {view === 'gallery' && (
            <GalleryView
              setView={setView}
              onOpenProject={(project) => {
                setProjectToLoad(project);
                setView('electrical');
              }}
              showToast={showToast}
              getActiveSnapshot={() => electricalLabViewRef.current?.getSaveSnapshot() ?? null}
              getActivePCBSnapshot={() => electricalLabViewRef.current?.getPCBSaveSnapshot() ?? null}
            />
          )}
          {view === 'jobs' && <JobsView user={currentUser} showToast={showToast} />}
          {view === 'ai' && (
            <div className={workspaceMode ? 'h-[calc(100vh-16px)] flex flex-col' : ''}>
              {workspaceMode && (
                <div className="flex items-center justify-between px-3 py-2 mb-3 bg-slate-900/90 border border-slate-700/60 rounded-lg shadow-sm">
                  <span className="hidden sm:flex items-center gap-1.5 pr-3 mr-1 border-r border-slate-700/60 text-amber-400 font-mono text-[11px] font-bold tracking-wider">
                    <Layers size={13} /> WORKSPACE
                  </span>
                  <button
                    onClick={() => setWorkspaceMode(false)}
                    className="px-4 py-1.5 text-xs font-mono font-semibold rounded-md border border-amber-500/40 text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 transition-colors flex items-center gap-1.5"
                  >
                    <X size={12} /> Exit Workspace
                  </button>
                </div>
              )}
              <div className={workspaceMode ? 'flex-1 min-h-0' : ''}>
                <HorusAIView
                  onOpenPCB={(result) => {
                    electricalLabViewRef.current?.importToPCB(result);
                    setView('electrical');
                  }}
                />
              </div>
            </div>
          )}
          {/* Kept mounted (hidden, not unmounted) when navigating away so live
              edits survive a trip to Project Gallery and back — required for
              Gallery's Update action to read the current in-progress circuit. */}
          <div className={view === 'electrical' ? 'contents' : 'hidden'}>
            <ElectricalLabView
              ref={electricalLabViewRef}
              loadProject={projectToLoad}
              onProjectLoaded={() => setProjectToLoad(null)}
              workspaceMode={workspaceMode}
              onEnterWorkspace={() => setWorkspaceMode(true)}
              onExitWorkspace={() => setWorkspaceMode(false)}
            />
          </div>
          {view === 'community' && <CommunityView />}
          {view === 'profile' && <ProfileView user={currentUser} />}
          {view === 'admin' && <AdminView />}
        </main>
      </div>

      {/* Toast */}
      <div className={`fixed top-4 left-1/2 -translate-x-1/2 px-4 py-2 bg-amber-500 text-slate-900 text-xs font-mono font-semibold rounded shadow-lg transition-all ${toast.show ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'}`}>
        {toast.msg}
      </div>

      {/* Settings dialog */}
      <SettingsDialog open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </div>
  );
}

// ─── Electrical Lab View ─────────────────────────────────────────────
export interface ElectricalLabViewHandle extends ElectricalLabHandle {
  getPCBSaveSnapshot: () => ReturnType<PCBLabHandle['getSaveSnapshot']> | null;
  /** Imports a Convert Circuit to PCB result and switches to the PCB
   *  tab — the same `handleConvertToPCB` path the Circuit Simulator's
   *  own "Convert to PCB" button already uses. Lets HORUS instances
   *  outside this component (e.g. the standalone Workspace HORUS page)
   *  reach the existing PCB interface without duplicating it. */
  importToPCB: (result: ConvertResult) => void;
}

const ElectricalLabView = React.forwardRef<ElectricalLabViewHandle, {
  loadProject?: SavedProject | null;
  onProjectLoaded?: () => void;
  workspaceMode?: boolean;
  onEnterWorkspace?: () => void;
  onExitWorkspace?: () => void;
}>(
  function ElectricalLabView({ loadProject, onProjectLoaded, workspaceMode = false, onEnterWorkspace, onExitWorkspace }, ref) {
  // A saved project opened from the Gallery determines which lab tab to
  // land on: PCB projects open into the PCB tab, circuit projects (or the
  // default) open into the Circuit Simulator tab.
  const [labTab, setLabTab] = useState<'circuit' | 'pcb' | 'coding' | 'horus'>('circuit');
  const electricalLabRef = useRef<ElectricalLabHandle | null>(null);
  const codingLabRef = useRef<CodingLabHandle | null>(null);
  const pcbLabRef = useRef<PCBLabHandle | null>(null);
  // Pending "Convert to PCB" payload waiting to be imported the next time
  // PCBLab mounts (see its pendingImport prop) - cleared once consumed.
  const [pcbImport, setPcbImport] = useState<ConvertResult | null>(null);

  // Route a Gallery-opened project to the right tab before it renders,
  // so PCB projects mount PCBLab (with loadProject already set) instead
  // of landing on the Circuit Simulator tab.
  useEffect(() => {
    if (!loadProject) return;
    setLabTab(loadProject.kind === 'pcb' ? 'pcb' : 'circuit');
  }, [loadProject]);

  // Forward the Circuit Simulator's and PCB Editor's handles so ancestors
  // (Project Gallery's Update action) can pull a live save snapshot.
  React.useImperativeHandle(ref, () => ({
    getEditor: () => electricalLabRef.current?.getEditor() ?? null,
    getSaveSnapshot: () => electricalLabRef.current?.getSaveSnapshot() ?? null,
    getPCBSaveSnapshot: () => pcbLabRef.current?.getSaveSnapshot() ?? null,
    importToPCB: (result: ConvertResult) => handleConvertToPCB(result),
  }), []);

  const handleOpenCoding = (payload?: { language: Language; code: string }) => {
    if (payload) {
      codingLabRef.current?.insertCode(payload.language, payload.code);
    }
    setLabTab('coding');
  };

  // Convert to PCB: stash the converted footprints/netlist and switch to
  // the PCB tab, where PCBLab imports them on mount.
  const handleConvertToPCB = (payload: ConvertResult) => {
    setPcbImport(payload);
    setLabTab('pcb');
  };

  const LAB_TABS = [
    { id: 'circuit' as const, label: 'Circuit Simulator' },
    { id: 'pcb' as const, label: 'PCB' },
    { id: 'coding' as const, label: 'Coding' },
    { id: 'horus' as const, label: '👁 HORUS' },
  ];

  // Workspace Mode's top nav uses shorter, more "app-like" labels than the
  // dashboard's tab-pill row (e.g. "Simulator" instead of "Circuit
  // Simulator") — same underlying tab ids, so switching still just flips
  // `labTab` and nothing remounts.
  const WORKSPACE_NAV_TABS = [
    { id: 'circuit' as const, label: 'Simulator' },
    { id: 'pcb' as const, label: 'PCB' },
    { id: 'coding' as const, label: 'Coding' },
    { id: 'horus' as const, label: '👁 HORUS' },
  ];

  return (
    <div className={workspaceMode ? 'h-[calc(100vh-16px)] flex flex-col' : 'h-[calc(100vh-100px)] flex flex-col'}>
      {/* Home Dashboard page header — hidden in Workspace Mode along with the
          header/sidebar chrome, since this label ("ENGINIX STUDIO") belongs
          to the dashboard, not the editor itself. */}
      {!workspaceMode && (
        <div className="flex items-baseline justify-between mb-4">
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <span className="text-amber-400 font-mono text-sm">05</span>
            ENGINIX STUDIO
          </h2>
          <span className="text-xs text-slate-500 font-mono">INTERACTIVE CIRCUIT SIMULATOR v2</span>
        </div>
      )}

      {workspaceMode ? (
        /* Workspace Mode top navigation bar. Switching tabs here only
           flips `labTab` — Circuit Simulator, PCB, and Coding are all kept
           mounted (hidden, not unmounted) below, so the loaded project,
           zoom, camera position, selection, and undo history are untouched
           by moving between them, and nothing reloads. */
        <div className="flex items-center justify-between px-3 py-2 mb-3 bg-slate-900/90 border border-slate-700/60 rounded-lg shadow-sm">
          <div className="flex items-center gap-1">
            <span className="hidden sm:flex items-center gap-1.5 pr-3 mr-1 border-r border-slate-700/60 text-amber-400 font-mono text-[11px] font-bold tracking-wider">
              <Layers size={13} /> WORKSPACE
            </span>
            {WORKSPACE_NAV_TABS.map(t => (
              <button
                key={t.id}
                onClick={() => setLabTab(t.id)}
                className={`relative px-4 py-1.5 text-xs font-mono font-semibold rounded-md transition-colors duration-200 ${
                  labTab === t.id
                    ? 'text-amber-400 bg-amber-500/10'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {t.label}
                <span
                  className={`absolute left-3 right-3 -bottom-[3px] h-0.5 rounded-full bg-amber-400 transition-all duration-200 ${
                    labTab === t.id ? 'opacity-100 scale-x-100' : 'opacity-0 scale-x-0'
                  }`}
                />
              </button>
            ))}
          </div>
          <button
            onClick={onExitWorkspace}
            className="px-4 py-1.5 text-xs font-mono font-semibold rounded-md border border-amber-500/40 text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 transition-colors flex items-center gap-1.5"
          >
            <X size={12} /> Exit Workspace
          </button>
        </div>
      ) : (
        /* Dashboard tab-pill row (unchanged, existing functionality). */
        <div className="flex items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-1 bg-slate-900/80 border border-slate-700/50 rounded-lg p-1 w-fit">
            {LAB_TABS.map(t => (
              <button
                key={t.id}
                onClick={() => setLabTab(t.id)}
                className={`px-4 py-1.5 text-xs font-mono font-semibold rounded-md transition-colors ${
                  labTab === t.id
                    ? 'bg-amber-500/20 text-amber-400'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Workspace Mode entry point: available inside both the Circuit
              Simulator and PCB Designer tabs. Hides only the Home Dashboard
              chrome (header + sidebar) and expands this editor to nearly
              the full window, without reloading the app or touching the
              loaded project, zoom, camera position, or selection. */}
          {(labTab === 'circuit' || labTab === 'pcb') && (
            <button
              onClick={onEnterWorkspace}
              className="px-4 py-1.5 text-xs font-mono font-semibold rounded-md border border-slate-600 text-slate-300 hover:border-amber-500 hover:text-amber-400 transition-colors flex items-center gap-1.5"
            >
              <Layers size={12} /> Workspace
            </button>
          )}
        </div>
      )}

      {/* Tab content */}
      <div className="flex-1 min-h-0">
        {/* Circuit Simulator and Coding stay mounted (hidden, not unmounted) so the
            circuit built in one tab is still there when scripted from the other. */}
        <div className={labTab === 'circuit' ? 'h-full' : 'hidden'}>
          <ElectricalLab
            ref={electricalLabRef}
            onOpenCoding={handleOpenCoding}
            loadProject={loadProject?.kind !== 'pcb' ? loadProject : undefined}
            onProjectLoaded={onProjectLoaded}
            onConvertToPCB={handleConvertToPCB}
          />
        </div>
        <div className={labTab === 'coding' ? 'h-full' : 'hidden'}>
          <CodingLab
            ref={codingLabRef}
            getEditor={() => electricalLabRef.current?.getEditor() ?? null}
            active={labTab === 'coding'}
          />
        </div>
        {/* PCB Designer stays mounted (hidden, not unmounted) too, same as
            Circuit Simulator and Coding above — so zoom, camera position,
            selection, and undo history survive switching away and back. */}
        <div className={labTab === 'pcb' ? 'h-full' : 'hidden'}>
          <PCBLab
            ref={pcbLabRef}
            getCircuitComponentTypes={() =>
              electricalLabRef.current?.getEditor()?.state.components.map(c => c.type) ?? []
            }
            pendingImport={pcbImport}
            onImportConsumed={() => setPcbImport(null)}
            loadProject={loadProject?.kind === 'pcb' ? loadProject : undefined}
            onProjectLoaded={onProjectLoaded}
          />
        </div>
        {/* HORUS Workspace tab — same HorusWorkspace chat used standalone
            on the Workspace HORUS page, wired here with onOpenPCB so its
            Convert Circuit to PCB result can open straight into this
            tab's own PCBLab instance. */}
        <div className={labTab === 'horus' ? 'h-full' : 'hidden'}>
          <HorusWorkspace onOpenPCB={handleConvertToPCB} />
        </div>
      </div>
    </div>
  );
});

// ─── Landing Page ────────────────────────────────────────────────────
function LandingPage({ onLogin, onRegister, authMode, onCloseAuth, onLoginSubmit, onRegisterSubmit, toast }: {
  onLogin: () => void;
  onRegister: () => void;
  authMode: 'login' | 'register' | null;
  onCloseAuth: () => void;
  onLoginSubmit: (email: string, password: string) => boolean;
  onRegisterSubmit: (user: Omit<User, 'bio' | 'skills'>) => void;
  toast: { msg: string; show: boolean };
}) {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const dark = theme === 'dark';

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Keep <html> in sync so scrollbars / form controls / focus rings follow theme too.
  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
    document.documentElement.classList.toggle('light', !dark);
    return () => {
      document.documentElement.classList.remove('dark', 'light');
    };
  }, [dark]);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  const palette = dark
    ? {
        surface: 'rgba(8,12,24,0.72)',
        surfaceSolid: '#0B1020',
        surfaceAlt: 'rgba(15,20,38,0.65)',
        ink: '#F5EFE0',
        sub: 'rgba(217,207,181,0.72)',
        gold: '#D4AF37',
        goldSoft: '#F5D77A',
        border: 'rgba(212,175,55,0.28)',
        navBg: 'rgba(5,5,5,0.55)',
      }
    : {
        surface: 'rgba(246,240,229,0.72)',
        surfaceSolid: '#F6F0E5',
        surfaceAlt: 'rgba(232,221,200,0.7)',
        ink: '#2A2110',
        sub: 'rgba(74,60,32,0.78)',
        gold: '#8A6A2B',
        goldSoft: '#C89B3C',
        border: 'rgba(138,106,43,0.32)',
        navBg: 'rgba(246,240,229,0.65)',
      };

  const heroImage = dark ? heroDark : heroLight;

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'features', label: 'Features' },
    { id: 'solutions', label: 'Solutions' },
    { id: 'about', label: 'About' },
    { id: 'contact', label: 'Contact' },
  ];

  const features = [
    { icon: <BrainCircuit size={20} />, title: 'HORUS', desc: 'A multilingual engineering copilot that explains, calculates, and reasons through complex electrical problems in seconds.' },
    { icon: <Calculator size={20} />, title: 'Electrical Calculations', desc: 'Load flow, short-circuit, cable sizing, and protection coordination — verified, precise, and instant.' },
    { icon: <Zap size={20} />, title: 'Power Systems', desc: 'Model generation, transmission, and distribution networks with production-grade simulation accuracy.' },
    { icon: <Workflow size={20} />, title: 'Automation Tools', desc: 'Design and validate control logic for industrial automation, PLCs, and embedded systems.' },
    { icon: <BookOpen size={20} />, title: 'Engineering Knowledge Base', desc: 'A curated library of standards, references, and worked examples, searchable in natural language.' },
    { icon: <FileBarChart size={20} />, title: 'Technical Reports', desc: 'Generate clean, standards-compliant engineering documentation directly from your calculations.' },
  ];

  return (
    <div
      className="min-h-screen w-full overflow-x-hidden transition-colors duration-500"
      style={{ background: palette.surfaceSolid, color: palette.ink, fontFamily: "'Inter', sans-serif" }}
    >
      {/* ── Auth Overlay ───────────────────────────────────────────── */}
      {authMode && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center z-[60] p-4">
          <div
            className="rounded-xl p-8 max-w-md w-full relative backdrop-blur-xl"
            style={{ background: dark ? 'rgba(11,16,32,0.94)' : 'rgba(246,240,229,0.97)', border: `1px solid ${palette.border}` }}
          >
            <button
              onClick={onCloseAuth}
              aria-label="Close dialog"
              className="absolute top-4 right-4 opacity-60 hover:opacity-100 focus-visible:outline focus-visible:outline-2"
              style={{ color: palette.ink, outlineColor: palette.gold }}
            >
              ✕
            </button>
            {authMode === 'login' ? (
              <LoginForm onSubmit={onLoginSubmit} onSwitch={() => onRegister()} />
            ) : (
              <RegisterForm onSubmit={onRegisterSubmit} onSwitch={() => onLogin()} />
            )}
          </div>
        </div>
      )}

      {/* Toast */}
      <div
        role="status"
        aria-live="polite"
        className={`fixed top-4 left-1/2 -translate-x-1/2 px-4 py-2 text-xs font-mono font-semibold rounded shadow-lg transition-all z-[60] ${toast.show ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'}`}
        style={{ background: palette.gold, color: '#0B0B0B' }}
      >
        {toast.msg}
      </div>

      {/* ── Navbar ─────────────────────────────────────────────────── */}
      <header
        className="fixed top-0 inset-x-0 z-50 transition-all duration-300"
        style={{
          background: scrolled ? palette.navBg : 'transparent',
          backdropFilter: scrolled ? 'blur(16px)' : 'none',
          WebkitBackdropFilter: scrolled ? 'blur(16px)' : 'none',
          borderBottom: scrolled ? `1px solid ${palette.border}` : '1px solid transparent',
        }}
      >
        <nav className="flex items-center justify-between px-[5%] py-4" aria-label="Primary">
          <button onClick={() => scrollTo('home')} className="flex items-center gap-2.5" aria-label="ENGINIX home">
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ border: `1.4px solid ${palette.gold}`, background: 'rgba(212,175,55,0.08)' }}
            >
              <Zap size={16} style={{ color: palette.gold }} />
            </div>
            <span className="font-bold text-lg tracking-[0.15em]" style={{ color: palette.gold, fontFamily: "'IBM Plex Mono', monospace" }}>
              ENGINIX
            </span>
          </button>

          <div className="hidden lg:flex items-center gap-7">
            {navLinks.map(link => (
              <button
                key={link.id}
                onClick={() => scrollTo(link.id)}
                className="text-xs tracking-wide transition-colors hover:opacity-100"
                style={{ color: palette.sub }}
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-3">
            <button
              onClick={() => setTheme(dark ? 'light' : 'dark')}
              className="w-9 h-9 rounded-full flex items-center justify-center transition-colors focus-visible:outline focus-visible:outline-2"
              style={{ border: `1px solid ${palette.border}`, color: palette.gold, outlineColor: palette.gold }}
              aria-label={dark ? 'Switch to light mode' : 'Switch to dark mode'}
            >
              {dark ? <Sun size={14} /> : <Moon size={14} />}
            </button>
            <button
              onClick={onLogin}
              className="px-4 py-2 text-xs font-semibold rounded-full transition-colors"
              style={{ border: `1px solid ${palette.border}`, color: palette.ink }}
            >
              Login
            </button>
            <button
              onClick={onRegister}
              className="px-5 py-2.5 text-xs font-bold rounded-full transition-all hover:-translate-y-0.5"
              style={{ background: `linear-gradient(135deg, ${palette.gold}, ${palette.goldSoft})`, color: '#0B0B0B' }}
            >
              Get Started
            </button>
          </div>

          {/* Mobile controls */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => setTheme(dark ? 'light' : 'dark')}
              className="w-9 h-9 rounded-full flex items-center justify-center"
              style={{ border: `1px solid ${palette.border}`, color: palette.gold }}
              aria-label={dark ? 'Switch to light mode' : 'Switch to dark mode'}
            >
              {dark ? <Sun size={16} /> : <Moon size={16} />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(o => !o)}
              className="w-9 h-9 rounded-full flex items-center justify-center"
              style={{ border: `1px solid ${palette.border}`, color: palette.ink }}
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X size={16} /> : <Menu size={16} />}
            </button>
          </div>
        </nav>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div
            className="lg:hidden px-[5%] pb-6 pt-2 flex flex-col gap-1"
            style={{ background: palette.navBg, backdropFilter: 'blur(16px)', borderBottom: `1px solid ${palette.border}` }}
          >
            {navLinks.map(link => (
              <button
                key={link.id}
                onClick={() => scrollTo(link.id)}
                className="text-sm text-left py-2.5"
                style={{ color: palette.ink }}
              >
                {link.label}
              </button>
            ))}
            <div className="flex gap-3 mt-3">
              <button
                onClick={() => { setMobileMenuOpen(false); onLogin(); }}
                className="flex-1 px-4 py-2.5 text-xs font-semibold rounded-full"
                style={{ border: `1px solid ${palette.border}`, color: palette.ink }}
              >
                Login
              </button>
              <button
                onClick={() => { setMobileMenuOpen(false); onRegister(); }}
                className="flex-1 px-4 py-2.5 text-xs font-bold rounded-full"
                style={{ background: `linear-gradient(135deg, ${palette.gold}, ${palette.goldSoft})`, color: '#0B0B0B' }}
              >
                Get Started
              </button>
            </div>
          </div>
        )}
      </header>

      {/* ── Hero ───────────────────────────────────────────────────── */}
      <section
        id="home"
        className="relative flex items-center justify-center px-[5%] pt-32 pb-24 md:pt-40 md:pb-32 min-h-[90vh]"
      >
        {/* Background image (theme-dependent, provided asset — not regenerated) */}
        <div
          className="absolute inset-0 bg-cover bg-center transition-opacity duration-500"
          style={{ backgroundImage: `url(${heroImage})` }}
          role="img"
          aria-label={dark ? 'Egyptian obelisks and pyramids rendered as a dark gold circuit blueprint' : 'Egyptian obelisks and pyramids rendered as a sandstone papyrus blueprint'}
        />
        {/* Readability overlay */}
        <div
          className="absolute inset-0"
          style={{
            background: dark
              ? 'linear-gradient(180deg, rgba(5,5,5,0.55) 0%, rgba(5,5,5,0.72) 55%, rgba(5,5,5,0.92) 100%)'
              : 'linear-gradient(180deg, rgba(246,240,229,0.45) 0%, rgba(246,240,229,0.72) 55%, rgba(246,240,229,0.94) 100%)',
          }}
        />

        <div className="relative z-10 max-w-3xl mx-auto text-center animate-[fadeInUp_0.8s_ease-out]">
          <div
            className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] mb-7 px-4 py-1.5 rounded-full"
            style={{ border: `1px solid ${palette.border}`, color: palette.gold, background: palette.surface, fontFamily: "'IBM Plex Mono', monospace" }}
          >
            <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: palette.gold }} />
            Electrical Engineering · AI Intelligence
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold leading-[1.1] mb-6 tracking-tight" style={{ color: palette.ink }}>
            Engineering Intelligence<br />
            <span
              key={theme}
              style={{
                background: `linear-gradient(135deg, ${palette.gold}, ${palette.goldSoft})`,
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                color: 'transparent',
              }}
            >
              Powered by Ancient Wisdom
            </span>
          </h1>
          <p className="text-sm md:text-base leading-relaxed mb-10 max-w-xl mx-auto" style={{ color: palette.sub }}>
            AI-powered engineering assistant for electrical design, calculations, automation, learning, and technical support.
          </p>
          <div className="flex gap-4 flex-wrap justify-center">
            <button
              onClick={onRegister}
              className="group flex items-center gap-2 px-7 py-3.5 rounded-full text-sm font-bold transition-all hover:-translate-y-0.5 hover:shadow-xl"
              style={{ background: `linear-gradient(135deg, ${palette.gold}, ${palette.goldSoft})`, color: '#0B0B0B' }}
            >
              Get Started
              <ArrowRight size={15} className="transition-transform group-hover:translate-x-1" />
            </button>
            <button
              onClick={() => scrollTo('features')}
              className="px-7 py-3.5 rounded-full text-sm font-bold transition-all"
              style={{ border: `1px solid ${palette.border}`, color: palette.ink, background: palette.surface }}
            >
              Explore Features
            </button>
          </div>
        </div>
      </section>

      {/* ── Features ───────────────────────────────────────────────── */}
      <section id="features" className="relative px-[5%] py-24 max-w-6xl mx-auto">
        <div className="mb-14 text-center">
          <div className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] mb-3" style={{ color: palette.gold, fontFamily: "'IBM Plex Mono', monospace" }}>
            <span className="w-6 h-px" style={{ background: palette.gold }} />
            Capabilities
            <span className="w-6 h-px" style={{ background: palette.gold }} />
          </div>
          <h2 className="text-3xl md:text-4xl font-extrabold mb-3">Everything an engineer needs, in one platform</h2>
          <p className="text-sm max-w-xl mx-auto" style={{ color: palette.sub }}>
            Precision engineering tools guided by an AI that understands the discipline.
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map(f => (
            <div
              key={f.title}
              className="rounded-xl p-6 transition-all duration-300 hover:-translate-y-1 relative overflow-hidden"
              style={{ background: dark ? 'rgba(212,175,55,0.05)' : 'rgba(138,106,43,0.05)', border: `1px solid ${palette.border}` }}
            >
              {/* Egyptian-inspired corner accent */}
              <div
                className="absolute top-0 right-0 w-10 h-10 opacity-40"
                style={{ borderTop: `1px solid ${palette.gold}`, borderRight: `1px solid ${palette.gold}`, margin: 8 }}
                aria-hidden="true"
              />
              <div
                className="w-11 h-11 rounded-full flex items-center justify-center mb-4"
                style={{ border: `1px solid ${palette.border}`, color: palette.gold, background: dark ? 'rgba(212,175,55,0.08)' : 'rgba(138,106,43,0.08)' }}
              >
                {f.icon}
              </div>
              <h3 className="font-bold text-sm mb-2">{f.title}</h3>
              <p className="text-xs leading-relaxed" style={{ color: palette.sub }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Solutions (Why ENGINIX) ───────────────────────────────── */}
      <section id="solutions" className="relative px-[5%] py-24" style={{ borderTop: `1px solid ${palette.border}`, borderBottom: `1px solid ${palette.border}` }}>
        <div className="max-w-5xl mx-auto">
          <div className="mb-14 text-center">
            <div className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] mb-3" style={{ color: palette.gold, fontFamily: "'IBM Plex Mono', monospace" }}>
              <span className="w-6 h-px" style={{ background: palette.gold }} />
              Why ENGINIX
              <span className="w-6 h-px" style={{ background: palette.gold }} />
            </div>
            <h2 className="text-3xl md:text-4xl font-extrabold mb-3">Built on precision, engineered for scale</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-0 relative" id="about">
            {[
              { title: 'Timeless Precision', desc: 'Every calculation is verified against engineering standards — accuracy is not negotiable.' },
              { title: 'Modern Intelligence', desc: 'A responsive AI that reasons through your problem, not a static reference lookup.' },
              { title: 'Built to Scale', desc: 'From a single circuit to a full smart-grid model, ENGINIX grows with the complexity of your work.' },
            ].map((item, i) => (
              <div key={item.title} className="relative px-6 py-8 text-center">
                {/* Obelisk-inspired divider */}
                {i > 0 && (
                  <div
                    className="hidden md:block absolute left-0 top-8 bottom-8 w-px"
                    style={{ background: `linear-gradient(180deg, transparent, ${palette.gold}, transparent)` }}
                    aria-hidden="true"
                  />
                )}
                <div
                  className="w-12 h-12 mx-auto mb-4 rounded-full flex items-center justify-center"
                  style={{ border: `1px solid ${palette.border}`, color: palette.gold }}
                  aria-hidden="true"
                >
                  <div className="w-2 h-2 rotate-45" style={{ background: palette.gold }} />
                </div>
                <h3 className="font-bold text-sm mb-2">{item.title}</h3>
                <p className="text-xs leading-relaxed max-w-xs mx-auto" style={{ color: palette.sub }}>{item.desc}</p>
              </div>
            ))}
          </div>

          {/* Hieroglyphic-inspired decorative line */}
          <div className="flex items-center justify-center gap-3 mt-14" aria-hidden="true">
            {Array.from({ length: 9 }).map((_, i) => (
              <span
                key={i}
                className="block"
                style={{
                  width: i % 3 === 0 ? 6 : 2,
                  height: i % 2 === 0 ? 14 : 8,
                  background: palette.gold,
                  opacity: 0.5,
                }}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ────────────────────────────────────────────────────── */}
      <section id="contact" className="relative px-[5%] py-20 text-center">
        <h2 className="text-2xl md:text-3xl font-extrabold mb-3">Engineer the future — with ancient precision</h2>
        <p className="text-sm mb-8 max-w-lg mx-auto" style={{ color: palette.sub }}>
          Step into ENGINIX and experience AI-guided circuit design, power analysis, and engineering intelligence.
        </p>
        <button
          onClick={onRegister}
          className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full text-sm font-bold transition-all hover:-translate-y-0.5"
          style={{ background: `linear-gradient(135deg, ${palette.gold}, ${palette.goldSoft})`, color: '#0B0B0B' }}
        >
          Get Started <ArrowRight size={15} />
        </button>
      </section>

      {/* ── Footer ─────────────────────────────────────────────────── */}
      <footer style={{ borderTop: `1px solid ${palette.border}` }} className="relative px-[5%] pt-12 pb-8">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ border: `1.4px solid ${palette.gold}` }}>
              <Zap size={14} style={{ color: palette.gold }} />
            </div>
            <span className="font-bold text-sm tracking-[0.15em]" style={{ color: palette.gold, fontFamily: "'IBM Plex Mono', monospace" }}>
              ENGINIX
            </span>
          </div>

          <nav className="flex flex-wrap items-center justify-center gap-6" aria-label="Footer">
            {navLinks.map(link => (
              <button key={link.id} onClick={() => scrollTo(link.id)} className="text-xs" style={{ color: palette.sub }}>
                {link.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            {[
              { icon: <Linkedin size={14} />, label: 'LinkedIn' },
              { icon: <Twitter size={14} />, label: 'Twitter' },
              { icon: <Github size={14} />, label: 'GitHub' },
              { icon: <Mail size={14} />, label: 'Email' },
            ].map(s => (
              <a
                key={s.label}
                href="#"
                aria-label={s.label}
                onClick={e => e.preventDefault()}
                className="w-8 h-8 rounded-full flex items-center justify-center transition-colors focus-visible:outline focus-visible:outline-2"
                style={{ border: `1px solid ${palette.border}`, color: palette.gold, outlineColor: palette.gold }}
              >
                {s.icon}
              </a>
            ))}
          </div>
        </div>
        <div className="text-center text-[11px] mt-10" style={{ color: palette.sub, fontFamily: "'IBM Plex Mono', monospace" }}>
          © {new Date().getFullYear()} ENGINIX HORUS — Electrical Engineering &amp; Power Systems Intelligence
        </div>
      </footer>
    </div>
  );
}
function LoginForm({ onSubmit, onSwitch }: { onSubmit: (email: string, password: string) => boolean; onSwitch: () => void }) {
  const [email, setEmail] = useState('sara@example.com');
  const [password, setPassword] = useState('demo1234');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onSubmit(email, password)) {
      setError('Incorrect email or password.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2 className="text-xl font-bold mb-1">Sign in</h2>
      <p className="text-xs text-slate-500 font-mono mb-5">DEMO ACCESS</p>
      <div className="space-y-4">
        <div>
          <label className="block text-[10px] text-amber-400 font-mono uppercase tracking-wider mb-1.5">Email</label>
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-transparent border-b border-slate-600 text-sm py-2 outline-none focus:border-amber-400 transition-colors" />
        </div>
        <div>
          <label className="block text-[10px] text-amber-400 font-mono uppercase tracking-wider mb-1.5">Password</label>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-transparent border-b border-slate-600 text-sm py-2 outline-none focus:border-amber-400 transition-colors" />
        </div>
        {error && <p className="text-xs text-red-400 font-mono">{error}</p>}
        <button type="submit" className="w-full py-2.5 bg-amber-500 text-slate-900 text-xs font-bold font-mono rounded hover:bg-amber-400 transition-colors">
          Sign in →
        </button>
      </div>
      <p className="mt-4 text-xs text-slate-500 text-center">
        No account? <button type="button" onClick={onSwitch} className="text-amber-400 hover:underline">Register</button>
      </p>
      <p className="mt-3 text-[10px] text-slate-600 font-mono border-t border-dashed border-slate-700 pt-3">
        Demo: <b className="text-amber-400">demo1234</b> for all accounts<br />
        sara@example.com · admin@enginix.io · co@enginix.io
      </p>
    </form>
  );
}

// ─── Register Form ───────────────────────────────────────────────────
function RegisterForm({ onSubmit, onSwitch }: { onSubmit: (user: Omit<User, 'bio' | 'skills'>) => void; onSwitch: () => void }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'student' | 'engineer' | 'professor' | 'company'>('student');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.length < 2) { setError('Enter your full name.'); return; }
    if (!email.includes('@')) { setError('Enter a valid email.'); return; }
    if (password.length < 8) { setError('Password must be at least 8 characters.'); return; }
    setError('');
    onSubmit({ email, password, full_name: name, role });
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2 className="text-xl font-bold mb-1">Create account</h2>
      <p className="text-xs text-slate-500 font-mono mb-5">NEW USER</p>
      <div className="space-y-4">
        <div>
          <label className="block text-[10px] text-amber-400 font-mono uppercase tracking-wider mb-1.5">Full name</label>
          <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Ahmed Khaled" className="w-full bg-transparent border-b border-slate-600 text-sm py-2 outline-none focus:border-amber-400 transition-colors placeholder:text-slate-600" />
        </div>
        <div>
          <label className="block text-[10px] text-amber-400 font-mono uppercase tracking-wider mb-1.5">Email</label>
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@university.edu.eg" className="w-full bg-transparent border-b border-slate-600 text-sm py-2 outline-none focus:border-amber-400 transition-colors placeholder:text-slate-600" />
        </div>
        <div>
          <label className="block text-[10px] text-amber-400 font-mono uppercase tracking-wider mb-1.5">Password</label>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 8 characters" className="w-full bg-transparent border-b border-slate-600 text-sm py-2 outline-none focus:border-amber-400 transition-colors placeholder:text-slate-600" />
        </div>
        <div>
          <label className="block text-[10px] text-amber-400 font-mono uppercase tracking-wider mb-1.5">Role</label>
          <select value={role} onChange={e => setRole(e.target.value as typeof role)} className="w-full bg-slate-800 border border-slate-600 text-sm py-2 rounded outline-none focus:border-amber-400">
            <option value="student">Student</option>
            <option value="engineer">Engineer</option>
            <option value="professor">Professor</option>
            <option value="company">Company</option>
          </select>
        </div>
        {error && <p className="text-xs text-red-400 font-mono">{error}</p>}
        <button type="submit" className="w-full py-2.5 bg-amber-500 text-slate-900 text-xs font-bold font-mono rounded hover:bg-amber-400 transition-colors">
          Create account →
        </button>
      </div>
      <p className="mt-4 text-xs text-slate-500 text-center">
        Already have an account? <button type="button" onClick={onSwitch} className="text-amber-400 hover:underline">Sign in</button>
      </p>
    </form>
  );
}

// ─── Overview View ───────────────────────────────────────────────────
function OverviewView({ user }: { user: User }) {
  const stats = user.role === 'company'
    ? [['4', 'Active job posts', '+1 this week'], ['139', 'Total applicants', '+23 this week'], ['12', 'Shortlisted', '+4 this week'], ['3.2 days', 'Avg. review time', '—']]
    : user.role === 'admin'
      ? [['14,208', 'Total users', '↑ 6.2%'], ['312', 'Active job posts', '↑ 3 today'], ['41,033', 'AI queries (mo)', '↑ 12%'], ['18', 'Pending reports', 'Needs review']]
      : [['3', 'Projects published', '+1 this month'], ['2', 'Job applications', '1 in review'], ['128', 'Profile views', '+34 this week'], ['12', 'AI credits left', 'of 20 free']];

  const activities = [
    'Your project "Smart Irrigation Controller" received a new 5★ rating.',
    'Delta Infrastructure Co. viewed your profile.',
    'New reply on "Best FEA software for a student budget?"',
    'HORUS generated a project idea for you 2 days ago.',
  ];

  return (
    <div>
      <div className="flex items-baseline justify-between mb-6">
        <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <span className="text-amber-400 font-mono text-sm">01</span> Overview
        </h2>
        <span className="text-xs text-slate-500 font-mono">WELCOME BACK, {user.full_name.split(' ')[0].toUpperCase()}</span>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {stats.map(([num, lbl, delta]) => (
          <div key={lbl} className="bg-slate-900/60 border border-slate-700/50 rounded-lg p-4">
            <div className="text-2xl font-extrabold text-amber-400">{num}</div>
            <div className="text-[10px] text-slate-500 font-mono uppercase mt-1">{lbl}</div>
            <div className="text-[10px] text-green-400 font-mono mt-1">{delta}</div>
          </div>
        ))}
      </div>
      <div className="bg-slate-900/60 border border-slate-700/50 rounded-lg p-5">
        <h4 className="font-bold text-sm mb-4">Recent Activity</h4>
        <div className="space-y-0">
          {activities.map((a, i) => (
            <div key={i} className="py-3 border-b border-dashed border-slate-700/30 last:border-0 text-xs text-slate-400">{a}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

function GalleryEmptyIllustration() {
  return (
    <svg width="220" height="180" viewBox="0 0 220 180" fill="none" xmlns="http://www.w3.org/2000/svg" className="mx-auto">
      <rect x="30" y="24" width="160" height="112" rx="10" className="stroke-slate-700" strokeWidth="2" fill="none" />
      <rect x="30" y="24" width="160" height="112" rx="10" className="fill-slate-800/40" />
      {/* circuit traces */}
      <path d="M50 60 h30 v20 h20" className="stroke-amber-500/40" strokeWidth="2" fill="none" strokeLinecap="round" />
      <path d="M140 50 v16 h-24 v14" className="stroke-teal-500/40" strokeWidth="2" fill="none" strokeLinecap="round" />
      <path d="M60 100 h40 v18" className="stroke-slate-500/50" strokeWidth="2" fill="none" strokeLinecap="round" />
      <circle cx="50" cy="60" r="4" className="fill-amber-500/60" />
      <circle cx="100" cy="80" r="4" className="fill-amber-500/60" />
      <circle cx="140" cy="50" r="4" className="fill-teal-500/60" />
      <circle cx="116" cy="80" r="4" className="fill-teal-500/60" />
      <circle cx="60" cy="100" r="4" className="fill-slate-500/60" />
      <circle cx="100" cy="118" r="4" className="fill-slate-500/60" />
      <rect x="88" y="70" width="24" height="16" rx="2" className="stroke-amber-400" strokeWidth="1.5" fill="none" />
      {/* folder base */}
      <path d="M20 150 h180 l-14 -14 a8 8 0 0 0 -6 -3 H40 a8 8 0 0 0 -6 3 z" className="fill-slate-800 stroke-slate-600" strokeWidth="1.5" />
      <rect x="14" y="150" width="192" height="10" rx="4" className="fill-slate-800 stroke-slate-600" strokeWidth="1.5" />
    </svg>
  );
}

function circuitTypeLabel(circuitJson: string): string {
  try {
    const { components } = JSON.parse(circuitJson) as { components?: Array<{ type: string }> };
    if (!components || components.length === 0) return 'Empty circuit';
    const counts = new Map<string, number>();
    for (const c of components) counts.set(c.type, (counts.get(c.type) ?? 0) + 1);
    const [topType] = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
    return topType.replace(/[-_]/g, ' ').replace(/\b\w/g, ch => ch.toUpperCase());
  } catch {
    return 'Circuit';
  }
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  } catch {
    return iso;
  }
}

function ProjectCard({
  project,
  onOpen,
  onUpdate,
  onRename,
  onDuplicate,
  onRequestDelete,
  onExport,
}: {
  project: SavedProject;
  onOpen: () => void;
  onUpdate: () => void;
  onRename: (name: string) => void;
  onDuplicate: () => void;
  onRequestDelete: () => void;
  onExport: (format: ExportFormat) => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [exportMenuOpen, setExportMenuOpen] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const [nameDraft, setNameDraft] = useState(project.name);
  const [thumbnailFailed, setThumbnailFailed] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const onClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
        setExportMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, [menuOpen]);

  const commitRename = () => {
    const trimmed = nameDraft.trim();
    setRenaming(false);
    if (trimmed && trimmed !== project.name) {
      onRename(trimmed);
    } else {
      setNameDraft(project.name);
    }
  };

  return (
    <div className="relative text-left w-full bg-slate-900/60 border border-slate-700/50 rounded-lg overflow-hidden hover:border-amber-400/40 transition-colors">
      {/* Card actions menu */}
      <div className="absolute top-2 right-2 z-10" ref={menuRef}>
        <button
          onClick={(e) => { e.stopPropagation(); setMenuOpen(v => !v); }}
          className="p-1.5 rounded bg-slate-900/80 border border-slate-700/60 text-slate-400 hover:text-amber-400 hover:border-amber-400/40 transition-colors"
          aria-label="Project options"
        >
          <MoreVertical size={14} />
        </button>

        {menuOpen && (
          <div className="absolute right-0 mt-1 w-36 bg-slate-900 border border-slate-700 rounded-md shadow-lg overflow-hidden">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setMenuOpen(false);
                setNameDraft(project.name);
                setRenaming(true);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-amber-400 transition-colors"
            >
              <Pencil size={12} /> Rename
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setMenuOpen(false);
                onDuplicate();
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-amber-400 transition-colors"
            >
              <Copy size={12} /> Duplicate
            </button>
            <div className="relative">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setExportMenuOpen(v => !v);
                }}
                className="w-full flex items-center justify-between gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-amber-400 transition-colors"
              >
                <span className="flex items-center gap-2"><Download size={12} /> Export</span>
                <ChevronRight size={12} />
              </button>
              {exportMenuOpen && (
                <div className="absolute right-full top-0 mr-1 w-40 bg-slate-900 border border-slate-700 rounded-md shadow-lg overflow-hidden">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setMenuOpen(false);
                      setExportMenuOpen(false);
                      onExport('json');
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-amber-400 transition-colors"
                  >
                    JSON
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setMenuOpen(false);
                      setExportMenuOpen(false);
                      onExport('enginix');
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-amber-400 transition-colors"
                  >
                    ENGINIX Project File
                  </button>
                </div>
              )}
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setMenuOpen(false);
                onRequestDelete();
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs text-red-400 hover:bg-slate-800 hover:text-red-300 transition-colors"
            >
              <Trash2 size={12} /> Delete
            </button>
          </div>
        )}
      </div>

      <button onClick={onOpen} className="text-left w-full">
        {/* Preview Image — real circuit snapshot when available, placeholder otherwise */}
        {project.thumbnail && !thumbnailFailed ? (
          <div className="aspect-video bg-slate-800/70 border-b border-slate-700/50 overflow-hidden">
            <img
              src={project.thumbnail}
              alt={`${project.name} preview`}
              className="w-full h-full object-cover"
              onError={() => setThumbnailFailed(true)}
            />
          </div>
        ) : (
          <div className="aspect-video bg-slate-800/70 border-b border-slate-700/50 flex flex-col items-center justify-center gap-2">
            <ImageIcon size={22} className="text-slate-600" />
            <span className="text-[10px] font-mono text-slate-600">No preview</span>
          </div>
        )}

        <div className="p-4">
          {renaming ? (
            <div
              className="flex items-center gap-1.5"
              onClick={(e) => e.stopPropagation()}
            >
              <input
                autoFocus
                value={nameDraft}
                onChange={(e) => setNameDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') commitRename();
                  if (e.key === 'Escape') { setNameDraft(project.name); setRenaming(false); }
                }}
                onBlur={commitRename}
                className="flex-1 min-w-0 bg-slate-800 border border-amber-400/50 rounded px-2 py-1 text-sm text-slate-100 outline-none"
              />
              <button
                onClick={commitRename}
                className="flex-shrink-0 p-1 rounded text-amber-400 hover:text-amber-300"
                aria-label="Confirm rename"
              >
                <Check size={14} />
              </button>
            </div>
          ) : (
            <h3 className="font-bold text-sm text-slate-200 truncate" title={project.name}>{project.name}</h3>
          )}
          {project.description && (
            <p className="text-xs text-slate-500 mt-1 line-clamp-2">{project.description}</p>
          )}

          <div className="flex items-center gap-1.5 mt-2">
            {project.kind === 'pcb' ? (
              <>
                <Layers size={12} className="text-amber-400" />
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                  PCB Board · {project.componentCount} components
                </span>
              </>
            ) : (
              <>
                <Cpu size={12} className="text-amber-400" />
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                  {circuitTypeLabel(project.circuit ?? '')}
                </span>
              </>
            )}
          </div>

          <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 border-t border-dashed border-slate-700 mt-3 pt-2">
            <span className="flex items-center gap-1"><Calendar size={11} /> {formatDate(project.createdAt)}</span>
            <span className="flex items-center gap-1"><Clock size={11} /> {formatDate(project.updatedAt)}</span>
          </div>
        </div>
      </button>

      {/* Primary card actions */}
      <div className="grid grid-cols-4 border-t border-slate-700/50">
        <button
          onClick={(e) => { e.stopPropagation(); onOpen(); }}
          className="flex flex-col items-center gap-1 py-2 text-[10px] font-mono text-slate-400 hover:text-amber-400 hover:bg-slate-800/60 transition-colors"
        >
          <FolderOpen size={13} /> Open
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); onUpdate(); }}
          className="flex flex-col items-center gap-1 py-2 text-[10px] font-mono text-slate-400 hover:text-amber-400 hover:bg-slate-800/60 transition-colors border-l border-slate-700/50"
        >
          <RefreshCw size={13} /> Update
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); onDuplicate(); }}
          className="flex flex-col items-center gap-1 py-2 text-[10px] font-mono text-slate-400 hover:text-amber-400 hover:bg-slate-800/60 transition-colors border-l border-slate-700/50"
        >
          <Copy size={13} /> Duplicate
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); onRequestDelete(); }}
          className="flex flex-col items-center gap-1 py-2 text-[10px] font-mono text-red-400/80 hover:text-red-300 hover:bg-slate-800/60 transition-colors border-l border-slate-700/50"
        >
          <Trash2 size={13} /> Delete
        </button>
      </div>
    </div>
  );
}

function DeleteProjectDialog({ project, onCancel, onConfirm }: { project: SavedProject; onCancel: () => void; onConfirm: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-4"
      onClick={onCancel}
    >
      <div
        className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-lg p-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
          <Trash2 size={16} className="text-red-400" /> Delete "{project.name}"?
        </h3>
        <p className="text-xs text-slate-500 mt-2">
          This will permanently remove this project from your saved projects. This action cannot be undone.
        </p>
        <div className="flex justify-end gap-2 mt-5">
          <button
            onClick={onCancel}
            className="px-3 py-1.5 text-xs font-mono rounded border border-slate-600 text-slate-300 hover:border-slate-400 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="px-3 py-1.5 text-xs font-mono rounded bg-red-500 hover:bg-red-400 text-slate-900 font-semibold transition-colors"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

function UpdateProjectDialog({ project, onCancel, onConfirm }: { project: SavedProject; onCancel: () => void; onConfirm: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-4"
      onClick={onCancel}
    >
      <div
        className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-lg p-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-sm font-bold text-slate-100">Update "{project.name}"?</h3>
        <p className="text-xs text-slate-500 mt-2">
          This will overwrite the saved project with your current changes, updating its thumbnail and last modified date. The project ID stays the same. This action cannot be undone.
        </p>
        <div className="flex justify-end gap-2 mt-5">
          <button
            onClick={onCancel}
            className="px-3 py-1.5 text-xs font-mono rounded border border-slate-600 text-slate-300 hover:border-slate-400 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="px-3 py-1.5 text-xs font-mono rounded bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transition-colors"
          >
            Update
          </button>
        </div>
      </div>
    </div>
  );
}


function ImportErrorDialog({ message, onClose }: { message: string; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-lg p-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-sm font-bold text-red-400 flex items-center gap-2">
          <AlertTriangle size={16} /> Import Failed
        </h3>
        <p className="text-xs text-slate-400 mt-2">{message}</p>
        <div className="flex justify-end mt-5">
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs font-mono rounded border border-slate-600 text-slate-300 hover:border-slate-400 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

function GalleryView({
  setView,
  onOpenProject,
  showToast,
  getActiveSnapshot,
  getActivePCBSnapshot,
}: {
  setView: (v: string) => void;
  onOpenProject: (project: SavedProject) => void;
  showToast: (msg: string) => void;
  getActiveSnapshot: () => ProjectSaveSnapshot | null;
  getActivePCBSnapshot: () => PCBProjectSaveSnapshot | null;
}) {
  const [projects, setProjects] = useState<SavedProject[]>(() => getSavedProjects());
  const [pendingDelete, setPendingDelete] = useState<SavedProject | null>(null);
  const [pendingUpdate, setPendingUpdate] = useState<SavedProject | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const importInputRef = useRef<HTMLInputElement>(null);

  const handleImportFileSelected = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const text = typeof reader.result === 'string' ? reader.result : '';
        const parsed = parseImportedProject(text);
        saveProject(parsed);
        setProjects(getSavedProjects());
        showToast('Project imported');
      } catch (e) {
        const message = e instanceof ProjectImportError ? e.message : 'This file could not be read as a valid ENGINIX project.';
        setImportError(message);
      }
    };
    reader.onerror = () => {
      setImportError('The file could not be read. Please try again.');
    };
    reader.readAsText(file);
  };

  const handleRename = (id: string, name: string) => {
    const updated = renameProject(id, name);
    if (updated) {
      setProjects(getSavedProjects());
      showToast('Project renamed');
    }
  };

  const handleDuplicate = (id: string) => {
    const copy = duplicateProject(id);
    if (copy) {
      setProjects(getSavedProjects());
      showToast('Project duplicated');
    }
  };

  const handleExport = (project: SavedProject, format: ExportFormat) => {
    exportProject(project, format);
    showToast(format === 'json' ? 'Exported as JSON' : 'Exported as ENGINIX Project File');
  };

  const handleUpdateRequest = (project: SavedProject) => {
    if (project.kind === 'pcb') {
      const pcbSnapshot = getActivePCBSnapshot();
      if (!pcbSnapshot || pcbSnapshot.loadedProjectId !== project.id) {
        showToast('Open this project in the PCB tab and edit it, then click Update here.');
        return;
      }
    } else {
      const snapshot = getActiveSnapshot();
      if (!snapshot || snapshot.loadedProjectId !== project.id) {
        showToast('Open this project in the Circuit Simulator and edit it, then click Update here.');
        return;
      }
    }
    setPendingUpdate(project);
  };

  const confirmUpdate = () => {
    if (!pendingUpdate) return;

    if (pendingUpdate.kind === 'pcb') {
      const pcbSnapshot = getActivePCBSnapshot();
      if (!pcbSnapshot || pcbSnapshot.loadedProjectId !== pendingUpdate.id) {
        showToast('Open this project in the PCB tab and edit it, then click Update here.');
        setPendingUpdate(null);
        return;
      }
      const updated = updatePCBProject(pendingUpdate.id, {
        name: pcbSnapshot.name,
        description: pcbSnapshot.description,
        boardState: pcbSnapshot.boardState,
        view: pcbSnapshot.view,
        layers: pcbSnapshot.layers,
        componentCount: pcbSnapshot.componentCount,
        traceCount: pcbSnapshot.traceCount,
        viaCount: pcbSnapshot.viaCount,
        thumbnail: pcbSnapshot.thumbnail,
      });
      if (updated) {
        setProjects(getSavedProjects());
        showToast('Project updated');
      }
      setPendingUpdate(null);
      return;
    }

    const snapshot = getActiveSnapshot();
    if (!snapshot || snapshot.loadedProjectId !== pendingUpdate.id) {
      showToast('Open this project in the Circuit Simulator and edit it, then click Update here.');
      setPendingUpdate(null);
      return;
    }
    const updated = updateProject(pendingUpdate.id, {
      name: snapshot.name,
      description: snapshot.description,
      circuit: snapshot.circuit,
      simulationSettings: snapshot.simulationSettings,
      componentCount: snapshot.componentCount,
      wireCount: snapshot.wireCount,
      thumbnail: snapshot.thumbnail,
    });
    if (updated) {
      setProjects(getSavedProjects());
      showToast('Project updated');
    }
    setPendingUpdate(null);
  };

  const confirmDelete = () => {
    if (!pendingDelete) return;
    const target = pendingDelete;
    // Always close the dialog and stay on the Gallery, no matter what
    // happens below — nothing here should ever navigate away or leave the
    // user stuck on a blank screen.
    setPendingDelete(null);
    try {
      const deleted = deleteProject(target.id);
      // Re-read from storage either way, so the Gallery reflects reality
      // (e.g. if the project was already gone, this just confirms that).
      setProjects(getSavedProjects());
      if (deleted) {
        showToast('Project deleted successfully');
      } else {
        // Missing/invalid project id — nothing to delete, but not a crash.
        showToast('Could not delete project: it was not found (it may have already been removed).');
      }
    } catch {
      // Unexpected storage failure — surface it and keep the list in sync
      // with whatever storage actually has, instead of trusting stale state.
      setProjects(getSavedProjects());
      showToast('Failed to delete project. Please try again.');
    }
  };

  if (projects.length === 0) {
    return (
      <div>
        <div className="flex items-baseline justify-between mb-6">
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <span className="text-amber-400 font-mono text-sm">02</span> Project Gallery
          </h2>
          <button
            onClick={() => importInputRef.current?.click()}
            className="flex items-center gap-1.5 text-xs text-slate-500 font-mono hover:text-amber-400 transition-colors"
          >
            <Upload size={12} /> Import Project
          </button>
        </div>

        <input
          ref={importInputRef}
          type="file"
          accept=".json,.enginix,application/json,application/vnd.enginix.project+json"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleImportFileSelected(file);
            e.target.value = '';
          }}
        />

        <div className="flex flex-col items-center justify-center text-center py-16 px-6">
          <GalleryEmptyIllustration />
          <h3 className="text-lg font-bold text-slate-200 mt-6">No Saved Projects</h3>
          <p className="text-sm text-slate-500 mt-2 max-w-sm">
            Create your first circuit then press Save to store it here.
          </p>
          <button
            onClick={() => setView('electrical')}
            className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-amber-500 hover:bg-amber-400 text-slate-900 text-sm font-bold transition-colors"
          >
            <Cpu size={16} />
            Go To Circuit Simulator
          </button>
        </div>

        {importError && (
          <ImportErrorDialog message={importError} onClose={() => setImportError(null)} />
        )}
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-baseline justify-between mb-6">
        <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <span className="text-amber-400 font-mono text-sm">02</span> Project Gallery
        </h2>
        <button
          onClick={() => setProjects(getSavedProjects())}
          className="text-xs text-slate-500 font-mono hover:text-amber-400 transition-colors"
        >
          Refresh
        </button>
      </div>

      <div className="flex justify-end mb-4">
        <button
          onClick={() => importInputRef.current?.click()}
          className="flex items-center gap-1.5 text-xs text-slate-500 font-mono hover:text-amber-400 transition-colors"
        >
          <Upload size={12} /> Import Project
        </button>
      </div>

      <input
        ref={importInputRef}
        type="file"
        accept=".json,.enginix,application/json,application/vnd.enginix.project+json"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleImportFileSelected(file);
          e.target.value = '';
        }}
      />

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {projects.map(p => (
          <ProjectCard
            key={p.id}
            project={p}
            onOpen={() => onOpenProject(p)}
            onUpdate={() => handleUpdateRequest(p)}
            onRename={(name) => handleRename(p.id, name)}
            onDuplicate={() => handleDuplicate(p.id)}
            onRequestDelete={() => setPendingDelete(p)}
            onExport={(format) => handleExport(p, format)}
          />
        ))}
      </div>

      {pendingDelete && (
        <DeleteProjectDialog
          project={pendingDelete}
          onCancel={() => setPendingDelete(null)}
          onConfirm={confirmDelete}
        />
      )}

      {pendingUpdate && (
        <UpdateProjectDialog
          project={pendingUpdate}
          onCancel={() => setPendingUpdate(null)}
          onConfirm={confirmUpdate}
        />
      )}

      {importError && (
        <ImportErrorDialog message={importError} onClose={() => setImportError(null)} />
      )}
    </div>
  );
}

// ─── Jobs View ───────────────────────────────────────────────────────
function JobsView({ user, showToast }: { user: User; showToast: (msg: string) => void }) {
  const [search, setSearch] = useState('');
  const [type, setType] = useState('');
  const [applied, setApplied] = useState<Set<number>>(new Set());

  const filtered = JOBS.filter(j => {
    return (!search || j.title.toLowerCase().includes(search.toLowerCase())) &&
      (!type || j.type === type);
  });

  return (
    <div>
      <div className="flex items-baseline justify-between mb-6">
        <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <span className="text-amber-400 font-mono text-sm">03</span> Jobs & Internships
        </h2>
        <span className="text-xs text-slate-500 font-mono">ONE-CLICK APPLY</span>
      </div>
      <div className="flex gap-3 mb-6">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search job title..." className="flex-1 bg-slate-900 border border-slate-700 rounded px-3 py-2 text-xs font-mono focus:border-amber-400 outline-none" />
        <select value={type} onChange={e => setType(e.target.value)} className="bg-slate-900 border border-slate-700 rounded px-3 py-2 text-xs font-mono focus:border-amber-400 outline-none">
          <option value="">All types</option>
          <option value="job">Jobs</option>
          <option value="internship">Internships</option>
        </select>
      </div>
      {filtered.length === 0 ? (
        <p className="text-sm text-slate-500 font-mono text-center py-12">No jobs match your search.</p>
      ) : (
        <div className="space-y-3">
          {filtered.map((j, i) => (
            <div key={j.title} className="flex justify-between gap-4 bg-slate-900/60 border border-slate-700/50 rounded-lg p-5">
              <div>
                <span className={`text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded ${j.type === 'job' ? 'bg-teal-700/30 text-teal-400' : 'bg-amber-500/20 text-amber-400'}`}>{j.type}</span>
                <h3 className="font-bold text-sm mt-2">{j.title}</h3>
                <p className="text-xs text-slate-500 font-mono mt-1">{j.company}</p>
                <p className="text-xs text-slate-400 mt-2 max-w-lg">{j.desc}</p>
              </div>
              <div className="text-right flex-shrink-0 flex flex-col items-end gap-2">
                <span className="text-xs text-slate-500 font-mono">{j.remote ? 'Remote' : j.location}</span>
                <span className="text-[10px] text-slate-600 font-mono">{j.applicants} applicants</span>
                {user.role !== 'company' && (
                  <button
                    onClick={() => { setApplied(prev => new Set([...prev, i])); showToast('Application sent!'); }}
                    disabled={applied.has(i)}
                    className={`px-3 py-1.5 text-[10px] font-mono rounded border transition-colors ${applied.has(i) ? 'bg-slate-800 text-slate-500 border-slate-700' : 'border-slate-500 text-slate-300 hover:border-amber-400 hover:text-amber-400'}`}
                  >
                    {applied.has(i) ? 'Applied ✓' : 'Apply'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Community View ──────────────────────────────────────────────────
function CommunityView() {
  return (
    <div>
      <div className="flex items-baseline justify-between mb-6">
        <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <span className="text-amber-400 font-mono text-sm">06</span> Community
        </h2>
        <span className="text-xs text-slate-500 font-mono">QUESTIONS · CLUBS · EVENTS</span>
      </div>
      <div className="space-y-3">
        {THREADS.map(t => (
          <div key={t.title} className="bg-slate-900/60 border border-slate-700/50 rounded-lg p-4">
            <div className="flex justify-between items-start gap-4">
              <h4 className="text-sm font-bold">
                <span className="text-[10px] font-mono bg-teal-700/20 text-teal-400 px-1.5 py-0.5 rounded mr-2">{t.club}</span>
                {t.title}
              </h4>
              <div className="flex gap-3 text-[10px] font-mono text-slate-500 flex-shrink-0">
                <span>{t.replies} replies</span>
                <span>{t.views} views</span>
              </div>
            </div>
            <p className="text-xs text-slate-400 mt-2">{t.snippet}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Profile View ────────────────────────────────────────────────────
function ProfileView({ user }: { user: User }) {
  return (
    <div>
      <div className="flex items-baseline justify-between mb-6">
        <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <span className="text-amber-400 font-mono text-sm">07</span> Profile
        </h2>
        <span className="text-xs text-slate-500 font-mono">PUBLIC PORTFOLIO</span>
      </div>
      <div className="flex items-center gap-4 mb-6">
        <div className="w-16 h-16 rounded-full bg-teal-700 flex items-center justify-center text-xl font-extrabold text-slate-100">
          {initials(user.full_name)}
        </div>
        <div>
          <h3 className="font-bold text-lg">{user.full_name}</h3>
          <span className="text-[10px] font-mono bg-amber-500/15 text-amber-400 px-2 py-0.5 rounded uppercase">{user.role}</span>
        </div>
      </div>
      <div className="bg-slate-900/60 border border-slate-700/50 rounded-lg p-5 mb-4">
        <h4 className="font-bold text-sm mb-3">Bio</h4>
        <p className="text-xs text-slate-400 leading-relaxed">{user.bio}</p>
      </div>
      <div className="bg-slate-900/60 border border-slate-700/50 rounded-lg p-5">
        <h4 className="font-bold text-sm mb-3">Skills</h4>
        <div className="flex gap-2 flex-wrap">
          {user.skills.length > 0 ? user.skills.map(s => (
            <span key={s} className="text-[10px] font-mono bg-teal-700 text-slate-100 px-2.5 py-1 rounded">{s}</span>
          )) : <span className="text-xs text-slate-500 font-mono">No skills listed.</span>}
        </div>
      </div>
    </div>
  );
}

// ─── Admin View ──────────────────────────────────────────────────────
function AdminView() {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  const userGrowth = [3200, 5100, 7400, 9200, 11500, 14208];
  const moderationItems = [
    { item: 'Project: "Free Energy Generator Concept"', type: 'Project', by: 'user4821', status: 'flagged' },
    { item: 'Comment on "GUC Robotics Club"', type: 'Comment', by: 'user1190', status: 'pending' },
    { item: 'Job: "Unpaid internship — 6 months"', type: 'Job posting', by: 'user7743', status: 'flagged' },
    { item: 'Profile: duplicate account report', type: 'User', by: 'user2201', status: 'pending' },
  ];

  return (
    <div>
      <div className="flex items-baseline justify-between mb-6">
        <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <span className="text-amber-400 font-mono text-sm">08</span> Admin Panel
        </h2>
        <span className="text-xs text-slate-500 font-mono">MODERATION & ANALYTICS</span>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          ['14,208', 'Total users', '↑ 6.2% this week'],
          ['41,033', 'AI queries (mo)', '↑ 12% this week'],
          ['312', 'Active job posts', '↑ 3 today'],
          ['18', 'Pending reports', 'Needs review'],
        ].map(([num, lbl, delta]) => (
          <div key={lbl} className="bg-slate-900/60 border border-slate-700/50 rounded-lg p-4">
            <div className="text-2xl font-extrabold text-amber-400">{num}</div>
            <div className="text-[10px] text-slate-500 font-mono uppercase mt-1">{lbl}</div>
            <div className="text-[10px] text-slate-400 font-mono mt-1">{delta}</div>
          </div>
        ))}
      </div>
      <div className="bg-slate-900/60 border border-slate-700/50 rounded-lg p-5 mb-4">
        <h4 className="font-bold text-sm mb-4">User growth (last 6 months)</h4>
        <div className="flex items-end gap-2 h-32">
          {userGrowth.map((v, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <span className="text-[9px] font-mono text-slate-500">{v}</span>
              <div className="w-full bg-gradient-to-t from-amber-500/30 to-amber-500 rounded-t" style={{ height: `${(v / 14208) * 100}%` }} />
              <span className="text-[9px] font-mono text-slate-600">{months[i]}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="bg-slate-900/60 border border-slate-700/50 rounded-lg p-5">
        <h4 className="font-bold text-sm mb-4">Moderation queue</h4>
        <table className="w-full text-xs">
          <thead>
            <tr className="text-left text-[10px] font-mono text-slate-500 uppercase tracking-wider border-b border-slate-700/50">
              <th className="pb-2">Item</th>
              <th className="pb-2">Type</th>
              <th className="pb-2">Reported by</th>
              <th className="pb-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {moderationItems.map((item, i) => (
              <tr key={i} className="border-b border-slate-700/30 last:border-0">
                <td className="py-3">{item.item}</td>
                <td className="py-3 text-slate-400">{item.type}</td>
                <td className="py-3 text-slate-500 font-mono">{item.by}</td>
                <td className="py-3">
                  <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded ${
                    item.status === 'flagged' ? 'bg-red-500/15 text-red-400' : 'bg-amber-500/15 text-amber-400'
                  }`}>{item.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default App;
