/**
 * GeminiService — reusable, standalone wrapper around the Google Gemini API.
 *
 * Drop-in replacement for the old ClaudeService, exposing the same public
 * API so every caller (PromptEngine, OptimizationEngine, ...) is unaffected.
 *
 * Usage:
 *
 *   import { generate } from './services/GeminiService';
 *   const result = await generate('Explain Ohm\'s law');
 *   if (result.ok) {
 *     console.log(result.text);
 *   } else {
 *     console.error(result.error);
 *   }
 */

import { getGeminiApiKey } from '../lib/geminiSettings';

// Official Gemini API (generativelanguage.googleapis.com), current stable
// generateContent endpoint — not a deprecated PaLM/v1 endpoint.
const GEMINI_API_BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const GEMINI_MODEL = 'gemini-3.5-flash';

export type ClaudeGenerateResult =
  | { ok: true; text: string }
  | { ok: false; error: string };

interface GeminiResponseBody {
  candidates?: Array<{
    content?: { parts?: Array<{ text?: string }> };
    finishReason?: string;
  }>;
  promptFeedback?: { blockReason?: string };
  error?: { message?: string; status?: string };
}

/**
 * Send a single prompt to Gemini and return the generated text.
 * Reads the API key from localStorage (via geminiSettings) on every call,
 * so it always reflects whatever the user last saved in Settings.
 * Never throws — all failure modes are returned as { ok: false, error }.
 */
export async function generate(prompt: string): Promise<ClaudeGenerateResult> {
  const trimmedPrompt = prompt?.trim();
  if (!trimmedPrompt) {
    return { ok: false, error: 'Prompt cannot be empty.' };
  }

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return { ok: false, error: 'No Gemini API key configured. Add one in Settings.' };
  }

  let response: Response;
  try {
    response = await fetch(`${GEMINI_API_BASE_URL}/${GEMINI_MODEL}:generateContent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: trimmedPrompt }] }],
      }),
    });
  } catch {
    return { ok: false, error: 'Network error — could not reach the Gemini API.' };
  }

  let data: GeminiResponseBody;
  try {
    data = await response.json();
  } catch {
    return { ok: false, error: 'Received an invalid response from the Gemini API.' };
  }

  if (!response.ok) {
    const message = data?.error?.message || `Gemini API request failed (status ${response.status}).`;
    return { ok: false, error: message };
  }

  const blockReason = data?.promptFeedback?.blockReason;
  if (blockReason) {
    return { ok: false, error: `Gemini blocked the request (${blockReason}).` };
  }

  const text = data?.candidates?.[0]?.content?.parts
    ?.map((part) => part.text ?? '')
    .join('')
    .trim();

  if (!text) {
    return { ok: false, error: 'Gemini API returned no text content.' };
  }

  return { ok: true, text };
}

export type ConnectionTestResult =
  | { status: 'success' }
  | { status: 'invalid_key' }
  | { status: 'missing_key' }
  | { status: 'rate_limited' }
  | { status: 'network_error' };

/**
 * Lightweight connectivity/key check for the Settings "Test Connection" button.
 *
 * Uses GET /v1beta/models (list models) instead of generateContent — this
 * validates the API key and reachability without generating any tokens,
 * so it's the cheapest possible way to verify a key works.
 */
export async function testConnection(): Promise<ConnectionTestResult> {
  const apiKey = getGeminiApiKey();
  if (!apiKey || !apiKey.trim()) {
    return { status: 'missing_key' };
  }

  let response: Response;
  try {
    response = await fetch(`${GEMINI_API_BASE_URL}?pageSize=1`, {
      method: 'GET',
      headers: {
        'x-goog-api-key': apiKey.trim(),
      },
    });
  } catch {
    return { status: 'network_error' };
  }

  if (response.status === 401 || response.status === 403) {
    return { status: 'invalid_key' };
  }

  if (response.status === 429) {
    return { status: 'rate_limited' };
  }

  if (!response.ok) {
    // Treat other 4xx (e.g. 400 malformed key) as an invalid key,
    // anything else unexpected as a network/server error.
    if (response.status >= 400 && response.status < 500) {
      return { status: 'invalid_key' };
    }
    return { status: 'network_error' };
  }

  return { status: 'success' };
}
