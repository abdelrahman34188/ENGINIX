/**
 * OptimizationEngine — centralized entry point for asking HORUS to
 * IMPROVE something that already exists, as opposed to PromptEngine
 * (which builds new circuits/code from a free-text description).
 *
 * optimizeCircuit(circuitJson, focus) — reviews an exported circuit
 * (components + wires, exactly as produced by CircuitEditor.exportCircuit())
 * and proposes component value changes, wiring fixes, and power
 * reductions.
 *
 * Routes the built prompt through HORUS Brain (`horus/runtime.ts`)
 * rather than calling an AI provider directly — this module has no
 * dependency on any concrete AI vendor. Response parsing/validation
 * lives in ../circuit/ClaudeCircuitOptimizer, kept separate on purpose
 * so this file only ever builds prompts and hands them to Brain.
 *
 * (The Coding-tab counterpart, optimizeCode(), was removed along with the
 * Coding module for a from-scratch rebuild — see CodingLab.tsx.)
 */

import { runHorusPrompt } from '../horus/runtime';
import { defaultProperties } from '../circuit/componentDefs';

export type ClaudeGenerateResult =
  | { ok: true; text: string }
  | { ok: false; error: string };

/** Which kind(s) of improvement the person is asking for. */
export type CircuitOptimizationFocus = 'circuit' | 'wiring' | 'power' | 'componentValues';

const FOCUS_LABELS: Record<CircuitOptimizationFocus, string> = {
  circuit: 'Optimize the overall circuit design (topology, redundant parts, better component choices).',
  wiring: 'Improve the wiring — flag unnecessary/roundabout connections, missing grounds, and propose cleaner routing.',
  power: 'Reduce power consumption — find components drawing more current/power than needed for the circuit to work correctly.',
  componentValues: 'Suggest better component values (resistances, capacitances, voltages, etc.) for reliability, safety, and efficiency.',
};

// Build the "valid props per component type" reference once, from the
// simulator's own property registry, so Claude only ever proposes prop
// keys and value ranges that actually exist on each component type.
function buildPropertyReference(): string {
  return Object.entries(defaultProperties)
    .filter(([, props]) => props.length > 0)
    .map(([type, props]) => {
      const propList = props
        .map((p) => {
          const range = p.type === 'number' && p.min !== undefined && p.max !== undefined
            ? ` (range ${p.min}-${p.max}${p.unit ? p.unit : ''})`
            : '';
          return `${p.key}${range}`;
        })
        .join(', ');
      return `${type}: ${propList}`;
    })
    .join('\n');
}

function buildCircuitSystemPrompt(focus: CircuitOptimizationFocus[]): string {
  const focusList = (focus.length > 0 ? focus : (['circuit', 'wiring', 'power', 'componentValues'] as CircuitOptimizationFocus[]))
    .map((f) => `- ${FOCUS_LABELS[f]}`)
    .join('\n');

  return `You are an expert electrical engineer reviewing an EXISTING circuit for improvements. You are not building a new circuit — you are optimizing one that already exists.

You will be given the circuit as JSON, exactly as exported by the simulator: { "components": [...], "wires": [...] }. Each component has a numeric "id", a "type", "props" (its current values), and, if the simulation has run, "voltage"/"current"/"power" fields you can use to reason about power draw.

Focus on these areas for this request:
${focusList}

Rules you must always follow:
- Never propose a change to a component id that isn't present in the given circuit.
- Only propose prop keys that are valid for that component's type, using exactly these keys and ranges:
${buildPropertyReference()}
- Keep every suggested value within the given range for that key.
- Do not change circuit topology (don't add/remove components or wires) — only propose value changes and describe wiring issues in words. This tool only applies value changes automatically; anything structural must be explained, not executed.
- Every change must have a concrete engineering reason (e.g. lower power draw at the same brightness, safer current margin, standard resistor value, better tolerance) — never change a value without justification.
- Prefer standard component values (E12/E24 resistor series, common capacitor values) where relevant.
- Return ONLY a single valid JSON object. No Markdown, no code fences, no prose before or after it.

Respond with EXACTLY this JSON shape:
{
  "success": true,
  "summary": "one or two sentence overview of what you found and improved",
  "estimatedPowerSavingsPercent": 0,
  "componentChanges": [
    { "id": 0, "prop": "resistance", "newValue": 330, "reason": "..." }
  ],
  "wiringSuggestions": [],
  "warnings": [],
  "errors": []
}
- "id" must be the exact numeric component id from the input JSON.
- "componentChanges" can be an empty array if nothing needs to change.
- "wiringSuggestions" is plain-language advice about rewiring (this tool does not rewire automatically).
- "estimatedPowerSavingsPercent" is your best-effort estimate (0 if not applicable/measurable).

If the circuit is empty or nothing can be meaningfully optimized, respond with:
{ "success": false, "errors": ["explain why, in the request's language"] }

Return nothing else besides one of these two JSON objects.`;
}

/**
 * Ask HORUS (via HORUS Brain) to review an exported circuit (JSON from
 * CircuitEditor.exportCircuit()) and propose component-value / wiring /
 * power improvements.
 */
export async function optimizeCircuit(
  circuitJson: string,
  focus: CircuitOptimizationFocus[] = ['circuit', 'wiring', 'power', 'componentValues']
): Promise<ClaudeGenerateResult> {
  const systemPrompt = buildCircuitSystemPrompt(focus);
  const fullPrompt = `${systemPrompt}\n\nCircuit to optimize:\n${circuitJson}`;
  return runHorusPrompt(fullPrompt);
}

