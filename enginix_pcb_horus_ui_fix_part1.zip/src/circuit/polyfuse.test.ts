import { describe, it, expect } from 'vitest';
import {
  defaultProperties,
  defaultTerminals,
  componentNames,
  componentCategories,
} from './componentDefs';
import { simulateDC, updateComponentState, advanceVisualState } from './simulator';
import { FOOTPRINTS } from '../pcb/footprints';
import { footprintKeyFor, hasFootprintFor } from '../pcb/simulatorSync';
import { convertCircuitToPCB } from '../pcb/convertFromCircuit';
import { detectCircuitErrors } from './errorDetector';
import { rotatePoint, footprintBBox, padAbsolutePos } from '../pcb/geometry';
import type { Component, Wire } from './types';
import type { PCBComponent } from '../pcb/types';

function makeComponent(type: Component['type'], id: number, propOverrides: Record<string, number | string | boolean> = {}): Component {
  const termDefs = defaultTerminals[type] || [];
  const props: Record<string, number | string | boolean> = {};
  for (const def of defaultProperties[type] || []) props[def.key] = def.defaultValue;
  Object.assign(props, propOverrides);
  return {
    id,
    type,
    x: 0,
    y: 0,
    rotation: 0,
    props,
    label: `${type}_${id}`,
    selected: false,
    voltage: 0,
    current: 0,
    power: 0,
    terminals: termDefs.map((td, idx) => ({
      id: id * 100 + idx,
      componentId: id,
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label,
      netId: null,
    })),
    state: {},
  } as Component;
}

function wire(id: number, a: Component, aIdx: number, b: Component, bIdx: number): Wire {
  return {
    id,
    fromTerminalId: a.terminals[aIdx].id,
    toTerminalId: b.terminals[bIdx].id,
    fromCompId: a.id,
    toCompId: b.id,
    color: '#fff',
    waypoints: [],
    selected: false,
  };
}

/** Battery(+V) -> polyfuse -> load resistor -> GND, battery(-) tied to the
 * same GND net. Returns the solved result plus the polyfuse's own current. */
function solvePolyfuse(
  batteryVoltage: number,
  loadOhms: number,
  propOverrides: Record<string, number | string | boolean> = {},
  priorPolyfuseState: Record<string, unknown> = {},
) {
  const battery = makeComponent('battery', 1, { voltage: batteryVoltage });
  const pf = makeComponent('polyfuse', 2, propOverrides);
  pf.state = { ...priorPolyfuseState };
  const gnd = makeComponent('ground', 3);
  const load = makeComponent('resistor', 4, { resistance: loadOhms });

  const wires: Wire[] = [
    wire(1, battery, 0, pf, 0),
    wire(2, pf, 1, load, 0),
    wire(3, load, 1, gnd, 0),
    wire(4, battery, 1, gnd, 0),
  ];

  const components = [battery, pf, gnd, load];
  const result = simulateDC(components, wires);
  const pfCurrent = result.branchCurrents.get(2) || 0;
  return { result, pfCurrent, components, wires };
}

describe('Polyfuse (PTC resettable fuse)', () => {
  it('is a registered placeable component type with a name and 2 terminals', () => {
    expect(componentNames.polyfuse).toBeTruthy();
    expect((defaultTerminals.polyfuse || []).length).toBe(2);
  });

  it('is not confused with the existing one-shot Fuse (distinct type, name, footprint)', () => {
    expect(componentNames.polyfuse).not.toBe(componentNames.fuse);
    expect(footprintKeyFor('polyfuse')).not.toBe(footprintKeyFor('fuse'));
  });

  it('appears in the active (dynamic-state) palette category alongside Fuse and Switch', () => {
    expect(componentCategories.active).toContain('polyfuse');
    expect(componentCategories.active).toContain('fuse');
    expect(componentCategories.active).toContain('switch');
  });

  it('has real default properties: hold/trip current, cold/tripped resistance, reset time', () => {
    const keys = (defaultProperties.polyfuse || []).map(p => p.key);
    expect(keys).toEqual(
      expect.arrayContaining(['holdCurrent', 'tripCurrent', 'coldResistance', 'trippedResistance', 'resetTimeMs']),
    );
  });

  it('has a mapped PCB footprint with real pads in the Power category', () => {
    expect(hasFootprintFor('polyfuse')).toBe(true);
    const key = footprintKeyFor('polyfuse')!;
    expect(FOOTPRINTS[key]).toBeTruthy();
    expect(FOOTPRINTS[key].pads.length).toBe(2);
    expect(FOOTPRINTS[key].category).toBe('Power');
  });

  it('supports Convert to PCB (produces a placed footprint, not left unmapped)', () => {
    const pf = makeComponent('polyfuse', 1);
    const result = convertCircuitToPCB([pf], []);
    expect(result.unmapped).toEqual([]);
    expect(result.components.length).toBe(1);
    expect(FOOTPRINTS[result.components[0].footprint]).toBeTruthy();
  });

  it('supports rotation: PCB footprint bounding box swaps width/height at 90°/270°', () => {
    const key = footprintKeyFor('polyfuse')!;
    const fp = FOOTPRINTS[key];
    expect(footprintBBox(fp.width, fp.height, 0)).toEqual({ w: fp.width, h: fp.height });
    expect(footprintBBox(fp.width, fp.height, 90)).toEqual({ w: fp.height, h: fp.width });
    expect(footprintBBox(fp.width, fp.height, 180)).toEqual({ w: fp.width, h: fp.height });
    expect(footprintBBox(fp.width, fp.height, 270)).toEqual({ w: fp.height, h: fp.width });
  });

  it('preserves its own rotation through a full Convert to PCB round trip', () => {
    const pf = makeComponent('polyfuse', 1);
    pf.rotation = 1; // 90 degrees, in the Circuit Simulator's 0-3 step units
    const result = convertCircuitToPCB([pf], []);
    expect(result.components[0].rotation).toBe(90);
  });

  it('supports flip: pad positions mirror on X when placed on the bottom side', () => {
    const key = footprintKeyFor('polyfuse')!;
    const fp = FOOTPRINTS[key];
    const topComp: PCBComponent = { id: 1, footprint: key, refDes: 'F1', x: 0, y: 0, rotation: 0, side: 'top', props: {} };
    const bottomComp: PCBComponent = { ...topComp, side: 'bottom' };
    for (const p of fp.pads) {
      const topPos = padAbsolutePos(topComp, p);
      const bottomPos = padAbsolutePos(bottomComp, p);
      expect(bottomPos.x).toBeCloseTo(-topPos.x, 6);
      expect(bottomPos.y).toBeCloseTo(topPos.y, 6);
    }
  });

  it('rotatePoint is consistent for all 4 cardinal rotations (sanity check shared by every footprint)', () => {
    expect(rotatePoint(1, 0, 0)).toEqual({ x: 1, y: 0 });
    expect(rotatePoint(1, 0, 90)).toEqual({ x: 0, y: 1 });
    expect(rotatePoint(1, 0, 180)).toEqual({ x: -1, y: 0 });
    expect(rotatePoint(1, 0, 270)).toEqual({ x: 0, y: -1 });
  });

  it('behaves as a real low-resistance conductor while under Hold Current', () => {
    // 1A hold, 5V across a 100Ω load -> ~50mA, well under hold - should
    // pass current almost as if it were a plain wire (small cold
    // resistance), not clamp it down toward the tripped-resistance case.
    const { result, pfCurrent } = solvePolyfuse(5, 100);
    expect(result.converged).toBe(true);
    expect(Math.abs(pfCurrent)).toBeGreaterThan(0.04);
    expect(Math.abs(pfCurrent)).toBeLessThan(0.06);
  });

  it('trips (goes high-resistance) once current exceeds Trip Current', () => {
    // Default hold=1A, trip=2A. A near-short (0.1Ω) load at 9V would
    // otherwise demand ~90A - one simulation+state-update tick should
    // detect the overcurrent and trip.
    const { result, components } = solvePolyfuse(9, 0.1);
    expect(result.converged).toBe(true);
    const updated = components.map(c => updateComponentState(c, result));
    const pf = updated.find(c => c.id === 2)!;
    expect(pf.state.tripped).toBe(true);
  });

  it('once tripped, current-limits to a small trickle rather than acting as a dead short or open circuit', () => {
    const { pfCurrent, result } = solvePolyfuse(9, 0.1, {}, { tripped: true });
    expect(result.converged).toBe(true);
    // Tripped resistance (4000Ω default) into a near-short load should
    // clamp current to a few mA - far below the fault current, but not
    // exactly zero (a real PTC doesn't become an ideal open).
    expect(Math.abs(pfCurrent)).toBeGreaterThan(0);
    expect(Math.abs(pfCurrent)).toBeLessThan(0.01);
  });

  it('does NOT reset instantly when tripped (needs Reset Time to elapse first)', () => {
    // Tripped, light load - resistance is now the high tripped value, so
    // current is tiny regardless, but a real PTC still needs physical
    // time to cool down before its cooldown timer can complete.
    const { components } = solvePolyfuse(5, 100_000, {}, { tripped: true });
    let updated = components;

    // Advancing less than the full Reset Time (default 3000ms) should
    // not yet reset it.
    updated = advanceVisualState(updated, 500);
    expect(updated.find(c => c.id === 2)!.state.tripped).toBe(true);
  });

  it('resets on its own after Reset Time has elapsed once the fault has actually cleared', () => {
    const { components, wires } = solvePolyfuse(5, 100_000, {}, { tripped: true });
    let comps = components;

    // Each loop iteration mirrors one real render-loop tick: advance the
    // cooldown timer, then re-solve the circuit and update state from
    // that fresh result - exactly like CircuitEditor's update() does.
    for (let i = 0; i < 4; i++) {
      comps = advanceVisualState(comps, 1000);
      const result = simulateDC(comps, wires);
      comps = comps.map(c => updateComponentState(c, result));
    }
    const pf = comps.find(c => c.id === 2)!;
    expect(pf.state.tripped).toBe(false);
  });

  it('re-trips immediately if the fault is still present when the cooldown timer completes (real PTC "nuisance cycling")', () => {
    // Same near-short load throughout - never actually cleared.
    const { components, wires } = solvePolyfuse(9, 0.1, {}, { tripped: true });
    let comps = components;

    for (let i = 0; i < 4; i++) {
      comps = advanceVisualState(comps, 1000);
      const result = simulateDC(comps, wires);
      comps = comps.map(c => updateComponentState(c, result));
    }
    const pf = comps.find(c => c.id === 2)!;
    // Still tripped - the moment the cooldown flips it back to cold
    // resistance, the still-present near-short pushes current straight
    // back past Trip Current and it re-trips on that same tick.
    expect(pf.state.tripped).toBe(true);
  });

  it('raises a warning-level (not critical) circuit error while tripped, unlike a blown Fuse', () => {
    const pf = makeComponent('polyfuse', 1);
    pf.state = { tripped: true };
    const errors = detectCircuitErrors([pf], [], null);
    const err = errors.find(e => e.type === 'polyfuse_tripped');
    expect(err).toBeTruthy();
    expect(err!.severity).toBe('warning');
  });
});
