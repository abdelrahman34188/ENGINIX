import { describe, it, expect } from 'vitest';
import {
  defaultProperties,
  defaultTerminals,
  componentNames,
  componentCategories,
} from './componentDefs';
import { simulateDC, updateComponentState } from './simulator';
import { FOOTPRINTS } from '../pcb/footprints';
import { footprintKeyFor, hasFootprintFor } from '../pcb/simulatorSync';
import { convertCircuitToPCB } from '../pcb/convertFromCircuit';
import { footprintBBox, padAbsolutePos } from '../pcb/geometry';
import type { Component, Wire } from './types';
import type { PCBComponent } from '../pcb/types';

const MOSFET_TYPES = ['irf520', 'irf540', 'irlz44n'] as const;

function makeComponent(type: Component['type'], id: number, propOverrides: Record<string, number | string | boolean> = {}): Component {
  const termDefs = defaultTerminals[type] || [];
  const props: Record<string, number | string | boolean> = {};
  for (const def of defaultProperties[type] || []) props[def.key] = def.defaultValue;
  Object.assign(props, propOverrides);
  return {
    id,
    type,
    x: 0,
    y: 0,
    rotation: 0,
    props,
    label: `${type}_${id}`,
    selected: false,
    voltage: 0,
    current: 0,
    power: 0,
    terminals: termDefs.map((td, idx) => ({
      id: id * 100 + idx,
      componentId: id,
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label,
      netId: null,
    })),
    state: {},
  } as Component;
}

function wire(id: number, a: Component, aIdx: number, b: Component, bIdx: number): Wire {
  return {
    id,
    fromTerminalId: a.terminals[aIdx].id,
    toTerminalId: b.terminals[bIdx].id,
    fromCompId: a.id,
    toCompId: b.id,
    color: '#fff',
    waypoints: [],
    selected: false,
  };
}

/** Low-side N-channel MOSFET switch driving a load (e.g. a DC motor
 * modeled as a plain resistor), gate driven by a PWM-style logic source
 * through a gate resistor: Vcc -> loadR -> Drain, Source -> GND, Vgg ->
 * gateR -> Gate, Gate return through the same GND. Mirrors
 * solveNpnSwitch()'s topology in transistor.test.ts, but the gate here
 * never draws current - it's a voltage divider, not a base-current path. */
function solveMosfetSwitch(
  type: (typeof MOSFET_TYPES)[number],
  vcc: number,
  loadOhms: number,
  vgg: number,
  gateOhms: number,
  priorState: Record<string, unknown> = {},
) {
  const vccSrc = makeComponent('battery', 1, { voltage: vcc });
  const loadR = makeComponent('resistor', 2, { resistance: loadOhms });
  const q = makeComponent(type, 3);
  q.state = { ...priorState };
  const gnd = makeComponent('ground', 4);
  const vggSrc = makeComponent('battery', 5, { voltage: vgg });
  const gateR = makeComponent('resistor', 6, { resistance: gateOhms });

  const wires: Wire[] = [
    wire(1, vccSrc, 0, loadR, 0),
    wire(2, loadR, 1, q, 1), // -> Drain (idx 1)
    wire(3, q, 2, gnd, 0), // Source (idx 2) -> GND
    wire(4, vccSrc, 1, gnd, 0),
    wire(5, vggSrc, 0, gateR, 0),
    wire(6, gateR, 1, q, 0), // -> Gate (idx 0)
    wire(7, vggSrc, 1, gnd, 0),
  ];

  const components = [vccSrc, loadR, q, gnd, vggSrc, gateR];
  const result = simulateDC(components, wires);
  return { result, components, wires, q };
}

describe('Power MOSFETs (IRF520 / IRF540 / IRLZ44N)', () => {
  it('are registered placeable component types with names and 3 terminals (Gate/Drain/Source)', () => {
    for (const type of MOSFET_TYPES) {
      expect(componentNames[type]).toBeTruthy();
      expect((defaultTerminals[type] || []).length).toBe(3);
      expect((defaultTerminals[type] || []).map(t => t.label)).toEqual(['G', 'D', 'S']);
    }
  });

  it('appear in the semiconductor palette category, distinct from the BJTs', () => {
    for (const type of MOSFET_TYPES) {
      expect(componentCategories.semiconductor).toContain(type);
    }
    expect(componentCategories.semiconductor).toContain('transistorNpn');
  });

  it('has real default properties: Gate Threshold Voltage, Rds-on, Max Drain Current, Logic Level flag', () => {
    for (const type of MOSFET_TYPES) {
      const keys = (defaultProperties[type] || []).map(p => p.key);
      expect(keys).toEqual(
        expect.arrayContaining(['partNumber', 'gateThresholdVoltage', 'rdsOn', 'maxDrainCurrent', 'logicLevel']),
      );
    }
  });

  it('IRLZ44N is a logic-level part (lower Gate Threshold Voltage, logicLevel=true) vs. the standard-level IRF520/IRF540', () => {
    const irlz = (defaultProperties.irlz44n || []).find(p => p.key === 'gateThresholdVoltage')!;
    const irf520 = (defaultProperties.irf520 || []).find(p => p.key === 'gateThresholdVoltage')!;
    const irf540 = (defaultProperties.irf540 || []).find(p => p.key === 'gateThresholdVoltage')!;
    expect(irlz.defaultValue as number).toBeLessThan(irf520.defaultValue as number);
    expect(irlz.defaultValue as number).toBeLessThan(irf540.defaultValue as number);

    const irlzLogic = (defaultProperties.irlz44n || []).find(p => p.key === 'logicLevel')!;
    const irf520Logic = (defaultProperties.irf520 || []).find(p => p.key === 'logicLevel')!;
    expect(irlzLogic.defaultValue).toBe(true);
    expect(irf520Logic.defaultValue).toBe(false);
  });

  it('has mapped PCB footprints (TO-220, 3 pads, Transistors category)', () => {
    for (const type of MOSFET_TYPES) {
      expect(hasFootprintFor(type)).toBe(true);
      const key = footprintKeyFor(type)!;
      expect(FOOTPRINTS[key].pads.length).toBe(3);
      expect(FOOTPRINTS[key].category).toBe('Transistors');
    }
  });

  it('supports Convert to PCB (produces a placed footprint, not left unmapped)', () => {
    const comps = MOSFET_TYPES.map((t, i) => makeComponent(t, i + 1));
    const result = convertCircuitToPCB(comps, []);
    expect(result.unmapped).toEqual([]);
    expect(result.components.length).toBe(3);
    for (const c of result.components) expect(FOOTPRINTS[c.footprint]).toBeTruthy();
  });

  it('supports rotation: PCB footprint bounding box swaps width/height at 90°/270°', () => {
    const key = footprintKeyFor('irf540')!;
    const fp = FOOTPRINTS[key];
    expect(footprintBBox(fp.width, fp.height, 0)).toEqual({ w: fp.width, h: fp.height });
    expect(footprintBBox(fp.width, fp.height, 90)).toEqual({ w: fp.height, h: fp.width });
    expect(footprintBBox(fp.width, fp.height, 270)).toEqual({ w: fp.height, h: fp.width });
  });

  it('supports flip: pad positions mirror on X when placed on the bottom side', () => {
    const key = footprintKeyFor('irlz44n')!;
    const fp = FOOTPRINTS[key];
    const topComp: PCBComponent = { id: 1, footprint: key, refDes: 'Q1', x: 0, y: 0, rotation: 0, side: 'top', props: {} };
    const bottomComp: PCBComponent = { ...topComp, side: 'bottom' };
    for (const p of fp.pads) {
      const topPos = padAbsolutePos(topComp, p);
      const bottomPos = padAbsolutePos(bottomComp, p);
      expect(bottomPos.x).toBeCloseTo(-topPos.x, 6);
      expect(bottomPos.y).toBeCloseTo(topPos.y, 6);
    }
  });

  // --- Real switching behavior (voltage-gated, PWM/motor-driving) --------

  for (const type of MOSFET_TYPES) {
    describe(type, () => {
      it('reports the real Gate-Source voltage (not the generic Gate-Drain terminal0/1 diff) as the component voltage', () => {
        // 5V gate drive through a 1k gate resistor into an ideal (zero
        // current) gate -> no drop across the gate resistor -> Vgs ~= 5V.
        const { result, q } = solveMosfetSwitch(type, 12, 100, 5, 1000, {});
        expect(result.converged).toBe(true);
        const updated = updateComponentState(q, result);
        expect(updated.voltage).toBeGreaterThan(4.9);
        expect(updated.voltage).toBeLessThan(5.1);
      });

      it('turns on (mosfetOn=true) once Vgs crosses Gate Threshold Voltage', () => {
        const { result, q } = solveMosfetSwitch(type, 12, 100, 5, 1000, {});
        expect(result.converged).toBe(true);
        const updated = updateComponentState(q, result);
        const vth = (q.props.gateThresholdVoltage as number) || 4;
        if (5 > vth) {
          expect(updated.state.mosfetOn).toBe(true);
        } else {
          expect(updated.state.mosfetOn).toBe(false);
        }
      });

      it('stays off (mosfetOn=false) with no gate drive (Vgs=0, well under threshold)', () => {
        const { result, q } = solveMosfetSwitch(type, 12, 100, 0, 1000, {});
        expect(result.converged).toBe(true);
        const updated = updateComponentState(q, result);
        expect(updated.state.mosfetOn).toBe(false);
      });

      it('the Gate draws no static current - a PWM/logic pin can drive it directly with no base-resistor current budget', () => {
        const { result, q } = solveMosfetSwitch(type, 12, 100, 5, 1000, {});
        expect(result.converged).toBe(true);
        const gateBranchCurrent = result.branchCurrents.get(q.id) || 0;
        expect(Math.abs(gateBranchCurrent)).toBeLessThan(1e-6);
      });

      it('once on (prior tick latched), the Drain-Source path really conducts real motor-load current (Vcc/loadR), not a scripted flag', () => {
        // A DC motor is modeled elsewhere as a resistive load - reusing a
        // plain resistor here isolates the MOSFET's own switching math.
        const { result } = solveMosfetSwitch(type, 12, 1000, 5, 1000, { mosfetOn: true });
        expect(result.converged).toBe(true);
        const loadCurrent = Math.abs(result.branchCurrents.get(2) || 0); // through loadR
        expect(loadCurrent).toBeGreaterThan(0.008);
        expect(loadCurrent).toBeLessThan(0.02);
      });

      it('while off (prior tick off, no gate drive), the Drain-Source path stays open - negligible load current', () => {
        const { result } = solveMosfetSwitch(type, 12, 1000, 0, 1000, { mosfetOn: false });
        expect(result.converged).toBe(true);
        const loadCurrent = Math.abs(result.branchCurrents.get(2) || 0);
        expect(loadCurrent).toBeLessThan(0.0005);
      });
    });
  }

  it('IRLZ44N saturates from a 3.3V/5V-level PWM gate drive where the standard-level IRF520/IRF540 would not', () => {
    // Same 3.3V gate drive on all three: only the logic-level part clears
    // its (lower) threshold.
    const logicLevelDrive = 3.3;
    const irlz = solveMosfetSwitch('irlz44n', 12, 100, logicLevelDrive, 1000, {});
    const irf520 = solveMosfetSwitch('irf520', 12, 100, logicLevelDrive, 1000, {});
    const irf540 = solveMosfetSwitch('irf540', 12, 100, logicLevelDrive, 1000, {});

    const irlzUpdated = updateComponentState(irlz.q, irlz.result);
    const irf520Updated = updateComponentState(irf520.q, irf520.result);
    const irf540Updated = updateComponentState(irf540.q, irf540.result);

    expect(irlzUpdated.state.mosfetOn).toBe(true);
    expect(irf520Updated.state.mosfetOn).toBe(false);
    expect(irf540Updated.state.mosfetOn).toBe(false);
  });
});
