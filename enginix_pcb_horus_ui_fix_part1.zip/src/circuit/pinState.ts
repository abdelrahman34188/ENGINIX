// Live Arduino Pin Inspector — per-pin real-time values.
//
// Purely a *read* of the same board props/state CircuitPinIO already
// reads/writes and the simulator already recomputes every animation
// frame. No new solve logic, no mutation, no changes to rendering or
// wiring behavior. Mirrors CircuitPinIO's own digitalRead()/analogRead()
// semantics exactly (see CircuitPinIO.ts) so the Inspector can never show
// a different HIGH/LOW or reading than a running sketch would actually see.

import type { Component } from './types';

export type PinLiveCategory = 'digital' | 'analog';

export interface PinLiveState {
  /** Terminal label as drawn on the board, e.g. 'D13', 'A0'. */
  label: string;
  category: PinLiveCategory;
  /** Digital pin's current mode, or null for analog-only pins. */
  mode: 'OUTPUT' | 'INPUT' | 'INPUT_PULLUP' | 'PWM' | null;
  /** HIGH(1)/LOW(0) for a digital pin not currently in PWM mode; null otherwise. */
  digital: 0 | 1 | null;
  /** 0-255 duty cycle while the pin is in PWM mode; null otherwise. */
  pwm: number | null;
  /** 0-1023 ADC reading for an analog pin; null for digital pins. */
  analog: number | null;
}

// Same fixed hardware fact CircuitPinIO.ts and pinMapping.ts already
// encode (Uno/Nano: 14 digital pins, Mega: 54) - duplicated rather than
// imported across the /src/arduino <-> /src/circuit boundary, same as
// those two files already do, to keep each side independently testable.
const DIGITAL_PIN_COUNT: Record<string, number> = {
  arduino: 14,
  arduinoNano: 14,
  arduinoMega: 54,
};

/**
 * Builds the live pin-state snapshot for one board. Safe to call on every
 * frame or wiring change - a plain read that never throws, even for a
 * freshly-placed board with no props/state populated yet (defaults to
 * INPUT/LOW/0, the real power-on state of an AVR pin).
 */
export function buildPinLiveStates(board: Component): PinLiveState[] {
  const digitalCount = DIGITAL_PIN_COUNT[board.type] ?? 14;
  const digitalValues = board.state.digitalValues as Record<string, boolean> | undefined;
  const analogValues = board.state.analogValues as Record<string, number> | undefined;

  const states: PinLiveState[] = [];
  for (const t of board.terminals) {
    const dMatch = /^D(\d+)$/.exec(t.label);
    if (dMatch && Number(dMatch[1]) < digitalCount) {
      const n = Number(dMatch[1]);
      const mode = ((board.props[`d${n}_mode`] as string) || 'INPUT') as PinLiveState['mode'];
      let digital: 0 | 1 | null = null;
      let pwm: number | null = null;
      if (mode === 'PWM') {
        pwm = Number(board.props[`d${n}_pwm`] ?? 0);
      } else if (mode === 'OUTPUT') {
        digital = board.props[`d${n}`] ? 1 : 0;
      } else {
        // INPUT / INPUT_PULLUP: mirror CircuitPinIO.digitalRead() exactly -
        // read the simulator's already-solved digitalValues for this pin.
        const label = `D${n}`;
        digital = digitalValues && label in digitalValues ? (digitalValues[label] ? 1 : 0) : 0;
      }
      states.push({ label: t.label, category: 'digital', mode, digital, pwm, analog: null });
      continue;
    }
    if (/^A\d+$/.test(t.label)) {
      const analog = analogValues?.[t.label] ?? 0;
      states.push({ label: t.label, category: 'analog', mode: null, digital: null, pwm: null, analog });
    }
  }
  return states;
}
