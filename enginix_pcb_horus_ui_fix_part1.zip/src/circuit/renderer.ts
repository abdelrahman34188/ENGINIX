/**
 * 2D Canvas Renderer for the Circuit Editor
 * Handles grid, components, wires, terminals, selection, and visual effects
 */

import type { Component, Wire, EditorState } from './types';
import { GRID_SIZE, COLORS, renderComponent } from './componentDefs';
import { buildOrthogonalPath, type GPoint } from './wireRouting';

export class CircuitRenderer {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  dpr: number;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
  }

  resize(width: number, height: number) {
    this.canvas.width = width * this.dpr;
    this.canvas.height = height * this.dpr;
    this.canvas.style.width = width + 'px';
    this.canvas.style.height = height + 'px';
    this.ctx.scale(this.dpr, this.dpr);
  }

  clear(width: number, height: number) {
    this.ctx.fillStyle = COLORS.background;
    this.ctx.fillRect(0, 0, width, height);
  }

  drawGrid(state: EditorState, width: number, height: number) {
    if (!state.showGrid) return;

    const { offsetX, offsetY, scale } = state;
    const gs = GRID_SIZE * scale;

    // Calculate visible grid range
    const startX = Math.floor(-offsetX / gs) * gs + offsetX;
    const startY = Math.floor(-offsetY / gs) * gs + offsetY;

    this.ctx.fillStyle = COLORS.gridDot;
    const dotSize = Math.max(1, scale * 1.5);

    for (let x = startX; x < width; x += gs) {
      for (let y = startY; y < height; y += gs) {
        this.ctx.fillRect(x - dotSize / 2, y - dotSize / 2, dotSize, dotSize);
      }
    }

    // Major grid lines every 5 units
    this.ctx.strokeStyle = 'rgba(148, 163, 184, 0.06)';
    this.ctx.lineWidth = 1;
    const majorGs = gs * 5;
    const startMajorX = Math.floor(-offsetX / majorGs) * majorGs + offsetX;
    const startMajorY = Math.floor(-offsetY / majorGs) * majorGs + offsetY;

    for (let x = startMajorX; x < width; x += majorGs) {
      this.ctx.beginPath();
      this.ctx.moveTo(x, 0);
      this.ctx.lineTo(x, height);
      this.ctx.stroke();
    }
    for (let y = startMajorY; y < height; y += majorGs) {
      this.ctx.beginPath();
      this.ctx.moveTo(0, y);
      this.ctx.lineTo(width, y);
      this.ctx.stroke();
    }
  }

  worldToScreen(wx: number, wy: number, state: EditorState): { x: number; y: number } {
    return {
      x: wx * GRID_SIZE * state.scale + state.offsetX,
      y: wy * GRID_SIZE * state.scale + state.offsetY,
    };
  }

  screenToWorld(sx: number, sy: number, state: EditorState): { x: number; y: number } {
    return {
      x: (sx - state.offsetX) / (GRID_SIZE * state.scale),
      y: (sy - state.offsetY) / (GRID_SIZE * state.scale),
    };
  }

  /**
   * Traces `path` into the current ctx path, rounding each interior corner
   * with a small arc instead of a hard 90° joint. The radius is capped to
   * half the shorter of the two adjacent segments so short legs (e.g. right
   * next to a terminal or another bend) never overshoot into a loop, and is
   * scaled with the current zoom so corners stay visually consistent from
   * fully zoomed-out to fully zoomed-in.
   */
  private tracePath(path: { x: number; y: number }[], scale: number) {
    const ctx = this.ctx;
    if (path.length < 2) return;
    const radius = Math.max(2, 7 * scale);

    ctx.moveTo(path[0].x, path[0].y);
    for (let i = 1; i < path.length - 1; i++) {
      const prev = path[i - 1];
      const curr = path[i];
      const next = path[i + 1];

      const toCurr = { x: curr.x - prev.x, y: curr.y - prev.y };
      const toNext = { x: next.x - curr.x, y: next.y - curr.y };
      const lenToCurr = Math.hypot(toCurr.x, toCurr.y);
      const lenToNext = Math.hypot(toNext.x, toNext.y);
      const r = Math.min(radius, lenToCurr / 2, lenToNext / 2);

      if (r < 0.5 || lenToCurr === 0 || lenToNext === 0) {
        // Segments too short to round without visible distortion - keep a
        // sharp corner rather than a kinked curve.
        ctx.lineTo(curr.x, curr.y);
        continue;
      }

      const before = {
        x: curr.x - (toCurr.x / lenToCurr) * r,
        y: curr.y - (toCurr.y / lenToCurr) * r,
      };
      const after = {
        x: curr.x + (toNext.x / lenToNext) * r,
        y: curr.y + (toNext.y / lenToNext) * r,
      };
      ctx.lineTo(before.x, before.y);
      ctx.quadraticCurveTo(curr.x, curr.y, after.x, after.y);
    }
    const last = path[path.length - 1];
    ctx.lineTo(last.x, last.y);
  }

  drawWire(wire: Wire, components: Component[], state: EditorState, isHovered: boolean, isSelectedOverride?: boolean) {
    const fromComp = components.find(c => c.id === wire.fromCompId);
    const toComp = components.find(c => c.id === wire.toCompId);
    if (!fromComp || !toComp) return;

    const fromTerm = fromComp.terminals.find(t => t.id === wire.fromTerminalId);
    const toTerm = toComp.terminals.find(t => t.id === wire.toTerminalId);
    if (!fromTerm || !toTerm) return;

    const isSelected = isSelectedOverride ?? wire.selected;
    this.ctx.save();

    // Wire styling. A gentle sine pulse on the glow (not the geometry)
    // keeps the selected/hovered state feeling alive without being
    // distracting or affecting hit-testing.
    const pulse = 0.75 + 0.25 * Math.sin(Date.now() / 260);
    if (isSelected) {
      this.ctx.shadowColor = COLORS.wireSelected;
      this.ctx.shadowBlur = 10 * pulse;
      this.ctx.strokeStyle = COLORS.wireSelected;
      this.ctx.lineWidth = 4 * state.scale;
    } else if (isHovered) {
      this.ctx.shadowColor = COLORS.wireHover;
      this.ctx.shadowBlur = 7;
      this.ctx.strokeStyle = COLORS.wireHover;
      this.ctx.lineWidth = 3.25 * state.scale;
    } else {
      this.ctx.strokeStyle = wire.color || COLORS.wireDefault;
      this.ctx.lineWidth = 2.25 * state.scale;
    }

    this.ctx.lineCap = 'round';
    this.ctx.lineJoin = 'round';

    // Route through the terminal endpoints plus any manual bend points,
    // auto-inserting a 90° elbow between any two anchors that aren't
    // already aligned - a Tinkercad-style corner, not a fixed midpoint jog.
    const anchors: GPoint[] = [
      { x: fromTerm.x, y: fromTerm.y },
      ...wire.waypoints.map(w => ({ x: w.x * GRID_SIZE, y: w.y * GRID_SIZE })),
      { x: toTerm.x, y: toTerm.y },
    ];
    const path = buildOrthogonalPath(anchors).map(p => ({
      x: p.x * state.scale + state.offsetX,
      y: p.y * state.scale + state.offsetY,
    }));

    this.ctx.beginPath();
    this.tracePath(path, state.scale);
    this.ctx.stroke();
    this.ctx.shadowBlur = 0;

    if (wire.netLabel && wire.netLabel.trim()) {
      const mid = path[Math.floor(path.length / 2)];
      this.ctx.save();
      this.ctx.font = `${Math.max(9, 10 * state.scale)}px "IBM Plex Mono", monospace`;
      this.ctx.textAlign = 'center';
      this.ctx.textBaseline = 'middle';
      const text = wire.netLabel.trim().toUpperCase();
      const padX = 4 * state.scale;
      const metrics = this.ctx.measureText(text);
      const boxW = metrics.width + padX * 2;
      const boxH = 12 * state.scale;
      this.ctx.fillStyle = 'rgba(15, 23, 41, 0.85)';
      this.ctx.strokeStyle = isSelected ? COLORS.wireSelected : (wire.color || COLORS.wireDefault);
      this.ctx.lineWidth = 1;
      this.ctx.fillRect(mid.x - boxW / 2, mid.y - boxH / 2 - 10 * state.scale, boxW, boxH);
      this.ctx.strokeRect(mid.x - boxW / 2, mid.y - boxH / 2 - 10 * state.scale, boxW, boxH);
      this.ctx.fillStyle = COLORS.text;
      this.ctx.fillText(text, mid.x, mid.y - 10 * state.scale);
      this.ctx.restore();
    }

    // Selection hit area (invisible wider line, generous enough to grab
    // easily at any zoom level without visually widening the wire itself)
    if (!isSelected) {
      this.ctx.strokeStyle = 'transparent';
      this.ctx.lineWidth = 12 * state.scale;
      this.ctx.beginPath();
      this.tracePath(path, state.scale);
      this.ctx.stroke();
    }

    this.ctx.restore();
  }

  drawComponent(comp: Component, state: EditorState, isHovered: boolean, isSelected: boolean) {
    this.ctx.save();

    // Apply scale for component rendering
    this.ctx.translate(state.offsetX, state.offsetY);
    this.ctx.scale(state.scale, state.scale);

    const isJunction = comp.type === 'junction';

    // Selection highlight
    if (isSelected) {
      this.ctx.save();
      this.ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
      this.ctx.strokeStyle = COLORS.selectedStroke;
      this.ctx.lineWidth = 2 / state.scale;
      this.ctx.setLineDash([4 / state.scale, 3 / state.scale]);
      if (isJunction) {
        this.ctx.beginPath();
        this.ctx.arc(0, 0, 12, 0, Math.PI * 2);
        this.ctx.stroke();
      } else {
        this.ctx.strokeRect(-35, -35, 70, 70);
      }
      this.ctx.setLineDash([]);
      this.ctx.restore();
    }

    // Hover highlight
    if (isHovered && !isSelected) {
      this.ctx.save();
      this.ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
      this.ctx.strokeStyle = COLORS.hoveredStroke;
      this.ctx.lineWidth = 1.5 / state.scale;
      this.ctx.setLineDash([3 / state.scale, 2 / state.scale]);
      if (isJunction) {
        this.ctx.beginPath();
        this.ctx.arc(0, 0, 10, 0, Math.PI * 2);
        this.ctx.stroke();
      } else {
        this.ctx.strokeRect(-35, -35, 70, 70);
      }
      this.ctx.setLineDash([]);
      this.ctx.restore();
    }

    // Render component body
    renderComponent(this.ctx, comp, isHovered);

    this.ctx.restore();
  }

  drawTerminals(comp: Component, state: EditorState, hoveredTerminalId: number | null) {
    this.ctx.save();
    for (const term of comp.terminals) {
      const sx = term.x * state.scale + state.offsetX;
      const sy = term.y * state.scale + state.offsetY;
      const isHovered = hoveredTerminalId === term.id;

      // Terminal circle - a soft halo on hover plus the solid pin dot,
      // so the target grows without ever looking jagged at any zoom.
      if (isHovered) {
        this.ctx.beginPath();
        this.ctx.arc(sx, sy, 11 * state.scale, 0, Math.PI * 2);
        this.ctx.fillStyle = 'rgba(56, 189, 248, 0.18)';
        this.ctx.fill();
      }
      this.ctx.beginPath();
      this.ctx.arc(sx, sy, (isHovered ? 7 : 5) * state.scale, 0, Math.PI * 2);
      this.ctx.fillStyle = isHovered ? COLORS.hoveredStroke : COLORS.terminalFill;
      this.ctx.fill();
      this.ctx.strokeStyle = isHovered ? '#fff' : COLORS.terminalStroke;
      this.ctx.lineWidth = Math.max(1, 1.5 * Math.min(1, state.scale));
      this.ctx.stroke();

      // Terminal label on hover
      if (isHovered) {
        this.ctx.fillStyle = COLORS.text;
        this.ctx.font = `${Math.max(9, 10 * state.scale)}px "IBM Plex Mono", monospace`;
        this.ctx.textAlign = 'center';
        this.ctx.fillText(term.label || 'pin', sx, sy - 12 * state.scale);
      }
    }
    this.ctx.restore();
  }

  drawWiringPreview(state: EditorState, mouseX: number, mouseY: number) {
    if (!state.wiringFrom) return;

    const comp = state.components.find(c => c.id === state.wiringFrom!.componentId);
    if (!comp) return;
    const term = comp.terminals.find(t => t.id === state.wiringFrom!.terminalId);
    if (!term) return;

    // End the preview at the live snap target (pin/wire/grid) rather than
    // the raw cursor position, so the preview shows exactly where the wire
    // will land if clicked right now.
    const snap = state.snapIndicator;
    const endWorld = snap
      ? { x: snap.x * GRID_SIZE, y: snap.y * GRID_SIZE }
      : { x: (mouseX - state.offsetX) / state.scale, y: (mouseY - state.offsetY) / state.scale };

    const anchors: GPoint[] = [
      { x: term.x, y: term.y },
      ...state.wiringWaypoints.map(w => ({ x: w.x * GRID_SIZE, y: w.y * GRID_SIZE })),
      endWorld,
    ];
    const path = buildOrthogonalPath(anchors).map(p => ({
      x: p.x * state.scale + state.offsetX,
      y: p.y * state.scale + state.offsetY,
    }));

    this.ctx.save();
    this.ctx.strokeStyle = COLORS.highlight;
    this.ctx.lineWidth = 2.25 * state.scale;
    this.ctx.lineCap = 'round';
    this.ctx.lineJoin = 'round';
    // Dash offset animates with time for a subtle "marching ants" flow
    // along the in-progress wire, so it reads as live rather than static.
    this.ctx.lineDashOffset = -(Date.now() / 40) % (10 * state.scale);
    this.ctx.setLineDash([6 * state.scale, 4 * state.scale]);
    this.ctx.shadowColor = COLORS.highlight;
    this.ctx.shadowBlur = 8;

    this.ctx.beginPath();
    this.tracePath(path, state.scale);
    this.ctx.stroke();

    this.ctx.setLineDash([]);
    this.ctx.shadowBlur = 0;
    this.ctx.restore();

    // Dots at each manual bend point placed so far, so the person can see
    // exactly where the wire is currently routed through.
    if (state.wiringWaypoints.length > 0) {
      this.ctx.save();
      this.ctx.fillStyle = COLORS.highlight;
      this.ctx.strokeStyle = COLORS.background;
      this.ctx.lineWidth = 1.5;
      for (const wp of state.wiringWaypoints) {
        const sx = wp.x * GRID_SIZE * state.scale + state.offsetX;
        const sy = wp.y * GRID_SIZE * state.scale + state.offsetY;
        this.ctx.beginPath();
        this.ctx.arc(sx, sy, 3.5 * state.scale, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.stroke();
      }
      this.ctx.restore();
    }

    this.drawSnapIndicator(state);
  }

  /** Highlights what the in-progress wire would snap to right now: a pin
   * or junction, a point along an existing wire, or a plain grid point. */
  drawSnapIndicator(state: EditorState) {
    const snap = state.snapIndicator;
    if (!snap) return;

    const sx = snap.x * GRID_SIZE * state.scale + state.offsetX;
    const sy = snap.y * GRID_SIZE * state.scale + state.offsetY;
    const color = snap.kind === 'pin' ? COLORS.terminalFill
      : snap.kind === 'wire' ? COLORS.hoveredStroke
      : COLORS.textDim;
    const pulse = 0.85 + 0.15 * Math.sin(Date.now() / 200);

    this.ctx.save();
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = 1.5 * state.scale;
    this.ctx.beginPath();
    this.ctx.arc(sx, sy, (snap.kind === 'grid' ? 4 : 7) * state.scale * pulse, 0, Math.PI * 2);
    this.ctx.stroke();
    if (snap.kind !== 'grid') {
      this.ctx.fillStyle = color;
      this.ctx.globalAlpha = 0.25;
      this.ctx.fill();
    }
    this.ctx.restore();
  }

  drawSelectionRect(state: EditorState) {
    if (!state.selectRect) return;
    const { x, y, w, h } = state.selectRect;

    this.ctx.save();
    this.ctx.fillStyle = 'rgba(56, 189, 248, 0.08)';
    this.ctx.strokeStyle = COLORS.hoveredStroke;
    this.ctx.lineWidth = 1;
    this.ctx.setLineDash([4, 3]);
    this.ctx.fillRect(x, y, w, h);
    this.ctx.strokeRect(x, y, w, h);
    this.ctx.setLineDash([]);
    this.ctx.restore();
  }

  render(state: EditorState, width: number, height: number, mouseX: number, mouseY: number) {
    this.clear(width, height);
    this.drawGrid(state, width, height);

    // Draw wires first (behind components)
    for (const wire of state.wires) {
      const isSelected = state.selectedWireIds.includes(wire.id);
      const isHovered = !isSelected && state.hoveredWireId === wire.id;
      this.drawWire(wire, state.components, state, isHovered, isSelected);
    }

    // Draw wiring preview
    if (state.mode === 'wire' && state.wiringFrom) {
      this.drawWiringPreview(state, mouseX, mouseY);
    }

    // Draw components
    for (const comp of state.components) {
      const isHovered = state.hoveredComponentId === comp.id;
      const isSelected = state.selectedComponentIds.includes(comp.id);
      this.drawComponent(comp, state, isHovered, isSelected);
    }

    // Draw terminals on top (junctions draw their own single dot as their body)
    for (const comp of state.components) {
      if (comp.type === 'junction') continue;
      this.drawTerminals(comp, state, state.hoveredTerminalId);
    }

    // Draw selection rectangle
    this.drawSelectionRect(state);
  }
}
