// @vitest-environment jsdom
//
// Full-stack verification for the three newly-added components (MAX485,
// CAN Bus Module, I2C Header) across every workflow the app supports:
// Simulator, PCB placement, Convert to PCB, Save/Load, Auto Wire
// (PCBEngine.autoRoute), Auto Arrange (both circuit- and PCB-side), and
// Arduino compatibility. rs485-can-i2c-modules.test.ts already covers
// per-component registration/footprint/electrical-model detail; this file
// checks the cross-cutting workflows that file didn't.
import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  defaultProperties,
  defaultTerminals,
} from './componentDefs';
import { CircuitEditor } from './CircuitEditor';
import { PCBEngine } from '../pcb/PCBEngine';
import { convertCircuitToPCB } from '../pcb/convertFromCircuit';
import { FOOTPRINTS } from '../pcb/footprints';
import { footprintBBox } from '../pcb/geometry';
import type { Component, Wire } from './types';
import type { PCBComponent } from '../pcb/types';

const NEW_TYPES = ['max485', 'canBusModule', 'i2cHeader'] as const;

function makeComponent(type: Component['type'], id: number, x = 0, y = 0): Component {
  const termDefs = defaultTerminals[type] || [];
  const props: Record<string, number | string | boolean> = {};
  for (const def of defaultProperties[type] || []) props[def.key] = def.defaultValue;
  return {
    id,
    type,
    x,
    y,
    rotation: 0,
    props,
    label: '',
    selected: false,
    voltage: 0,
    current: 0,
    power: 0,
    terminals: termDefs.map((td, idx) => ({
      id: id * 100 + idx,
      componentId: id,
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label,
      netId: null,
    })),
    state: {},
  } as Component;
}

function wire(id: number, a: Component, aIdx: number, b: Component, bIdx: number): Wire {
  return {
    id,
    fromTerminalId: a.terminals[aIdx].id,
    toTerminalId: b.terminals[bIdx].id,
    fromCompId: a.id,
    toCompId: b.id,
    color: '#fff',
    waypoints: [],
    selected: false,
  };
}

function makeCircuitEditor(): CircuitEditor {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    beginPath: () => {},
    fillRect: () => {},
    strokeRect: () => {},
    fill: () => {},
    stroke: () => {},
    arc: () => {},
    moveTo: () => {},
    lineTo: () => {},
    fillText: () => {},
    setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return new CircuitEditor(canvas, container);
}

function makePCBEngine(): PCBEngine {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({} as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  return new PCBEngine(canvas, container);
}

describe('New components work inside the Circuit Simulator (editor-level)', () => {
  for (const type of NEW_TYPES) {
    it(`${type}: can be added to a CircuitEditor and terminals resolve to real screen positions`, () => {
      const editor = makeCircuitEditor();
      const comp = makeComponent(type, 1, 5, 5);
      editor.state.components.push(comp);
      editor.updateAllTerminalPositions();
      const updated = editor.state.components.find(c => c.id === 1)!;
      expect(updated.terminals.length).toBe((defaultTerminals[type] || []).length);
      for (const t of updated.terminals) {
        expect(Number.isFinite(t.x)).toBe(true);
        expect(Number.isFinite(t.y)).toBe(true);
      }
    });
  }
});

describe('New components work inside the PCB Editor (placement, board growth)', () => {
  let engine: PCBEngine;
  beforeEach(() => { engine = makePCBEngine(); });

  for (const type of NEW_TYPES) {
    it(`${type}: converts and imports into the PCB board with a valid, non-degenerate footprint`, () => {
      const comp = makeComponent(type, 1, 2, 2);
      const result = convertCircuitToPCB([comp], []);
      expect(result.unmapped).toEqual([]);
      const placed = engine.importFromCircuit(result);
      expect(placed).toBe(1);
      expect(engine.state.components.length).toBe(1);
      const pcbComp = engine.state.components[0];
      const fp = FOOTPRINTS[pcbComp.footprint];
      expect(fp).toBeTruthy();
      expect(fp.pads.length).toBeGreaterThan(0);
      expect(fp.width).toBeGreaterThan(0);
      expect(fp.height).toBeGreaterThan(0);
    });
  }
});

describe('Convert to PCB preserves electrical connectivity for the new components', () => {
  it('MAX485 RO wired to CAN module INT and an I2C header SDA all land in the same PCB net', () => {
    const max485 = makeComponent('max485', 1, 0, 0);
    const can = makeComponent('canBusModule', 2, 5, 0);
    const hdr = makeComponent('i2cHeader', 3, 10, 0);
    const wires: Wire[] = [
      wire(1, max485, 2, can, 6), // MAX485 RO -> CAN INT
      wire(2, can, 6, hdr, 2), // CAN INT -> header SDA
    ];
    const result = convertCircuitToPCB([max485, can, hdr], wires);
    expect(result.unmapped).toEqual([]);
    expect(result.netlist.length).toBe(1);
    const pins = result.netlist[0].pins;
    expect(pins).toEqual(expect.arrayContaining([
      expect.objectContaining({ terminalLabel: 'RO' }),
      expect.objectContaining({ terminalLabel: 'INT' }),
      expect.objectContaining({ terminalLabel: 'SDA' }),
    ]));
  });

  it('each new component keeps its own refDes and property values through conversion', () => {
    const max485 = makeComponent('max485', 1);
    max485.label = 'U9';
    max485.props.partNumber = 'MAX3485';
    const result = convertCircuitToPCB([max485], []);
    expect(result.components[0].refDes).toBe('U9');
    expect(result.components[0].props.partNumber).toBe('MAX3485');
  });
});

describe('Save/Load round-trips the new components through exportCircuit/importCircuit', () => {
  it('MAX485, CAN Bus Module, and I2C Header survive a circuit export -> import cycle intact', () => {
    const editor = makeCircuitEditor();
    const max485 = makeComponent('max485', 1, 3, 3);
    max485.props.busIdleHigh = false;
    const can = makeComponent('canBusModule', 2, 6, 3);
    can.props.messagePending = true;
    const hdr = makeComponent('i2cHeader', 3, 9, 3);
    editor.state.components.push(max485, can, hdr);
    editor.state.wires.push(wire(1, max485, 2, can, 6));
    editor.updateAllTerminalPositions();

    const json = editor.exportCircuit();

    const editor2 = makeCircuitEditor();
    editor2.importCircuit(json);

    expect(editor2.state.components.length).toBe(3);
    expect(editor2.state.wires.length).toBe(1);
    const reloadedMax485 = editor2.state.components.find(c => c.type === 'max485')!;
    expect(reloadedMax485.props.busIdleHigh).toBe(false);
    const reloadedCan = editor2.state.components.find(c => c.type === 'canBusModule')!;
    expect(reloadedCan.props.messagePending).toBe(true);
    expect(editor2.state.components.some(c => c.type === 'i2cHeader')).toBe(true);
  });
});

describe('Auto Wire (PCBEngine.autoRoute) routes nets touching the new footprints', () => {
  let engine: PCBEngine;
  beforeEach(() => { engine = makePCBEngine(); });

  for (const type of NEW_TYPES) {
    it(`${type}: a two-pin net to a resistor auto-routes cleanly with no unrouted nets`, () => {
      const comp = makeComponent(type, 1, 0, 0);
      const resistor = makeComponent('resistor', 2, 20, 0);
      const firstLabel = (defaultTerminals[type] || [])[0]?.label;
      const secondLabel = (defaultTerminals[type] || [])[1]?.label;
      const wires: Wire[] = [
        wire(1, comp, 0, resistor, 0),
        wire(2, comp, 1, resistor, 1),
      ];
      const result = convertCircuitToPCB([comp, resistor], wires);
      expect(result.unmapped).toEqual([]);
      engine.importFromCircuit(result);
      const out = engine.autoRoute();
      expect(out.unrouted).toEqual([]);
      expect(out.routed).toBeGreaterThan(0);
      // Sanity: the two pins we wired are indeed the labels we expect.
      expect(firstLabel).toBeTruthy();
      expect(secondLabel).toBeTruthy();
    });
  }
});

describe('Auto Arrange spreads the new components apart, on both the Circuit and PCB sides', () => {
  it('CircuitEditor.autoArrangeCircuit moves overlapping new components into non-overlapping positions', () => {
    const editor = makeCircuitEditor();
    const max485 = makeComponent('max485', 1, 0, 0);
    const can = makeComponent('canBusModule', 2, 0, 0);
    const hdr = makeComponent('i2cHeader', 3, 0, 0);
    editor.state.components.push(max485, can, hdr);
    editor.updateAllTerminalPositions();

    const out = editor.autoArrangeCircuit();
    expect(out.moved).toBeGreaterThan(0);

    const positions = editor.state.components.map(c => ({ x: c.x, y: c.y }));
    // No two components share the exact same position after arranging.
    const uniquePositions = new Set(positions.map(p => `${p.x},${p.y}`));
    expect(uniquePositions.size).toBe(positions.length);
  });

  it('PCBEngine.autoArrange spreads overlapping new footprints into non-overlapping bounding boxes', () => {
    const engine = makePCBEngine();
    const max485 = makeComponent('max485', 1, 0, 0);
    const can = makeComponent('canBusModule', 2, 0, 0);
    const hdr = makeComponent('i2cHeader', 3, 0, 0);
    const result = convertCircuitToPCB([max485, can, hdr], []);
    engine.importFromCircuit(result);

    const out = engine.autoArrange();
    expect(out.moved).toBe(3);

    const comps = engine.state.components;
    const bbox = (c: PCBComponent) => {
      const fp = FOOTPRINTS[c.footprint];
      const b = footprintBBox(fp.width, fp.height, c.rotation);
      return { minX: c.x - b.w / 2, maxX: c.x + b.w / 2, minY: c.y - b.h / 2, maxY: c.y + b.h / 2 };
    };
    for (let i = 0; i < comps.length; i++) {
      for (let j = i + 1; j < comps.length; j++) {
        const A = bbox(comps[i]);
        const B = bbox(comps[j]);
        const overlaps = A.minX < B.maxX && A.maxX > B.minX && A.minY < B.maxY && A.maxY > B.minY;
        expect(overlaps).toBe(false);
      }
    }
  });
});

describe('Arduino compatibility: the new components wire directly into an Arduino Uno', () => {
  it('MAX485 RO -> D0 (RX) and DI <- D1 (TX) both resolve on the same simulated board', () => {
    const uno = makeComponent('arduino', 1);
    const max485 = makeComponent('max485', 2);
    const gnd = makeComponent('ground', 3);
    const d0 = (defaultTerminals.arduino || []).findIndex(t => t.label === 'D0');
    const d1 = (defaultTerminals.arduino || []).findIndex(t => t.label === 'D1');
    const unoGnd = (defaultTerminals.arduino || []).findIndex(t => t.label === 'GND');
    expect(d0).toBeGreaterThanOrEqual(0);
    expect(d1).toBeGreaterThanOrEqual(0);
    const wires: Wire[] = [
      wire(1, max485, 2, uno, d0), // RO -> D0
      wire(2, max485, 5, uno, d1), // DI -> D1
      wire(3, max485, 1, gnd, 0),
      wire(4, uno, unoGnd, gnd, 0),
    ];
    const result = convertCircuitToPCB([uno, max485, gnd], wires);
    expect(result.unmapped).toEqual([]);
  });

  it('CAN Bus Module SPI pins (CS/SO/SI/SCK) wire onto an Arduino Uno\'s hardware SPI pins (D10-D13)', () => {
    const uno = makeComponent('arduino', 1);
    const can = makeComponent('canBusModule', 2);
    const labels = (defaultTerminals.arduino || []).map(t => t.label);
    const d10 = labels.indexOf('D10');
    const d11 = labels.indexOf('D11');
    const d12 = labels.indexOf('D12');
    const d13 = labels.indexOf('D13');
    expect([d10, d11, d12, d13].every(i => i >= 0)).toBe(true);
    const wires: Wire[] = [
      wire(1, can, 2, uno, d10), // CS -> D10 (SS)
      wire(2, can, 3, uno, d12), // SO -> D12 (MISO)
      wire(3, can, 4, uno, d11), // SI -> D11 (MOSI)
      wire(4, can, 5, uno, d13), // SCK -> D13 (SCK)
    ];
    const result = convertCircuitToPCB([uno, can], wires);
    expect(result.unmapped).toEqual([]);
    // All four SPI pins should have landed in four distinct nets (no
    // accidental shorting between MOSI/MISO/SCK/CS).
    expect(result.netlist.length).toBe(4);
  });

  it('I2C Header SDA/SCL wire onto an Arduino Uno\'s dedicated I2C pins (A4/A5)', () => {
    const uno = makeComponent('arduino', 1);
    const hdr = makeComponent('i2cHeader', 2);
    const labels = (defaultTerminals.arduino || []).map(t => t.label);
    const a4 = labels.indexOf('A4');
    const a5 = labels.indexOf('A5');
    expect(a4).toBeGreaterThanOrEqual(0);
    expect(a5).toBeGreaterThanOrEqual(0);
    const wires: Wire[] = [
      wire(1, hdr, 2, uno, a4), // SDA -> A4
      wire(2, hdr, 3, uno, a5), // SCL -> A5
    ];
    const result = convertCircuitToPCB([uno, hdr], wires);
    expect(result.unmapped).toEqual([]);
    expect(result.netlist.length).toBe(2);
  });
});
