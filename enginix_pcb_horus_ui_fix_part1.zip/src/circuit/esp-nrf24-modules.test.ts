import { describe, it, expect } from 'vitest';
import {
  defaultProperties,
  defaultTerminals,
  componentNames,
  componentCategories,
} from './componentDefs';
import { simulateDC, updateComponentState } from './simulator';
import { FOOTPRINTS } from '../pcb/footprints';
import { footprintKeyFor, hasFootprintFor } from '../pcb/simulatorSync';
import { convertCircuitToPCB } from '../pcb/convertFromCircuit';
import { footprintBBox, padAbsolutePos } from '../pcb/geometry';
import type { Component, Wire } from './types';
import type { PCBComponent } from '../pcb/types';

function makeComponent(type: Component['type'], id: number, propOverrides: Record<string, number | string | boolean> = {}): Component {
  const termDefs = defaultTerminals[type] || [];
  const props: Record<string, number | string | boolean> = {};
  for (const def of defaultProperties[type] || []) props[def.key] = def.defaultValue;
  Object.assign(props, propOverrides);
  return {
    id,
    type,
    x: 0,
    y: 0,
    rotation: 0,
    props,
    label: `${type}_${id}`,
    selected: false,
    voltage: 0,
    current: 0,
    power: 0,
    terminals: termDefs.map((td, idx) => ({
      id: id * 100 + idx,
      componentId: id,
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label,
      netId: null,
    })),
    state: {},
  } as Component;
}

function wire(id: number, a: Component, aIdx: number, b: Component, bIdx: number): Wire {
  return {
    id,
    fromTerminalId: a.terminals[aIdx].id,
    toTerminalId: b.terminals[bIdx].id,
    fromCompId: a.id,
    toCompId: b.id,
    color: '#fff',
    waypoints: [],
    selected: false,
  };
}

describe('ESP8266 (ESP-01) Wi-Fi module', () => {
  it('is registered with 8 terminals in the real ESP-01 pin order', () => {
    expect(componentNames.esp8266).toBeTruthy();
    expect((defaultTerminals.esp8266 || []).map(t => t.label)).toEqual(
      ['VCC', 'GND', 'TXD', 'RXD', 'CH_PD', 'RST', 'GPIO0', 'GPIO2'],
    );
  });

  it('appears in the communication palette category', () => {
    expect(componentCategories.communication).toContain('esp8266');
  });

  it('has real default properties: baud rate, 3.3V logic level, powered, wifi connected', () => {
    const keys = (defaultProperties.esp8266 || []).map(p => p.key);
    expect(keys).toEqual(expect.arrayContaining(['partNumber', 'baudRate', 'logicLevel', 'powered', 'connected']));
    const logicLevel = (defaultProperties.esp8266 || []).find(p => p.key === 'logicLevel');
    expect(logicLevel?.defaultValue).toBe(3.3);
  });

  it('has a mapped 8-pad PCB footprint (Connectors category, correct pin labels)', () => {
    expect(hasFootprintFor('esp8266')).toBe(true);
    const key = footprintKeyFor('esp8266')!;
    const fp = FOOTPRINTS[key];
    expect(fp.pads.length).toBe(8);
    expect(fp.pads.map(p => p.id).sort()).toEqual(['CH_PD', 'GND', 'GPIO0', 'GPIO2', 'RST', 'RXD', 'TXD', 'VCC'].sort());
    expect(fp.category).toBe('Connectors');
  });

  it('supports Convert to PCB', () => {
    const esp = makeComponent('esp8266', 1);
    const result = convertCircuitToPCB([esp], []);
    expect(result.unmapped).toEqual([]);
    expect(result.components.length).toBe(1);
    expect(FOOTPRINTS[result.components[0].footprint]).toBeTruthy();
  });

  it('supports rotation and flip like other footprints', () => {
    const key = footprintKeyFor('esp8266')!;
    const fp = FOOTPRINTS[key];
    expect(footprintBBox(fp.width, fp.height, 90)).toEqual({ w: fp.height, h: fp.width });
    const topComp: PCBComponent = { id: 1, footprint: key, refDes: 'U1', x: 0, y: 0, rotation: 0, side: 'top', props: {} };
    const bottomComp: PCBComponent = { ...topComp, side: 'bottom' };
    for (const p of fp.pads) {
      expect(padAbsolutePos(bottomComp, p).x).toBeCloseTo(-padAbsolutePos(topComp, p).x, 6);
    }
  });

  it('drives TXD to its 3.3V logic level once Powered, and 0V once unpowered', () => {
    const battery = makeComponent('battery', 1, { voltage: 5 });
    const esp = makeComponent('esp8266', 2, { powered: true, logicLevel: 3.3 });
    const gnd = makeComponent('ground', 3);
    const wires: Wire[] = [
      wire(1, battery, 0, esp, 0), // VCC
      wire(2, esp, 1, gnd, 0), // GND
      wire(3, battery, 1, gnd, 0),
    ];
    const result = simulateDC([battery, esp, gnd], wires);
    expect(result.converged).toBe(true);
    const updated = updateComponentState(esp, result);
    expect(updated.state.txdVoltage).toBeCloseTo(3.3, 5);

    const espOff = makeComponent('esp8266', 2, { powered: false });
    const result2 = simulateDC([battery, espOff, gnd], wires);
    const updated2 = updateComponentState(espOff, result2);
    expect(updated2.state.txdVoltage).toBe(0);
  });

  it('can be wired straight into an Arduino Uno D0 (RX) pin and the link solves', () => {
    const uno = makeComponent('arduino', 1);
    const esp = makeComponent('esp8266', 2, { powered: true, logicLevel: 3.3 });
    const gnd = makeComponent('ground', 3);
    const unoD0Idx = (defaultTerminals.arduino || []).findIndex(t => t.label === 'D0');
    const unoGndIdx = (defaultTerminals.arduino || []).findIndex(t => t.label === 'GND');
    const wires: Wire[] = [
      wire(1, esp, 2, uno, unoD0Idx), // ESP8266 TXD -> Arduino D0 (RX)
      wire(2, esp, 1, gnd, 0), // ESP8266 GND -> GND
      wire(3, uno, unoGndIdx, gnd, 0),
    ];
    const result = simulateDC([uno, esp, gnd], wires);
    expect(result.converged).toBe(true);
  });
});

describe('ESP32 Wi-Fi/BLE module', () => {
  it('is registered with a 6-pin UART/programming header', () => {
    expect(componentNames.esp32).toBeTruthy();
    expect((defaultTerminals.esp32 || []).map(t => t.label)).toEqual(['VCC', 'TXD', 'RXD', 'EN', 'GND', 'IO0']);
  });

  it('appears in the communication palette category', () => {
    expect(componentCategories.communication).toContain('esp32');
  });

  it('has real default properties including part number variants', () => {
    const keys = (defaultProperties.esp32 || []).map(p => p.key);
    expect(keys).toEqual(expect.arrayContaining(['partNumber', 'baudRate', 'logicLevel', 'powered', 'connected']));
    const partNumber = (defaultProperties.esp32 || []).find(p => p.key === 'partNumber');
    expect(partNumber?.options?.map(o => o.value)).toEqual(expect.arrayContaining(['ESP32-WROOM-32', 'ESP32-S3']));
  });

  it('has a mapped 6-pad PCB footprint (Connectors category, correct pin labels)', () => {
    expect(hasFootprintFor('esp32')).toBe(true);
    const key = footprintKeyFor('esp32')!;
    const fp = FOOTPRINTS[key];
    expect(fp.pads.length).toBe(6);
    expect(fp.pads.map(p => p.id).sort()).toEqual(['EN', 'GND', 'IO0', 'RXD', 'TXD', 'VCC'].sort());
    expect(fp.category).toBe('Connectors');
  });

  it('supports Convert to PCB', () => {
    const esp = makeComponent('esp32', 1);
    const result = convertCircuitToPCB([esp], []);
    expect(result.unmapped).toEqual([]);
    expect(FOOTPRINTS[result.components[0].footprint]).toBeTruthy();
  });

  it('drives TXD to its logic level once Powered', () => {
    const battery = makeComponent('battery', 1, { voltage: 5 });
    const esp = makeComponent('esp32', 2, { powered: true, logicLevel: 3.3 });
    const gnd = makeComponent('ground', 3);
    const wires: Wire[] = [
      wire(1, battery, 0, esp, 0), // VCC
      wire(2, esp, 4, gnd, 0), // GND
      wire(3, battery, 1, gnd, 0),
    ];
    const result = simulateDC([battery, esp, gnd], wires);
    expect(result.converged).toBe(true);
    const updated = updateComponentState(esp, result);
    expect(updated.state.txdVoltage).toBeCloseTo(3.3, 5);
    expect(updated.state.wifiConnected).toBe(false);
  });

  it('reports Wi-Fi Connected once Powered and Connected are both set', () => {
    const battery = makeComponent('battery', 1, { voltage: 5 });
    const esp = makeComponent('esp32', 2, { powered: true, connected: true });
    const gnd = makeComponent('ground', 3);
    const wires: Wire[] = [wire(1, battery, 0, esp, 0), wire(2, esp, 4, gnd, 0), wire(3, battery, 1, gnd, 0)];
    const result = simulateDC([battery, esp, gnd], wires);
    const updated = updateComponentState(esp, result);
    expect(updated.state.wifiConnected).toBe(true);
  });
});

describe('NRF24L01+ 2.4GHz SPI transceiver', () => {
  it('is registered with 8 terminals in standard breakout pin order', () => {
    expect(componentNames.nrf24l01).toBeTruthy();
    expect((defaultTerminals.nrf24l01 || []).map(t => t.label)).toEqual(
      ['VCC', 'GND', 'CE', 'CSN', 'SCK', 'MOSI', 'MISO', 'IRQ'],
    );
  });

  it('appears in the communication palette category', () => {
    expect(componentCategories.communication).toContain('nrf24l01');
  });

  it('has real default properties: channel, data rate, powered, data ready', () => {
    const keys = (defaultProperties.nrf24l01 || []).map(p => p.key);
    expect(keys).toEqual(expect.arrayContaining(['partNumber', 'channel', 'dataRate', 'powered', 'dataReady']));
    const channel = (defaultProperties.nrf24l01 || []).find(p => p.key === 'channel');
    expect(channel?.defaultValue).toBe(76);
  });

  it('has a mapped 8-pad PCB footprint (Connectors category, correct SPI pin labels)', () => {
    expect(hasFootprintFor('nrf24l01')).toBe(true);
    const key = footprintKeyFor('nrf24l01')!;
    const fp = FOOTPRINTS[key];
    expect(fp.pads.length).toBe(8);
    expect(fp.pads.map(p => p.id).sort()).toEqual(['CE', 'CSN', 'GND', 'IRQ', 'MISO', 'MOSI', 'SCK', 'VCC'].sort());
    expect(fp.category).toBe('Connectors');
  });

  it('supports Convert to PCB', () => {
    const nrf = makeComponent('nrf24l01', 1);
    const result = convertCircuitToPCB([nrf], []);
    expect(result.unmapped).toEqual([]);
    expect(FOOTPRINTS[result.components[0].footprint]).toBeTruthy();
  });

  it('supports rotation and flip like other footprints', () => {
    const key = footprintKeyFor('nrf24l01')!;
    const fp = FOOTPRINTS[key];
    expect(footprintBBox(fp.width, fp.height, 90)).toEqual({ w: fp.height, h: fp.width });
    const topComp: PCBComponent = { id: 1, footprint: key, refDes: 'U1', x: 0, y: 0, rotation: 0, side: 'top', props: {} };
    const bottomComp: PCBComponent = { ...topComp, side: 'bottom' };
    for (const p of fp.pads) {
      expect(padAbsolutePos(bottomComp, p).x).toBeCloseTo(-padAbsolutePos(topComp, p).x, 6);
    }
  });

  it('idles IRQ high (module logic level) once Powered with no data ready', () => {
    const battery = makeComponent('battery', 1, { voltage: 5 });
    const nrf = makeComponent('nrf24l01', 2, { powered: true, dataReady: false, logicLevel: 3.3 });
    const gnd = makeComponent('ground', 3);
    const wires: Wire[] = [
      wire(1, battery, 0, nrf, 0), // VCC
      wire(2, nrf, 1, gnd, 0), // GND
      wire(3, battery, 1, gnd, 0),
    ];
    const result = simulateDC([battery, nrf, gnd], wires);
    expect(result.converged).toBe(true);
    const updated = updateComponentState(nrf, result);
    expect(updated.state.irqVoltage).toBeCloseTo(3.3, 5);
    expect(updated.state.irqActive).toBe(false);
  });

  it('pulls IRQ low (active) once Data Ready is asserted, even while Powered', () => {
    const battery = makeComponent('battery', 1, { voltage: 5 });
    const nrf = makeComponent('nrf24l01', 2, { powered: true, dataReady: true, logicLevel: 3.3 });
    const gnd = makeComponent('ground', 3);
    const wires: Wire[] = [wire(1, battery, 0, nrf, 0), wire(2, nrf, 1, gnd, 0), wire(3, battery, 1, gnd, 0)];
    const result = simulateDC([battery, nrf, gnd], wires);
    expect(result.converged).toBe(true);
    const updated = updateComponentState(nrf, result);
    expect(updated.state.irqVoltage).toBe(0);
    expect(updated.state.irqActive).toBe(true);
  });

  it('drops IRQ to 0V once unpowered', () => {
    const battery = makeComponent('battery', 1, { voltage: 5 });
    const nrf = makeComponent('nrf24l01', 2, { powered: false });
    const gnd = makeComponent('ground', 3);
    const wires: Wire[] = [wire(1, battery, 0, nrf, 0), wire(2, nrf, 1, gnd, 0), wire(3, battery, 1, gnd, 0)];
    const result = simulateDC([battery, nrf, gnd], wires);
    const updated = updateComponentState(nrf, result);
    expect(updated.state.irqVoltage).toBe(0);
  });

  it('supports non-default channel and data rate as real, storable properties', () => {
    const nrf = makeComponent('nrf24l01', 1, { channel: 40, dataRate: '2Mbps' });
    expect(nrf.props.channel).toBe(40);
    expect(nrf.props.dataRate).toBe('2Mbps');
  });
});

describe('Regression: existing HC-05/HC-06/UART modules unaffected by ESP/NRF24 additions', () => {
  it('hc05/hc06 still resolve to the Bluetooth footprint (not accidentally remapped)', () => {
    expect(footprintKeyFor('hc05')).toBe('BLUETOOTH_UART_6PIN');
    expect(footprintKeyFor('hc06')).toBe('BLUETOOTH_UART_6PIN');
  });

  it('every ComponentType still has exactly one footprint mapping (no duplicate/missing keys introduced)', () => {
    for (const type of ['esp8266', 'esp32', 'nrf24l01', 'hc05', 'hc06', 'uartHeader']) {
      expect(hasFootprintFor(type)).toBe(true);
    }
  });
});
