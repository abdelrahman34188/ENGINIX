/**
 * Circuit Audio Engine
 *
 * All sound in the simulator is synthesized live with the Web Audio API -
 * nothing is a pre-recorded/placeholder sample. Every voice is driven
 * directly by simulation state and starts/stops on its own as that state
 * changes; nothing needs to be triggered manually beyond unlocking the
 * AudioContext on the user's first interaction (browser autoplay policy).
 *
 *  - Buzzer:     continuous tone while powered, stops the instant power is
 *                removed (tiny 5ms ramp only to avoid a click). Active
 *                Buzzer behaves the same way at its one fixed tone; Passive
 *                Buzzer instead tracks the driven signal's simulated
 *                frequency, so its pitch rises and falls with it.
 *  - DC Motor:   continuous whir (tone + filtered noise) while spinning;
 *                pitch and brightness scale with motor speed, and it fades
 *                out automatically as the motor slows to a stop.
 *  - Lamp:       very soft mains-style electrical hum while lit, level
 *                tied to brightness.
 *  - Relay:      a single mechanical "click" transient on every state
 *                change (energized <-> de-energized).
 *  - Push Button: a short tactile "click" transient the moment it's pressed.
 *  - Switch:     a toggle "clack" transient on every open<->closed flip.
 *  - Relay Module: same "clack" as the bare relay, but timed to the
 *                actual (delayed) contact switch rather than the coil
 *                command, matching its Switching Delay property.
 *  - Solenoid Valve: a sharper "tock" transient the instant the plunger
 *                actually opens or closes.
 *  - Servo:      a quiet high-pitched gear whine, only while the horn is
 *                actively sweeping toward its commanded angle - silent the
 *                instant it settles, like a real RC servo.
 *  - Stepper:    a choppy, buzzy whine (square-wave chopper-drive
 *                character) while powered/stepping, pitch tracking speed;
 *                cuts instantly the moment power is removed.
 */

interface ComponentLike {
  id: number;
  type: string;
  state: Record<string, unknown>;
  props: Record<string, unknown>;
}

interface BuzzerVoice {
  osc: OscillatorNode;
  gain: GainNode;
}

interface MotorVoice {
  osc: OscillatorNode;
  oscGain: GainNode;
  noiseSrc: AudioBufferSourceNode;
  noiseFilter: BiquadFilterNode;
  noiseGain: GainNode;
}

interface LampVoice {
  osc: OscillatorNode;
  osc2: OscillatorNode;
  gain: GainNode;
}

interface ServoVoice {
  osc: OscillatorNode;
  gain: GainNode;
}

interface StepperVoice {
  osc: OscillatorNode;
  gain: GainNode;
}

class CircuitAudioEngine {
  private ctx: AudioContext | null = null;
  private noiseBufferCache: AudioBuffer | null = null;

  // Continuous voices, keyed by component id.
  private buzzerVoices = new Map<number, BuzzerVoice>();
  private motorVoices = new Map<number, MotorVoice>();
  private lampVoices = new Map<number, LampVoice>();
  private servoVoices = new Map<number, ServoVoice>();
  private stepperVoices = new Map<number, StepperVoice>();

  // Last-seen boolean state, used to detect the edges that trigger clicks.
  private lastRelayEnergized = new Map<number, boolean>();
  private lastButtonPressed = new Map<number, boolean>();
  private lastSwitchClosed = new Map<number, boolean>();
  private lastValveOpen = new Map<number, boolean>();

  /**
   * Create/resume the AudioContext. Must be called from within a user
   * gesture handler (e.g. pointerdown) to satisfy browser autoplay policy.
   */
  ensureContext(): AudioContext | null {
    const Ctor: typeof AudioContext | undefined =
      window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    if (!this.ctx) {
      this.ctx = new Ctor();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private getNoiseBuffer(ctx: AudioContext): AudioBuffer {
    if (!this.noiseBufferCache) {
      const length = Math.floor(ctx.sampleRate * 1);
      const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
      this.noiseBufferCache = buffer;
    }
    return this.noiseBufferCache;
  }

  /** Reconcile every sounding component against current simulation state. Call every frame. */
  sync(components: ComponentLike[]) {
    if (!this.ctx) return; // Audio not unlocked by a user gesture yet.
    this.syncBuzzers(components);
    this.syncMotors(components);
    this.syncServos(components);
    this.syncSteppers(components);
    this.syncLamps(components);
    this.syncRelayClicks(components);
    this.syncButtonClicks(components);
    this.syncSwitchClicks(components);
    this.syncValveClicks(components);
  }

  // ---------------------------------------------------------------------
  // Buzzer - continuous tone, starts/stops with power
  // ---------------------------------------------------------------------

  private syncBuzzers(components: ComponentLike[]) {
    const ctx = this.ctx!;
    const activeIds = new Set<number>();

    for (const comp of components) {
      const isBuzzerType = comp.type === 'buzzer' || comp.type === 'activeBuzzer' || comp.type === 'passiveBuzzer';
      if (!isBuzzerType || !comp.state.active) continue;
      activeIds.add(comp.id);

      // Active buzzer: fixed internal tone, same as a generic buzzer.
      // Passive buzzer: pitch tracks the driven signal's simulated
      // frequency (falls back to its configured min frequency if the
      // simulator hasn't produced one yet).
      let freq: number;
      if (comp.type === 'passiveBuzzer') {
        freq = (comp.state.frequency as number) || (comp.props.minFrequency as number) || 100;
      } else {
        freq = (comp.props.frequency as number) || 2000;
      }
      freq = Math.max(20, Math.min(20000, freq));
      const voice = this.buzzerVoices.get(comp.id);
      if (!voice) {
        this.startBuzzer(comp.id, freq);
      } else if (voice.osc.frequency.value !== freq) {
        voice.osc.frequency.setValueAtTime(freq, ctx.currentTime);
      }
    }

    for (const id of Array.from(this.buzzerVoices.keys())) {
      if (!activeIds.has(id)) this.stopBuzzer(id);
    }
  }

  private startBuzzer(id: number, freq: number) {
    const ctx = this.ctx;
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'square';
    osc.frequency.value = freq;

    const now = ctx.currentTime;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.05, now + 0.005);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);

    this.buzzerVoices.set(id, { osc, gain });
  }

  private stopBuzzer(id: number) {
    const ctx = this.ctx;
    const voice = this.buzzerVoices.get(id);
    this.buzzerVoices.delete(id);
    if (!ctx || !voice) return;

    try {
      const now = ctx.currentTime;
      voice.gain.gain.cancelScheduledValues(now);
      voice.gain.gain.setValueAtTime(voice.gain.gain.value, now);
      voice.gain.gain.linearRampToValueAtTime(0, now + 0.005);
      voice.osc.stop(now + 0.008);
    } catch {
      // Oscillator may already be stopped - nothing to do.
    }

    voice.osc.onended = () => {
      voice.osc.disconnect();
      voice.gain.disconnect();
    };
  }

  // ---------------------------------------------------------------------
  // DC Motor / Water Pump - continuous whir, pitch/level track speed,
  // cut instantly (not faded) the moment power is removed.
  // ---------------------------------------------------------------------

  private syncMotors(components: ComponentLike[]) {
    const activeIds = new Set<number>();
    for (const comp of components) {
      if (comp.type !== 'dcMotor' && comp.type !== 'waterPump') continue;
      activeIds.add(comp.id);
      const rpm = (comp.state.visualRpm as number) || 0;
      let voice = this.motorVoices.get(comp.id);
      if (!voice) voice = this.startMotor(comp.id);
      if (voice) this.updateMotor(voice, rpm);
    }
    for (const id of Array.from(this.motorVoices.keys())) {
      if (!activeIds.has(id)) this.stopMotor(id);
    }
  }

  private startMotor(id: number): MotorVoice | undefined {
    const ctx = this.ctx;
    if (!ctx) return undefined;

    // Tonal component of the whir.
    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    const oscGain = ctx.createGain();
    oscGain.gain.value = 0;
    osc.connect(oscGain);
    oscGain.connect(ctx.destination);

    // Filtered noise gives it a "motor" texture rather than a pure tone.
    const noiseSrc = ctx.createBufferSource();
    noiseSrc.buffer = this.getNoiseBuffer(ctx);
    noiseSrc.loop = true;
    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.Q.value = 0.7;
    const noiseGain = ctx.createGain();
    noiseGain.gain.value = 0;
    noiseSrc.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(ctx.destination);

    osc.start();
    noiseSrc.start();

    const voice: MotorVoice = { osc, oscGain, noiseSrc, noiseFilter, noiseGain };
    this.motorVoices.set(id, voice);
    return voice;
  }

  private updateMotor(voice: MotorVoice, rpm: number) {
    const ctx = this.ctx;
    if (!ctx) return;
    const now = ctx.currentTime;
    const running = rpm > 5;
    const speedFrac = Math.min(1, rpm / 3000);

    // Pitch and texture both rise with speed, like a real motor spinning up.
    voice.osc.frequency.setTargetAtTime(50 + speedFrac * 260, now, 0.08);
    voice.noiseFilter.frequency.setTargetAtTime(250 + speedFrac * 2200, now, 0.08);

    const targetOscGain = running ? 0.02 + speedFrac * 0.05 : 0;
    const targetNoiseGain = running ? 0.015 + speedFrac * 0.03 : 0;
    if (running) {
      voice.oscGain.gain.setTargetAtTime(targetOscGain, now, 0.15);
      voice.noiseGain.gain.setTargetAtTime(targetNoiseGain, now, 0.15);
    } else {
      // Power removed - stop instantly rather than smoothly fading out.
      voice.oscGain.gain.cancelScheduledValues(now);
      voice.oscGain.gain.setValueAtTime(0, now);
      voice.noiseGain.gain.cancelScheduledValues(now);
      voice.noiseGain.gain.setValueAtTime(0, now);
    }
  }

  private stopMotor(id: number) {
    const ctx = this.ctx;
    const voice = this.motorVoices.get(id);
    this.motorVoices.delete(id);
    if (!ctx || !voice) return;

    try {
      const now = ctx.currentTime;
      voice.oscGain.gain.cancelScheduledValues(now);
      voice.oscGain.gain.setValueAtTime(voice.oscGain.gain.value, now);
      voice.oscGain.gain.linearRampToValueAtTime(0, now + 0.05);
      voice.noiseGain.gain.cancelScheduledValues(now);
      voice.noiseGain.gain.setValueAtTime(voice.noiseGain.gain.value, now);
      voice.noiseGain.gain.linearRampToValueAtTime(0, now + 0.05);
      voice.osc.stop(now + 0.1);
      voice.noiseSrc.stop(now + 0.1);
    } catch {
      // Already stopped - nothing to do.
    }

    voice.osc.onended = () => { voice.osc.disconnect(); voice.oscGain.disconnect(); };
    voice.noiseSrc.onended = () => { voice.noiseSrc.disconnect(); voice.noiseFilter.disconnect(); voice.noiseGain.disconnect(); };
  }

  // ---------------------------------------------------------------------
  // Servo Motor - quiet gear whine only while actively sweeping
  // ---------------------------------------------------------------------

  private syncServos(components: ComponentLike[]) {
    const activeIds = new Set<number>();
    for (const comp of components) {
      if (comp.type !== 'servoMotor') continue;
      const moving = !!comp.state.moving;
      if (!moving) continue;
      activeIds.add(comp.id);
      let voice = this.servoVoices.get(comp.id);
      if (!voice) voice = this.startServo(comp.id);
      if (voice) this.updateServo(voice);
    }
    for (const id of Array.from(this.servoVoices.keys())) {
      if (!activeIds.has(id)) this.stopServo(id);
    }
  }

  private startServo(id: number): ServoVoice | undefined {
    const ctx = this.ctx;
    if (!ctx) return undefined;

    // A small high-pitched gear whine, like an RC servo's internal motor
    // and gear train under load - quiet and short-lived, not a drone.
    const osc = ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.value = 180;
    const gain = ctx.createGain();
    gain.gain.value = 0;

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();

    const now = ctx.currentTime;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.02, now + 0.015);

    const voice: ServoVoice = { osc, gain };
    this.servoVoices.set(id, voice);
    return voice;
  }

  private updateServo(voice: ServoVoice) {
    const ctx = this.ctx;
    if (!ctx) return;
    const now = ctx.currentTime;
    // Faint pitch flutter gives the whine a "geared" texture rather than
    // a flat tone.
    const flutter = 180 + Math.sin(now * 40) * 12;
    voice.osc.frequency.setTargetAtTime(flutter, now, 0.02);
  }

  private stopServo(id: number) {
    const ctx = this.ctx;
    const voice = this.servoVoices.get(id);
    this.servoVoices.delete(id);
    if (!ctx || !voice) return;

    try {
      const now = ctx.currentTime;
      voice.gain.gain.cancelScheduledValues(now);
      voice.gain.gain.setValueAtTime(voice.gain.gain.value, now);
      voice.gain.gain.linearRampToValueAtTime(0, now + 0.02);
      voice.osc.stop(now + 0.03);
    } catch {
      // Already stopped - nothing to do.
    }

    voice.osc.onended = () => { voice.osc.disconnect(); voice.gain.disconnect(); };
  }

  // ---------------------------------------------------------------------
  // Stepper Motor - choppy, buzzy "chopper drive" whine while powered,
  // pitch tracking speed; cuts instantly the moment power is removed
  // (same instant-stop behavior as the DC motor/water pump).
  // ---------------------------------------------------------------------

  private syncSteppers(components: ComponentLike[]) {
    const activeIds = new Set<number>();
    for (const comp of components) {
      if (comp.type !== 'stepperMotor') continue;
      const rpm = (comp.state.visualRpm as number) || 0;
      const powered = !!comp.state.powered && rpm > 0.5;
      if (!powered) continue;
      activeIds.add(comp.id);
      let voice = this.stepperVoices.get(comp.id);
      if (!voice) voice = this.startStepper(comp.id);
      if (voice) this.updateStepper(voice, rpm);
    }
    for (const id of Array.from(this.stepperVoices.keys())) {
      if (!activeIds.has(id)) this.stopStepper(id);
    }
  }

  private startStepper(id: number): StepperVoice | undefined {
    const ctx = this.ctx;
    if (!ctx) return undefined;

    // Square wave gives the choppy, buzzy character of a real stepper's
    // chopper-drive current control, distinct from the DC motor's smoother
    // sawtooth+noise whir.
    const osc = ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.value = 80;
    const gain = ctx.createGain();
    gain.gain.value = 0;

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();

    const voice: StepperVoice = { osc, gain };
    this.stepperVoices.set(id, voice);
    return voice;
  }

  private updateStepper(voice: StepperVoice, rpm: number) {
    const ctx = this.ctx;
    if (!ctx) return;
    const now = ctx.currentTime;
    const speedFrac = Math.min(1, rpm / 300);

    // Pitch rises with speed, like a real stepper's audible whine
    // climbing as step rate increases.
    voice.osc.frequency.setTargetAtTime(80 + speedFrac * 500, now, 0.05);
    voice.gain.gain.setTargetAtTime(0.02 + speedFrac * 0.025, now, 0.1);
  }

  private stopStepper(id: number) {
    const ctx = this.ctx;
    const voice = this.stepperVoices.get(id);
    this.stepperVoices.delete(id);
    if (!ctx || !voice) return;

    try {
      const now = ctx.currentTime;
      // Power removed - stop instantly rather than smoothly fading out.
      voice.gain.gain.cancelScheduledValues(now);
      voice.gain.gain.setValueAtTime(0, now);
      voice.osc.stop(now + 0.02);
    } catch {
      // Already stopped - nothing to do.
    }

    voice.osc.onended = () => { voice.osc.disconnect(); voice.gain.disconnect(); };
  }

  // ---------------------------------------------------------------------
  // Lamp - soft continuous electrical hum while lit
  // ---------------------------------------------------------------------

  private syncLamps(components: ComponentLike[]) {
    const activeIds = new Set<number>();
    for (const comp of components) {
      if (comp.type !== 'bulb') continue;
      activeIds.add(comp.id);
      const brightness = (comp.state.visualBrightness as number) || 0;
      let voice = this.lampVoices.get(comp.id);
      if (!voice) voice = this.startLamp(comp.id);
      if (voice) this.updateLamp(voice, brightness);
    }
    for (const id of Array.from(this.lampVoices.keys())) {
      if (!activeIds.has(id)) this.stopLamp(id);
    }
  }

  private startLamp(id: number): LampVoice | undefined {
    const ctx = this.ctx;
    if (!ctx) return undefined;

    // 60Hz mains fundamental plus its first harmonic - the classic soft
    // electrical hum of a lit filament/ballast.
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = 60;
    const osc2 = ctx.createOscillator();
    osc2.type = 'sine';
    osc2.frequency.value = 120;

    const gain = ctx.createGain();
    gain.gain.value = 0;
    osc.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc2.start();

    const voice: LampVoice = { osc, osc2, gain };
    this.lampVoices.set(id, voice);
    return voice;
  }

  private updateLamp(voice: LampVoice, brightness: number) {
    const ctx = this.ctx;
    if (!ctx) return;
    const now = ctx.currentTime;
    // Kept deliberately quiet - a background hum, not a buzz.
    const target = brightness > 0.05 ? 0.004 + brightness * 0.008 : 0;
    voice.gain.gain.setTargetAtTime(target, now, 0.2);
  }

  private stopLamp(id: number) {
    const ctx = this.ctx;
    const voice = this.lampVoices.get(id);
    this.lampVoices.delete(id);
    if (!ctx || !voice) return;

    try {
      const now = ctx.currentTime;
      voice.gain.gain.cancelScheduledValues(now);
      voice.gain.gain.setValueAtTime(voice.gain.gain.value, now);
      voice.gain.gain.linearRampToValueAtTime(0, now + 0.05);
      voice.osc.stop(now + 0.1);
      voice.osc2.stop(now + 0.1);
    } catch {
      // Already stopped - nothing to do.
    }

    voice.osc.onended = () => { voice.osc.disconnect(); voice.osc2.disconnect(); voice.gain.disconnect(); };
  }

  // ---------------------------------------------------------------------
  // Click transients - relay, push button, switch
  // ---------------------------------------------------------------------

  /** Synthesizes a short percussive "click" from filtered noise. */
  private playClick(filterFreq: number, q: number, duration: number, peakGain: number) {
    const ctx = this.ctx;
    if (!ctx) return;

    const src = ctx.createBufferSource();
    src.buffer = this.getNoiseBuffer(ctx);
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = filterFreq;
    filter.Q.value = q;
    const gain = ctx.createGain();

    const now = ctx.currentTime;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(peakGain, now + 0.002);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    src.start(now);
    src.stop(now + duration + 0.02);
    src.onended = () => {
      src.disconnect();
      filter.disconnect();
      gain.disconnect();
    };
  }

  private syncRelayClicks(components: ComponentLike[]) {
    const seen = new Set<number>();
    for (const comp of components) {
      if (comp.type !== 'relay' && comp.type !== 'relayModule') continue;
      seen.add(comp.id);
      const energized = !!comp.state.energized;
      const last = this.lastRelayEnergized.get(comp.id);
      if (last !== undefined && last !== energized) {
        // Lower-pitched, slightly longer "clack" - a mechanical armature.
        // For relayModule, `energized` only flips after its Switching
        // Delay has elapsed, so this click naturally lands on the actual
        // contact-switch moment, not the coil command.
        this.playClick(1100, 1.4, 0.055, 0.2);
      }
      this.lastRelayEnergized.set(comp.id, energized);
    }
    for (const id of Array.from(this.lastRelayEnergized.keys())) {
      if (!seen.has(id)) this.lastRelayEnergized.delete(id);
    }
  }

  private syncButtonClicks(components: ComponentLike[]) {
    const seen = new Set<number>();
    for (const comp of components) {
      if (comp.type !== 'pushButton') continue;
      seen.add(comp.id);
      const pressed = !!comp.state.pressed;
      const last = this.lastButtonPressed.get(comp.id);
      // Requirement is "click when pressed" - only the press edge, not release.
      if (last !== undefined && !last && pressed) {
        this.playClick(2800, 2, 0.03, 0.14);
      }
      this.lastButtonPressed.set(comp.id, pressed);
    }
    for (const id of Array.from(this.lastButtonPressed.keys())) {
      if (!seen.has(id)) this.lastButtonPressed.delete(id);
    }
  }

  private syncSwitchClicks(components: ComponentLike[]) {
    const seen = new Set<number>();
    for (const comp of components) {
      if (comp.type !== 'switch') continue;
      seen.add(comp.id);
      const closed = !!comp.props.closed;
      const last = this.lastSwitchClosed.get(comp.id);
      if (last !== undefined && last !== closed) {
        this.playClick(1700, 1.6, 0.045, 0.16);
      }
      this.lastSwitchClosed.set(comp.id, closed);
    }
    for (const id of Array.from(this.lastSwitchClosed.keys())) {
      if (!seen.has(id)) this.lastSwitchClosed.delete(id);
    }
  }

  private syncValveClicks(components: ComponentLike[]) {
    const seen = new Set<number>();
    for (const comp of components) {
      if (comp.type !== 'solenoidValve') continue;
      seen.add(comp.id);
      const open = !!comp.state.open;
      const last = this.lastValveOpen.get(comp.id);
      if (last !== undefined && last !== open) {
        // Sharper, higher-pitched "tock" than the relay's clack - a
        // solenoid plunger snapping against its seat/stop.
        this.playClick(2200, 1.8, 0.04, 0.18);
      }
      this.lastValveOpen.set(comp.id, open);
    }
    for (const id of Array.from(this.lastValveOpen.keys())) {
      if (!seen.has(id)) this.lastValveOpen.delete(id);
    }
  }

  // ---------------------------------------------------------------------

  /** Immediately stop and release every voice (editor teardown). */
  stopAll() {
    for (const id of Array.from(this.buzzerVoices.keys())) this.stopBuzzer(id);
    for (const id of Array.from(this.motorVoices.keys())) this.stopMotor(id);
    for (const id of Array.from(this.servoVoices.keys())) this.stopServo(id);
    for (const id of Array.from(this.stepperVoices.keys())) this.stopStepper(id);
    for (const id of Array.from(this.lampVoices.keys())) this.stopLamp(id);
    this.lastRelayEnergized.clear();
    this.lastButtonPressed.clear();
    this.lastSwitchClosed.clear();
    this.lastValveOpen.clear();
  }
}

export const circuitAudio = new CircuitAudioEngine();
