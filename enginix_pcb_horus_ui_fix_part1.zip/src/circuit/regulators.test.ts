import { describe, it, expect } from 'vitest';
import { defaultProperties, defaultTerminals, componentNames, componentCategories } from './componentDefs';
import { buildNets, simulateDC } from './simulator';
import { FOOTPRINTS } from '../pcb/footprints';
import { footprintKeyFor, hasFootprintFor } from '../pcb/simulatorSync';
import { convertCircuitToPCB } from '../pcb/convertFromCircuit';
import type { Component, Wire } from './types';

const NEW_TYPES = ['reg7805', 'ams1117', 'lm317'] as const;

function makeComponent(type: Component['type'], id: number, propOverrides: Record<string, number | string | boolean> = {}): Component {
  const termDefs = defaultTerminals[type] || [];
  const props: Record<string, number | string | boolean> = {};
  for (const def of defaultProperties[type] || []) props[def.key] = def.defaultValue;
  Object.assign(props, propOverrides);
  return {
    id,
    type,
    x: 0,
    y: 0,
    rotation: 0,
    props,
    label: `${type}_${id}`,
    selected: false,
    voltage: 0,
    current: 0,
    power: 0,
    terminals: termDefs.map((td, idx) => ({
      id: id * 100 + idx,
      componentId: id,
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label,
      netId: null,
    })),
    state: {},
  } as Component;
}

function wire(id: number, a: Component, aIdx: number, b: Component, bIdx: number): Wire {
  return {
    id,
    fromTerminalId: a.terminals[aIdx].id,
    toTerminalId: b.terminals[bIdx].id,
    fromCompId: a.id,
    toCompId: b.id,
    color: '#fff',
    waypoints: [],
    selected: false,
  };
}

const terminalId = (compId: number, idx: number) => compId * 10000 + idx;

/** Battery(+V) -> regulator IN -> [regulator] -> OUT -> load resistor -> GND,
 * with battery(-) and the regulator's own GND pin (when it has one) also
 * tied to the shared GND net. Returns the solved output-pin voltage
 * (relative to true circuit ground). */
function solveRegulator(
  type: 'reg7805' | 'ams1117' | 'lm317',
  batteryVoltage: number,
  loadOhms: number,
  propOverrides: Record<string, number | string | boolean> = {},
) {
  const battery = makeComponent('battery', 1, { voltage: batteryVoltage });
  const reg = makeComponent(type, 2, propOverrides);
  const gnd = makeComponent('ground', 3);
  const load = makeComponent('resistor', 4, { resistance: loadOhms });

  const inIdx = type === 'reg7805' ? 0 : 2; // IN pin index per defaultTerminals
  const gndIdx = type === 'reg7805' ? 1 : type === 'ams1117' ? 0 : null; // GND pin (LM317 has none)
  const outIdx = type === 'reg7805' ? 2 : 1; // OUT pin index

  const wires: Wire[] = [
    wire(1, battery, 0, reg, inIdx),
    wire(2, battery, 1, gnd, 0),
    wire(3, reg, outIdx, load, 0),
    wire(4, load, 1, gnd, 0),
  ];
  if (gndIdx !== null) wires.push(wire(5, reg, gndIdx, gnd, 0));

  const components = [battery, reg, gnd, load];
  const result = simulateDC(components, wires);
  const netMap = buildNets(components, wires);
  const outNet = netMap.get(terminalId(2, outIdx))!;
  const outVoltage = result.nodeVoltages.get(outNet) ?? 0;
  return { result, outVoltage };
}

describe('Linear voltage regulators: 7805, AMS1117, LM317', () => {
  it('are registered as placeable component types with names and 3 terminals', () => {
    for (const type of NEW_TYPES) {
      expect(componentNames[type]).toBeTruthy();
      expect((defaultTerminals[type] || []).length).toBe(3);
    }
  });

  it('appear in the ICs palette category', () => {
    for (const type of NEW_TYPES) {
      expect(componentCategories.ics).toContain(type);
    }
  });

  it('have correct real-world pinouts', () => {
    expect(defaultTerminals.reg7805.map(t => t.label)).toEqual(['IN', 'GND', 'OUT']);
    expect(defaultTerminals.ams1117.map(t => t.label)).toEqual(['GND', 'OUT', 'IN']);
    expect(defaultTerminals.lm317.map(t => t.label)).toEqual(['ADJ', 'OUT', 'IN']);
  });

  it('have a mapped PCB footprint with real pads in the ICs category', () => {
    for (const type of NEW_TYPES) {
      expect(hasFootprintFor(type)).toBe(true);
      const key = footprintKeyFor(type)!;
      expect(FOOTPRINTS[key]).toBeTruthy();
      expect(FOOTPRINTS[key].pads.length).toBeGreaterThanOrEqual(3);
      expect(FOOTPRINTS[key].category).toBe('ICs');
    }
  });

  it('support Convert to PCB (each produces a placed footprint, none unmapped)', () => {
    const comps = NEW_TYPES.map((type, i) => makeComponent(type, i + 1));
    const result = convertCircuitToPCB(comps, []);
    expect(result.unmapped).toEqual([]);
    expect(result.components.length).toBe(NEW_TYPES.length);
    for (const c of result.components) {
      expect(FOOTPRINTS[c.footprint]).toBeTruthy();
    }
  });

  it('7805 regulates a 9V input down to ~5V into a light load', () => {
    const { result, outVoltage } = solveRegulator('reg7805', 9, 1000);
    expect(result.converged).toBe(true);
    expect(outVoltage).toBeGreaterThan(4.9);
    expect(outVoltage).toBeLessThan(5.1);
  });

  it('7805 drops out of regulation when Vin - dropout falls below 5V', () => {
    // 6V in, 2V typical dropout -> only 4V of headroom available, so the
    // real part can't hold 5V - it should sag toward pass-through
    // instead of holding an impossible 5V.
    const { outVoltage } = solveRegulator('reg7805', 6, 1000);
    expect(outVoltage).toBeLessThan(4.5);
    expect(outVoltage).toBeGreaterThan(3.5);
  });

  it('AMS1117-3.3 regulates a 5V input down to ~3.3V', () => {
    const { result, outVoltage } = solveRegulator('ams1117', 5, 1000);
    expect(result.converged).toBe(true);
    expect(outVoltage).toBeGreaterThan(3.2);
    expect(outVoltage).toBeLessThan(3.4);
  });

  it('AMS1117-3.3 (LDO, ~1.1V dropout) still regulates with only 4.4V in', () => {
    const { outVoltage } = solveRegulator('ams1117', 4.4, 1000);
    expect(outVoltage).toBeGreaterThan(3.2);
    expect(outVoltage).toBeLessThan(3.4);
  });

  it('LM317 regulates to its configured Output Voltage property', () => {
    const { result, outVoltage } = solveRegulator('lm317', 15, 1000, { outputVoltage: 9 });
    expect(result.converged).toBe(true);
    expect(outVoltage).toBeGreaterThan(8.8);
    expect(outVoltage).toBeLessThan(9.2);
  });

  it('LM317 sags when input headroom is below the configured set point + dropout', () => {
    // Set point 9V + ~2V dropout needs >=11V in; only 8V in means it
    // cannot reach 9V and must fall back toward pass-through.
    const { outVoltage } = solveRegulator('lm317', 8, 1000, { outputVoltage: 9 });
    expect(outVoltage).toBeLessThan(6.5);
  });

  it('all three regulators output ~0V when disabled', () => {
    for (const type of NEW_TYPES) {
      const { outVoltage } = solveRegulator(type, 12, 1000, { enabled: false });
      expect(Math.abs(outVoltage)).toBeLessThan(0.05);
    }
  });

  it('output never exceeds the input rail (no free energy from the model)', () => {
    for (const type of NEW_TYPES) {
      const { outVoltage } = solveRegulator(type, 3, 1000, type === 'lm317' ? { outputVoltage: 20 } : {});
      expect(outVoltage).toBeLessThanOrEqual(3.05);
    }
  });

  it('sags further under an overloaded (well below rated current) output', () => {
    // A near-short load (2Ω) demands far more than the 1A/1.5A rated
    // limit at these set points - the crude foldback should visibly pull
    // the output down relative to the light-load case, not hold the
    // full set point into an overload.
    const light = solveRegulator('reg7805', 12, 1000).outVoltage;
    const heavy = solveRegulator('reg7805', 12, 2).outVoltage;
    expect(heavy).toBeLessThan(light);
  });
});
