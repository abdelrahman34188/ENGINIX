import { describe, it, expect } from 'vitest';
import {
  defaultProperties,
  defaultTerminals,
  componentNames,
  componentCategories,
} from './componentDefs';
import { simulateDC, updateComponentState } from './simulator';
import { FOOTPRINTS } from '../pcb/footprints';
import { footprintKeyFor, hasFootprintFor } from '../pcb/simulatorSync';
import { convertCircuitToPCB } from '../pcb/convertFromCircuit';
import { rotatePoint, footprintBBox, padAbsolutePos } from '../pcb/geometry';
import type { Component, Wire } from './types';
import type { PCBComponent } from '../pcb/types';

function makeComponent(type: Component['type'], id: number, propOverrides: Record<string, number | string | boolean> = {}): Component {
  const termDefs = defaultTerminals[type] || [];
  const props: Record<string, number | string | boolean> = {};
  for (const def of defaultProperties[type] || []) props[def.key] = def.defaultValue;
  Object.assign(props, propOverrides);
  return {
    id,
    type,
    x: 0,
    y: 0,
    rotation: 0,
    props,
    label: `${type}_${id}`,
    selected: false,
    voltage: 0,
    current: 0,
    power: 0,
    terminals: termDefs.map((td, idx) => ({
      id: id * 100 + idx,
      componentId: id,
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label,
      netId: null,
    })),
    state: {},
  } as Component;
}

function wire(id: number, a: Component, aIdx: number, b: Component, bIdx: number): Wire {
  return {
    id,
    fromTerminalId: a.terminals[aIdx].id,
    toTerminalId: b.terminals[bIdx].id,
    fromCompId: a.id,
    toCompId: b.id,
    color: '#fff',
    waypoints: [],
    selected: false,
  };
}

/** NPN common-emitter switch: Vcc -> loadR -> Collector, Emitter -> GND,
 * Vbb -> baseR -> Base, Base return through the same GND. Returns the
 * solved result plus the transistor's own (Base-Emitter) branch current. */
function solveNpnSwitch(
  vcc: number,
  loadOhms: number,
  vbb: number,
  baseOhms: number,
  priorState: Record<string, unknown> = {},
) {
  const vccSrc = makeComponent('battery', 1, { voltage: vcc });
  const loadR = makeComponent('resistor', 2, { resistance: loadOhms });
  const q = makeComponent('transistorNpn', 3);
  q.state = { ...priorState };
  const gnd = makeComponent('ground', 4);
  const vbbSrc = makeComponent('battery', 5, { voltage: vbb });
  const baseR = makeComponent('resistor', 6, { resistance: baseOhms });

  const wires: Wire[] = [
    wire(1, vccSrc, 0, loadR, 0),
    wire(2, loadR, 1, q, 1), // -> Collector (idx 1)
    wire(3, q, 2, gnd, 0), // Emitter (idx 2) -> GND
    wire(4, vccSrc, 1, gnd, 0),
    wire(5, vbbSrc, 0, baseR, 0),
    wire(6, baseR, 1, q, 0), // -> Base (idx 0)
    wire(7, vbbSrc, 1, gnd, 0),
  ];

  const components = [vccSrc, loadR, q, gnd, vbbSrc, baseR];
  const result = simulateDC(components, wires);
  const qCurrent = result.branchCurrents.get(3) || 0;
  return { result, qCurrent, components, wires, q };
}

/** PNP common-emitter switch: Vcc ties directly to Emitter, Collector ->
 * loadR -> GND. Base pulled toward `baseReturnNet` ('gnd' turns it on by
 * pulling the base below the emitter; 'vcc' keeps base == emitter, off)
 * through baseR. */
function solvePnpSwitch(
  vcc: number,
  loadOhms: number,
  baseOhms: number,
  baseReturnNet: 'gnd' | 'vcc',
  priorState: Record<string, unknown> = {},
) {
  const vccSrc = makeComponent('battery', 1, { voltage: vcc });
  const loadR = makeComponent('resistor', 2, { resistance: loadOhms });
  const q = makeComponent('transistorPnp', 3);
  q.state = { ...priorState };
  const gnd = makeComponent('ground', 4);
  const baseR = makeComponent('resistor', 5, { resistance: baseOhms });

  const wires: Wire[] = [
    wire(1, vccSrc, 0, q, 2), // Vcc(+) -> Emitter (idx 2)
    wire(2, q, 1, loadR, 0), // Collector (idx 1) -> loadR
    wire(3, loadR, 1, gnd, 0),
    wire(4, vccSrc, 1, gnd, 0),
    wire(5, q, 0, baseR, 0), // Base (idx 0) -> baseR
    wire(6, baseR, 1, baseReturnNet === 'gnd' ? gnd : vccSrc, baseReturnNet === 'gnd' ? 0 : 0),
  ];

  const components = [vccSrc, loadR, q, gnd, baseR];
  const result = simulateDC(components, wires);
  const qCurrent = result.branchCurrents.get(3) || 0;
  return { result, qCurrent, components, wires, q };
}

describe('NPN/PNP Transistors', () => {
  it('are registered placeable component types with names and 3 terminals (Base/Collector/Emitter)', () => {
    expect(componentNames.transistorNpn).toBeTruthy();
    expect(componentNames.transistorPnp).toBeTruthy();
    expect((defaultTerminals.transistorNpn || []).length).toBe(3);
    expect((defaultTerminals.transistorPnp || []).length).toBe(3);
    expect((defaultTerminals.transistorNpn || []).map(t => t.label)).toEqual(['B', 'C', 'E']);
    expect((defaultTerminals.transistorPnp || []).map(t => t.label)).toEqual(['B', 'C', 'E']);
  });

  it('are distinct from each other (names, footprints) and appear in the semiconductor category', () => {
    expect(componentNames.transistorNpn).not.toBe(componentNames.transistorPnp);
    expect(footprintKeyFor('transistorNpn')).not.toBe(footprintKeyFor('transistorPnp'));
    expect(componentCategories.semiconductor).toContain('transistorNpn');
    expect(componentCategories.semiconductor).toContain('transistorPnp');
  });

  it('has real default properties: gain, BE turn-on voltage/current, max collector current', () => {
    for (const type of ['transistorNpn', 'transistorPnp'] as const) {
      const keys = (defaultProperties[type] || []).map(p => p.key);
      expect(keys).toEqual(
        expect.arrayContaining(['partNumber', 'beta', 'vBEon', 'baseTurnOnCurrent', 'maxCollectorCurrent']),
      );
    }
  });

  it('has mapped PCB footprints (TO-92, 3 pads, Transistors category) - reusing the already-present NPN_TO92/PNP_TO92', () => {
    expect(hasFootprintFor('transistorNpn')).toBe(true);
    expect(hasFootprintFor('transistorPnp')).toBe(true);
    const npnKey = footprintKeyFor('transistorNpn')!;
    const pnpKey = footprintKeyFor('transistorPnp')!;
    expect(FOOTPRINTS[npnKey].pads.length).toBe(3);
    expect(FOOTPRINTS[pnpKey].pads.length).toBe(3);
    expect(FOOTPRINTS[npnKey].category).toBe('Transistors');
    expect(FOOTPRINTS[pnpKey].category).toBe('Transistors');
  });

  it('supports Convert to PCB (produces a placed footprint, not left unmapped)', () => {
    const npn = makeComponent('transistorNpn', 1);
    const pnp = makeComponent('transistorPnp', 2);
    const result = convertCircuitToPCB([npn, pnp], []);
    expect(result.unmapped).toEqual([]);
    expect(result.components.length).toBe(2);
    for (const c of result.components) expect(FOOTPRINTS[c.footprint]).toBeTruthy();
  });

  it('supports rotation: PCB footprint bounding box swaps width/height at 90°/270°', () => {
    const key = footprintKeyFor('transistorNpn')!;
    const fp = FOOTPRINTS[key];
    expect(footprintBBox(fp.width, fp.height, 0)).toEqual({ w: fp.width, h: fp.height });
    expect(footprintBBox(fp.width, fp.height, 90)).toEqual({ w: fp.height, h: fp.width });
    expect(footprintBBox(fp.width, fp.height, 180)).toEqual({ w: fp.width, h: fp.height });
    expect(footprintBBox(fp.width, fp.height, 270)).toEqual({ w: fp.height, h: fp.width });
  });

  it('supports flip: pad positions mirror on X when placed on the bottom side', () => {
    const key = footprintKeyFor('transistorPnp')!;
    const fp = FOOTPRINTS[key];
    const topComp: PCBComponent = { id: 1, footprint: key, refDes: 'Q1', x: 0, y: 0, rotation: 0, side: 'top', props: {} };
    const bottomComp: PCBComponent = { ...topComp, side: 'bottom' };
    for (const p of fp.pads) {
      const topPos = padAbsolutePos(topComp, p);
      const bottomPos = padAbsolutePos(bottomComp, p);
      expect(bottomPos.x).toBeCloseTo(-topPos.x, 6);
      expect(bottomPos.y).toBeCloseTo(topPos.y, 6);
    }
  });

  it('rotatePoint is consistent for all 4 cardinal rotations (sanity check shared by every footprint)', () => {
    expect(rotatePoint(1, 0, 0)).toEqual({ x: 1, y: 0 });
    expect(rotatePoint(1, 0, 90)).toEqual({ x: 0, y: 1 });
    expect(rotatePoint(1, 0, 180)).toEqual({ x: -1, y: 0 });
    expect(rotatePoint(1, 0, 270)).toEqual({ x: 0, y: -1 });
  });

  // --- Real switching behavior -------------------------------------------

  it('NPN: computes a real Base-Emitter junction current from the actual diode equation, and turns on once it crosses Base Turn-On Current', () => {
    // Vbb=5V through a 10k base resistor into a ~0.65V junction -> real
    // forward current of roughly (5 - 0.65) / 10k =~ 0.435mA, well above
    // the default 0.1mA Base Turn-On Current spec.
    const { result, q } = solveNpnSwitch(12, 1000, 5, 10_000, {});
    expect(result.converged).toBe(true);
    const updated = updateComponentState(q, result);
    expect(updated.state.baseCurrent as number).toBeGreaterThan(0.0003);
    expect(updated.state.baseCurrent as number).toBeLessThan(0.0006);
    expect(updated.state.transistorOn).toBe(true);
  });

  it('NPN: stays off (transistorOn=false) when base drive is far below Base Turn-On Current', () => {
    // No base voltage at all -> negligible junction current, well under
    // the 0.1mA threshold.
    const { result, q } = solveNpnSwitch(12, 1000, 0, 10_000, {});
    expect(result.converged).toBe(true);
    const updated = updateComponentState(q, result);
    expect(updated.state.transistorOn).toBe(false);
  });

  it('NPN: once saturated (prior tick on), the Collector-Emitter path really conducts Vcc/loadR - not a scripted brightness flag', () => {
    // Mirrors the PC817/Relay pattern: buildNets() unions Collector/
    // Emitter using LAST tick's transistorOn, so seed state.transistorOn
    // to see the actual conduction this tick.
    const { result, qCurrent } = solveNpnSwitch(12, 1000, 5, 10_000, { transistorOn: true });
    expect(result.converged).toBe(true);
    // With C-E unioned (near-zero Vce), the load resistor sees ~Vcc/loadR
    // = 12V / 1kOhm = 12mA flowing through the Collector into the
    // Emitter/GND net - this shows up as real collector-side current
    // circulating in the solved netlist, not merely a state flag.
    const collectorCurrent = Math.abs(result.branchCurrents.get(2) || 0); // through loadR
    expect(collectorCurrent).toBeGreaterThan(0.008);
    expect(collectorCurrent).toBeLessThan(0.02);
    void qCurrent;
  });

  it('NPN: while off (prior tick off, no base drive), the Collector-Emitter path stays open - negligible load current', () => {
    const { result } = solveNpnSwitch(12, 1000, 0, 10_000, { transistorOn: false });
    expect(result.converged).toBe(true);
    const collectorCurrent = Math.abs(result.branchCurrents.get(2) || 0);
    expect(collectorCurrent).toBeLessThan(0.0005);
  });

  it('PNP: turns on (real forward E->B junction current) when its base is pulled toward GND, below the emitter/Vcc rail', () => {
    const { result, q } = solvePnpSwitch(12, 1000, 10_000, 'gnd', {});
    expect(result.converged).toBe(true);
    const updated = updateComponentState(q, result);
    expect(updated.state.transistorOn).toBe(true);
    expect(Math.abs(updated.state.baseCurrent as number)).toBeGreaterThan(0.0003);
  });

  it('PNP: stays off when its base is tied to the same net as the emitter (no forward bias, no junction current)', () => {
    const { result, q } = solvePnpSwitch(12, 1000, 10_000, 'vcc', {});
    expect(result.converged).toBe(true);
    const updated = updateComponentState(q, result);
    expect(updated.state.transistorOn).toBe(false);
  });

  it('PNP: once saturated, Emitter->Collector really conducts real load current (Vcc/loadR), matching the NPN case with polarity reversed', () => {
    const { result } = solvePnpSwitch(12, 1000, 10_000, 'gnd', { transistorOn: true });
    expect(result.converged).toBe(true);
    const collectorCurrent = Math.abs(result.branchCurrents.get(2) || 0); // through loadR
    expect(collectorCurrent).toBeGreaterThan(0.008);
    expect(collectorCurrent).toBeLessThan(0.02);
  });

  it('reports the real Base-Emitter voltage (not the generic Base-Collector terminal0/1 diff) as the component voltage', () => {
    const { result, q } = solveNpnSwitch(12, 1000, 5, 10_000, { transistorOn: true });
    const updated = updateComponentState(q, result);
    // A forward-biased silicon BE junction settles close to its modeled
    // turn-on voltage (0.65V default), never near the ~12V Base-Collector
    // rail difference the generic terminal0/1 calculation would have
    // produced if left unoverridden.
    expect(Math.abs(updated.voltage)).toBeGreaterThan(0.4);
    expect(Math.abs(updated.voltage)).toBeLessThan(0.9);
  });
});
