/**
 * Circuit Simulation Engine
 * Modified Nodal Analysis (MNA) based DC circuit solver
 * Implements Ohm's Law, KVL, and KCL
 */

import type { Component, Wire, SimulationResult } from './types';
import { GRID_SIZE } from './componentDefs';

// --- Display component helpers -------------------------------------------

function hsvToHex(h: number, s: number, v: number): string {
  const hh = ((h % 360) + 360) % 360;
  const c = v * s;
  const x = c * (1 - Math.abs((hh / 60) % 2 - 1));
  const m = v - c;
  let r = 0, g = 0, b = 0;
  if (hh < 60) { r = c; g = x; }
  else if (hh < 120) { r = x; g = c; }
  else if (hh < 180) { g = c; b = x; }
  else if (hh < 240) { g = x; b = c; }
  else if (hh < 300) { r = x; b = c; }
  else { r = c; b = x; }
  const toHex = (n: number) => Math.round(Math.max(0, Math.min(1, n + m)) * 255).toString(16).padStart(2, '0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function scaleHexBrightness(hex: string, factor: number): string {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return '#1e293b';
  const num = parseInt(m[1], 16);
  const clampedFactor = Math.max(0, Math.min(1, factor));
  const r = Math.round(((num >> 16) & 255) * clampedFactor);
  const g = Math.round(((num >> 8) & 255) * clampedFactor);
  const b = Math.round((num & 255) * clampedFactor);
  const toHex = (n: number) => Math.max(0, Math.min(255, n)).toString(16).padStart(2, '0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

// Each pixel is independently addressed (its own index into the strip),
// even though today's demo modes compute all of them from one shared
// pattern - the same shape a future per-pixel code API would fill in.
function computeNeopixelColor(mode: string, i: number, count: number, phase: number, solidColor: string, brightness: number): string {
  switch (mode) {
    case 'solid':
      return scaleHexBrightness(solidColor, brightness);
    case 'rainbow': {
      const hue = (i / count) * 360 + phase * 60;
      return hsvToHex(hue, 1, brightness);
    }
    case 'chase': {
      const pos = Math.floor(phase * 6) % count;
      const dist = Math.min(Math.abs(i - pos), count - Math.abs(i - pos));
      return dist === 0 ? scaleHexBrightness(solidColor, brightness) : '#1e293b';
    }
    case 'breathing': {
      const b = (Math.sin(phase * 3) * 0.5 + 0.5) * brightness;
      return scaleHexBrightness(solidColor, b);
    }
    default:
      return '#1e293b';
  }
}

// Standard 7-segment encodings for digits 0-9 (segments a-g; dp unused here).
const SEVEN_SEG_DIGITS: Record<string, string[]> = {
  '0': ['a', 'b', 'c', 'd', 'e', 'f'],
  '1': ['b', 'c'],
  '2': ['a', 'b', 'g', 'e', 'd'],
  '3': ['a', 'b', 'g', 'c', 'd'],
  '4': ['f', 'g', 'b', 'c'],
  '5': ['a', 'f', 'g', 'c', 'd'],
  '6': ['a', 'f', 'g', 'e', 'd', 'c'],
  '7': ['a', 'b', 'c'],
  '8': ['a', 'b', 'c', 'd', 'e', 'f', 'g'],
  '9': ['a', 'b', 'c', 'd', 'f', 'g'],
};

function digitToSegments(digit: string): Record<string, boolean> {
  const on = new Set(SEVEN_SEG_DIGITS[digit] || []);
  const segs: Record<string, boolean> = {};
  for (const label of ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'dp']) {
    segs[label] = on.has(label);
  }
  return segs;
}

// Matrix operations for MNA
class Matrix {
  data: number[][];
  rows: number;
  cols: number;

  constructor(rows: number, cols: number) {
    this.rows = rows;
    this.cols = cols;
    this.data = Array.from({ length: rows }, () => Array(cols).fill(0));
  }

  get(r: number, c: number): number { return this.data[r]?.[c] ?? 0; }
  set(r: number, c: number, v: number) { if (this.data[r]) this.data[r][c] = v; }
  add(r: number, c: number, v: number) { if (this.data[r]) this.data[r][c] += v; }

  // Gaussian elimination with partial pivoting
  solve(): number[] | null {
    const n = this.rows;
    const m = this.cols;
    if (m !== n + 1) return null;

    // Augmented matrix
    const aug = this.data.map(row => [...row]);

    for (let col = 0; col < n; col++) {
      // Partial pivoting
      let maxRow = col;
      let maxVal = Math.abs(aug[col][col]);
      for (let row = col + 1; row < n; row++) {
        if (Math.abs(aug[row][col]) > maxVal) {
          maxVal = Math.abs(aug[row][col]);
          maxRow = row;
        }
      }

      if (maxVal < 1e-15) {
        // Singular or near-singular - try to continue
        continue;
      }

      // Swap rows
      if (maxRow !== col) {
        [aug[col], aug[maxRow]] = [aug[maxRow], aug[col]];
      }

      // Eliminate
      for (let row = col + 1; row < n; row++) {
        const factor = aug[row][col] / aug[col][col];
        for (let c = col; c <= n; c++) {
          aug[row][c] -= factor * aug[col][c];
        }
      }
    }

    // Back substitution
    const result = new Array(n).fill(0);
    for (let i = n - 1; i >= 0; i--) {
      if (Math.abs(aug[i][i]) < 1e-15) {
        result[i] = 0;
        continue;
      }
      let sum = aug[i][n];
      for (let j = i + 1; j < n; j++) {
        sum -= aug[i][j] * result[j];
      }
      result[i] = sum / aug[i][i];
    }

    return result;
  }
}

/**
 * Build nets from components and wires
 * A net is a group of electrically connected terminals
 */
export function buildNets(components: Component[], wires: Wire[]): Map<number, number> {
  // Union-Find data structure
  const parent = new Map<number, number>();

  function find(id: number): number {
    if (!parent.has(id)) parent.set(id, id);
    let p = parent.get(id)!;
    if (p !== id) {
      p = find(p);
      parent.set(id, p);
    }
    return p;
  }

  function union(a: number, b: number) {
    const pa = find(a);
    const pb = find(b);
    if (pa !== pb) parent.set(pa, pb);
  }

  // Each terminal gets a unique ID: componentId * 1000 + terminalIndex
  const terminalId = (compId: number, termIdx: number) => compId * 10000 + termIdx;

  // Connect terminals within the same component that should be shorted
  // (e.g., for ideal wires, switches that are closed)
  for (const comp of components) {
    if (comp.type === 'switch' && comp.props.closed) {
      // Closed switch: both terminals are the same net
      if (comp.terminals.length >= 2) {
        union(terminalId(comp.id, 0), terminalId(comp.id, 1));
      }
    }
    if (comp.type === 'pushButton' && comp.state.pressed) {
      // Pressed push button: momentarily closed, same as a closed switch
      if (comp.terminals.length >= 2) {
        union(terminalId(comp.id, 0), terminalId(comp.id, 1));
      }
    }
    if (comp.type === 'relay' && comp.terminals.length >= 5) {
      // Real SPDT contact: COM (index 4) is shorted to whichever fixed
      // contact is currently made - NC (index 2) while de-energized, NO
      // (index 3) once energized. `energized` is last frame's coil result
      // (set in updateComponentState below), so this closes the loop the
      // same way a switch's `closed` prop does.
      const noIdx = 3, ncIdx = 2, comIdx = 4;
      union(terminalId(comp.id, comIdx), terminalId(comp.id, comp.state.energized ? noIdx : ncIdx));
    }
    if (comp.type === 'pc817' && comp.terminals.length >= 4) {
      // PC817 optocoupler: the phototransistor's Collector (index 3) and
      // Emitter (index 2) are only ever joined into the same net while
      // the internal IR LED is on - `transistorOn` is last frame's
      // optically-coupled result (set in updateComponentState below from
      // the real LED-side diode current), same one-tick-delayed pattern
      // as the Relay's coil/contact above. There is deliberately no
      // union (and no shared net at all) between the LED side (Anode/
      // Cathode, indices 0/1) and this transistor side - that's the
      // actual electrical isolation a real optocoupler provides.
      if (comp.state.transistorOn) {
        union(terminalId(comp.id, 2), terminalId(comp.id, 3));
      }
    }
    if ((comp.type === 'transistorNpn' || comp.type === 'transistorPnp' || comp.type === 'tip120' || comp.type === 'tip122') && comp.terminals.length >= 3) {
      // BJT saturation switch: Collector (idx 1) and Emitter (idx 2) are
      // joined into one net once the Base-Emitter junction's real diode
      // current (stamped below; `transistorOn` is last tick's result,
      // computed in updateComponentState from that same junction current)
      // crosses Base Turn-On Current - i.e. the transistor has driven
      // into saturation. Same one-tick-delayed union pattern as the
      // Relay/PC817 above, but driven by a real BE junction rather than a
      // coil voltage or optical threshold.
      if (comp.state.transistorOn) {
        union(terminalId(comp.id, 1), terminalId(comp.id, 2));
      }
    }
    if ((comp.type === 'irf520' || comp.type === 'irf540' || comp.type === 'irlz44n') && comp.terminals.length >= 3) {
      // N-channel power MOSFET switch: Drain (idx 1) and Source (idx 2) are
      // joined into one net once Gate-Source voltage (last tick's result,
      // computed in updateComponentState below purely from node voltages -
      // the gate itself draws no DC current, so there is nothing to stamp
      // for it) has crossed Gate Threshold Voltage. Same one-tick-delayed
      // union pattern as the BJTs/Relay/PC817 above, but voltage-gated
      // rather than current-gated, matching a real MOSFET's insulated gate.
      if (comp.state.mosfetOn) {
        union(terminalId(comp.id, 1), terminalId(comp.id, 2));
      }
    }
  }

  // Connect wires
  for (const wire of wires) {
    const fromComp = components.find(c => c.id === wire.fromCompId);
    const toComp = components.find(c => c.id === wire.toCompId);
    if (fromComp && toComp) {
      const fromIdx = fromComp.terminals.findIndex(t => t.id === wire.fromTerminalId);
      const toIdx = toComp.terminals.findIndex(t => t.id === wire.toTerminalId);
      if (fromIdx >= 0 && toIdx >= 0) {
        union(terminalId(fromComp.id, fromIdx), terminalId(toComp.id, toIdx));
      }
    }
  }

  // Connect wires that share the same net label (e.g. "VCC", "GND") even
  // when they aren't physically touching - this is what lets a schematic
  // use named nets instead of a literal wire for every shared rail.
  // Labels are matched trimmed + case-insensitively; blank/whitespace-only
  // labels never join anything.
  const labelFirstTerminal = new Map<string, number>();
  for (const wire of wires) {
    const label = wire.netLabel?.trim().toUpperCase();
    if (!label) continue;

    const fromComp = components.find(c => c.id === wire.fromCompId);
    const toComp = components.find(c => c.id === wire.toCompId);
    if (!fromComp || !toComp) continue;
    const fromIdx = fromComp.terminals.findIndex(t => t.id === wire.fromTerminalId);
    const toIdx = toComp.terminals.findIndex(t => t.id === wire.toTerminalId);
    if (fromIdx < 0 || toIdx < 0) continue;

    const fromTid = terminalId(fromComp.id, fromIdx);
    const toTid = terminalId(toComp.id, toIdx);
    union(fromTid, toTid);

    const anchor = labelFirstTerminal.get(label);
    if (anchor === undefined) {
      labelFirstTerminal.set(label, fromTid);
    } else {
      union(anchor, fromTid);
    }
  }

  // Build net map: terminal key -> netId
  const netMap = new Map<number, number>();
  const netRoots = new Map<number, number>();
  let nextNetId = 0;

  for (const comp of components) {
    for (let i = 0; i < comp.terminals.length; i++) {
      const tid = terminalId(comp.id, i);
      const root = find(tid);
      if (!netRoots.has(root)) {
        netRoots.set(root, nextNetId++);
      }
      netMap.set(tid, netRoots.get(root)!);
    }
  }

  return netMap;
}

/**
 * Run DC simulation using Modified Nodal Analysis
 */
export function simulateDC(
  components: Component[],
  wires: Wire[]
): SimulationResult {
  if (components.length === 0) {
    return { converged: true, iterations: 0, nodeVoltages: new Map(), branchCurrents: new Map(), powers: new Map(), error: 0 };
  }

  // Build nets
  const netMap = buildNets(components, wires);
  const terminalId = (compId: number, termIdx: number) => compId * 10000 + termIdx;

  // Collect unique net IDs (excluding ground net), and how many terminals
  // sit on each net - a count of 1 means that terminal is floating.
  const netIds = new Set<number>();
  const netTerminalCounts = new Map<number, number>();
  for (const comp of components) {
    for (let i = 0; i < comp.terminals.length; i++) {
      const nid = netMap.get(terminalId(comp.id, i));
      if (nid !== undefined) {
        netIds.add(nid);
        netTerminalCounts.set(nid, (netTerminalCounts.get(nid) || 0) + 1);
      }
    }
  }

  // Find ground net (connected to ground components)
  let groundNetId: number | null = null;
  for (const comp of components) {
    if (comp.type === 'ground' && comp.terminals.length > 0) {
      groundNetId = netMap.get(terminalId(comp.id, 0)) ?? null;
      break;
    }
  }

  // If no ground, use the net with most connections as reference
  if (groundNetId === null) {
    const netConnectionCount = new Map<number, number>();
    for (const comp of components) {
      for (let i = 0; i < comp.terminals.length; i++) {
        const nid = netMap.get(terminalId(comp.id, i));
        if (nid !== undefined) {
          netConnectionCount.set(nid, (netConnectionCount.get(nid) || 0) + 1);
        }
      }
    }
    let maxCount = 0;
    for (const [nid, count] of netConnectionCount) {
      if (count > maxCount) {
        maxCount = count;
        groundNetId = nid;
      }
    }
  }

  // Create node index mapping (skip ground node)
  const nodeIndex = new Map<number, number>();
  let idx = 0;
  for (const nid of netIds) {
    if (nid !== groundNetId) {
      nodeIndex.set(nid, idx++);
    }
  }
  const numNodes = idx;

  // Count voltage sources for MNA
  let numVoltageSources = 0;
  const voltageSourceList: Array<{ comp: Component; nodePos: number; nodeNeg: number; voltage: number }> = [];

  for (const comp of components) {
    if (comp.type === 'battery' && comp.terminals.length >= 2) {
      const netPos = netMap.get(terminalId(comp.id, 0));
      const netNeg = netMap.get(terminalId(comp.id, 1));
      if (netPos !== undefined && netNeg !== undefined) {
        const nodePos = netPos === groundNetId ? -1 : nodeIndex.get(netPos) ?? -1;
        const nodeNeg = netNeg === groundNetId ? -1 : nodeIndex.get(netNeg) ?? -1;
        voltageSourceList.push({ comp, nodePos, nodeNeg, voltage: (comp.props.voltage as number) || 9 });
        numVoltageSources++;
      }
    }

    // Arduino: GND/5V/3V3 are fixed rails, and each digital pin (D0-D13 on
    // Uno/Nano, D0-D53 on Mega) behaves like an ideal HIGH(5V)/LOW(0V)
    // output source referenced to the board's own GND — same idea as a
    // battery, just several of them sharing one ground pin. Analog pins
    // (A0-A5/A7/A15) are intentionally NOT stamped here: on a real board
    // they're high-impedance ADC inputs, not driven outputs, so they're
    // left floating for the solver and instead just *read* afterwards
    // (see updateComponentState) to compute an analogRead()-equivalent value.
    if ((comp.type === 'arduino' || comp.type === 'arduinoMega' || comp.type === 'arduinoNano') && comp.terminals.length > 0) {
      const gndIdx = comp.terminals.findIndex(t => t.label === 'GND');
      const gndNet = gndIdx >= 0 ? netMap.get(terminalId(comp.id, gndIdx)) : undefined;
      if (gndNet !== undefined) {
        const gndNode = gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1;

        const railLabels: Array<{ label: string; voltage: number }> = [
          { label: '5V', voltage: 5 },
          { label: '3V3', voltage: 3.3 },
        ];
        for (const rail of railLabels) {
          const railIdx = comp.terminals.findIndex(t => t.label === rail.label);
          if (railIdx < 0) continue;
          const railNet = netMap.get(terminalId(comp.id, railIdx));
          if (railNet === undefined) continue;
          const railNode = railNet === groundNetId ? -1 : nodeIndex.get(railNet) ?? -1;
          voltageSourceList.push({ comp, nodePos: railNode, nodeNeg: gndNode, voltage: rail.voltage });
          numVoltageSources++;
        }

        // Each digital pin's *electrical* behavior now depends on its
        // pinMode (set via the Properties panel, mirroring a real
        // pinMode() call):
        //  - OUTPUT (default, preserves old behavior): ideal HIGH(5V)/LOW(0V)
        //    source driven by the d{n} boolean.
        //  - PWM (analogWrite, PWM-capable pins only): ideal source at the
        //    averaged duty-cycle voltage 5V*(duty/255) - the same
        //    simplification this file already uses for the NE555's OUT.
        //  - INPUT / INPUT_PULLUP: not stamped as a source here at all, so
        //    the pin is a true high-impedance input the rest of the circuit
        //    can drive; INPUT_PULLUP's weak pull to 5V is instead stamped
        //    as a conductance alongside the other resistive elements below.
        comp.terminals.forEach((t, termIdx) => {
          const m = /^D(\d+)$/.exec(t.label);
          if (!m) return;
          // While the board is held in reset (see updateComponentState,
          // one-tick delayed like this file's other latched signals), a
          // real AVR tri-states every I/O pin instead of driving it - so
          // skip stamping entirely and let the pin float, same as INPUT.
          if (comp.state?.resetActive) return;
          const mode = (comp.props[`d${m[1]}_mode`] as string) || 'OUTPUT';
          if (mode === 'INPUT' || mode === 'INPUT_PULLUP') return;
          const pinNet = netMap.get(terminalId(comp.id, termIdx));
          if (pinNet === undefined) return;
          const pinNode = pinNet === groundNetId ? -1 : nodeIndex.get(pinNet) ?? -1;
          let voltage: number;
          if (mode === 'PWM') {
            const duty = Math.max(0, Math.min(255, (comp.props[`d${m[1]}_pwm`] as number) ?? 0));
            voltage = 5 * (duty / 255);
          } else {
            const isHigh = !!comp.props[`d${m[1]}`];
            voltage = isHigh ? 5 : 0;
          }
          voltageSourceList.push({ comp, nodePos: pinNode, nodeNeg: gndNode, voltage });
          numVoltageSources++;
        });
      }
    }

    // HC-SR04: Echo (terminal 2) behaves like an ideal digital output
    // referenced to GND (terminal 3) — HIGH (5V) while a measurement pulse
    // is in progress, LOW (0V) otherwise. The pulse itself is timed in
    // advanceVisualState(); here we just expose whatever state it computed
    // as an electrical signal so downstream wiring reads a real voltage.
    if (comp.type === 'hcSr04' && comp.terminals.length >= 4) {
      const echoNet = netMap.get(terminalId(comp.id, 2));
      const gndNet = netMap.get(terminalId(comp.id, 3));
      if (echoNet !== undefined && gndNet !== undefined) {
        const echoNode = echoNet === groundNetId ? -1 : nodeIndex.get(echoNet) ?? -1;
        const gndNode = gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1;
        const echoHigh = !!comp.state.echoHigh;
        voltageSourceList.push({ comp, nodePos: echoNode, nodeNeg: gndNode, voltage: echoHigh ? 5 : 0 });
        numVoltageSources++;
      }
    }

    // HC-05/HC-06 UART Bluetooth modules: TXD (terminal 1) idles at the
    // module's own Logic Level (real modules run their UART at 3.3V TTL
    // off their onboard regulator, regardless of the 5V VCC feeding them)
    // once Powered, referenced to GND (terminal 4) — this is the UART
    // idle-high line level a host MCU's RX pin would actually see.
    // STATE (terminal 3) is a second ideal digital output on the same
    // reference, driven high once Connected (Paired) — mirroring the
    // real STATE pin a host commonly polls to detect an active link.
    // Terminal order (VCC, TXD, RXD, STATE, GND, EN) matches
    // defaultTerminals.hc05/hc06 in componentDefs.ts; RXD/EN are left
    // unstamped (passive inputs), same as HC-SR04's Trig pin above.
    // GPS NEO-6M: TX (terminal 1) idles at the module's own Logic Level
    // (real NEO-6M breakouts run their UART at 3.3V TTL off their onboard
    // regulator) once Powered and a Fix has been Acquired, referenced to
    // GND (terminal 3) - same pattern as HC-05/06's TXD above. RX
    // (terminal 2) is left unstamped (passive input). Terminal order
    // (VCC, TX, RX, GND) matches defaultTerminals.gpsNeo6m in
    // componentDefs.ts.
    if (comp.type === 'gpsNeo6m' && comp.terminals.length >= 4) {
      const txNet = netMap.get(terminalId(comp.id, 1));
      const gndNet = netMap.get(terminalId(comp.id, 3));
      const gndNode = gndNet !== undefined ? (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1) : undefined;
      const powered = comp.props.powered !== false;
      const fixAcquired = comp.props.fixAcquired !== false;
      const logicLevel = (comp.props.logicLevel as number) || 3.3;
      if (txNet !== undefined && gndNode !== undefined) {
        const txNode = txNet === groundNetId ? -1 : nodeIndex.get(txNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: txNode, nodeNeg: gndNode, voltage: powered && fixAcquired ? logicLevel : 0 });
        numVoltageSources++;
      }
    }
    if ((comp.type === 'hc05' || comp.type === 'hc06') && comp.terminals.length >= 5) {
      const txdNet = netMap.get(terminalId(comp.id, 1));
      const stateNet = netMap.get(terminalId(comp.id, 3));
      const gndNet = netMap.get(terminalId(comp.id, 4));
      const gndNode = gndNet !== undefined ? (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1) : undefined;
      const powered = comp.props.powered !== false;
      const connected = !!comp.props.connected;
      const logicLevel = (comp.props.logicLevel as number) || 3.3;
      if (txdNet !== undefined && gndNode !== undefined) {
        const txdNode = txdNet === groundNetId ? -1 : nodeIndex.get(txdNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: txdNode, nodeNeg: gndNode, voltage: powered ? logicLevel : 0 });
        numVoltageSources++;
      }
      if (stateNet !== undefined && gndNode !== undefined) {
        const stateNode = stateNet === groundNetId ? -1 : nodeIndex.get(stateNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: stateNode, nodeNeg: gndNode, voltage: powered && connected ? logicLevel : 0 });
        numVoltageSources++;
      }
    }

    // ESP8266/ESP32 Wi-Fi UART modules: same TXD idle-line model as
    // HC-05/HC-06 above - idles at the module's own logic level (3.3V,
    // not 5V tolerant) once Powered, referenced to GND. Terminal order
    // matches defaultTerminals.esp8266 (0=VCC,1=GND,2=TXD,3=RXD,...) and
    // defaultTerminals.esp32 (0=VCC,1=TXD,2=RXD,...) in componentDefs.ts.
    if (comp.type === 'esp8266' && comp.terminals.length >= 4) {
      const txdNet = netMap.get(terminalId(comp.id, 2));
      const gndNet = netMap.get(terminalId(comp.id, 1));
      const gndNode = gndNet !== undefined ? (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1) : undefined;
      const powered = comp.props.powered !== false;
      const logicLevel = (comp.props.logicLevel as number) || 3.3;
      if (txdNet !== undefined && gndNode !== undefined) {
        const txdNode = txdNet === groundNetId ? -1 : nodeIndex.get(txdNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: txdNode, nodeNeg: gndNode, voltage: powered ? logicLevel : 0 });
        numVoltageSources++;
      }
    }
    if (comp.type === 'esp32' && comp.terminals.length >= 5) {
      const txdNet = netMap.get(terminalId(comp.id, 1));
      const gndNet = netMap.get(terminalId(comp.id, 4));
      const gndNode = gndNet !== undefined ? (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1) : undefined;
      const powered = comp.props.powered !== false;
      const logicLevel = (comp.props.logicLevel as number) || 3.3;
      if (txdNet !== undefined && gndNode !== undefined) {
        const txdNode = txdNet === groundNetId ? -1 : nodeIndex.get(txdNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: txdNode, nodeNeg: gndNode, voltage: powered ? logicLevel : 0 });
        numVoltageSources++;
      }
    }

    // RC522 (MFRC522) SPI RFID reader: MISO (terminal 3) is the module's
    // one digital output to the host SPI bus - idles at the module's
    // Logic Level once Powered, referenced to GND (terminal 6), same
    // idle-line treatment as NRF24L01's IRQ/MAX485's RO above (SDA/SCK/
    // MOSI/RST are host-driven inputs and are left unstamped). Terminal
    // order (SDA, SCK, MOSI, MISO, RST, 3.3V, GND) matches
    // defaultTerminals.rc522 in componentDefs.ts.
    if (comp.type === 'rc522' && comp.terminals.length >= 7) {
      const misoNet = netMap.get(terminalId(comp.id, 3));
      const gndNet = netMap.get(terminalId(comp.id, 6));
      const gndNode = gndNet !== undefined ? (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1) : undefined;
      const powered = comp.props.powered !== false;
      const logicLevel = (comp.props.logicLevel as number) || 3.3;
      if (misoNet !== undefined && gndNode !== undefined) {
        const misoNode = misoNet === groundNetId ? -1 : nodeIndex.get(misoNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: misoNode, nodeNeg: gndNode, voltage: powered ? logicLevel : 0 });
        numVoltageSources++;
      }
    }

    // NRF24L01(+) SPI transceiver: IRQ (terminal 7) is the module's one
    // digital output - active-low, idling at the module's logic level
    // once Powered and pulled to 0V once Data Ready is asserted (mirrors
    // HC-05's STATE pin, just inverted-active to match the real chip's
    // open-drain-active-low IRQ). Terminal order matches
    // defaultTerminals.nrf24l01 (0=VCC,1=GND,...,7=IRQ) in componentDefs.ts.
    if (comp.type === 'nrf24l01' && comp.terminals.length >= 8) {
      const irqNet = netMap.get(terminalId(comp.id, 7));
      const gndNet = netMap.get(terminalId(comp.id, 1));
      const gndNode = gndNet !== undefined ? (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1) : undefined;
      const powered = comp.props.powered !== false;
      const dataReady = !!comp.props.dataReady;
      const logicLevel = (comp.props.logicLevel as number) || 3.3;
      if (irqNet !== undefined && gndNode !== undefined) {
        const irqNode = irqNet === groundNetId ? -1 : nodeIndex.get(irqNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: irqNode, nodeNeg: gndNode, voltage: powered && !dataReady ? logicLevel : 0 });
        numVoltageSources++;
      }
    }

    // MAX485 RS-485 transceiver: RO (terminal 2) is the module's one
    // digital output to the host UART - idles at the module's logic
    // level once Powered and Bus Idle High, referenced to GND (terminal
    // 1). Same idle-line model as HC-05/ESP8266's TXD above. Terminal
    // order matches defaultTerminals.max485 (0=VCC,1=GND,2=RO,...).
    if (comp.type === 'max485' && comp.terminals.length >= 3) {
      const roNet = netMap.get(terminalId(comp.id, 2));
      const gndNet = netMap.get(terminalId(comp.id, 1));
      const gndNode = gndNet !== undefined ? (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1) : undefined;
      const powered = comp.props.powered !== false;
      const busIdleHigh = comp.props.busIdleHigh !== false;
      const logicLevel = (comp.props.logicLevel as number) || 5;
      if (roNet !== undefined && gndNode !== undefined) {
        const roNode = roNet === groundNetId ? -1 : nodeIndex.get(roNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: roNode, nodeNeg: gndNode, voltage: powered && busIdleHigh ? logicLevel : 0 });
        numVoltageSources++;
      }
    }

    // CAN Bus Module (MCP2515+TJA1050): INT (terminal 6) is the module's
    // one digital output - active-low, open-drain with an onboard
    // pull-up, idling high (module's logic level) once Powered and
    // pulled low once a message is pending - exactly the same
    // active-low idle-high pattern as NRF24L01's IRQ above. Terminal
    // order matches defaultTerminals.canBusModule (0=VCC,1=GND,...,6=INT).
    if (comp.type === 'canBusModule' && comp.terminals.length >= 7) {
      const intNet = netMap.get(terminalId(comp.id, 6));
      const gndNet = netMap.get(terminalId(comp.id, 1));
      const gndNode = gndNet !== undefined ? (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1) : undefined;
      const powered = comp.props.powered !== false;
      const messagePending = !!comp.props.messagePending;
      const logicLevel = (comp.props.logicLevel as number) || 5;
      if (intNet !== undefined && gndNode !== undefined) {
        const intNode = intNet === groundNetId ? -1 : nodeIndex.get(intNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: intNode, nodeNeg: gndNode, voltage: powered && !messagePending ? logicLevel : 0 });
        numVoltageSources++;
      }
    }

    // LM35: OUT (terminal 1) behaves like an ideal analog voltage source
    // referenced to GND (terminal 2), producing 10 mV per °C of the
    // component's Temperature property — exactly matching the real LM35
    // datasheet transfer function (0V at 0°C, linear, no offset).
    // Terminal order is VCC, OUT, GND.
    if (comp.type === 'lm35' && comp.terminals.length >= 3) {
      const outNet = netMap.get(terminalId(comp.id, 1));
      const gndNet = netMap.get(terminalId(comp.id, 2));
      if (outNet !== undefined && gndNet !== undefined) {
        const outNode = outNet === groundNetId ? -1 : nodeIndex.get(outNet) ?? -1;
        const gndNode = gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1;
        const enabled = comp.props.enabled !== false;
        const temperature = Math.max(-55, Math.min(150, (comp.props.temperature as number) ?? 25));
        const outVoltage = enabled ? temperature * 0.01 : 0; // 10 mV/°C
        voltageSourceList.push({ comp, nodePos: outNode, nodeNeg: gndNode, voltage: outVoltage });
        numVoltageSources++;
      }
    }

    // NE555 Timer: OUT (idx 2) behaves as an ideal digital output
    // referenced to GND (idx 0), driven HIGH (Supply Voltage) or LOW (0V)
    // by the internal astable/monostable timing state computed each frame
    // in advanceVisualState() - same pattern as the HC-SR04's Echo pin and
    // the Arduino's D-pins, so downstream wiring (an LED, a solenoid, a
    // future Arduino input) reads a real, live voltage.
    if (comp.type === 'ne555' && comp.terminals.length >= 8) {
      const ne555GndNet = netMap.get(terminalId(comp.id, 0));
      const ne555OutNet = netMap.get(terminalId(comp.id, 2));
      if (ne555GndNet !== undefined && ne555OutNet !== undefined) {
        const ne555GndNode = ne555GndNet === groundNetId ? -1 : nodeIndex.get(ne555GndNet) ?? -1;
        const ne555OutNode = ne555OutNet === groundNetId ? -1 : nodeIndex.get(ne555OutNet) ?? -1;
        const supplyV = Math.max(4.5, (comp.props.supplyVoltage as number) || 5);
        const outHigh = !!comp.state.outHigh;
        voltageSourceList.push({ comp, nodePos: ne555OutNode, nodeNeg: ne555GndNode, voltage: outHigh ? supplyV : 0 });
        numVoltageSources++;
      }
    }

    // DHT11: DATA (terminal 1) is a single-wire, open-drain bus that idles
    // HIGH (via the sensor's internal/board pull-up) and is actively driven
    // LOW/HIGH by the sensor while it shifts out a reading. The bit-level
    // waveform (response pulse + 40 data bits) is computed once per sample
    // cycle in advanceVisualState() and stored as comp.state.dataHigh; here
    // we just expose that as a real voltage on the DATA net, referenced to
    // GND (terminal 3). Terminal order is VCC, DATA, NC, GND.
    if (comp.type === 'dht11' && comp.terminals.length >= 4) {
      const dataNet = netMap.get(terminalId(comp.id, 1));
      const gndNet = netMap.get(terminalId(comp.id, 3));
      if (dataNet !== undefined && gndNet !== undefined) {
        const dataNode = dataNet === groundNetId ? -1 : nodeIndex.get(dataNet) ?? -1;
        const gndNode = gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1;
        const dataHigh = comp.state.dataHigh !== false; // idle HIGH by default
        voltageSourceList.push({ comp, nodePos: dataNode, nodeNeg: gndNode, voltage: dataHigh ? 5 : 0 });
        numVoltageSources++;
      }
    }

    // PIR Motion Sensor: OUT (terminal 1) is a digital push-pull output
    // referenced to GND (terminal 2), HIGH (5V) while the sensor considers
    // motion "present" and LOW (0V) otherwise. The realistic response/hold
    // timing is computed once per frame in advanceVisualState() and stored
    // as comp.state.outHigh; here we just expose that as a real voltage on
    // the OUT net. Terminal order is VCC, OUT, GND.
    if (comp.type === 'pirMotion' && comp.terminals.length >= 3) {
      const outNet = netMap.get(terminalId(comp.id, 1));
      const gndNet = netMap.get(terminalId(comp.id, 2));
      if (outNet !== undefined && gndNet !== undefined) {
        const outNode = outNet === groundNetId ? -1 : nodeIndex.get(outNet) ?? -1;
        const gndNode = gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1;
        const outHigh = !!comp.state.outHigh;
        voltageSourceList.push({ comp, nodePos: outNode, nodeNeg: gndNode, voltage: outHigh ? 5 : 0 });
        numVoltageSources++;
      }
    }

    // IR Obstacle Sensor: OUT (terminal 2) is a digital push-pull output
    // referenced to GND (terminal 1) — active LOW, matching common IR
    // obstacle modules (LM393-comparator based): OUT goes LOW when an
    // obstacle is within range, HIGH otherwise. The realistic detection
    // response timing is computed once per frame in advanceVisualState()
    // and stored as comp.state.outHigh; here we just expose that as a real
    // voltage on the OUT net. Terminal order is VCC, GND, OUT.
    if (comp.type === 'irObstacle' && comp.terminals.length >= 3) {
      const gndNet = netMap.get(terminalId(comp.id, 1));
      const outNet = netMap.get(terminalId(comp.id, 2));
      if (outNet !== undefined && gndNet !== undefined) {
        const outNode = outNet === groundNetId ? -1 : nodeIndex.get(outNet) ?? -1;
        const gndNode = gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1;
        const outHigh = !!comp.state.outHigh;
        voltageSourceList.push({ comp, nodePos: outNode, nodeNeg: gndNode, voltage: outHigh ? 5 : 0 });
        numVoltageSources++;
      }
    }

    // MQ-2 Gas Sensor: AO (terminal 2) is an analog push-pull output
    // referenced to GND (terminal 1), proportional to "Gas Concentration"
    // (0-100% maps to 0-5V, mirroring the 0-5V analog range a real MQ-2's
    // internal comparator op-amp/voltage-divider output swings across).
    // DO (terminal 3) is a digital push-pull output referenced to the same
    // GND, driven by the onboard comparator: HIGH once concentration
    // reaches the configured "Digital Threshold", LOW below it. Both
    // values are computed fresh every frame in advanceVisualState() and
    // stored as comp.state.aoVoltage / comp.state.doHigh; here we just
    // expose them as real voltages on their nets. Terminal order is
    // VCC, GND, AO, DO.
    if (comp.type === 'mq2Gas' && comp.terminals.length >= 4) {
      const gndNet = netMap.get(terminalId(comp.id, 1));
      const aoNet = netMap.get(terminalId(comp.id, 2));
      const doNet = netMap.get(terminalId(comp.id, 3));
      const gndNode = gndNet !== undefined ? (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1) : undefined;

      if (aoNet !== undefined && gndNode !== undefined) {
        const aoNode = aoNet === groundNetId ? -1 : nodeIndex.get(aoNet) ?? -1;
        const aoVoltage = typeof comp.state.aoVoltage === 'number' ? comp.state.aoVoltage : 0;
        voltageSourceList.push({ comp, nodePos: aoNode, nodeNeg: gndNode, voltage: aoVoltage });
        numVoltageSources++;
      }
      if (doNet !== undefined && gndNode !== undefined) {
        const doNode = doNet === groundNetId ? -1 : nodeIndex.get(doNet) ?? -1;
        const doHigh = !!comp.state.doHigh;
        voltageSourceList.push({ comp, nodePos: doNode, nodeNeg: gndNode, voltage: doHigh ? 5 : 0 });
        numVoltageSources++;
      }
    }

    // Flame Sensor: DO (terminal 2) is a digital push-pull output
    // referenced to GND (terminal 1) — active LOW, matching common
    // YG1006/KY-026-style flame sensor modules (LM393-comparator based):
    // DO goes LOW once Flame Intensity crosses the configured Digital
    // Threshold, HIGH otherwise. AO (terminal 3) is an analog push-pull
    // output referenced to the same GND, proportional to Flame Intensity
    // (0-100% maps to 0-5V). Both values are computed fresh every frame in
    // advanceVisualState() and stored as comp.state.doHigh / aoVoltage;
    // here we just expose them as real voltages on their nets. Terminal
    // order is VCC, GND, DO, AO.
    if (comp.type === 'flameSensor' && comp.terminals.length >= 4) {
      const gndNet = netMap.get(terminalId(comp.id, 1));
      const doNet = netMap.get(terminalId(comp.id, 2));
      const aoNet = netMap.get(terminalId(comp.id, 3));
      const gndNode = gndNet !== undefined ? (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1) : undefined;

      if (doNet !== undefined && gndNode !== undefined) {
        const doNode = doNet === groundNetId ? -1 : nodeIndex.get(doNet) ?? -1;
        const doHigh = comp.state.doHigh !== false; // idle HIGH (no flame) by default
        voltageSourceList.push({ comp, nodePos: doNode, nodeNeg: gndNode, voltage: doHigh ? 5 : 0 });
        numVoltageSources++;
      }
      if (aoNet !== undefined && gndNode !== undefined) {
        const aoNode = aoNet === groundNetId ? -1 : nodeIndex.get(aoNet) ?? -1;
        const aoVoltage = typeof comp.state.aoVoltage === 'number' ? comp.state.aoVoltage : 0;
        voltageSourceList.push({ comp, nodePos: aoNode, nodeNeg: gndNode, voltage: aoVoltage });
        numVoltageSources++;
      }
    }

    // L293D / L298N H-bridge drivers: each channel's pair of OUT pins is
    // a real push-pull voltage source swinging across Motor Supply
    // Voltage (Vs) - forward ties OUTa high/OUTb low, reverse is the
    // opposite, and disabled/braking ties both low (0V differential; a
    // true tri-state float isn't used here since an unpowered floating
    // node with only the motor's coil resistance on it would leave the
    // matrix under-constrained). The direction/enable decision itself is
    // computed once per tick in updateComponentState() from the wired
    // IN/EN pins and stored in comp.state - same one-tick-delayed pattern
    // as the NE555's OUT - so it only needs reading here, not solving.
    const stampHBridgeChannel = (outAIdx: number, outBIdx: number, gndIdx: number, enabledKey: string, dirKey: string) => {
      const outANet = netMap.get(terminalId(comp.id, outAIdx));
      const outBNet = netMap.get(terminalId(comp.id, outBIdx));
      if (outANet === undefined || outBNet === undefined) return;
      const outANode = outANet === groundNetId ? -1 : nodeIndex.get(outANet) ?? -1;
      const outBNode = outBNet === groundNetId ? -1 : nodeIndex.get(outBNet) ?? -1;
      const gndNet = netMap.get(terminalId(comp.id, gndIdx));
      const gndNode = gndNet === undefined ? -1 : (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1);
      const vs = Math.max(0, (comp.props.motorSupplyVoltage as number) || 12);
      const enableLevel = Math.max(0, Math.min(1, (comp.state[enabledKey] as number) ?? 1));
      const dir = (comp.state[dirKey] as number) || 0;
      const outAV = dir > 0 ? vs * enableLevel : 0;
      const outBV = dir < 0 ? vs * enableLevel : 0;
      voltageSourceList.push({ comp, nodePos: outANode, nodeNeg: gndNode, voltage: outAV });
      numVoltageSources++;
      voltageSourceList.push({ comp, nodePos: outBNode, nodeNeg: gndNode, voltage: outBV });
      numVoltageSources++;
    };
    if (comp.type === 'l293d' && comp.terminals.length >= 16) {
      stampHBridgeChannel(2, 5, 3, 'ch1Enabled', 'ch1Direction');   // OUT1/OUT2, GND idx3
      stampHBridgeChannel(10, 13, 11, 'ch2Enabled', 'ch2Direction'); // OUT3/OUT4, GND idx11
    }
    if (comp.type === 'l298n' && comp.terminals.length >= 13) {
      stampHBridgeChannel(6, 7, 0, 'ch1Enabled', 'ch1Direction');   // OUT1/OUT2, GND idx0
      stampHBridgeChannel(11, 12, 0, 'ch2Enabled', 'ch2Direction'); // OUT3/OUT4, GND idx0
    }

    // ULN2003: 7 independent open-collector Darlington channels, not an
    // H-bridge. Each OUTn is a real voltage source referenced to GND
    // (idx 7): saturationVoltage (near 0V) while its Darlington pair is
    // on (INn read high last tick), or the COM rail while off - modeling
    // the pair turning off and the wired coil/load pulling that node back
    // up toward COM through the internal flyback diode with no current
    // flowing. COM's own voltage is only known from last tick's solve
    // (same one-tick-delayed pattern as the L293D/L298N's enable/
    // direction above and the NE555's OUT), computed in
    // updateComponentState() below and cached in comp.state.comVoltage -
    // falling back to the Supply Voltage (COM) property if COM isn't
    // wired at all yet.
    if (comp.type === 'uln2003' && comp.terminals.length >= 16) {
      const gndNet = netMap.get(terminalId(comp.id, 7));
      const gndNode = gndNet === undefined ? -1 : (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1);
      const satV = Math.max(0, (comp.props.saturationVoltage as number) ?? 0.9);
      const comV = typeof comp.state.comVoltage === 'number'
        ? comp.state.comVoltage as number
        : Math.max(0, (comp.props.comSupplyVoltage as number) ?? 12);

      const stampULNChannel = (outIdx: number, onKey: string) => {
        const outNet = netMap.get(terminalId(comp.id, outIdx));
        if (outNet === undefined) return;
        const outNode = outNet === groundNetId ? -1 : nodeIndex.get(outNet) ?? -1;
        const on = !!comp.state[onKey];
        voltageSourceList.push({ comp, nodePos: outNode, nodeNeg: gndNode, voltage: on ? satV : comV });
        numVoltageSources++;
      };
      // idx 15=OUT1 ... idx 9=OUT7, paired with IN1 (idx 0) ... IN7 (idx 6).
      stampULNChannel(15, 'out1On');
      stampULNChannel(14, 'out2On');
      stampULNChannel(13, 'out3On');
      stampULNChannel(12, 'out4On');
      stampULNChannel(11, 'out5On');
      stampULNChannel(10, 'out6On');
      stampULNChannel(9, 'out7On');
    }

    // 74HC595: 8 latched parallel outputs (Q0-Q7) + 1 always-active
    // serial cascade output (Q7'), each a real digital voltage source
    // referenced to this chip's own GND (idx 7). Q0-Q7 reflect the
    // OE-gated output latch computed in updateComponentState() below
    // (one-tick delayed, same pattern as every other sequential IC in
    // this file) - when OE is disabled (driven high) the corresponding
    // voltage source is skipped entirely so the pin genuinely floats
    // (real Hi-Z), rather than being forced to some arbitrary voltage.
    // Q7' isn't gated by OE or the ST_CP latch at all on the real chip -
    // it always mirrors the live internal shift register's last stage,
    // which is exactly what lets multiple 595s be daisy-chained - so it
    // stamps unconditionally from state.shiftBit7.
    if (comp.type === '74hc595' && comp.terminals.length >= 16) {
      const gndNet = netMap.get(terminalId(comp.id, 7));
      const gndNode = gndNet === undefined ? -1 : (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1);
      const highV = Math.max(0, (comp.props.supplyVoltage as number) ?? 5);
      const outputEnabled = !!comp.state.outputEnabled;

      const stampQ = (idx: number, key: string) => {
        if (!outputEnabled) return; // OE high: pin floats (Hi-Z), no source stamped
        const net = netMap.get(terminalId(comp.id, idx));
        if (net === undefined) return;
        const node = net === groundNetId ? -1 : nodeIndex.get(net) ?? -1;
        voltageSourceList.push({ comp, nodePos: node, nodeNeg: gndNode, voltage: comp.state[key] ? highV : 0 });
        numVoltageSources++;
      };
      stampQ(14, 'q0'); // idx14 = Q0
      stampQ(0, 'q1'); stampQ(1, 'q2'); stampQ(2, 'q3'); stampQ(3, 'q4');
      stampQ(4, 'q5'); stampQ(5, 'q6'); stampQ(6, 'q7');

      const serialOutNet = netMap.get(terminalId(comp.id, 8)); // idx8 = Q7'
      if (serialOutNet !== undefined) {
        const serialOutNode = serialOutNet === groundNetId ? -1 : nodeIndex.get(serialOutNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: serialOutNode, nodeNeg: gndNode, voltage: comp.state.shiftBit7 ? highV : 0 });
        numVoltageSources++;
      }
    }

    // 74HC165: only QH (serial data out) and its complement QH' are
    // ever driven by this chip - D0-D7/SER/SH-LD/CLK/CLK-INH are all
    // inputs read (not stamped) in updateComponentState() below. QH
    // reflects the actual current shift-register output bit (one-tick
    // delayed, same pattern as the 74HC595 above); QH' is its exact
    // logical complement, both referenced to this chip's own GND.
    if (comp.type === '74hc165' && comp.terminals.length >= 16) {
      const gndNet = netMap.get(terminalId(comp.id, 7));
      const gndNode = gndNet === undefined ? -1 : (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1);
      const highV = Math.max(0, (comp.props.supplyVoltage as number) ?? 5);
      const qH = !!comp.state.qH;

      const qhNet = netMap.get(terminalId(comp.id, 14)); // idx14 = QH
      if (qhNet !== undefined) {
        const qhNode = qhNet === groundNetId ? -1 : nodeIndex.get(qhNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: qhNode, nodeNeg: gndNode, voltage: qH ? highV : 0 });
        numVoltageSources++;
      }
      const qhBarNet = netMap.get(terminalId(comp.id, 6)); // idx6 = QH'
      if (qhBarNet !== undefined) {
        const qhBarNode = qhBarNet === groundNetId ? -1 : nodeIndex.get(qhBarNet) ?? -1;
        voltageSourceList.push({ comp, nodePos: qhBarNode, nodeNeg: gndNode, voltage: qH ? 0 : highV });
        numVoltageSources++;
      }
    }

    // CD4017: 10 decoded Johnson-counter outputs (Q0-Q9, exactly one
    // high at a time) + CARRY OUT, each a real digital voltage source
    // referenced to this chip's own GND (idx 7). All reflect the actual
    // counter state computed in updateComponentState() below (one-tick
    // delayed, same pattern as every other sequential IC in this file).
    if (comp.type === 'cd4017' && comp.terminals.length >= 16) {
      const gndNet = netMap.get(terminalId(comp.id, 7));
      const gndNode = gndNet === undefined ? -1 : (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1);
      const highV = Math.max(0, (comp.props.supplyVoltage as number) ?? 5);

      const stampPin = (idx: number, key: string) => {
        const net = netMap.get(terminalId(comp.id, idx));
        if (net === undefined) return;
        const node = net === groundNetId ? -1 : nodeIndex.get(net) ?? -1;
        voltageSourceList.push({ comp, nodePos: node, nodeNeg: gndNode, voltage: comp.state[key] ? highV : 0 });
        numVoltageSources++;
      };
      // idx per pin: Q5=0, Q1=1, Q0=2, Q2=3, Q6=4, Q7=5, Q3=6, Q8=8,
      // Q9=9, Q4=10, CO=11.
      stampPin(2, 'q0'); stampPin(1, 'q1'); stampPin(3, 'q2'); stampPin(6, 'q3');
      stampPin(10, 'q4'); stampPin(0, 'q5'); stampPin(4, 'q6'); stampPin(5, 'q7');
      stampPin(8, 'q8'); stampPin(9, 'q9'); stampPin(11, 'carryOut');
    }

    // CD4026: decoded a-g 7-segment outputs (only driven while DISPLAY
    // ENABLE IN is high, matching the real part) + CARRY OUT + ungated
    // "C" segment (always driven, regardless of DISPLAY ENABLE IN) +
    // DISPLAY ENABLE OUT (mirrors DISPLAY ENABLE IN), each referenced to
    // this chip's own GND (idx 7). All reflect the actual counter/
    // decoder state computed in updateComponentState() below (one-tick
    // delayed, same pattern as every other sequential IC in this file).
    if (comp.type === 'cd4026' && comp.terminals.length >= 16) {
      const gndNet = netMap.get(terminalId(comp.id, 7));
      const gndNode = gndNet === undefined ? -1 : (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1);
      const highV = Math.max(0, (comp.props.supplyVoltage as number) ?? 5);

      const stampPin = (idx: number, key: string) => {
        const net = netMap.get(terminalId(comp.id, idx));
        if (net === undefined) return;
        const node = net === groundNetId ? -1 : nodeIndex.get(net) ?? -1;
        voltageSourceList.push({ comp, nodePos: node, nodeNeg: gndNode, voltage: comp.state[key] ? highV : 0 });
        numVoltageSources++;
      };
      // idx per pin: CO=4, g=5, f=6, d=8, a=9, e=10, b=11, c=12, C'=13, DEO=3.
      stampPin(4, 'carryOut');
      stampPin(5, 'g'); stampPin(6, 'f'); stampPin(8, 'd'); stampPin(9, 'a');
      stampPin(10, 'e'); stampPin(11, 'b'); stampPin(12, 'c');
      stampPin(13, 'ungatedC');
      stampPin(3, 'displayEnabled'); // DEO mirrors DEI
    }
  }

  // Op-amps (LM741 / LM358): modeled as an ideal VCVS (voltage-controlled
  // voltage source) - Vout = clamp(gain * (V+ - V-), railLow, railHigh).
  // Inputs are ideal (infinite input impedance, draw no current) so they
  // get no conductance stamp at all; the output is a real dependent
  // voltage source, exactly like a battery, except its target voltage is
  // a linear function of two other node voltages instead of a constant.
  // Each instance consumes one MNA unknown/row, same as any voltage
  // source, so it's counted into numVoltageSources here and stamped
  // alongside voltageSourceList after the main solve loop starts.
  interface OpAmpSource {
    comp: Component;
    nodeOut: number;
    nodePlus: number | null;
    nodeMinus: number | null;
    gain: number;
    railHigh: number;
    railLow: number;
  }
  const opAmpList: OpAmpSource[] = [];
  function addOpAmp(comp: Component, plusIdx: number, minusIdx: number, outIdx: number, lowHeadroom: number, highHeadroom: number, defaultGain: number) {
    const outNet = netMap.get(terminalId(comp.id, outIdx));
    if (outNet === undefined) return; // output not wired - nothing to solve
    const plusNet = netMap.get(terminalId(comp.id, plusIdx));
    const minusNet = netMap.get(terminalId(comp.id, minusIdx));
    const nodeOut = outNet === groundNetId ? -1 : nodeIndex.get(outNet) ?? -1;
    const nodePlus = plusNet === undefined ? null : (plusNet === groundNetId ? -1 : nodeIndex.get(plusNet) ?? -1);
    const nodeMinus = minusNet === undefined ? null : (minusNet === groundNetId ? -1 : nodeIndex.get(minusNet) ?? -1);
    const posSupply = (comp.props.positiveSupply as number) ?? highHeadroom + 13.4;
    const negSupply = (comp.props.negativeSupply as number) ?? -(lowHeadroom + 13.4);
    const gain = Math.max(1000, (comp.props.openLoopGain as number) || defaultGain);
    opAmpList.push({
      comp, nodeOut, nodePlus, nodeMinus, gain,
      railHigh: posSupply - highHeadroom,
      railLow: negSupply + lowHeadroom,
    });
    numVoltageSources++;
  }
  for (const comp of components) {
    // LM741: single op-amp. IN- is terminal 1, IN+ is terminal 2, OUT is
    // terminal 5. Classic bipolar output stage needs ~1.6V headroom off
    // either rail before it saturates.
    if (comp.type === 'lm741' && comp.terminals.length >= 6) {
      addOpAmp(comp, 2, 1, 5, 1.6, 1.6, 200000);
    }
    // LM358: dual op-amp, each half wired independently but sharing
    // supply props. It's designed for single-supply use, so its output
    // can swing to within ~50mV of the negative rail/GND (unlike the
    // LM741), while still needing ~1.6V off the positive rail.
    if (comp.type === 'lm358' && comp.terminals.length >= 8) {
      addOpAmp(comp, 2, 1, 0, 0.05, 1.6, 100000); // amp 1: IN1+ idx2, IN1- idx1, OUT1 idx0
      addOpAmp(comp, 4, 5, 6, 0.05, 1.6, 100000); // amp 2: IN2+ idx4, IN2- idx5, OUT2 idx6
    }
  }

  // Linear regulators (7805 / AMS1117 / LM317): modeled as a dependent
  // ideal voltage source referenced to the part's own GND pin (7805,
  // AMS1117) or to circuit ground (LM317, which has no GND pin - see
  // addRegulator's comment), with two real, datasheet-driven
  // nonlinearities decided fresh each outer Newton iteration from the
  // previous iterate (same "limiting" approach as the op-amps above):
  //  - Dropout: the part can't regulate once Vin - Vgnd falls within
  //    `dropout` volts of the target, at which point it just passes
  //    input-through-minus-dropout (or 0V with no/insufficient input)
  //    instead of holding the set point - exactly what a real 7805/
  //    AMS1117/LM317 does as the input sags.
  //  - Current limit: a crude foldback - if the previous iteration's
  //    source current exceeded the part's rated limit, the target is
  //    pulled down proportionally so the next iterate draws less. This
  //    is not a datasheet foldback curve, just enough to keep an
  //    overloaded regulator's output sagging instead of holding an
  //    unphysical fixed voltage into a short.
  interface RegulatorSource {
    comp: Component;
    nodeIn: number | null;   // null = input pin not wired
    nodeGnd: number | null;  // null = no GND pin on this part (LM317)
    nodeOut: number;
    setVoltage: number;      // target Vout - Vgnd when enabled and in regulation
    dropout: number;
    currentLimit: number;
  }
  const regulatorList: RegulatorSource[] = [];
  function addRegulator(comp: Component, inIdx: number, gndIdx: number | null, outIdx: number, setVoltage: number, dropout: number, currentLimit: number) {
    const outNet = netMap.get(terminalId(comp.id, outIdx));
    if (outNet === undefined) return; // output not wired - nothing to solve
    const inNet = netMap.get(terminalId(comp.id, inIdx));
    const gndNet = gndIdx === null ? undefined : netMap.get(terminalId(comp.id, gndIdx));
    const nodeOut = outNet === groundNetId ? -1 : nodeIndex.get(outNet) ?? -1;
    const nodeIn = inNet === undefined ? null : (inNet === groundNetId ? -1 : nodeIndex.get(inNet) ?? -1);
    const nodeGnd = gndNet === undefined ? null : (gndNet === groundNetId ? -1 : nodeIndex.get(gndNet) ?? -1);
    const enabled = comp.props.enabled !== false;
    regulatorList.push({ comp, nodeIn, nodeGnd, nodeOut, setVoltage: enabled ? setVoltage : 0, dropout, currentLimit });
    numVoltageSources++;
  }
  for (const comp of components) {
    // 7805: pin0=IN, pin1=GND, pin2=OUT. Fixed 5V, ~2V typical dropout,
    // 1A rated output current (datasheet TO-220 values).
    if (comp.type === 'reg7805' && comp.terminals.length >= 3) {
      addRegulator(comp, 0, 1, 2, 5, 2.0, 1.0);
    }
    // AMS1117-3.3: pin0=GND, pin1=OUT, pin2=IN. Fixed 3.3V LDO, ~1.1V
    // typical dropout, 1A rated output current.
    if (comp.type === 'ams1117' && comp.terminals.length >= 3) {
      addRegulator(comp, 2, 0, 1, 3.3, 1.1, 1.0);
    }
    // LM317: pin0=ADJ, pin1=OUT, pin2=IN. No GND pin - in a real circuit
    // ADJ sits near ground through a resistor divider that sets Vout;
    // here the divider is simplified into the part's own Output Voltage
    // property (what the divider has been set to produce), referenced
    // directly to circuit ground. ~2V typical dropout, 1.5A rated
    // output current.
    if (comp.type === 'lm317' && comp.terminals.length >= 3) {
      const target = Math.max(1.25, Math.min(37, (comp.props.outputVoltage as number) ?? 5));
      addRegulator(comp, 2, null, 1, target, 2.0, 1.5);
    }
  }

  // Prepare MNA matrices (sized only now that op-amp slots are counted too)
  const totalVars = numNodes + numVoltageSources;
  if (totalVars === 0) {
    return { converged: true, iterations: 0, nodeVoltages: new Map(), branchCurrents: new Map(), powers: new Map(), error: 0 };
  }

  // Iterative solver for nonlinear elements (diodes)
  const maxIterations = 100;
  const tolerance = 1e-9;
  let lastSolution: number[] | null = null;

  for (let iter = 0; iter < maxIterations; iter++) {
    const G = new Matrix(totalVars, totalVars + 1);

    // Add conductances from resistors
    for (const comp of components) {
      if (comp.type === 'bulb' && comp.props.on === false) {
        // Lamp switched off via script (Lamp.turnOff()) — behaves as an open circuit.
        continue;
      }

      if (comp.type === 'resistor' || comp.type === 'bulb' || comp.type === 'dcMotor' || comp.type === 'waterPump' || comp.type === 'stepperMotor' || comp.type === 'solenoidValve') {
        // Motors/pumps are modeled as their equivalent coil/winding
        // resistance so they behave as real electrical loads: they draw
        // current, dissipate power, and their terminal voltage responds to
        // the rest of the circuit exactly like a resistor/bulb would,
        // instead of floating with no effect on the solve.
        const resistance = comp.type === 'bulb'
          ? ((comp.props.ratedVoltage as number) || 12) ** 2 / ((comp.props.ratedPower as number) || 5)
          : comp.type === 'dcMotor'
          ? (comp.props.coilResistance as number) || 10
          : comp.type === 'waterPump'
          ? ((comp.props.voltage as number) || 12) / Math.max(1e-6, (comp.props.ratedCurrent as number) || 3)
          : comp.type === 'stepperMotor'
          // Only the A+/A- coil (terminals 0,1) is modeled electrically for
          // now - the B+/B- pair (2,3) is exposed for a future A4988/ULN2003
          // driver component to drive independently.
          ? (comp.props.coilResistance as number) || 30
          : comp.type === 'solenoidValve'
          ? (comp.props.coilResistance as number) || 24
          : (comp.props.resistance as number) || 1000;

        if (resistance > 0 && comp.terminals.length >= 2) {
          const netA = netMap.get(terminalId(comp.id, 0));
          const netB = netMap.get(terminalId(comp.id, 1));
          if (netA !== undefined && netB !== undefined && netA !== netB) {
            const conductance = 1 / resistance;
            const nodeA = netA === groundNetId ? -1 : nodeIndex.get(netA) ?? -1;
            const nodeB = netB === groundNetId ? -1 : nodeIndex.get(netB) ?? -1;

            if (nodeA >= 0) {
              G.add(nodeA, nodeA, conductance);
              if (nodeB >= 0) G.add(nodeA, nodeB, -conductance);
            }
            if (nodeB >= 0) {
              G.add(nodeB, nodeB, conductance);
              if (nodeA >= 0) G.add(nodeB, nodeA, -conductance);
            }
          }
        }
      }

      // Polyfuse (resettable PTC fuse): a real low resistance while cold
      // (conducting normally), or the PTC's high trip-state resistance
      // once tripped - unlike an idealized switch, tripped is not an open
      // circuit, it's a large-but-finite resistance that still passes a
      // small trickle current (which is exactly what lets it sense the
      // fault clearing so it can reset). state.tripped is last frame's
      // result (set in updateComponentState below), same one-tick-delayed
      // pattern the Relay/PC817 contacts use above.
      if (comp.type === 'polyfuse' && comp.terminals.length >= 2) {
        const cold = Math.max(1e-3, (comp.props.coldResistance as number) || 0.15);
        const trippedR = Math.max(1, (comp.props.trippedResistance as number) || 4000);
        const resistance = comp.state.tripped ? trippedR : cold;

        const netA = netMap.get(terminalId(comp.id, 0));
        const netB = netMap.get(terminalId(comp.id, 1));
        if (netA !== undefined && netB !== undefined && netA !== netB) {
          const conductance = 1 / resistance;
          const nodeA = netA === groundNetId ? -1 : nodeIndex.get(netA) ?? -1;
          const nodeB = netB === groundNetId ? -1 : nodeIndex.get(netB) ?? -1;

          if (nodeA >= 0) {
            G.add(nodeA, nodeA, conductance);
            if (nodeB >= 0) G.add(nodeA, nodeB, -conductance);
          }
          if (nodeB >= 0) {
            G.add(nodeB, nodeB, conductance);
            if (nodeA >= 0) G.add(nodeB, nodeA, -conductance);
          }
        }
      }

      // LDR (photoresistor): resistance follows a real photoresistor's
      // logarithmic light-to-resistance curve — roughly 1 MΩ in the dark
      // down to ~100 Ω in bright light, not a straight line. When Enabled
      // is off, the sensor is treated as inactive and reads its darkest
      // (highest-resistance) state.
      if (comp.type === 'ldr' && comp.terminals.length >= 2) {
        const enabled = comp.props.enabled !== false;
        const lightLevel = enabled ? Math.max(0, Math.min(100, (comp.props.lightLevel as number) ?? 50)) : 0;
        const darkResistance = 1_000_000; // ~1 MΩ at 0% light
        const brightResistance = 100;     // ~100 Ω at 100% light
        // Logarithmic interpolation: resistance drops by orders of
        // magnitude as light increases, matching a real CdS cell's
        // exponential response rather than a linear one.
        const resistance = darkResistance * Math.pow(brightResistance / darkResistance, lightLevel / 100);

        const netA = netMap.get(terminalId(comp.id, 0));
        const netB = netMap.get(terminalId(comp.id, 1));
        if (netA !== undefined && netB !== undefined && netA !== netB && resistance > 0) {
          const conductance = 1 / resistance;
          const nodeA = netA === groundNetId ? -1 : nodeIndex.get(netA) ?? -1;
          const nodeB = netB === groundNetId ? -1 : nodeIndex.get(netB) ?? -1;

          if (nodeA >= 0) {
            G.add(nodeA, nodeA, conductance);
            if (nodeB >= 0) G.add(nodeA, nodeB, -conductance);
          }
          if (nodeB >= 0) {
            G.add(nodeB, nodeB, conductance);
            if (nodeA >= 0) G.add(nodeB, nodeA, -conductance);
          }
        }
      }

      // Arduino INPUT_PULLUP: real AVR internal pull-ups are ~20-50k to
      // the chip's own 5V rail. Modeled as a plain weak resistor to this
      // board's 5V net (same conductance-stamp pattern as the resistor/LDR
      // above) so an external switch to GND can still pull the pin low,
      // while an unconnected pin correctly reads HIGH.
      if ((comp.type === 'arduino' || comp.type === 'arduinoMega' || comp.type === 'arduinoNano') && comp.terminals.length > 0) {
        const railIdx = comp.terminals.findIndex(t => t.label === '5V');
        const railNet = railIdx >= 0 ? netMap.get(terminalId(comp.id, railIdx)) : undefined;
        if (railNet !== undefined) {
          const railNode = railNet === groundNetId ? -1 : nodeIndex.get(railNet) ?? -1;
          const pullupR = 20000;
          const conductance = 1 / pullupR;
          comp.terminals.forEach((t, termIdx) => {
            const m = /^D(\d+)$/.exec(t.label);
            const isDigitalPullup = !!m && comp.props[`d${m[1]}_mode`] === 'INPUT_PULLUP';
            const isResetPin = t.label === 'RESET';
            if (!isDigitalPullup && !isResetPin) return;
            const pinNet = netMap.get(terminalId(comp.id, termIdx));
            if (pinNet === undefined || pinNet === railNet) return;
            const pinNode = pinNet === groundNetId ? -1 : nodeIndex.get(pinNet) ?? -1;
            // RESET uses a stronger (~10k) pull-up than a digital
            // INPUT_PULLUP's ~20-50k, matching a real board's dedicated
            // reset pull-up resistor.
            const g = isResetPin ? 1 / 10000 : conductance;
            if (pinNode >= 0) {
              G.add(pinNode, pinNode, g);
              if (railNode >= 0) G.add(pinNode, railNode, -g);
            }
            if (railNode >= 0) {
              G.add(railNode, railNode, g);
              if (pinNode >= 0) G.add(railNode, pinNode, -g);
            }
          });
        }
      }

      // Variable resistor (unchanged - not part of this fix's scope)
      if (comp.type === 'variableResistor' && comp.terminals.length >= 3) {
        const maxR = (comp.props.resistance as number) || 10000;
        const wiperPos = (comp.props.wiperPosition as number) || 0.5;
        const r1 = maxR * wiperPos;
        const r2 = maxR * (1 - wiperPos);

        const netA = netMap.get(terminalId(comp.id, 0));
        const netW = netMap.get(terminalId(comp.id, 2));
        const netB = netMap.get(terminalId(comp.id, 1));

        if (netA !== undefined && netW !== undefined && netA !== netW && r1 > 0) {
          const g1 = 1 / r1;
          const nA = netA === groundNetId ? -1 : nodeIndex.get(netA) ?? -1;
          const nW = netW === groundNetId ? -1 : nodeIndex.get(netW) ?? -1;
          if (nA >= 0) { G.add(nA, nA, g1); if (nW >= 0) { G.add(nA, nW, -g1); G.add(nW, nA, -g1); G.add(nW, nW, g1); } }
          else if (nW >= 0) G.add(nW, nW, g1);
        }
        if (netW !== undefined && netB !== undefined && netW !== netB && r2 > 0) {
          const g2 = 1 / r2;
          const nW = netW === groundNetId ? -1 : nodeIndex.get(netW) ?? -1;
          const nB = netB === groundNetId ? -1 : nodeIndex.get(netB) ?? -1;
          if (nW >= 0) { G.add(nW, nW, g2); if (nB >= 0) { G.add(nW, nB, -g2); G.add(nB, nW, -g2); G.add(nB, nB, g2); } }
          else if (nB >= 0) G.add(nB, nB, g2);
        }
      }

      // Potentiometer: terminal 0 ('1', left) = VCC side, terminal 1 ('2',
      // right) = GND side, terminal 2 ('W') = wiper - see componentDefs.ts's
      // terminal layout. Modeled as two series resistors, VCC-to-wiper and
      // wiper-to-GND, so the wiper node lands at outputVoltage = VCC *
      // wiperPosition: at wiperPosition 0 the wiper should sit at the GND
      // end (0V), so the VCC-side leg must be the *large* one there (and
      // the GND-side leg ~0); at wiperPosition 1 it's the reverse. That
      // means the VCC-side resistor scales with (1 - wiperPosition) and
      // the GND-side one scales with wiperPosition - the previous version
      // of this code had that backwards (r1/r2 swapped), which is why the
      // wiper voltage didn't track the slider correctly.
      // A tiny epsilon floor (instead of a hard 0) keeps both legs' stamp
      // applied even at the 0.0/1.0 extremes - skipping the stamp entirely
      // when a leg's resistance hit exactly 0 (the previous code's `r > 0`
      // guard) left the wiper node under-constrained/floating right at the
      // ends, which is what made the reading look constant/stuck instead
      // of sweeping smoothly from 0V to 5V.
      if (comp.type === 'potentiometer' && comp.terminals.length >= 3) {
        const maxR = (comp.props.resistance as number) || 10000;
        const wiperPos = Math.max(0, Math.min(1, (comp.props.wiperPosition as number) ?? 0.5));
        const MIN_LEG_OHMS = 1e-3;
        const r1 = Math.max(MIN_LEG_OHMS, maxR * (1 - wiperPos)); // VCC (terminal 0) -> wiper
        const r2 = Math.max(MIN_LEG_OHMS, maxR * wiperPos);       // wiper -> GND (terminal 1)

        const netA = netMap.get(terminalId(comp.id, 0));
        const netW = netMap.get(terminalId(comp.id, 2));
        const netB = netMap.get(terminalId(comp.id, 1));

        if (netA !== undefined && netW !== undefined && netA !== netW) {
          const g1 = 1 / r1;
          const nA = netA === groundNetId ? -1 : nodeIndex.get(netA) ?? -1;
          const nW = netW === groundNetId ? -1 : nodeIndex.get(netW) ?? -1;
          if (nA >= 0) { G.add(nA, nA, g1); if (nW >= 0) { G.add(nA, nW, -g1); G.add(nW, nA, -g1); G.add(nW, nW, g1); } }
          else if (nW >= 0) G.add(nW, nW, g1);
        }
        if (netW !== undefined && netB !== undefined && netW !== netB) {
          const g2 = 1 / r2;
          const nW = netW === groundNetId ? -1 : nodeIndex.get(netW) ?? -1;
          const nB = netB === groundNetId ? -1 : nodeIndex.get(netB) ?? -1;
          if (nW >= 0) { G.add(nW, nW, g2); if (nB >= 0) { G.add(nW, nB, -g2); G.add(nB, nW, -g2); G.add(nB, nB, g2); } }
          else if (nB >= 0) G.add(nB, nB, g2);
        }
      }

      // Diode (iterative linearization) - also covers the PC817
      // optocoupler's internal IR LED (Anode/Cathode = terminals 0/1);
      // its phototransistor side (Emitter/Collector) is handled
      // separately below via buildNets()'s isolated switch-contact union,
      // never through this diode stamp.
      if ((comp.type === 'diode' || comp.type === 'led' || comp.type === 'pc817') && comp.terminals.length >= 2) {
        const netA = netMap.get(terminalId(comp.id, 0)); // Anode
        const netB = netMap.get(terminalId(comp.id, 1)); // Cathode
        if (netA !== undefined && netB !== undefined) {
          const nA = netA === groundNetId ? -1 : nodeIndex.get(netA) ?? -1;
          const nB = netB === groundNetId ? -1 : nodeIndex.get(netB) ?? -1;

          // Get diode voltage from last iteration
          let vd = 0;
          if (lastSolution) {
            const va = nA >= 0 ? lastSolution[nA] : 0;
            const vb = nB >= 0 ? lastSolution[nB] : 0;
            vd = va - vb;
          }

          const vForward = comp.type === 'led' ? ((comp.props.forwardVoltage as number) || 2)
            : comp.type === 'pc817' ? ((comp.props.forwardVoltage as number) || 1.2)
            : 0.7;
          const Is = 1e-14;
          const n = 1;
          const vt = 0.026;

          // LED-only: SPICE-style junction voltage limiting. Without this,
          // the exponential diode model's Newton-Raphson iteration can take
          // an unbounded step as soon as `vd` (last iteration's guess)
          // overshoots vForward - Geq/Ieq can jump many orders of magnitude
          // in a single iteration, and the linear solve overshoots into a
          // nonphysical fixed point (e.g. the junction reading strongly
          // reverse-biased on a correctly forward-wired LED) instead of
          // settling near the true ~vForward operating point. Clamping how
          // far vd is allowed to move past the critical voltage per
          // iteration keeps the iteration converging toward the real
          // operating point. Scoped to 'led' only - diode/pc817 keep their
          // original (unlimited) behavior untouched.
          // Exponential diode model with series resistance
          let Ieq = 0;
          let Geq = 1e-12; // Small conductance for numerical stability

          if (vd > -10) {
            const expArg = Math.min((vd - vForward) / (n * vt), 700);
            Ieq = Is * (Math.exp(expArg) - 1);
            Geq = Math.max(1e-12, (Is / (n * vt)) * Math.exp(expArg));
          }

          // LED-only fix: the companion-current term below (Ieq - Geq*vd)
          // is the y-intercept of the tangent line I(V) = Geq*V + (Ieq -
          // Geq*vd), and it must be *subtracted* from the node's KCL
          // equation as a current leaving the node - i.e. the RHS needs
          // -(Ieq - Geq*vd), not +(Ieq - Geq*vd). The existing diode/pc817
          // code below has that sign backwards; for a shallow diode
          // (vForward ~0.7V, tiny signal currents) the resulting error is
          // small enough to stay unnoticed, but for the LED's much larger
          // forward voltage/current the inverted sign actively repels each
          // Newton iteration away from the true operating point instead of
          // pulling it in, so the solve never converges (it locks into a
          // stable oscillation between a spurious near-5V "reverse-biased"
          // reading and a wild overshoot) - producing exactly the reported
          // 0V/0mA/false-reversed-polarity symptoms. Verified analytically
          // and numerically against the true operating point for this
          // circuit (a 220 Ohm series resistor to a 2V-forward LED settles
          // at ~2.72V / ~10.4mA) - the corrected sign converges to that
          // point directly; the original sign does not converge at all.
          // Scoped to 'led' only so diode/pc817 keep their original,
          // long-standing formula untouched.
          const ledSign = comp.type === 'led' ? -1 : 1;

          // Stamp diode conductance
          if (nA >= 0) {
            G.add(nA, nA, Geq);
            if (nB >= 0) G.add(nA, nB, -Geq);
            G.add(nA, totalVars, ledSign * (Ieq - Geq * vd)); // RHS
          }
          if (nB >= 0) {
            G.add(nB, nB, Geq);
            if (nA >= 0) G.add(nB, nA, -Geq);
            G.add(nB, totalVars, ledSign * (-Ieq + Geq * vd)); // RHS
          }
        }
      }

      // BJT Base-Emitter junction (NPN/PNP) - a real forward-biased diode,
      // stamped with the same exponential companion-model math as
      // diode/led/pc817 above (kept as its own block rather than folded
      // into that shared conditional, so the long-standing diode/LED
      // behavior above stays completely untouched). Terminal order is
      // Base=0, Collector=1, Emitter=2 (see defaultTerminals.transistorNpn/
      // transistorPnp in componentDefs.ts). For NPN the junction conducts
      // Base->Emitter (anode=Base, cathode=Emitter); for PNP it's reversed
      // (anode=Emitter, cathode=Base) - the same junction physically
      // flipped, matching a real PNP's doping order. The Collector-Emitter
      // path itself is NOT stamped here - it's handled as a real
      // saturation switch in buildNets() above, gated by `transistorOn`
      // (computed in updateComponentState below from this junction's
      // actual current), the same one-tick-delayed pattern the Relay and
      // PC817 use for their own switched contacts.
      if ((comp.type === 'transistorNpn' || comp.type === 'transistorPnp' || comp.type === 'tip120' || comp.type === 'tip122') && comp.terminals.length >= 3) {
        const isPnp = comp.type === 'transistorPnp';
        const anodeIdx = isPnp ? 2 : 0; // PNP: Emitter: NPN: Base
        const cathodeIdx = isPnp ? 0 : 2; // PNP: Base; NPN: Emitter
        const netA = netMap.get(terminalId(comp.id, anodeIdx));
        const netB = netMap.get(terminalId(comp.id, cathodeIdx));
        if (netA !== undefined && netB !== undefined) {
          const nA = netA === groundNetId ? -1 : nodeIndex.get(netA) ?? -1;
          const nB = netB === groundNetId ? -1 : nodeIndex.get(netB) ?? -1;

          let vd = 0;
          if (lastSolution) {
            const va = nA >= 0 ? lastSolution[nA] : 0;
            const vb = nB >= 0 ? lastSolution[nB] : 0;
            vd = va - vb;
          }

          const vForward = (comp.props.vBEon as number) || 0.65;
          const Is = 1e-14;
          const n = 1;
          const vt = 0.026;

          let Ieq = 0;
          let Geq = 1e-12;
          if (vd > -10) {
            const expArg = Math.min((vd - vForward) / (n * vt), 700);
            Ieq = Is * (Math.exp(expArg) - 1);
            Geq = Math.max(1e-12, (Is / (n * vt)) * Math.exp(expArg));
          }

          if (nA >= 0) {
            G.add(nA, nA, Geq);
            if (nB >= 0) G.add(nA, nB, -Geq);
            G.add(nA, totalVars, Ieq - Geq * vd);
          }
          if (nB >= 0) {
            G.add(nB, nB, Geq);
            if (nA >= 0) G.add(nB, nA, -Geq);
            G.add(nB, totalVars, -(Ieq - Geq * vd));
          }
        }
      }

      // RGB LED: three independent diode junctions (R, G, B), each stamped
      // exactly like a regular LED but sharing one common leg, so real
      // per-channel voltages genuinely mix into the final color rather
      // than a scripted swap.
      if (comp.type === 'rgbLed' && comp.terminals.length >= 4) {
        const commonAnode = comp.props.commonType === 'anode';
        const vForward = (comp.props.forwardVoltage as number) || 2.1;
        const Is = 1e-14;
        const vt = 0.026;
        const channelTermIdx = [0, 2, 3]; // R, G, B - terminal 1 is Common
        for (const colorIdx of channelTermIdx) {
          // Anode is the color pin on a common-cathode part, or the
          // shared common leg on a common-anode part (and vice versa).
          const anodeIdx = commonAnode ? 1 : colorIdx;
          const cathodeIdx = commonAnode ? colorIdx : 1;
          const netA = netMap.get(terminalId(comp.id, anodeIdx));
          const netB = netMap.get(terminalId(comp.id, cathodeIdx));
          if (netA === undefined || netB === undefined) continue;
          const nA = netA === groundNetId ? -1 : nodeIndex.get(netA) ?? -1;
          const nB = netB === groundNetId ? -1 : nodeIndex.get(netB) ?? -1;

          let vd = 0;
          if (lastSolution) {
            const va = nA >= 0 ? lastSolution[nA] : 0;
            const vb = nB >= 0 ? lastSolution[nB] : 0;
            vd = va - vb;
          }

          let Ieq = 0;
          let Geq = 1e-12;
          if (vd > -10) {
            const expArg = Math.min((vd - vForward) / vt, 700);
            Ieq = Is * (Math.exp(expArg) - 1);
            Geq = Math.max(1e-12, (Is / vt) * Math.exp(expArg));
          }

          if (nA >= 0) {
            G.add(nA, nA, Geq);
            if (nB >= 0) G.add(nA, nB, -Geq);
            G.add(nA, totalVars, Ieq - Geq * vd);
          }
          if (nB >= 0) {
            G.add(nB, nB, Geq);
            if (nA >= 0) G.add(nB, nA, -Geq);
            G.add(nB, totalVars, -Ieq + Geq * vd);
          }
        }
      }

      // Zener diode
      if (comp.type === 'zenerDiode' && comp.terminals.length >= 2) {
        const netA = netMap.get(terminalId(comp.id, 0)); // Anode
        const netB = netMap.get(terminalId(comp.id, 1)); // Cathode
        if (netA !== undefined && netB !== undefined) {
          const nA = netA === groundNetId ? -1 : nodeIndex.get(netA) ?? -1;
          const nB = netB === groundNetId ? -1 : nodeIndex.get(netB) ?? -1;

          let vd = 0;
          if (lastSolution) {
            const va = nA >= 0 ? lastSolution[nA] : 0;
            const vb = nB >= 0 ? lastSolution[nB] : 0;
            vd = va - vb;
          }

          const vz = (comp.props.zenerVoltage as number) || 5.1;
          const Geq = vd < -vz ? 10 : 1e-12;
          const Ieq = vd < -vz ? -vz * Geq : 0;

          if (nA >= 0) {
            G.add(nA, nA, Geq);
            if (nB >= 0) G.add(nA, nB, -Geq);
            G.add(nA, totalVars, Ieq);
          }
          if (nB >= 0) {
            G.add(nB, nB, Geq);
            if (nA >= 0) G.add(nB, nA, -Geq);
            G.add(nB, totalVars, -Ieq);
          }
        }
      }

      // DC current source
      if (comp.type === 'dcCurrentSource' && comp.terminals.length >= 2) {
        const netA = netMap.get(terminalId(comp.id, 0));
        const netB = netMap.get(terminalId(comp.id, 1));
        const current = (comp.props.current as number) || 0.1;
        if (netA !== undefined && netB !== undefined) {
          const nA = netA === groundNetId ? -1 : nodeIndex.get(netA) ?? -1;
          const nB = netB === groundNetId ? -1 : nodeIndex.get(netB) ?? -1;
          if (nA >= 0) G.add(nA, totalVars, -current);
          if (nB >= 0) G.add(nB, totalVars, current);
        }
      }
    }

    // Stamp voltage sources
    let vsIdx = numNodes;
    for (const vs of voltageSourceList) {
      if (vs.nodePos >= 0) {
        G.add(vs.nodePos, vsIdx, 1);
        G.add(vsIdx, vs.nodePos, 1);
      }
      if (vs.nodeNeg >= 0) {
        G.add(vs.nodeNeg, vsIdx, -1);
        G.add(vsIdx, vs.nodeNeg, -1);
      }
      G.set(vsIdx, totalVars, vs.voltage);
      vsIdx++;
    }

    // Stamp op-amps. Each one is piecewise-linear (clamped), so every
    // outer iteration first decides - from the previous iterate's inputs -
    // whether it's in its linear region or saturated against a rail (the
    // standard SPICE "limiting" approach), then stamps the matching
    // linear equation for this solve. This converges in a handful of
    // iterations for ordinary feedback topologies (followers, inverting/
    // non-inverting amps, comparators).
    for (const oa of opAmpList) {
      const vPlusPrev = lastSolution ? (oa.nodePlus !== null && oa.nodePlus >= 0 ? lastSolution[oa.nodePlus] : 0) : 0;
      const vMinusPrev = lastSolution ? (oa.nodeMinus !== null && oa.nodeMinus >= 0 ? lastSolution[oa.nodeMinus] : 0) : 0;
      const idealOut = oa.gain * (vPlusPrev - vMinusPrev);

      if (idealOut > oa.railHigh) {
        // Saturated high - behaves as a fixed voltage source at the rail.
        if (oa.nodeOut >= 0) { G.add(oa.nodeOut, vsIdx, 1); G.add(vsIdx, oa.nodeOut, 1); }
        G.set(vsIdx, totalVars, oa.railHigh);
      } else if (idealOut < oa.railLow) {
        // Saturated low - fixed voltage source at the other rail.
        if (oa.nodeOut >= 0) { G.add(oa.nodeOut, vsIdx, 1); G.add(vsIdx, oa.nodeOut, 1); }
        G.set(vsIdx, totalVars, oa.railLow);
      } else {
        // Linear region: Vout - gain*V+ + gain*V- = 0. Inputs draw no
        // current (ideal), so V+ / V- only appear in this row, never in
        // their own node's KCL row.
        if (oa.nodeOut >= 0) { G.add(oa.nodeOut, vsIdx, 1); G.add(vsIdx, oa.nodeOut, 1); }
        if (oa.nodePlus !== null && oa.nodePlus >= 0) G.add(vsIdx, oa.nodePlus, -oa.gain);
        if (oa.nodeMinus !== null && oa.nodeMinus >= 0) G.add(vsIdx, oa.nodeMinus, oa.gain);
        G.set(vsIdx, totalVars, 0);
      }
      vsIdx++;
    }

    // Stamp regulators. Each is a fixed-at-this-iteration voltage source
    // (like a battery), but the value it's fixed to is recomputed every
    // iteration from the previous iterate's input rail and own current
    // draw - the same piecewise-linear "limiting" pattern the op-amps
    // use above, applied to dropout and current-limit instead of rail
    // saturation. myIdx below is this entry's own MNA unknown index -
    // voltageSourceList's and opAmpList's rows come first (in the same
    // order every iteration, since both lists are built once above), so
    // regulatorList's rows start right after them.
    regulatorList.forEach((reg, i) => {
      const myIdx = numNodes + voltageSourceList.length + opAmpList.length + i;
      const vInPrev = !lastSolution ? (reg.setVoltage + reg.dropout) // first-iteration seed: assume enough headroom
        : reg.nodeIn === null ? 0
        : reg.nodeIn === -1 ? 0
        : lastSolution[reg.nodeIn];
      const vGndPrev = !lastSolution || reg.nodeGnd === null ? 0
        : reg.nodeGnd === -1 ? 0
        : lastSolution[reg.nodeGnd];
      const prevCurrent = lastSolution ? Math.abs(lastSolution[myIdx] ?? 0) : 0;

      // Dropout: can only regulate up to (Vin - Vgnd - dropout) above
      // its ground reference; below that it sags toward pass-through.
      const headroom = vInPrev - vGndPrev - reg.dropout;
      let aboveGnd = Math.max(0, Math.min(reg.setVoltage, headroom));

      // Current limit: crude proportional foldback if the previous
      // iterate drew more than the rated current.
      if (prevCurrent > reg.currentLimit && reg.currentLimit > 0) {
        aboveGnd = aboveGnd * (reg.currentLimit / prevCurrent);
      }

      const outVoltage = vGndPrev + aboveGnd;
      if (reg.nodeOut >= 0) { G.add(reg.nodeOut, myIdx, 1); G.add(myIdx, reg.nodeOut, 1); }
      if (reg.nodeGnd !== null && reg.nodeGnd >= 0) { G.add(reg.nodeGnd, myIdx, -1); G.add(myIdx, reg.nodeGnd, -1); }
      G.set(myIdx, totalVars, outVoltage);
    });
    const solution = G.solve();
    if (!solution) {
      return { converged: false, iterations: iter, nodeVoltages: new Map(), branchCurrents: new Map(), powers: new Map(), error: Infinity };
    }

    // Check convergence
    if (lastSolution) {
      let maxDiff = 0;
      for (let i = 0; i < Math.min(solution.length, lastSolution.length); i++) {
        maxDiff = Math.max(maxDiff, Math.abs(solution[i] - lastSolution[i]));
      }
      if (maxDiff < tolerance) {
        lastSolution = solution;
        break;
      }
    }

    lastSolution = solution;
  }

  if (!lastSolution) {
    return { converged: false, iterations: maxIterations, nodeVoltages: new Map(), branchCurrents: new Map(), powers: new Map(), error: Infinity };
  }

  // Build results
  const nodeVoltages = new Map<number, number>();
  for (const [nid, idx] of nodeIndex) {
    nodeVoltages.set(nid, lastSolution[idx]);
  }
  if (groundNetId !== null) nodeVoltages.set(groundNetId, 0);

  const branchCurrents = new Map<number, number>();
  const powers = new Map<number, number>();

  // Calculate branch currents and powers
  for (const comp of components) {
    const netA = comp.terminals.length > 0 ? netMap.get(terminalId(comp.id, 0)) : undefined;
    const netB = comp.terminals.length > 1 ? netMap.get(terminalId(comp.id, 1)) : undefined;

    const vA = netA !== undefined ? (nodeVoltages.get(netA) || 0) : 0;
    const vB = netB !== undefined ? (nodeVoltages.get(netB) || 0) : 0;
    const vDiff = vA - vB;

    let current = 0;
    let power = 0;

    switch (comp.type) {
      case 'resistor': {
        const r = (comp.props.resistance as number) || 1000;
        current = r > 0 ? vDiff / r : 0;
        power = vDiff * current;
        break;
      }
      case 'bulb': {
        const ratedV = (comp.props.ratedVoltage as number) || 12;
        const ratedP = (comp.props.ratedPower as number) || 5;
        const r = ratedV * ratedV / ratedP;
        current = vDiff / r;
        power = vDiff * current;
        break;
      }
      case 'potentiometer': {
        // vDiff here is VCC (terminal 0) minus GND (terminal 1) - the full
        // divider's end-to-end voltage - regardless of wiper position, the
        // same current flows through the two legs in series (r1+r2 always
        // equals the pot's total resistance), same as any two fixed
        // resistors in series would draw.
        const totalR = Math.max(1e-3, (comp.props.resistance as number) || 10000);
        current = vDiff / totalR;
        power = vDiff * current;
        break;
      }
      case 'dcMotor': {
        const r = (comp.props.coilResistance as number) || 10;
        current = r > 0 ? vDiff / r : 0;
        power = vDiff * current;
        break;
      }
      case 'stepperMotor': {
        const r = (comp.props.coilResistance as number) || 30;
        current = r > 0 ? vDiff / r : 0;
        power = vDiff * current;
        break;
      }
      case 'solenoidValve': {
        const r = (comp.props.coilResistance as number) || 24;
        current = r > 0 ? vDiff / r : 0;
        power = vDiff * current;
        break;
      }
      case 'waterPump': {
        const r = ((comp.props.voltage as number) || 12) / Math.max(1e-6, (comp.props.ratedCurrent as number) || 3);
        current = r > 0 ? vDiff / r : 0;
        power = vDiff * current;
        break;
      }
      case 'transistorNpn':
      case 'transistorPnp':
      case 'tip120':
      case 'tip122': {
        // The generic vDiff above is Base-Collector (terminal 0 vs 1) for
        // this component, not the junction we care about - recompute the
        // real Base-Emitter voltage (terminal 0 vs 2) directly, same
        // exponential junction equation as the MNA stamp above.
        const isPnp = comp.type === 'transistorPnp';
        const netBase = netMap.get(terminalId(comp.id, 0));
        const netEmitter = netMap.get(terminalId(comp.id, 2));
        const vBase = netBase !== undefined ? (nodeVoltages.get(netBase) || 0) : 0;
        const vEmitter = netEmitter !== undefined ? (nodeVoltages.get(netEmitter) || 0) : 0;
        const vBE = vBase - vEmitter;
        const vJunction = isPnp ? -vBE : vBE; // forward direction: NPN B->E, PNP E->B
        const vForward = (comp.props.vBEon as number) || 0.65;
        const Is = 1e-14;
        const vt = 0.026;
        let baseCurrent = 0;
        if (vJunction > vForward - 10) {
          baseCurrent = Is * (Math.exp(Math.min((vJunction - vForward) / vt, 700)) - 1);
        }
        current = isPnp ? -baseCurrent : baseCurrent; // sign matches conventional B->E (NPN) / E->B (PNP) flow
        power = vBE * current;
        break;
      }
      case 'diode':
      case 'led':
      case 'pc817': {
        const vForward = comp.type === 'led' ? ((comp.props.forwardVoltage as number) || 2)
          : comp.type === 'pc817' ? ((comp.props.forwardVoltage as number) || 1.2)
          : 0.7;
        const Is = 1e-14;
        const vt = 0.026;
        if (vDiff > vForward) {
          current = Is * (Math.exp(Math.min((vDiff - vForward) / vt, 700)) - 1);
        } else {
          current = vDiff * 1e-12;
        }
        power = vDiff * current;
        break;
      }
      case 'battery': {
        // Find the current through this voltage source
        const vsIdx = voltageSourceList.findIndex(v => v.comp.id === comp.id);
        if (vsIdx >= 0) {
          current = lastSolution[numNodes + vsIdx] || 0;
        }
        const vSource = (comp.props.voltage as number) || 9;
        power = vSource * current;
        break;
      }
      case 'capacitor': {
        // In DC steady state, capacitor is open circuit
        current = 0;
        power = 0;
        break;
      }
      case 'inductor': {
        // In DC steady state, inductor is short circuit
        current = vDiff * 1e6; // Very high conductance
        power = 0;
        break;
      }
      case 'polyfuse': {
        const cold = Math.max(1e-3, (comp.props.coldResistance as number) || 0.15);
        const trippedR = Math.max(1, (comp.props.trippedResistance as number) || 4000);
        const r = comp.state.tripped ? trippedR : cold;
        current = r > 0 ? vDiff / r : 0;
        power = vDiff * current;
        break;
      }
      case 'switch': {
        if (comp.props.closed) {
          current = vDiff * 1e6; // Very high conductance
        } else {
          current = 0;
        }
        power = 0;
        break;
      }
      case 'pushButton': {
        if (comp.state.pressed) {
          current = vDiff * 1e6; // Very high conductance (momentarily closed)
        } else {
          current = 0;
        }
        power = 0;
        break;
      }
      default: {
        current = 0;
        power = 0;
      }
    }

    branchCurrents.set(comp.id, current);
    powers.set(comp.id, power);
  }

  // Calculate error
  let error = 0;
  for (const comp of components) {
    if (comp.type === 'resistor') {
      const netA = comp.terminals.length > 0 ? netMap.get(terminalId(comp.id, 0)) : undefined;
      const netB = comp.terminals.length > 1 ? netMap.get(terminalId(comp.id, 1)) : undefined;
      if (netA !== undefined && netB !== undefined) {
        const vA = nodeVoltages.get(netA) || 0;
        const vB = nodeVoltages.get(netB) || 0;
        const r = (comp.props.resistance as number) || 1000;
        const i = branchCurrents.get(comp.id) || 0;
        error = Math.max(error, Math.abs(vA - vB - i * r));
      }
    }
  }

  return {
    converged: true,
    iterations: maxIterations,
    nodeVoltages,
    branchCurrents,
    powers,
    error,
    netTerminalCounts,
  };
}

/**
 * Update component simulation state (brightness, etc.)
 */
export function updateComponentState(comp: Component, result: SimulationResult): Component {
  const updated = { ...comp, state: { ...comp.state } };
  const current = result.branchCurrents.get(comp.id) || 0;
  const power = result.powers.get(comp.id) || 0;
  const v = comp.terminals.length >= 2 ? Math.abs((result.nodeVoltages.get(comp.terminals[0].netId || 0) || 0) - (result.nodeVoltages.get(comp.terminals[1].netId || 0) || 0)) : 0;

  updated.current = current;
  updated.power = power;
  updated.voltage = v;

  // Potentiometer: the generic `v` above is VCC-to-GND (terminals 0/1),
  // which is constant regardless of wiper position - what a sketch/user
  // actually cares about seeing here is the wiper's own output, i.e. its
  // voltage relative to the GND-side pin (terminal 1), which is what
  // tracks Wiper Position live (0 -> 0V ... 1 -> VCC).
  if (comp.type === 'potentiometer' && comp.terminals.length >= 3) {
    const netW = comp.terminals[2]?.netId;
    const netB = comp.terminals[1]?.netId;
    const vW = netW !== null && netW !== undefined ? (result.nodeVoltages.get(netW) || 0) : 0;
    const vB = netB !== null && netB !== undefined ? (result.nodeVoltages.get(netB) || 0) : 0;
    updated.voltage = vW - vB;
  }

  // Transistor: the generic `v` above is Base-Collector (terminals 0/1),
  // not the junction that actually matters - override with the real
  // Base-Emitter voltage (terminals 0/2), matching what `current` above
  // (computed in simulateDC's per-component switch) already represents.
  if ((comp.type === 'transistorNpn' || comp.type === 'transistorPnp' || comp.type === 'tip120' || comp.type === 'tip122') && comp.terminals.length >= 3) {
    const netBase = comp.terminals[0]?.netId;
    const netEmitter = comp.terminals[2]?.netId;
    const vBase = netBase !== null && netBase !== undefined ? (result.nodeVoltages.get(netBase) || 0) : 0;
    const vEmitter = netEmitter !== null && netEmitter !== undefined ? (result.nodeVoltages.get(netEmitter) || 0) : 0;
    updated.voltage = vBase - vEmitter;
  }

  // MOSFET: the generic `v` above is Gate-Drain (terminals 0/1), not the
  // Gate-Source voltage that actually gates the channel - override with
  // the real Vgs (terminals 0/2), matching what state.mosfetOn below is
  // computed from.
  if ((comp.type === 'irf520' || comp.type === 'irf540' || comp.type === 'irlz44n') && comp.terminals.length >= 3) {
    const netGate = comp.terminals[0]?.netId;
    const netSource = comp.terminals[2]?.netId;
    const vGate = netGate !== null && netGate !== undefined ? (result.nodeVoltages.get(netGate) || 0) : 0;
    const vSource = netSource !== null && netSource !== undefined ? (result.nodeVoltages.get(netSource) || 0) : 0;
    updated.voltage = vGate - vSource;
  }

  switch (comp.type) {
    case 'bulb': {
      if (comp.props.on === false) {
        // Switched off via script (Lamp.turnOff())
        updated.state.brightness = 0;
        break;
      }
      const ratedV = (comp.props.ratedVoltage as number) || 12;
      const ratedP = (comp.props.ratedPower as number) || 5;
      const resistance = ratedV * ratedV / ratedP;
      const actualPower = current * current * resistance;
      // Brightness proportional to power, with non-linear perception
      updated.state.brightness = Math.min(1, Math.pow(actualPower / ratedP, 0.7));
      // Overvoltage protection visual
      if (v > ratedV * 1.5) {
        updated.state.burned = true;
        updated.state.brightness = 0;
      }
      break;
    }
    case 'led': {
      const maxCurrent = ((comp.props.maxCurrent as number) || 20) / 1000;
      updated.state.brightness = Math.min(1, Math.abs(current) / (maxCurrent * 0.5));
      if (Math.abs(current) > maxCurrent * 1.2) {
        updated.state.burned = true;
        updated.state.brightness = 0;
      }
      break;
    }
    case 'pc817': {
      // Real optocoupler behavior: the internal IR LED's actual junction
      // current (computed above via the diode equation on Anode/Cathode,
      // terminals 0/1) is compared against this part's LED Turn-On
      // Current spec to decide whether enough IR light is reaching the
      // phototransistor to saturate it. `transistorOn` is read one tick
      // later by buildNets() to union (or not) the Collector/Emitter
      // terminals - the only link between the two sides is this optical
      // threshold; there is never a shared net.
      const thresholdA = ((comp.props.thresholdCurrent as number) || 1) / 1000;
      const ledOn = Math.abs(current) >= thresholdA;
      updated.state.ledCurrent = current;
      updated.state.ledOn = ledOn;
      updated.state.transistorOn = ledOn;
      break;
    }
    case 'transistorNpn':
    case 'transistorPnp':
    case 'tip120':
    case 'tip122': {
      // Real BJT switching: `current` here is this tick's actual
      // Base-Emitter junction current (computed in simulateDC's
      // per-component switch above, from the real exponential diode
      // equation stamped into the MNA solve). Once its magnitude crosses
      // the part's Base Turn-On Current spec, the transistor has enough
      // base drive to saturate - `transistorOn` is read one tick later
      // by buildNets() to union (or not) the Collector/Emitter terminals,
      // the same delayed-switch pattern PC817 uses above for its
      // optically-coupled contact.
      const thresholdA = ((comp.props.baseTurnOnCurrent as number) || 0.1) / 1000;
      updated.state.baseCurrent = current;
      updated.state.transistorOn = Math.abs(current) >= thresholdA;
      break;
    }
    case 'irf520':
    case 'irf540':
    case 'irlz44n': {
      // Real MOSFET switching: `updated.voltage` above is this tick's
      // actual Gate-Source voltage (from the real MNA node solve - no
      // gate current involved, since an ideal insulated gate draws none).
      // Once it crosses the part's Gate Threshold Voltage spec, the
      // channel has turned on - `mosfetOn` is read one tick later by
      // buildNets() to union the Drain/Source terminals, the same
      // delayed-switch pattern the BJTs use above for their Base-Emitter
      // junction current, just gated by voltage instead of current
      // (matching a real power MOSFET's voltage-controlled gate, which is
      // what makes it PWM-friendly - a PWM pin can drive it directly
      // without a base resistor).
      const vgsThreshold = (comp.props.gateThresholdVoltage as number) || 4;
      updated.state.gateVoltage = updated.voltage;
      updated.state.mosfetOn = updated.voltage >= vgsThreshold;
      break;
    }
    case 'rgbLed': {
      // Each channel is read as its own real diode junction voltage, so
      // the resulting mix genuinely reflects whatever's wired into R/G/B -
      // not a scripted color swap.
      const commonAnode = comp.props.commonType === 'anode';
      const vForward = (comp.props.forwardVoltage as number) || 2.1;
      const maxCurrent = ((comp.props.maxCurrent as number) || 20) / 1000;
      const Is = 1e-14, vt = 0.026;
      const vAt = (idx: number) => result.nodeVoltages.get(comp.terminals[idx]?.netId ?? -1) || 0;
      const vCommon = vAt(1);
      const channelTermIdx: Record<string, number> = { R: 0, G: 2, B: 3 };
      for (const ch of Object.keys(channelTermIdx)) {
        const vPin = vAt(channelTermIdx[ch]);
        const vd = commonAnode ? (vCommon - vPin) : (vPin - vCommon);
        let chCurrent = 0;
        if (vd > vForward) {
          chCurrent = Is * (Math.exp(Math.min((vd - vForward) / vt, 700)) - 1);
        }
        updated.state[`brightness${ch}`] = Math.min(1, Math.max(0, chCurrent / (maxCurrent * 0.5)));
      }
      break;
    }
    case 'neopixel': {
      const vAt = (idx: number) => result.nodeVoltages.get(comp.terminals[idx]?.netId ?? -1) || 0;
      const vSupply = Math.abs(vAt(0) - vAt(3));
      updated.state.on = vSupply > 2.5 && comp.props.animationMode !== 'off';
      break;
    }
    case 'lcd16x2': {
      const vAt = (idx: number) => result.nodeVoltages.get(comp.terminals[idx]?.netId ?? -1) || 0;
      const vSupply = Math.abs(vAt(0) - vAt(1));
      updated.state.on = vSupply > 2.5;
      break;
    }
    case 'oledSsd1306': {
      const vAt = (idx: number) => result.nodeVoltages.get(comp.terminals[idx]?.netId ?? -1) || 0;
      const vSupply = Math.abs(vAt(0) - vAt(1));
      updated.state.on = vSupply > 2.5 && comp.props.pattern !== 'off';
      break;
    }
    case 'sevenSegment': {
      const preview = comp.props.previewDigit as string;
      if (preview && preview !== 'none') {
        updated.state.segments = digitToSegments(preview);
      } else {
        const commonAnode = comp.props.commonType === 'anode';
        const labels = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'dp'];
        const commonIdx = comp.terminals.findIndex(t => t.label === 'COM');
        const vAt = (idx: number) => result.nodeVoltages.get(comp.terminals[idx]?.netId ?? -1) || 0;
        const vCommon = commonIdx >= 0 ? vAt(commonIdx) : 0;
        const segs: Record<string, boolean> = {};
        labels.forEach((label, idx) => {
          const vPin = vAt(idx);
          segs[label] = commonAnode ? (vCommon - vPin > 2) : (vPin - vCommon > 2);
        });
        updated.state.segments = segs;
      }
      break;
    }
    case 'sevenSegment4': {
      const previewStr = String(comp.props.previewValue ?? '');
      const commonAnode = comp.props.commonType === 'anode';
      const labels = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'dp'];
      const digitCommonLabels = ['D1', 'D2', 'D3', 'D4'];
      const vAt = (idx: number) => result.nodeVoltages.get(comp.terminals[idx]?.netId ?? -1) || 0;
      const digits: Array<Record<string, boolean>> = [];
      for (let d = 0; d < 4; d++) {
        const previewChar = previewStr[d];
        if (previewChar && /[0-9]/.test(previewChar)) {
          digits.push(digitToSegments(previewChar));
          continue;
        }
        const commonIdx = comp.terminals.findIndex(t => t.label === digitCommonLabels[d]);
        const vCommon = commonIdx >= 0 ? vAt(commonIdx) : 0;
        const digitActive = commonAnode ? vCommon > 2.5 : vCommon < 2.5;
        const segs: Record<string, boolean> = {};
        labels.forEach((label, idx) => {
          const vPin = vAt(idx);
          segs[label] = digitActive && (commonAnode ? (vCommon - vPin > 2) : (vPin - vCommon > 2));
        });
        digits.push(segs);
      }
      updated.state.digits = digits;
      break;
    }
    case 'dcMotor': {
      const ratedV = (comp.props.ratedVoltage as number) || 12;
      const rpm = Math.min(10000, Math.abs(v) / ratedV * 3000);
      updated.state.rpm = rpm;
      // Reversing the applied polarity reverses a real DC motor's spin
      // direction. Small voltages (near 0) don't flip direction back and
      // forth on solver noise - direction only updates once there's a
      // meaningful signal, otherwise it holds its last value.
      if (Math.abs(v) > 0.05) {
        updated.state.direction = v >= 0 ? 1 : -1;
      }
      break;
    }
    case 'waterPump': {
      const ratedV = (comp.props.voltage as number) || 12;
      const ratedRpm = (comp.props.ratedRpm as number) || 3000;
      const speedRatio = Math.min(1.5, Math.abs(v) / ratedV);
      const rpm = speedRatio * ratedRpm;
      updated.state.rpm = rpm;
      updated.state.speedRatio = speedRatio;
      if (Math.abs(v) > 0.05) {
        updated.state.direction = v >= 0 ? 1 : -1;
      }
      break;
    }
    case 'stepperMotor': {
      // Driven speed scales with applied voltage vs. the rated voltage,
      // capped at the motor's rated RPM. Rotation direction, unlike a DC
      // motor, isn't inferred from polarity here - a real driver
      // (A4988/ULN2003) picks direction via its own step-sequence logic,
      // which isn't modeled yet, so the Direction property stands in for
      // that until a driver component is added.
      const ratedV = (comp.props.ratedVoltage as number) || 12;
      const ratedRpm = (comp.props.ratedRpm as number) || 60;
      const speedRatio = Math.min(1, Math.abs(v) / ratedV);
      updated.state.rpm = speedRatio * ratedRpm;
      updated.state.powered = Math.abs(v) > 0.05;
      updated.state.direction = comp.props.direction === 'ccw' ? -1 : 1;
      break;
    }
    case 'servoMotor': {
      // PWM-style control: the net voltage stands in for a duty-cycle
      // signal scaled 0-5V (matching typical 3.3V/5V logic), mapped
      // linearly onto this servo's configured pulse-width range, which in
      // turn maps onto its 0-180deg travel - exactly how a real RC servo
      // decodes its control pulse.
      const minPulse = (comp.props.minPulse as number) ?? 1;
      const maxPulse = (comp.props.maxPulse as number) ?? 2;
      const dutyFrac = Math.max(0, Math.min(1, v / 5));
      const pulseWidth = minPulse + dutyFrac * (maxPulse - minPulse);
      const angle = Math.max(0, Math.min(180, ((pulseWidth - minPulse) / Math.max(0.0001, maxPulse - minPulse)) * 180));
      updated.state.angle = angle;
      break;
    }
    case 'buzzer': {
      updated.state.active = Math.abs(v) > 0.5;
      break;
    }
    case 'activeBuzzer': {
      // Active buzzers have their own internal driver oscillator - they
      // just need enough voltage present and immediately sound their one
      // fixed built-in tone. No signal shaping needed.
      const ratedV = (comp.props.ratedVoltage as number) || 5;
      updated.state.active = Math.abs(v) >= ratedV * 0.5;
      break;
    }
    case 'passiveBuzzer': {
      // Passive buzzers have no internal oscillator - they're a bare
      // driven element, so (as with the servo's PWM-duty stand-in above)
      // the net voltage here represents the driving signal's duty/level,
      // linearly mapped onto this buzzer's configured audible frequency
      // range. Silent below a small threshold, matching a flat/absent
      // PWM signal.
      const ratedV = (comp.props.ratedVoltage as number) || 5;
      const minFreq = (comp.props.minFrequency as number) ?? 100;
      const maxFreq = (comp.props.maxFrequency as number) ?? 4000;
      const on = Math.abs(v) > 0.3;
      updated.state.active = on;
      if (on) {
        const frac = Math.max(0, Math.min(1, Math.abs(v) / ratedV));
        updated.state.frequency = minFreq + frac * (maxFreq - minFreq);
      } else {
        updated.state.frequency = 0;
      }
      break;
    }
    case 'relay': {
      const coilV = (comp.props.coilVoltage as number) || 5;
      updated.state.energized = v >= coilV * 0.8;
      break;
    }
    case 'relayModule': {
      // Only the *commanded* state is set here - the actual (delayed)
      // energized/contact state is advanced over time in
      // advanceVisualState(), which is what the switching-delay and click
      // sound both key off of.
      const coilV = (comp.props.coilVoltage as number) || 5;
      updated.state.commandEnergized = v >= coilV * 0.8;
      break;
    }
    case 'solenoidValve': {
      // Simple on/off valve: opens once the coil sees roughly half its
      // rated voltage. The actual (eased) open/close animation and flow
      // are advanced in advanceVisualState().
      const ratedV = (comp.props.voltage as number) || 12;
      updated.state.open = Math.abs(v) >= ratedV * 0.5;
      break;
    }
    case 'fuse': {
      const rating = (comp.props.currentRating as number) || 1;
      if (Math.abs(current) > rating * 1.5) {
        updated.state.blown = true;
      }
      break;
    }
    case 'polyfuse': {
      // Trips (goes high-resistance) the instant current exceeds Trip
      // Current - fast, same as a real PTC's self-heating runaway. Reset
      // is purely time-based (see advanceVisualState's cooldown timer) -
      // once the timer flips it back to cold resistance, the *next*
      // solve naturally re-exposes it to whatever current the circuit
      // now demands: if the fault actually cleared, that current is
      // small and it stays reset; if the fault is still there, the
      // resulting current instantly exceeds Trip Current again and this
      // same check re-trips it right back - the real "nuisance cycling"
      // behavior a PTC shows under a sustained fault, without needing a
      // separate (and physically shaky) "is the fault still there?"
      // heuristic here.
      const tripCurrent = Math.max(0, (comp.props.tripCurrent as number) || 2);
      const alreadyTripped = !!comp.state.tripped;
      if (!alreadyTripped && Math.abs(current) > tripCurrent) {
        updated.state.tripped = true;
        updated.state.coolingMs = 0;
      }
      break;
    }
    case 'andGate':
    case 'orGate':
    case 'notGate':
    case 'nandGate':
    case 'norGate':
    case 'xorGate': {
      // Simple logic: assume 5V logic levels
      updated.state.outputHigh = v > 2.5;
      break;
    }
    case 'hcSr04': {
      // Read the Trig pin's actual electrical level (relative to this
      // sensor's own GND pin) so advanceVisualState() can detect a
      // low->high trigger edge. Echo's own driven voltage is excluded
      // from `v` here since terminal order is VCC, Trig, Echo, GND.
      if (comp.terminals.length >= 4) {
        const trigNetId = comp.terminals[1].netId;
        const gndNetId = comp.terminals[3].netId;
        const trigV = (trigNetId !== null ? result.nodeVoltages.get(trigNetId) : undefined) || 0;
        const gndV = (gndNetId !== null ? result.nodeVoltages.get(gndNetId) : undefined) || 0;
        updated.state.trigHigh = (trigV - gndV) > 2.5;
      }
      break;
    }
    case 'lm35': {
      // Expose the sensor's own driven output voltage (10 mV/°C) so the
      // renderer/UI can display it without recomputing the transfer
      // function elsewhere. Also expose the equivalent 10-bit ADC code
      // (0-1023) an Arduino's analogRead() would return for this voltage
      // on a 5V reference (Uno/Nano/Mega all use the same 5V, 10-bit ADC),
      // so any consumer reading this sensor's node gets a realistic,
      // temperature-derived analog value.
      const enabled = comp.props.enabled !== false;
      const temperature = Math.max(-55, Math.min(150, (comp.props.temperature as number) ?? 25));
      const outputVoltage = enabled ? temperature * 0.01 : 0;
      updated.state.outputVoltage = outputVoltage;
      updated.state.adcValue = Math.max(0, Math.min(1023, Math.round((outputVoltage / 5) * 1023)));
      break;

    }
    case 'gpsNeo6m': {
      // Expose the module's own driven TX level (matches the
      // voltage-source stamp in simulateDC above) so the renderer/UI can
      // show fix status without recomputing it elsewhere.
      const powered = comp.props.powered !== false;
      const fixAcquired = comp.props.fixAcquired !== false;
      const logicLevel = (comp.props.logicLevel as number) || 3.3;
      updated.state.txVoltage = powered && fixAcquired ? logicLevel : 0;
      updated.state.fixHigh = powered && fixAcquired;
      break;
    }
    case 'hc05':
    case 'hc06': {
      // Expose the module's own driven pin levels (matches the
      // voltage-source stamp in simulateDC above) so the renderer/UI can
      // show link status without recomputing it elsewhere.
      const powered = comp.props.powered !== false;
      const connected = !!comp.props.connected;
      const logicLevel = (comp.props.logicLevel as number) || 3.3;
      updated.state.txdVoltage = powered ? logicLevel : 0;
      updated.state.stateHigh = powered && connected;
      break;
    }
    case 'esp8266':
    case 'esp32': {
      // Same pattern as hc05/hc06 above: expose the driven TXD level and
      // the Wi-Fi Connected flag for the renderer/UI.
      const powered = comp.props.powered !== false;
      const connected = !!comp.props.connected;
      const logicLevel = (comp.props.logicLevel as number) || 3.3;
      updated.state.txdVoltage = powered ? logicLevel : 0;
      updated.state.wifiConnected = powered && connected;
      break;
    }
    case 'rc522': {
      // Expose the module's own driven MISO level (matches the
      // voltage-source stamp in simulateDC above), plus the currently
      // selected test card's UID, for the renderer/UI.
      const powered = comp.props.powered !== false;
      const cardPresent = comp.props.cardPresent !== false;
      const logicLevel = (comp.props.logicLevel as number) || 3.3;
      updated.state.misoVoltage = powered ? logicLevel : 0;
      updated.state.cardPresent = powered && cardPresent;
      updated.state.cardUid = (comp.props.cardUid as string) || '';
      break;
    }
    case 'nrf24l01': {
      // Expose the driven (active-low) IRQ level for the renderer/UI -
      // matches the voltage-source stamp in simulateDC above.
      const powered = comp.props.powered !== false;
      const dataReady = !!comp.props.dataReady;
      const logicLevel = (comp.props.logicLevel as number) || 3.3;
      updated.state.irqVoltage = powered && !dataReady ? logicLevel : 0;
      updated.state.irqActive = powered && dataReady;
      break;
    }
    case 'max485': {
      // Expose the driven RO level for the renderer/UI - matches the
      // voltage-source stamp in simulateDC above.
      const powered = comp.props.powered !== false;
      const busIdleHigh = comp.props.busIdleHigh !== false;
      const logicLevel = (comp.props.logicLevel as number) || 5;
      updated.state.roVoltage = powered && busIdleHigh ? logicLevel : 0;
      break;
    }
    case 'canBusModule': {
      // Expose the driven (active-low) INT level for the renderer/UI -
      // matches the voltage-source stamp in simulateDC above.
      const powered = comp.props.powered !== false;
      const messagePending = !!comp.props.messagePending;
      const logicLevel = (comp.props.logicLevel as number) || 5;
      updated.state.intVoltage = powered && !messagePending ? logicLevel : 0;
      updated.state.intActive = powered && messagePending;
      break;
    }
    case 'reg7805':
    case 'ams1117':
    case 'lm317': {
      // Read back this regulator's own output pin voltage (relative to
      // its GND pin where it has one) from the already-solved circuit,
      // so the renderer's readout matches what simulateDC actually
      // computed (dropout/current-limit included) instead of just
      // echoing the set point.
      const outIdx = comp.type === 'reg7805' ? 2 : 1; // OUT terminal index
      const gndIdx = comp.type === 'reg7805' ? 1 : comp.type === 'ams1117' ? 0 : null; // GND terminal index (LM317 has none)
      const outTerm = comp.terminals[outIdx];
      const gndTerm = gndIdx === null ? null : comp.terminals[gndIdx];
      const outNetId = outTerm ? outTerm.netId : null;
      const gndNetId = gndTerm ? gndTerm.netId : null;
      const vOut = outNetId !== null ? (result.nodeVoltages.get(outNetId) ?? 0) : 0;
      const vGnd = gndNetId !== null ? (result.nodeVoltages.get(gndNetId) ?? 0) : 0;
      updated.state.outputVoltage = vOut - vGnd;
      break;
    }
    case 'ne555': {
      // Read TRIG and RESET relative to this chip's own GND pin so
      // advanceVisualState() can detect a monostable trigger edge and an
      // active-low reset. A floating (unwired) pin solves to 0V the same
      // as a genuinely low one, so netTerminalCounts is used to treat an
      // unwired TRIG/RESET as inactive instead of permanently
      // triggering/resetting the chip - matching how most people drop a
      // 555 down without wiring pins they don't need yet.
      if (comp.terminals.length >= 8) {
        const gndNetId = comp.terminals[0].netId;
        const trigNetId = comp.terminals[1].netId;
        const resetNetId = comp.terminals[3].netId;
        const counts = result.netTerminalCounts;
        const isWired = (netId: number | null) => netId !== null && (counts?.get(netId) || 0) > 1;
        const gndV = (gndNetId !== null ? result.nodeVoltages.get(gndNetId) : undefined) || 0;
        const trigV = (trigNetId !== null ? result.nodeVoltages.get(trigNetId) : undefined) || 0;
        const resetV = (resetNetId !== null ? result.nodeVoltages.get(resetNetId) : undefined) || 0;
        const supplyV = Math.max(4.5, (comp.props.supplyVoltage as number) || 5);
        updated.state.trigLow = isWired(trigNetId) && (trigV - gndV) < supplyV / 3;
        updated.state.resetActive = isWired(resetNetId) && (resetV - gndV) < supplyV / 3;
      }
      break;
    }
    case 'lm741': {
      // OUT is terminal index 5. The actual solved value already reflects
      // the op-amp's gain/clamping behavior stamped in the MNA solve
      // above - this just surfaces it for the live-output indicator.
      const outNetId = comp.terminals[5]?.netId ?? null;
      updated.state.outVoltage = outNetId !== null ? (result.nodeVoltages.get(outNetId) || 0) : 0;
      break;
    }
    case 'lm358': {
      // Two independent amps: OUT1 is terminal index 0, OUT2 is index 6.
      const out1NetId = comp.terminals[0]?.netId ?? null;
      const out2NetId = comp.terminals[6]?.netId ?? null;
      updated.state.out1Voltage = out1NetId !== null ? (result.nodeVoltages.get(out1NetId) || 0) : 0;
      updated.state.out2Voltage = out2NetId !== null ? (result.nodeVoltages.get(out2NetId) || 0) : 0;
      break;
    }
    case 'l293d':
    case 'l298n': {
      // Decode each channel's EN + pair of IN pins. EN is read as an
      // analog 0-1 level (voltage / 5V, clamped) rather than a hard
      // threshold: a real L298N/L293D's enable pin is almost always
      // PWM'd from an Arduino analogWrite() pin to get variable motor
      // speed, and since this simulator represents PWM as an averaged
      // DC voltage (see the Arduino's PWM pin stamp), reading EN as a
      // ratio is what makes that speed control actually work instead of
      // EN just snapping the channel fully on/off at the 2.5V midpoint.
      // IN pins are still decoded as digital (direction is discrete on a
      // real H-bridge), and stored for next tick's H-bridge stamp in
      // simulateDC() above (same one-tick-delayed pattern as the NE555's
      // OUT). An unwired EN reads as fully enabled (1) - real boards
      // (the L298N module especially) are almost always used with EN
      // tied high via an onboard jumper - while an unwired IN pair reads
      // as stopped rather than an arbitrary direction.
      const counts = result.netTerminalCounts;
      const isWired = (netId: number | null) => netId !== null && (counts?.get(netId) || 0) > 1;
      const isHigh = (netId: number | null) => isWired(netId) && (result.nodeVoltages.get(netId as number) || 0) > 2.5;
      const netAt = (idx: number) => comp.terminals[idx]?.netId ?? null;

      const decodeChannel = (enIdx: number, inAIdx: number, inBIdx: number) => {
        const enNet = netAt(enIdx);
        const enableLevel = !isWired(enNet)
          ? 1
          : Math.max(0, Math.min(1, (result.nodeVoltages.get(enNet as number) || 0) / 5));
        const inAHigh = isHigh(netAt(inAIdx));
        const inBHigh = isHigh(netAt(inBIdx));
        const direction = inAHigh === inBHigh ? 0 : (inAHigh ? 1 : -1);
        return { enableLevel, direction };
      };

      const ch1 = comp.type === 'l293d' ? decodeChannel(0, 1, 6) : decodeChannel(3, 4, 5);
      const ch2 = comp.type === 'l293d' ? decodeChannel(8, 9, 14) : decodeChannel(8, 9, 10);
      updated.state.ch1Enabled = ch1.enableLevel;
      updated.state.ch1Direction = ch1.direction;
      updated.state.ch2Enabled = ch2.enableLevel;
      updated.state.ch2Direction = ch2.direction;
      break;
    }
    case 'uln2003': {
      // Decode each IN pin at a fixed ~2.5V threshold (assuming standard
      // 5V logic, e.g. an Arduino digital pin) into a per-channel on/off
      // flag for next tick's open-collector stamp in simulateDC() above
      // (same one-tick-delayed pattern as the L293D/L298N's enable/
      // direction). An unwired IN reads as low/off - a real Darlington
      // base with nothing driving it doesn't spontaneously saturate.
      if (comp.terminals.length >= 16) {
        const counts = result.netTerminalCounts;
        const isWired = (netId: number | null) => netId !== null && (counts?.get(netId) || 0) > 1;
        const isHigh = (netId: number | null) => isWired(netId) && (result.nodeVoltages.get(netId as number) || 0) > 2.5;
        const netAt = (idx: number) => comp.terminals[idx]?.netId ?? null;

        updated.state.out1On = isHigh(netAt(0));
        updated.state.out2On = isHigh(netAt(1));
        updated.state.out3On = isHigh(netAt(2));
        updated.state.out4On = isHigh(netAt(3));
        updated.state.out5On = isHigh(netAt(4));
        updated.state.out6On = isHigh(netAt(5));
        updated.state.out7On = isHigh(netAt(6));

        // Cache COM's (idx 8) actual solved voltage this tick for use as
        // the "off" rail in next tick's stamp; fall back to the Supply
        // Voltage (COM) property whenever COM isn't wired at all.
        const comNetId = netAt(8);
        updated.state.comVoltage = comNetId !== null
          ? (result.nodeVoltages.get(comNetId) || 0)
          : Math.max(0, (comp.props.comSupplyVoltage as number) ?? 12);
      }
      break;
    }
    case '74hc595': {
      // Real 8-bit SIPO shift register with a separate output latch,
      // clocked exactly like the physical part: every SH_CP rising edge
      // shifts DS into the register (toward Q7); every ST_CP rising edge
      // copies the current register into the Q0-Q7 output latch. Both
      // edges are detected by comparing this tick's decoded clock level
      // against last tick's cached level (same one-tick-delayed pattern
      // used throughout this file, e.g. the NE555's trigLow/prevTrigLow).
      // MR (active-low) asynchronously clears the shift register only -
      // matching the real chip, where the output latch isn't touched
      // until the next ST_CP pulse propagates the cleared bits through.
      if (comp.terminals.length >= 16) {
        const counts = result.netTerminalCounts;
        const isWired = (netId: number | null) => netId !== null && (counts?.get(netId) || 0) > 1;
        const isHigh = (netId: number | null) => isWired(netId) && (result.nodeVoltages.get(netId as number) || 0) > 2.5;
        const netAt = (idx: number) => comp.terminals[idx]?.netId ?? null;

        const mrActive = isWired(netAt(9)) && !isHigh(netAt(9));
        const shClockHigh = isHigh(netAt(10));
        const stClockHigh = isHigh(netAt(11));
        // OE is active-low; an unwired OE is treated as enabled, matching
        // this file's existing convention for the L293D/L298N's EN pins
        // (real boards almost always tie an unused active-low enable low).
        const outputEnabled = !isWired(netAt(12)) || !isHigh(netAt(12));
        const dsHigh = isHigh(netAt(13));

        const prevBits = [0, 1, 2, 3, 4, 5, 6, 7].map(i => !!comp.state[`shiftBit${i}`]);
        const shiftEdge = shClockHigh && !comp.state.prevShiftClockHigh;
        let bits: boolean[];
        if (mrActive) {
          bits = new Array(8).fill(false);
        } else if (shiftEdge) {
          bits = [dsHigh, prevBits[0], prevBits[1], prevBits[2], prevBits[3], prevBits[4], prevBits[5], prevBits[6]];
        } else {
          bits = prevBits;
        }

        const prevLatch = [0, 1, 2, 3, 4, 5, 6, 7].map(i => !!comp.state[`q${i}`]);
        const latchEdge = stClockHigh && !comp.state.prevLatchClockHigh;
        const latch = latchEdge ? bits : prevLatch;

        for (let i = 0; i < 8; i++) {
          updated.state[`shiftBit${i}`] = bits[i];
          updated.state[`q${i}`] = latch[i];
        }
        updated.state.outputEnabled = outputEnabled;
        updated.state.prevShiftClockHigh = shClockHigh;
        updated.state.prevLatchClockHigh = stClockHigh;
      }
      break;
    }
    case '74hc165': {
      // Real 8-bit PISO shift register: while SH/LD is active (low), the
      // register continuously loads D0-D7 (A-H) in parallel; once SH/LD
      // goes high, each CLK rising edge (while CLK INH is low) shifts SER
      // in and the whole register one step toward QH, exactly like the
      // physical part. QH always reflects the current last stage - same
      // one-tick-delayed edge detection pattern as the 74HC595 above.
      if (comp.terminals.length >= 16) {
        const counts = result.netTerminalCounts;
        const isWired = (netId: number | null) => netId !== null && (counts?.get(netId) || 0) > 1;
        const isHigh = (netId: number | null) => isWired(netId) && (result.nodeVoltages.get(netId as number) || 0) > 2.5;
        const netAt = (idx: number) => comp.terminals[idx]?.netId ?? null;

        // SH/LD is active-low (load); unwired reads as inactive (shift mode).
        const loadActive = isWired(netAt(0)) && !isHigh(netAt(0));
        const clockHigh = isHigh(netAt(1));
        // CLK INH is active-low (clock enabled); unwired reads as enabled,
        // same "unwired active-low enable = enabled" convention as OE above.
        const clockInhibited = isWired(netAt(8)) && isHigh(netAt(8));
        const serHigh = isHigh(netAt(9));
        const dPins = [netAt(10), netAt(11), netAt(12), netAt(13), netAt(2), netAt(3), netAt(4), netAt(5)]; // D0-D7

        const prevBits = [0, 1, 2, 3, 4, 5, 6, 7].map(i => !!comp.state[`regBit${i}`]);
        const shiftEdge = clockHigh && !comp.state.prevClockHigh && !clockInhibited;
        let bits: boolean[];
        if (loadActive) {
          bits = dPins.map(net => isHigh(net));
        } else if (shiftEdge) {
          bits = [serHigh, prevBits[0], prevBits[1], prevBits[2], prevBits[3], prevBits[4], prevBits[5], prevBits[6]];
        } else {
          bits = prevBits;
        }

        for (let i = 0; i < 8; i++) {
          updated.state[`regBit${i}`] = bits[i];
        }
        updated.state.qH = bits[7];
        updated.state.loading = loadActive;
        updated.state.prevClockHigh = clockHigh;
      }
      break;
    }
    case 'cd4017': {
      // Real 5-stage Johnson decade counter/divider: every CLOCK rising
      // edge (while CLOCK INHIBIT is low) advances the count 0-9, then
      // wraps back to 0, exactly like the physical part - same one-tick-
      // delayed edge detection pattern as the 74HC595/74HC165 above.
      // RESET (active-high) asynchronously forces the count back to 0,
      // same as the 74HC595's MR. CARRY OUT completes one full cycle
      // every 10 clocks: it's high while count is 0-4 and low while
      // count is 5-9, matching the real chip's timing diagram (falls at
      // Q5, rises at Q0).
      if (comp.terminals.length >= 16) {
        const counts = result.netTerminalCounts;
        const isWired = (netId: number | null) => netId !== null && (counts?.get(netId) || 0) > 1;
        const isHigh = (netId: number | null) => isWired(netId) && (result.nodeVoltages.get(netId as number) || 0) > 2.5;
        const netAt = (idx: number) => comp.terminals[idx]?.netId ?? null;

        const resetActive = isHigh(netAt(14));
        const clockInhibited = isWired(netAt(12)) && isHigh(netAt(12));
        const clockHigh = isHigh(netAt(13));
        const prevCount = ((comp.state.count as number) ?? 0) | 0;
        const clockEdge = clockHigh && !comp.state.prevClockHigh && !clockInhibited;

        let count = prevCount;
        if (resetActive) {
          count = 0;
        } else if (clockEdge) {
          count = (prevCount + 1) % 10;
        }

        updated.state.count = count;
        for (let q = 0; q < 10; q++) {
          updated.state[`q${q}`] = count === q;
        }
        updated.state.carryOut = count < 5;
        updated.state.prevClockHigh = clockHigh;
      }
      break;
    }
    case 'cd4026': {
      // Real 5-stage Johnson decade counter with a built-in Johnson-to-
      // 7-segment decoder: same CLOCK/CLOCK INHIBIT/RESET counting
      // behavior as the CD4017 above (count 0-9, wraps to 0), but each
      // count is additionally decoded into the standard a-g 7-segment
      // pattern, gated live by DISPLAY ENABLE IN (no latch - a real
      // CD4026's segment outputs go low immediately whenever DEI goes
      // low, independent of the clock). CARRY OUT completes one cycle
      // every 10 clocks (same Q5/Q0 timing as the CD4017); the ungated
      // "C" segment output is the C-segment decode *without* the
      // DISPLAY ENABLE IN gate, matching the real chip's cascading
      // behavior. DISPLAY ENABLE OUT simply mirrors DISPLAY ENABLE IN.
      if (comp.terminals.length >= 16) {
        const counts = result.netTerminalCounts;
        const isWired = (netId: number | null) => netId !== null && (counts?.get(netId) || 0) > 1;
        const isHigh = (netId: number | null) => isWired(netId) && (result.nodeVoltages.get(netId as number) || 0) > 2.5;
        const netAt = (idx: number) => comp.terminals[idx]?.netId ?? null;

        const resetActive = isHigh(netAt(14));
        const clockInhibited = isHigh(netAt(1));
        const clockHigh = isHigh(netAt(0));
        // Unwired DISPLAY ENABLE IN defaults to enabled, since most
        // single-digit circuits tie it straight to VDD.
        const displayEnabled = !isWired(netAt(2)) || isHigh(netAt(2));
        const prevCount = ((comp.state.count as number) ?? 0) | 0;
        const clockEdge = clockHigh && !comp.state.prevClockHigh && !clockInhibited;

        let count = prevCount;
        if (resetActive) {
          count = 0;
        } else if (clockEdge) {
          count = (prevCount + 1) % 10;
        }

        // Standard Johnson-decade-to-7-segment decode table (common
        // cathode convention: true = segment lit), same digit shapes any
        // 7-segment driver uses for 0-9.
        const SEGMENTS: Record<number, string> = {
          0: 'abcdef', 1: 'bc', 2: 'abged', 3: 'abgcd', 4: 'fgbc',
          5: 'afgcd', 6: 'afgecd', 7: 'abc', 8: 'abcdefg', 9: 'abcdfg',
        };
        const lit = SEGMENTS[count] || '';
        const rawSeg: Record<string, boolean> = {
          a: lit.includes('a'), b: lit.includes('b'), c: lit.includes('c'),
          d: lit.includes('d'), e: lit.includes('e'), f: lit.includes('f'),
          g: lit.includes('g'),
        };

        updated.state.count = count;
        for (const seg of ['a', 'b', 'c', 'd', 'e', 'f', 'g'] as const) {
          updated.state[seg] = displayEnabled && rawSeg[seg];
        }
        // Ungated "C" segment: the C decode without the DEI gate.
        updated.state.ungatedC = rawSeg.c;
        updated.state.carryOut = count < 5;
        updated.state.displayEnabled = displayEnabled;
        updated.state.prevClockHigh = clockHigh;
      }
      break;
    }
    case 'arduino':
    case 'arduinoMega':
    case 'arduinoNano': {
      // Analog pins are high-impedance ADC inputs (not driven in the MNA
      // stamp above), so read whatever voltage the wiring settled on and
      // convert it to the 10-bit code (0-1023, 5V reference) analogRead()
      // would return on a real Uno/Nano/Mega.
      const gndIdx = comp.terminals.findIndex(t => t.label === 'GND');
      const gndNetId = gndIdx >= 0 ? comp.terminals[gndIdx].netId : null;
      const gndV = (gndNetId !== null ? result.nodeVoltages.get(gndNetId) : undefined) || 0;
      const analogValues: Record<string, number> = {};
      for (const t of comp.terminals) {
        if (!/^A\d+$/.test(t.label)) continue;
        const pinV = (t.netId !== null ? result.nodeVoltages.get(t.netId) : undefined) || 0;
        const relV = Math.max(0, Math.min(5, pinV - gndV));
        analogValues[t.label] = Math.round((relV / 5) * 1023);
      }
      updated.state.analogValues = analogValues;

      // digitalRead(): for any pin in INPUT or INPUT_PULLUP mode (not
      // stamped as a source in the MNA pass above), read back whatever
      // voltage the rest of the circuit settled the pin to and threshold
      // it at 2.5V (standard TTL/CMOS midpoint) to get the HIGH/LOW a
      // real digitalRead() call would return.
      const digitalValues: Record<string, boolean> = {};
      for (const t of comp.terminals) {
        const m = /^D(\d+)$/.exec(t.label);
        if (!m) continue;
        const mode = (comp.props[`d${m[1]}_mode`] as string) || 'OUTPUT';
        if (mode !== 'INPUT' && mode !== 'INPUT_PULLUP') continue;
        const pinV = (t.netId !== null ? result.nodeVoltages.get(t.netId) : undefined) || 0;
        const relV = pinV - gndV;
        // An unwired INPUT_PULLUP pin has nothing else on its net besides
        // its own weak pull-up, so it correctly settles at ~5V (HIGH) -
        // matching a real board's floating-high pulled-up input.
        digitalValues[t.label] = relV > 2.5;
      }
      updated.state.digitalValues = digitalValues;

      // Reset detection: RESET is active-low with its own onboard
      // pull-up (stamped above), so it reads HIGH (~5V) when left
      // unconnected and only drops low when something (a reset button,
      // an external low signal) actually pulls it down - exactly like a
      // real board. Latched here for next tick's tri-state gating above.
      const resetIdx = comp.terminals.findIndex(t => t.label === 'RESET');
      if (resetIdx >= 0) {
        const resetNetId = comp.terminals[resetIdx].netId;
        const resetV = (resetNetId !== null ? result.nodeVoltages.get(resetNetId) : undefined) || 0;
        updated.state.resetActive = (resetV - gndV) < 1.0;
      }
      break;
    }
    case 'ldr': {
      // Mirror the same resistance formula used in the MNA stamp above so
      // the UI can show the sensor's current resistance without
      // recomputing it, and so it updates immediately whenever Light
      // Level changes (this runs every simulation pass).
      const enabled = comp.props.enabled !== false;
      const lightLevel = enabled ? Math.max(0, Math.min(100, (comp.props.lightLevel as number) ?? 50)) : 0;
      const darkResistance = 1_000_000;
      const brightResistance = 100;
      updated.state.resistance = darkResistance * Math.pow(brightResistance / darkResistance, lightLevel / 100);
      break;
    }
  }

  return updated;
}

/**
 * Advance smoothed, time-based animation state for components.
 *
 * updateComponentState() above computes the *instantaneous* electrical
 * target for each component (brightness, rpm, energized, pressed, ...)
 * straight from Ohm's-law math, so it jumps the moment the underlying
 * current/voltage changes. Real components don't move that fast — a
 * filament takes time to heat/cool, a motor has inertia, a relay's blade
 * physically travels between contacts. This function runs every animation
 * frame (independent of how often the DC solver re-converges) and eases
 * each component's *visual* fields toward those targets using the elapsed
 * frame time, so lamps fade, motors spin up/down smoothly, and relay/button
 * contacts animate their travel instead of teleporting.
 */
export function advanceVisualState(components: Component[], dtMs: number): Component[] {
  // Clamp so a dropped frame (tab backgrounded, first frame, etc.) can't
  // cause a huge, visually-jarring jump.
  const dt = Math.max(0, Math.min(dtMs, 100));

  // Exponential ease toward target - alpha depends on elapsed time so the
  // animation speed is frame-rate independent.
  const ease = (current: number, target: number, timeConstantMs: number) => {
    const alpha = 1 - Math.exp(-dt / timeConstantMs);
    return current + (target - current) * alpha;
  };

  return components.map(comp => {
    switch (comp.type) {
      case 'bulb': {
        const target = (comp.state.brightness as number) || 0;
        const prev = (comp.state.visualBrightness as number) || 0;
        // Incandescent filaments heat up a bit faster than they cool down.
        const timeConstant = target > prev ? 120 : 220;
        const state = { ...comp.state, visualBrightness: ease(prev, target, timeConstant) };
        return { ...comp, state };
      }
      case 'dcMotor': {
        const targetRpm = (comp.state.rpm as number) || 0;
        const prevRpm = (comp.state.visualRpm as number) || 0;
        // Real motors coast down gradually when still spinning, but the
        // client explicitly wants an *instant* stop the moment power is
        // removed (no coasting) — so skip the easing only for the
        // zero-target case, while spin-up still ramps smoothly.
        const nextRpm = targetRpm === 0 ? 0 : ease(prevRpm, targetRpm, 350);
        const direction = (comp.state.direction as number) || 1;
        const prevAngle = (comp.state.rotationAngle as number) || 0;
        const angularSpeed = direction * (nextRpm / 60) * Math.PI * 2; // rad/s, signed for direction
        const nextAngle = nextRpm === 0 ? prevAngle : (prevAngle + angularSpeed * (dt / 1000)) % (Math.PI * 2);
        const state = { ...comp.state, visualRpm: nextRpm, rotationAngle: nextAngle };
        return { ...comp, state };
      }
      case 'waterPump': {
        const targetRpm = (comp.state.rpm as number) || 0;
        const prevRpm = (comp.state.visualRpm as number) || 0;
        // Same instant-stop behavior as the DC motor: coast down while
        // still running, but snap to a dead stop the instant power (and
        // thus the target speed) drops to zero.
        const nextRpm = targetRpm === 0 ? 0 : ease(prevRpm, targetRpm, 350);
        const direction = (comp.state.direction as number) || 1;
        const prevAngle = (comp.state.rotationAngle as number) || 0;
        const angularSpeed = direction * (nextRpm / 60) * Math.PI * 2;
        const nextAngle = nextRpm === 0 ? prevAngle : (prevAngle + angularSpeed * (dt / 1000)) % (Math.PI * 2);

        // Water speed depends on both applied voltage (via nextRpm, already
        // voltage-ratio based) and the pump's Horse Power rating — a
        // stronger pump visibly pushes water faster at the same speed
        // ratio. Referenced against 0.5 HP (a small/common pump) so the
        // multiplier reads as "normal" there and scales up/down from it.
        const hp = Math.max(0.01, (comp.props.horsePower as number) || 0.5);
        const hpFactor = Math.min(3, Math.max(0.4, Math.sqrt(hp / 0.5)));
        const speedRatio = (comp.state.speedRatio as number) || 0;
        const targetFlow = speedRatio * hpFactor;
        const prevFlow = (comp.state.visualFlow as number) || 0;
        const nextFlow = targetFlow === 0 ? 0 : ease(prevFlow, targetFlow, 300);
        const prevPhase = (comp.state.flowPhase as number) || 0;
        const nextPhase = nextFlow === 0 ? prevPhase : (prevPhase + nextFlow * 6 * (dt / 1000)) % (Math.PI * 2);

        const state = {
          ...comp.state,
          visualRpm: nextRpm,
          rotationAngle: nextAngle,
          visualFlow: nextFlow,
          flowPhase: nextPhase,
        };
        return { ...comp, state };
      }
      case 'servoMotor': {
        // Real servos sweep at a bounded angular rate (their rated
        // Speed, in deg/s) rather than snapping instantly - move the
        // visual angle toward the commanded target at that rate.
        const target = Math.max(0, Math.min(180, (comp.state.angle as number) || 0));
        const prev = (comp.state.visualAngle as number) ?? target;
        const degPerSec = Math.max(1, (comp.props.speed as number) || 300);
        const maxStep = degPerSec * (dt / 1000);
        const diff = target - prev;
        let nextAngle: number;
        if (Math.abs(diff) <= maxStep) {
          nextAngle = target;
        } else {
          nextAngle = prev + Math.sign(diff) * maxStep;
        }
        const moving = Math.abs(target - nextAngle) > 0.05;
        const state = { ...comp.state, visualAngle: nextAngle, moving };
        return { ...comp, state };
      }
      case 'polyfuse': {
        if (!comp.state.tripped) return comp;
        const resetTimeMs = Math.max(0, (comp.props.resetTimeMs as number) || 3000);
        const coolingMs = ((comp.state.coolingMs as number) || 0) + dt;
        const resetNow = coolingMs >= resetTimeMs;
        const state = {
          ...comp.state,
          coolingMs: resetNow ? 0 : coolingMs,
          tripped: resetNow ? false : true,
        };
        return { ...comp, state };
      }
      case 'relay': {
        const target = comp.state.energized ? 1 : 0;
        const prev = (comp.state.contactPos as number) || 0;
        const state = { ...comp.state, contactPos: ease(prev, target, 90) };
        return { ...comp, state };
      }
      case 'relayModule': {
        // The coil's commanded state changes instantly, but a real
        // armature doesn't move until it's had time to physically pull
        // in/drop out - hold the actual (energized) state steady until
        // Switching Delay ms have elapsed since the command changed, then
        // flip it and let the contact blade ease over exactly like the
        // bare relay above. syncRelayClicks() (audio) keys off this same
        // delayed `energized` flip, so the click naturally lands only once
        // the contact actually switches.
        const commanded = !!comp.state.commandEnergized;
        const actual = !!comp.state.energized;
        const delayMs = Math.max(0, (comp.props.switchingDelay as number) || 0);
        let pendingMs = (comp.state.pendingDelayMs as number) || 0;
        let energized = actual;
        if (commanded !== actual) {
          pendingMs += dt;
          if (pendingMs >= delayMs) {
            energized = commanded;
            pendingMs = 0;
          }
        } else {
          pendingMs = 0;
        }
        const target = energized ? 1 : 0;
        const prev = (comp.state.contactPos as number) || 0;
        const state = {
          ...comp.state,
          energized,
          pendingDelayMs: pendingMs,
          contactPos: ease(prev, target, 90),
        };
        return { ...comp, state };
      }
      case 'solenoidValve': {
        const target = comp.state.open ? 1 : 0;
        const prev = (comp.state.visualOpen as number) || 0;
        const visualOpen = ease(prev, target, 120);
        // Flow only progresses once the plunger has actually cleared the
        // seat enough to pass water.
        const flowing = visualOpen > 0.3;
        const prevPhase = (comp.state.flowPhase as number) || 0;
        const nextPhase = flowing ? (prevPhase + 1.2 * (dt / 1000)) % 1 : prevPhase;
        const state = { ...comp.state, visualOpen, flowPhase: nextPhase };
        return { ...comp, state };
      }
      case 'stepperMotor': {
        // Real motors coast down gradually when still spinning, but (as
        // with the DC motor) stop instantly the moment power is removed.
        const targetRpm = (comp.state.rpm as number) || 0;
        const prevRpm = (comp.state.visualRpm as number) || 0;
        const nextRpm = targetRpm === 0 ? 0 : ease(prevRpm, targetRpm, 200);

        // Convert speed into discrete steps rather than continuous
        // rotation: accumulate elapsed time and advance exactly one Step
        // Angle increment each time enough time has passed for a full
        // step at the current speed - this is what makes the motion
        // step-by-step instead of a smooth continuous spin.
        const stepAngleDeg = Math.max(0.1, (comp.props.stepAngle as number) || 1.8);
        const direction = (comp.state.direction as number) || 1;
        const stepsPerSec = (nextRpm / 60) * (360 / stepAngleDeg);

        let accumulatorMs = (comp.state.stepAccumulatorMs as number) || 0;
        let stepIndex = (comp.state.stepIndex as number) || 0;
        let stepped = false;
        if (stepsPerSec > 0.01) {
          accumulatorMs += dt;
          const msPerStep = 1000 / stepsPerSec;
          // Cap iterations so a huge dt (e.g. a backgrounded tab) can't
          // spin through thousands of steps in one frame.
          let guard = 0;
          while (accumulatorMs >= msPerStep && guard < 200) {
            accumulatorMs -= msPerStep;
            stepIndex += direction;
            stepped = true;
            guard++;
          }
        } else {
          accumulatorMs = 0;
        }

        // The rotor's hard, quantized target angle for this step...
        const targetAngleDeg = stepIndex * stepAngleDeg;
        // ...but real stepper rotors don't teleport between poles - they
        // briefly overshoot/settle each step. A fast ease toward the
        // target (instead of an instant jump) gives that "smooth
        // step-by-step" feel while still visibly moving in discrete hops.
        const prevDisplay = (comp.state.displayAngle as number) ?? targetAngleDeg;
        const displayAngle = ease(prevDisplay, targetAngleDeg, 35);

        const state = {
          ...comp.state,
          visualRpm: nextRpm,
          stepAccumulatorMs: accumulatorMs,
          stepIndex,
          displayAngle,
          stepping: stepped,
        };
        return { ...comp, state };
      }
      case 'neopixel': {
        const on = !!comp.state.on;
        const count = Math.max(1, Math.min(60, (comp.props.pixelCount as number) || 8));
        const mode = (comp.props.animationMode as string) || 'rainbow';
        const brightness = Math.max(0, Math.min(1, (comp.props.brightness as number) ?? 1));
        const prevPhase = (comp.state.animPhase as number) || 0;
        const nextPhase = on ? prevPhase + dt / 1000 : prevPhase;
        let colors: string[];
        if (on && mode !== 'off') {
          colors = [];
          for (let i = 0; i < count; i++) {
            colors.push(computeNeopixelColor(mode, i, count, nextPhase, (comp.props.color as string) || '#00ffaa', brightness));
          }
        } else {
          colors = new Array(count).fill('#1e293b');
        }
        const state = { ...comp.state, animPhase: nextPhase, pixelColors: colors };
        return { ...comp, state };
      }
      case 'oledSsd1306': {
        const on = !!comp.state.on;
        const pattern = (comp.props.pattern as string) || 'bouncingBall';
        const sw = 116, sh = 42; // inner screen size, matches drawOledBody
        let ballX = (comp.state.ballX as number) ?? sw / 2;
        let ballY = (comp.state.ballY as number) ?? sh / 2;
        let vx = (comp.state.ballVX as number) ?? 46;
        let vy = (comp.state.ballVY as number) ?? 33;
        let animPhase = (comp.state.animPhase as number) || 0;
        if (on && pattern === 'bouncingBall') {
          ballX += vx * (dt / 1000);
          ballY += vy * (dt / 1000);
          if (ballX < 6 || ballX > sw - 6) { vx = -vx; ballX = Math.max(6, Math.min(sw - 6, ballX)); }
          if (ballY < 6 || ballY > sh - 6) { vy = -vy; ballY = Math.max(6, Math.min(sh - 6, ballY)); }
        }
        if (on && pattern === 'bars') {
          animPhase += dt / 300;
        }
        const state = { ...comp.state, ballX, ballY, ballVX: vx, ballVY: vy, animPhase };
        return { ...comp, state };
      }
      case 'ne555': {
        // Real time-based pulse generation - both modes advance against
        // actual elapsed ms (dt) rather than a scripted animation, so the
        // waveform genuinely reflects the Frequency/Duty Cycle/Pulse Width
        // properties (and responds live if they're changed mid-run).
        const resetActive = !!comp.state.resetActive;
        const mode = (comp.props.mode as string) || 'astable';

        if (resetActive) {
          // Active-low RESET immediately forces OUT low and clears any
          // in-progress timing, exactly like the real chip.
          const state = { ...comp.state, outHigh: false, phaseMs: 0, monoRemainingMs: 0, prevTrigLow: !!comp.state.trigLow };
          return { ...comp, state };
        }

        if (mode === 'monostable') {
          const trigLow = !!comp.state.trigLow;
          const prevTrigLow = !!comp.state.prevTrigLow;
          const pulseWidthMs = Math.max(1, (comp.props.pulseWidth as number) || 500);
          let remainingMs = (comp.state.monoRemainingMs as number) || 0;

          // Falling edge on TRIG (re)starts the one-shot, same as a real
          // 555 - including retriggering if it fires again mid-pulse.
          if (trigLow && !prevTrigLow) {
            remainingMs = pulseWidthMs;
          } else if (remainingMs > 0) {
            remainingMs = Math.max(0, remainingMs - dt);
          }

          const state = {
            ...comp.state,
            outHigh: remainingMs > 0,
            monoRemainingMs: remainingMs,
            prevTrigLow: trigLow,
          };
          return { ...comp, state };
        }

        // Astable: free-running square wave whose HIGH/LOW split each
        // period comes straight from Frequency + Duty Cycle.
        const freqHz = Math.max(0.1, (comp.props.frequency as number) || 1);
        const dutyPct = Math.max(1, Math.min(99, (comp.props.dutyCycle as number) || 50));
        const periodMs = 1000 / freqHz;
        const highMs = periodMs * (dutyPct / 100);
        const phaseMs = ((comp.state.phaseMs as number) || 0) + dt;
        const cyclePos = phaseMs % periodMs;

        const state = {
          ...comp.state,
          outHigh: cyclePos < highMs,
          phaseMs,
        };
        return { ...comp, state };
      }
      case 'pushButton': {
        const target = comp.state.pressed ? 1 : 0;
        const prev = (comp.state.buttonPos as number) || 0;
        const state = { ...comp.state, buttonPos: ease(prev, target, 70) };
        return { ...comp, state };
      }
      case 'hcSr04': {
        const trigHigh = !!comp.state.trigHigh;
        const prevTrigHigh = !!comp.state.prevTrigHigh;
        let pulsing = !!comp.state.pulsing;
        let pulseElapsedMs = (comp.state.pulseElapsedMs as number) || 0;
        let pulseDurationMs = (comp.state.pulseDurationMs as number) || 0;

        // Rising edge on Trig starts a new measurement (real sensors ignore
        // re-triggers while a measurement is already in progress).
        if (trigHigh && !prevTrigHigh && !pulsing) {
          const distanceCm = Math.max(2, Math.min(400, (comp.props.distance as number) ?? 50));
          const soundSpeedCmPerMs = 34.3; // ~343 m/s, the speed of sound
          pulseDurationMs = (2 * distanceCm) / soundSpeedCmPerMs; // real round-trip echo width
          pulseElapsedMs = 0;
          pulsing = true;
        } else if (pulsing) {
          pulseElapsedMs += dt;
          if (pulseElapsedMs >= pulseDurationMs) {
            pulsing = false;
            pulseElapsedMs = 0;
            pulseDurationMs = 0;
          }
        }

        const state = {
          ...comp.state,
          prevTrigHigh: trigHigh,
          pulsing,
          pulseElapsedMs,
          pulseDurationMs,
          echoHigh: pulsing,
        };
        return { ...comp, state };
      }
      case 'dht11': {
        // Real DHT11 timing (datasheet, all times in microseconds):
        //   - Sensor response after being addressed: 80us LOW, 80us HIGH
        //   - 40 data bits (humidity int, humidity dec, temp int, temp dec,
        //     checksum — MSB first): each bit starts with a 50us LOW, then
        //     goes HIGH for ~27us ('0') or ~70us ('1')
        //   - End of frame: 50us LOW, then the bus releases HIGH (idle)
        // The sensor also cannot be sampled faster than once per second
        // (its minimum sampling period), so a new frame is only built once
        // per second — that's the "realistic update interval" the DATA pin
        // waveform is regenerated at, always using the *current* Properties
        // panel values so edits are reflected on the very next frame.
        const SAMPLE_PERIOD_MS = 1000;
        const enabled = comp.props.enabled !== false;

        if (!enabled) {
          const state = {
            ...comp.state,
            dataHigh: true,
            transmitting: false,
            timeline: undefined,
            timelineIndex: 0,
            segmentElapsedUs: 0,
            cycleElapsedMs: 0,
          };
          return { ...comp, state };
        }

        let cycleElapsedMs = (comp.state.cycleElapsedMs as number) || 0;
        let timeline = comp.state.timeline as Array<{ durationUs: number; high: boolean }> | undefined;
        let timelineIndex = (comp.state.timelineIndex as number) || 0;
        let segmentElapsedUs = (comp.state.segmentElapsedUs as number) || 0;
        let dataHigh = comp.state.dataHigh !== false;

        cycleElapsedMs += dt;

        if (!timeline && cycleElapsedMs >= SAMPLE_PERIOD_MS) {
          // DHT11 range/precision per datasheet: 20-90% RH and 0-50°C,
          // whole-number resolution (decimal bytes are always 0).
          const humidity = Math.round(Math.max(20, Math.min(90, (comp.props.humidity as number) ?? 50)));
          const temperature = Math.round(Math.max(0, Math.min(50, (comp.props.temperature as number) ?? 25)));
          const humidityDec = 0;
          const tempDec = 0;
          const checksum = (humidity + humidityDec + temperature + tempDec) & 0xff;
          const bytes = [humidity, humidityDec, temperature, tempDec, checksum];

          const bits: number[] = [];
          for (const byte of bytes) {
            for (let i = 7; i >= 0; i--) bits.push((byte >> i) & 1);
          }

          const newTimeline: Array<{ durationUs: number; high: boolean }> = [
            { durationUs: 80, high: false }, // sensor response
            { durationUs: 80, high: true },
          ];
          for (const bit of bits) {
            newTimeline.push({ durationUs: 50, high: false }); // every bit starts LOW
            newTimeline.push({ durationUs: bit ? 70 : 27, high: true }); // '1' vs '0' width
          }
          newTimeline.push({ durationUs: 50, high: false }); // end-of-frame LOW

          timeline = newTimeline;
          timelineIndex = 0;
          segmentElapsedUs = 0;
          cycleElapsedMs = 0;
        }

        let transmitting = false;
        if (timeline) {
          transmitting = true;
          segmentElapsedUs += dt * 1000; // ms -> us

          while (timelineIndex < timeline.length && segmentElapsedUs >= timeline[timelineIndex].durationUs) {
            segmentElapsedUs -= timeline[timelineIndex].durationUs;
            timelineIndex++;
          }

          if (timelineIndex >= timeline.length) {
            // Frame finished — bus releases and idles HIGH until the next
            // sample cycle.
            dataHigh = true;
            timeline = undefined;
            timelineIndex = 0;
            segmentElapsedUs = 0;
            transmitting = false;
          } else {
            dataHigh = timeline[timelineIndex].high;
          }
        }

        const state = {
          ...comp.state,
          dataHigh,
          transmitting,
          timeline,
          timelineIndex,
          segmentElapsedUs,
          cycleElapsedMs,
        };
        return { ...comp, state };
      }
      case 'pirMotion': {
        // Real PIR modules don't snap their OUT pin instantly:
        //   - Response delay: the pyroelectric element + analog signal
        //     conditioning takes a short moment (roughly 200-300ms on
        //     common modules) to assert OUT after motion begins.
        //   - Output hold time: once triggered, OUT is held HIGH for a
        //     minimum period (commonly ~2-3s on low-cost modules) even if
        //     motion stops, before dropping back LOW — this prevents rapid
        //     re-triggering/chatter.
        const RESPONSE_DELAY_MS = 250;
        const HOLD_TIME_MS = 2500;

        const enabled = comp.props.enabled !== false;
        const motionDetected = enabled && !!comp.props.motionDetected;

        if (!enabled) {
          const state = {
            ...comp.state,
            outHigh: false,
            risingElapsedMs: 0,
            holdElapsedMs: 0,
            wasMotionDetected: false,
          };
          return { ...comp, state };
        }

        let outHigh = !!comp.state.outHigh;
        let risingElapsedMs = (comp.state.risingElapsedMs as number) || 0;
        let holdElapsedMs = (comp.state.holdElapsedMs as number) || 0;
        const wasMotionDetected = !!comp.state.wasMotionDetected;

        if (motionDetected) {
          if (!wasMotionDetected) {
            // Freshly triggered — start the response-delay countdown.
            risingElapsedMs = 0;
          }
          if (!outHigh) {
            risingElapsedMs += dt;
            if (risingElapsedMs >= RESPONSE_DELAY_MS) {
              outHigh = true;
            }
          }
          holdElapsedMs = 0; // motion still present, hold timer doesn't run
        } else {
          risingElapsedMs = 0;
          if (outHigh) {
            holdElapsedMs += dt;
            if (holdElapsedMs >= HOLD_TIME_MS) {
              outHigh = false;
              holdElapsedMs = 0;
            }
          }
        }

        const state = {
          ...comp.state,
          outHigh,
          risingElapsedMs,
          holdElapsedMs,
          wasMotionDetected: motionDetected,
        };
        return { ...comp, state };
      }
      case 'irObstacle': {
        // Common IR obstacle modules (IR LED + phototransistor feeding an
        // LM393 comparator) are active-LOW: OUT is pulled LOW when the
        // reflected IR signal indicates an obstacle inside the configured
        // range, and HIGH otherwise. The comparator itself is fast, but a
        // small debounce (~30ms) models real-world response/settling time
        // rather than an instant, unrealistic snap.
        const RESPONSE_DELAY_MS = 30;

        const enabled = comp.props.enabled !== false;
        // "Detection Distance" sets the sensor's configured sensing range;
        // "Obstacle Detected" reflects whether an object currently sits
        // within that range. Both are read fresh every frame so property
        // edits take effect immediately.
        const detectionDistance = Math.max(2, Math.min(30, (comp.props.detectionDistance as number) ?? 10));
        const obstaclePresent = enabled && !!comp.props.obstacleDetected && detectionDistance > 0;

        if (!enabled) {
          const state = {
            ...comp.state,
            outHigh: true, // no obstacle possible while disabled -> idle HIGH
            detectElapsedMs: 0,
            wasObstaclePresent: false,
          };
          return { ...comp, state };
        }

        let outHigh = comp.state.outHigh !== false; // idle HIGH (no obstacle) by default
        let detectElapsedMs = (comp.state.detectElapsedMs as number) || 0;
        const wasObstaclePresent = !!comp.state.wasObstaclePresent;

        if (obstaclePresent) {
          if (!wasObstaclePresent) {
            detectElapsedMs = 0; // freshly detected — start debounce
          }
          if (outHigh) {
            detectElapsedMs += dt;
            if (detectElapsedMs >= RESPONSE_DELAY_MS) {
              outHigh = false; // active LOW while obstacle is present
            }
          }
        } else {
          detectElapsedMs = 0;
          outHigh = true; // obstacle cleared -> OUT returns HIGH immediately
        }

        const state = {
          ...comp.state,
          outHigh,
          detectElapsedMs,
          wasObstaclePresent: obstaclePresent,
        };
        return { ...comp, state };
      }
      case 'mq2Gas': {
        // MQ-2 modules use a heated tin-dioxide sensing element whose
        // resistance drops as gas concentration rises; the module's
        // onboard op-amp converts that into an analog voltage (AO) that
        // rises with concentration, and a comparator trips a digital
        // output (DO) once AO crosses a trim-pot-set threshold. Real
        // sensing elements never sit at a perfectly flat voltage — there's
        // always a small amount of thermal/electrical noise riding on top
        // — so a slow, subtle wobble (~±1% of full scale) is layered onto
        // the analog output for realism. Both AO and DO otherwise track
        // "Gas Concentration" / "Digital Threshold" immediately, with no
        // artificial response delay, since property edits should be
        // reflected right away.
        const enabled = comp.props.enabled !== false;

        if (!enabled) {
          const state = { ...comp.state, aoVoltage: 0, doHigh: false, noiseElapsedMs: 0 };
          return { ...comp, state };
        }

        const gasConcentration = Math.max(0, Math.min(100, (comp.props.gasConcentration as number) ?? 20));
        const digitalThreshold = Math.max(0, Math.min(100, (comp.props.digitalThreshold as number) ?? 50));

        const noiseElapsedMs = ((comp.state.noiseElapsedMs as number) || 0) + dt;
        const noiseVolts = Math.sin(noiseElapsedMs / 250) * 0.05; // slow ~±0.05V analog wobble

        const baseVoltage = (gasConcentration / 100) * 5; // 0-100% -> 0-5V
        const aoVoltage = Math.max(0, Math.min(5, baseVoltage + noiseVolts));
        const doHigh = gasConcentration >= digitalThreshold;

        const state = { ...comp.state, aoVoltage, doHigh, noiseElapsedMs };
        return { ...comp, state };
      }
      case 'flameSensor': {
        // Real flame sensor modules (YG1006 IR photodiode + LM393
        // comparator) produce an analog voltage that rises with detected
        // flame intensity, and trip a digital comparator output LOW once
        // that intensity crosses a trim-pot-set threshold - active LOW,
        // same convention as this file's IR Obstacle sensor. As with the
        // MQ-2, a small amount of thermal/electrical noise is layered onto
        // the analog output for realism, and both AO/DO otherwise track
        // "Flame Intensity" / "Digital Threshold" immediately, with no
        // artificial response delay.
        const enabled = comp.props.enabled !== false;

        if (!enabled) {
          const state = { ...comp.state, aoVoltage: 0, doHigh: true, noiseElapsedMs: 0 };
          return { ...comp, state };
        }

        const flameIntensity = Math.max(0, Math.min(100, (comp.props.flameIntensity as number) ?? 0));
        const digitalThreshold = Math.max(0, Math.min(100, (comp.props.digitalThreshold as number) ?? 30));

        const noiseElapsedMs = ((comp.state.noiseElapsedMs as number) || 0) + dt;
        const noiseVolts = Math.sin(noiseElapsedMs / 250) * 0.05; // slow ~±0.05V analog wobble

        const baseVoltage = (flameIntensity / 100) * 5; // 0-100% -> 0-5V
        const aoVoltage = Math.max(0, Math.min(5, baseVoltage + noiseVolts));
        const doHigh = flameIntensity < digitalThreshold; // active LOW once a flame is detected

        const state = { ...comp.state, aoVoltage, doHigh, noiseElapsedMs };
        return { ...comp, state };
      }
      default:
        return comp;
    }
  });
}

/**
 * Compute terminal absolute positions based on component position and rotation
 */
export function computeTerminalPositions(comp: Component): Component {
  const cos_r = Math.cos(-comp.rotation * Math.PI / 2);
  const sin_r = Math.sin(-comp.rotation * Math.PI / 2);

  const updated = { ...comp, terminals: comp.terminals.map(t => ({ ...t })) };
  for (const t of updated.terminals) {
    // Rotate local offset
    const rx = t.dx * GRID_SIZE * cos_r - t.dy * GRID_SIZE * sin_r;
    const ry = t.dx * GRID_SIZE * sin_r + t.dy * GRID_SIZE * cos_r;
    t.x = comp.x * GRID_SIZE + rx;
    t.y = comp.y * GRID_SIZE + ry;
  }
  return updated;
}
