import { describe, it, expect } from 'vitest';
import {
  defaultProperties,
  defaultTerminals,
  componentNames,
  componentCategories,
} from './componentDefs';
import { simulateDC, updateComponentState } from './simulator';
import { FOOTPRINTS } from '../pcb/footprints';
import { footprintKeyFor, hasFootprintFor } from '../pcb/simulatorSync';
import { convertCircuitToPCB } from '../pcb/convertFromCircuit';
import { footprintBBox, padAbsolutePos } from '../pcb/geometry';
import type { Component, Wire } from './types';
import type { PCBComponent } from '../pcb/types';

function makeComponent(type: Component['type'], id: number, propOverrides: Record<string, number | string | boolean> = {}): Component {
  const termDefs = defaultTerminals[type] || [];
  const props: Record<string, number | string | boolean> = {};
  for (const def of defaultProperties[type] || []) props[def.key] = def.defaultValue;
  Object.assign(props, propOverrides);
  return {
    id,
    type,
    x: 0,
    y: 0,
    rotation: 0,
    props,
    label: `${type}_${id}`,
    selected: false,
    voltage: 0,
    current: 0,
    power: 0,
    terminals: termDefs.map((td, idx) => ({
      id: id * 100 + idx,
      componentId: id,
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label,
      netId: null,
    })),
    state: {},
  } as Component;
}

function wire(id: number, a: Component, aIdx: number, b: Component, bIdx: number): Wire {
  return {
    id,
    fromTerminalId: a.terminals[aIdx].id,
    toTerminalId: b.terminals[bIdx].id,
    fromCompId: a.id,
    toCompId: b.id,
    color: '#fff',
    waypoints: [],
    selected: false,
  };
}

describe('MAX485 RS-485 transceiver', () => {
  it('is registered with 8 terminals in breakout pin order', () => {
    expect(componentNames.max485).toBeTruthy();
    expect((defaultTerminals.max485 || []).map(t => t.label)).toEqual(
      ['VCC', 'GND', 'RO', 'RE', 'DE', 'DI', 'A', 'B'],
    );
  });

  it('appears in the communication palette category', () => {
    expect(componentCategories.communication).toContain('max485');
  });

  it('has real default properties: logic level, powered, bus idle high', () => {
    const keys = (defaultProperties.max485 || []).map(p => p.key);
    expect(keys).toEqual(expect.arrayContaining(['partNumber', 'logicLevel', 'powered', 'busIdleHigh']));
    const logicLevel = (defaultProperties.max485 || []).find(p => p.key === 'logicLevel');
    expect(logicLevel?.defaultValue).toBe(5);
  });

  it('has a mapped 8-pad PCB footprint (Connectors category, correct pin labels)', () => {
    expect(hasFootprintFor('max485')).toBe(true);
    const key = footprintKeyFor('max485')!;
    const fp = FOOTPRINTS[key];
    expect(fp.pads.length).toBe(8);
    expect(fp.pads.map(p => p.id).sort()).toEqual(['A', 'B', 'DE', 'DI', 'GND', 'RE', 'RO', 'VCC'].sort());
    expect(fp.category).toBe('Connectors');
  });

  it('supports Convert to PCB', () => {
    const max485 = makeComponent('max485', 1);
    const result = convertCircuitToPCB([max485], []);
    expect(result.unmapped).toEqual([]);
    expect(result.components.length).toBe(1);
    expect(FOOTPRINTS[result.components[0].footprint]).toBeTruthy();
  });

  it('supports rotation and flip like other footprints', () => {
    const key = footprintKeyFor('max485')!;
    const fp = FOOTPRINTS[key];
    expect(footprintBBox(fp.width, fp.height, 90)).toEqual({ w: fp.height, h: fp.width });
    const topComp: PCBComponent = { id: 1, footprint: key, refDes: 'U1', x: 0, y: 0, rotation: 0, side: 'top', props: {} };
    const bottomComp: PCBComponent = { ...topComp, side: 'bottom' };
    for (const p of fp.pads) {
      expect(padAbsolutePos(bottomComp, p).x).toBeCloseTo(-padAbsolutePos(topComp, p).x, 6);
    }
  });

  it('drives RO to its logic level once Powered and Bus Idle High, and 0V otherwise', () => {
    const battery = makeComponent('battery', 1, { voltage: 5 });
    const max485 = makeComponent('max485', 2, { powered: true, busIdleHigh: true, logicLevel: 5 });
    const gnd = makeComponent('ground', 3);
    const wires: Wire[] = [
      wire(1, battery, 0, max485, 0), // VCC
      wire(2, max485, 1, gnd, 0), // GND
      wire(3, battery, 1, gnd, 0),
    ];
    const result = simulateDC([battery, max485, gnd], wires);
    expect(result.converged).toBe(true);
    const updated = updateComponentState(max485, result);
    expect(updated.state.roVoltage).toBeCloseTo(5, 5);

    const idleLow = makeComponent('max485', 2, { powered: true, busIdleHigh: false });
    const result2 = simulateDC([battery, idleLow, gnd], wires);
    const updated2 = updateComponentState(idleLow, result2);
    expect(updated2.state.roVoltage).toBe(0);

    const unpowered = makeComponent('max485', 2, { powered: false });
    const result3 = simulateDC([battery, unpowered, gnd], wires);
    const updated3 = updateComponentState(unpowered, result3);
    expect(updated3.state.roVoltage).toBe(0);
  });

  it('can be wired straight into an Arduino Uno D0 (RX) pin and the link solves', () => {
    const uno = makeComponent('arduino', 1);
    const max485 = makeComponent('max485', 2, { powered: true, busIdleHigh: true });
    const gnd = makeComponent('ground', 3);
    const unoD0Idx = (defaultTerminals.arduino || []).findIndex(t => t.label === 'D0');
    const unoGndIdx = (defaultTerminals.arduino || []).findIndex(t => t.label === 'GND');
    const wires: Wire[] = [
      wire(1, max485, 2, uno, unoD0Idx), // MAX485 RO -> Arduino D0 (RX)
      wire(2, max485, 1, gnd, 0), // MAX485 GND -> GND
      wire(3, uno, unoGndIdx, gnd, 0),
    ];
    const result = simulateDC([uno, max485, gnd], wires);
    expect(result.converged).toBe(true);
  });
});

describe('CAN Bus Module (MCP2515+TJA1050)', () => {
  it('is registered with 7 terminals in standard SPI breakout pin order', () => {
    expect(componentNames.canBusModule).toBeTruthy();
    expect((defaultTerminals.canBusModule || []).map(t => t.label)).toEqual(
      ['VCC', 'GND', 'CS', 'SO', 'SI', 'SCK', 'INT'],
    );
  });

  it('appears in the communication palette category', () => {
    expect(componentCategories.communication).toContain('canBusModule');
  });

  it('has real default properties: bit rate, powered, message pending', () => {
    const keys = (defaultProperties.canBusModule || []).map(p => p.key);
    expect(keys).toEqual(expect.arrayContaining(['partNumber', 'bitRate', 'logicLevel', 'powered', 'messagePending']));
    const bitRate = (defaultProperties.canBusModule || []).find(p => p.key === 'bitRate');
    expect(bitRate?.defaultValue).toBe('500kbps');
  });

  it('has a mapped 7-pad PCB footprint (Connectors category, correct SPI pin labels)', () => {
    expect(hasFootprintFor('canBusModule')).toBe(true);
    const key = footprintKeyFor('canBusModule')!;
    const fp = FOOTPRINTS[key];
    expect(fp.pads.length).toBe(7);
    expect(fp.pads.map(p => p.id).sort()).toEqual(['CS', 'GND', 'INT', 'SCK', 'SI', 'SO', 'VCC'].sort());
    expect(fp.category).toBe('Connectors');
  });

  it('supports Convert to PCB', () => {
    const can = makeComponent('canBusModule', 1);
    const result = convertCircuitToPCB([can], []);
    expect(result.unmapped).toEqual([]);
    expect(FOOTPRINTS[result.components[0].footprint]).toBeTruthy();
  });

  it('supports rotation and flip like other footprints', () => {
    const key = footprintKeyFor('canBusModule')!;
    const fp = FOOTPRINTS[key];
    expect(footprintBBox(fp.width, fp.height, 90)).toEqual({ w: fp.height, h: fp.width });
    const topComp: PCBComponent = { id: 1, footprint: key, refDes: 'U1', x: 0, y: 0, rotation: 0, side: 'top', props: {} };
    const bottomComp: PCBComponent = { ...topComp, side: 'bottom' };
    for (const p of fp.pads) {
      expect(padAbsolutePos(bottomComp, p).x).toBeCloseTo(-padAbsolutePos(topComp, p).x, 6);
    }
  });

  it('idles INT high (module logic level) once Powered with no message pending', () => {
    const battery = makeComponent('battery', 1, { voltage: 5 });
    const can = makeComponent('canBusModule', 2, { powered: true, messagePending: false, logicLevel: 5 });
    const gnd = makeComponent('ground', 3);
    const wires: Wire[] = [
      wire(1, battery, 0, can, 0), // VCC
      wire(2, can, 1, gnd, 0), // GND
      wire(3, battery, 1, gnd, 0),
    ];
    const result = simulateDC([battery, can, gnd], wires);
    expect(result.converged).toBe(true);
    const updated = updateComponentState(can, result);
    expect(updated.state.intVoltage).toBeCloseTo(5, 5);
    expect(updated.state.intActive).toBe(false);
  });

  it('pulls INT low (active) once a message is pending, and reports 0V once unpowered', () => {
    const battery = makeComponent('battery', 1, { voltage: 5 });
    const can = makeComponent('canBusModule', 2, { powered: true, messagePending: true });
    const gnd = makeComponent('ground', 3);
    const wires: Wire[] = [wire(1, battery, 0, can, 0), wire(2, can, 1, gnd, 0), wire(3, battery, 1, gnd, 0)];
    const result = simulateDC([battery, can, gnd], wires);
    const updated = updateComponentState(can, result);
    expect(updated.state.intVoltage).toBe(0);
    expect(updated.state.intActive).toBe(true);

    const unpowered = makeComponent('canBusModule', 2, { powered: false });
    const result2 = simulateDC([battery, unpowered, gnd], wires);
    const updated2 = updateComponentState(unpowered, result2);
    expect(updated2.state.intVoltage).toBe(0);
  });

  it('can be wired straight into an Arduino Uno D2 (interrupt) pin and the link solves', () => {
    const uno = makeComponent('arduino', 1);
    const can = makeComponent('canBusModule', 2, { powered: true, messagePending: false });
    const gnd = makeComponent('ground', 3);
    const unoD2Idx = (defaultTerminals.arduino || []).findIndex(t => t.label === 'D2');
    const unoGndIdx = (defaultTerminals.arduino || []).findIndex(t => t.label === 'GND');
    const wires: Wire[] = [
      wire(1, can, 6, uno, unoD2Idx), // CAN module INT -> Arduino D2
      wire(2, can, 1, gnd, 0), // CAN module GND -> GND
      wire(3, uno, unoGndIdx, gnd, 0),
    ];
    const result = simulateDC([uno, can, gnd], wires);
    expect(result.converged).toBe(true);
  });
});

describe('I2C Header (passive 4-pin VCC/GND/SDA/SCL breakout)', () => {
  it('is registered with 4 terminals in standard I2C bus order', () => {
    expect(componentNames.i2cHeader).toBeTruthy();
    expect((defaultTerminals.i2cHeader || []).map(t => t.label)).toEqual(['VCC', 'GND', 'SDA', 'SCL']);
  });

  it('appears in a palette category so it shows up in the Circuit Simulator palette', () => {
    const allListed = Object.values(componentCategories).flat();
    expect(allListed).toContain('i2cHeader');
  });

  it('has no electrical properties of its own (a bare header, like uartHeader)', () => {
    expect(defaultProperties.i2cHeader || []).toEqual([]);
  });

  it('has a mapped 4-pad PCB footprint (Connectors category, correct pin labels)', () => {
    expect(hasFootprintFor('i2cHeader')).toBe(true);
    const key = footprintKeyFor('i2cHeader')!;
    const fp = FOOTPRINTS[key];
    expect(fp.pads.length).toBe(4);
    expect(fp.pads.map(p => p.id).sort()).toEqual(['GND', 'SCL', 'SDA', 'VCC'].sort());
    expect(fp.category).toBe('Connectors');
  });

  it('supports Convert to PCB', () => {
    const hdr = makeComponent('i2cHeader', 1);
    const result = convertCircuitToPCB([hdr], []);
    expect(result.unmapped).toEqual([]);
    expect(FOOTPRINTS[result.components[0].footprint]).toBeTruthy();
  });

  it('supports rotation and flip like other footprints', () => {
    const key = footprintKeyFor('i2cHeader')!;
    const fp = FOOTPRINTS[key];
    expect(footprintBBox(fp.width, fp.height, 90)).toEqual({ w: fp.height, h: fp.width });
    const topComp: PCBComponent = { id: 1, footprint: key, refDes: 'J1', x: 0, y: 0, rotation: 0, side: 'top', props: {} };
    const bottomComp: PCBComponent = { ...topComp, side: 'bottom' };
    for (const p of fp.pads) {
      expect(padAbsolutePos(bottomComp, p).x).toBeCloseTo(-padAbsolutePos(topComp, p).x, 6);
    }
  });

  it('electrical behavior: SDA/SCL solve correctly once externally wired to another component', () => {
    const hdr = makeComponent('i2cHeader', 1);
    const resistor = makeComponent('resistor', 2);
    const gnd = makeComponent('ground', 3);
    const battery = makeComponent('battery', 4, { voltage: 5 });
    const wires: Wire[] = [
      wire(1, battery, 0, hdr, 0), // VCC -> header VCC
      wire(2, hdr, 1, gnd, 0), // header GND -> GND
      wire(3, battery, 1, gnd, 0),
      wire(4, hdr, 2, resistor, 0), // header SDA -> resistor
      wire(5, hdr, 3, resistor, 1), // header SCL -> resistor other leg
    ];
    const result = simulateDC([battery, hdr, resistor, gnd], wires);
    expect(result.converged).toBe(true);
  });

  it('can be wired straight into an Arduino Uno A4/A5 (SDA/SCL) pins and the link solves', () => {
    const uno = makeComponent('arduino', 1);
    const hdr = makeComponent('i2cHeader', 2);
    const gnd = makeComponent('ground', 3);
    const unoA4Idx = (defaultTerminals.arduino || []).findIndex(t => t.label === 'A4');
    const unoA5Idx = (defaultTerminals.arduino || []).findIndex(t => t.label === 'A5');
    const unoGndIdx = (defaultTerminals.arduino || []).findIndex(t => t.label === 'GND');
    const wires: Wire[] = [
      wire(1, hdr, 2, uno, unoA4Idx), // SDA -> A4
      wire(2, hdr, 3, uno, unoA5Idx), // SCL -> A5
      wire(3, hdr, 1, gnd, 0),
      wire(4, uno, unoGndIdx, gnd, 0),
    ];
    const result = simulateDC([uno, hdr, gnd], wires);
    expect(result.converged).toBe(true);
  });
});
