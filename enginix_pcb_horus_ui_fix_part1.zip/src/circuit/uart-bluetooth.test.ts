import { describe, it, expect } from 'vitest';
import {
  defaultProperties,
  defaultTerminals,
  componentNames,
  componentCategories,
} from './componentDefs';
import { simulateDC, updateComponentState } from './simulator';
import { FOOTPRINTS } from '../pcb/footprints';
import { footprintKeyFor, hasFootprintFor } from '../pcb/simulatorSync';
import { convertCircuitToPCB } from '../pcb/convertFromCircuit';
import { footprintBBox, padAbsolutePos } from '../pcb/geometry';
import type { Component, Wire } from './types';
import type { PCBComponent } from '../pcb/types';

const BT_TYPES = ['hc05', 'hc06'] as const;

function makeComponent(type: Component['type'], id: number, propOverrides: Record<string, number | string | boolean> = {}): Component {
  const termDefs = defaultTerminals[type] || [];
  const props: Record<string, number | string | boolean> = {};
  for (const def of defaultProperties[type] || []) props[def.key] = def.defaultValue;
  Object.assign(props, propOverrides);
  return {
    id,
    type,
    x: 0,
    y: 0,
    rotation: 0,
    props,
    label: `${type}_${id}`,
    selected: false,
    voltage: 0,
    current: 0,
    power: 0,
    terminals: termDefs.map((td, idx) => ({
      id: id * 100 + idx,
      componentId: id,
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label,
      netId: null,
    })),
    state: {},
  } as Component;
}

function wire(id: number, a: Component, aIdx: number, b: Component, bIdx: number): Wire {
  return {
    id,
    fromTerminalId: a.terminals[aIdx].id,
    toTerminalId: b.terminals[bIdx].id,
    fromCompId: a.id,
    toCompId: b.id,
    color: '#fff',
    waypoints: [],
    selected: false,
  };
}

/** Power a HC-05/HC-06 module (VCC=idx0 <- Vcc rail, GND=idx4 -> GND)
 * from a battery, and solve. Terminal order is fixed: VCC, TXD, RXD,
 * STATE, GND, EN (see defaultTerminals.hc05/hc06 in componentDefs.ts). */
function solveBtModule(
  type: (typeof BT_TYPES)[number],
  propOverrides: Record<string, number | string | boolean> = {},
) {
  const vccSrc = makeComponent('battery', 1, { voltage: 5 });
  const bt = makeComponent(type, 2, propOverrides);
  const gnd = makeComponent('ground', 3);

  const wires: Wire[] = [
    wire(1, vccSrc, 0, bt, 0), // Vcc(+) -> VCC (idx 0)
    wire(2, bt, 4, gnd, 0), // GND (idx 4) -> GND
    wire(3, vccSrc, 1, gnd, 0),
  ];

  const components = [vccSrc, bt, gnd];
  const result = simulateDC(components, wires);
  return { result, bt, components, wires };
}

describe('UART Header', () => {
  it('is a registered, purely passive 4-pin connector (VCC/GND/TXD/RXD)', () => {
    expect(componentNames.uartHeader).toBeTruthy();
    expect((defaultTerminals.uartHeader || []).map(t => t.label)).toEqual(['VCC', 'GND', 'TXD', 'RXD']);
    expect(defaultProperties.uartHeader).toEqual([]);
  });

  it('appears in the palette and has a mapped 4-pad PCB footprint', () => {
    expect(componentCategories.other).toContain('uartHeader');
    expect(hasFootprintFor('uartHeader')).toBe(true);
    const key = footprintKeyFor('uartHeader')!;
    const fp = FOOTPRINTS[key];
    expect(fp.pads.length).toBe(4);
    expect(fp.pads.map(p => p.id).sort()).toEqual(['GND', 'RXD', 'TXD', 'VCC']);
    expect(fp.category).toBe('Connectors');
  });

  it('supports Convert to PCB', () => {
    const hdr = makeComponent('uartHeader', 1);
    const result = convertCircuitToPCB([hdr], []);
    expect(result.unmapped).toEqual([]);
    expect(result.components.length).toBe(1);
    expect(FOOTPRINTS[result.components[0].footprint]).toBeTruthy();
  });
});

describe('HC-05 / HC-06 UART Bluetooth modules', () => {
  it('are registered placeable component types with 6 terminals (VCC/TXD/RXD/STATE/GND/EN)', () => {
    for (const type of BT_TYPES) {
      expect(componentNames[type]).toBeTruthy();
      expect((defaultTerminals[type] || []).length).toBe(6);
      expect((defaultTerminals[type] || []).map(t => t.label)).toEqual(['VCC', 'TXD', 'RXD', 'STATE', 'GND', 'EN']);
    }
  });

  it('appear in a dedicated communication palette category', () => {
    for (const type of BT_TYPES) {
      expect(componentCategories.communication).toContain(type);
    }
  });

  it('are electrically/physically distinct from each other (different footprint keys not required, but real hardware difference in properties)', () => {
    // HC-05 supports Master/Slave role; HC-06 is Slave-only and has no
    // Role property at all - the actual hardware/firmware difference.
    const hc05Keys = (defaultProperties.hc05 || []).map(p => p.key);
    const hc06Keys = (defaultProperties.hc06 || []).map(p => p.key);
    expect(hc05Keys).toContain('role');
    expect(hc06Keys).not.toContain('role');
  });

  it('has real default properties: baud rate, logic level, powered, connected', () => {
    for (const type of BT_TYPES) {
      const keys = (defaultProperties[type] || []).map(p => p.key);
      expect(keys).toEqual(
        expect.arrayContaining(['partNumber', 'baudRate', 'logicLevel', 'powered', 'connected']),
      );
    }
  });

  it('has a mapped 6-pad PCB footprint (Connectors category, correct pin labels)', () => {
    for (const type of BT_TYPES) {
      expect(hasFootprintFor(type)).toBe(true);
      const key = footprintKeyFor(type)!;
      const fp = FOOTPRINTS[key];
      expect(fp.pads.length).toBe(6);
      expect(fp.pads.map(p => p.id).sort()).toEqual(['EN', 'GND', 'RXD', 'STATE', 'TXD', 'VCC']);
      expect(fp.category).toBe('Connectors');
    }
  });

  it('supports Convert to PCB (produces a placed footprint, not left unmapped)', () => {
    const hc05 = makeComponent('hc05', 1);
    const hc06 = makeComponent('hc06', 2);
    const result = convertCircuitToPCB([hc05, hc06], []);
    expect(result.unmapped).toEqual([]);
    expect(result.components.length).toBe(2);
    for (const c of result.components) expect(FOOTPRINTS[c.footprint]).toBeTruthy();
  });

  it('supports rotation: PCB footprint bounding box swaps width/height at 90°/270°', () => {
    const key = footprintKeyFor('hc05')!;
    const fp = FOOTPRINTS[key];
    expect(footprintBBox(fp.width, fp.height, 0)).toEqual({ w: fp.width, h: fp.height });
    expect(footprintBBox(fp.width, fp.height, 90)).toEqual({ w: fp.height, h: fp.width });
    expect(footprintBBox(fp.width, fp.height, 180)).toEqual({ w: fp.width, h: fp.height });
    expect(footprintBBox(fp.width, fp.height, 270)).toEqual({ w: fp.height, h: fp.width });
  });

  it('supports flip: pad positions mirror on X when placed on the bottom side', () => {
    const key = footprintKeyFor('hc06')!;
    const fp = FOOTPRINTS[key];
    const topComp: PCBComponent = { id: 1, footprint: key, refDes: 'U1', x: 0, y: 0, rotation: 0, side: 'top', props: {} };
    const bottomComp: PCBComponent = { ...topComp, side: 'bottom' };
    for (const p of fp.pads) {
      const topPos = padAbsolutePos(topComp, p);
      const bottomPos = padAbsolutePos(bottomComp, p);
      expect(bottomPos.x).toBeCloseTo(-topPos.x, 6);
      expect(bottomPos.y).toBeCloseTo(topPos.y, 6);
    }
  });

  for (const type of BT_TYPES) {
    describe(type, () => {
      it('drives TXD to its Logic Level (idle-high UART line) once Powered', () => {
        const { result, bt } = solveBtModule(type, { powered: true, logicLevel: 3.3 });
        expect(result.converged).toBe(true);
        const updated = updateComponentState(bt, result);
        expect(updated.state.txdVoltage).toBeCloseTo(3.3, 5);
        const txdNet = bt.terminals[1].netId;
        const gndNet = bt.terminals[4].netId;
        const txdV = txdNet !== null ? (result.nodeVoltages.get(txdNet) || 0) : 0;
        const gndV = gndNet !== null ? (result.nodeVoltages.get(gndNet) || 0) : 0;
        expect(txdV - gndV).toBeCloseTo(3.3, 5);
      });

      it('drops TXD to 0V once Powered is turned off (module unpowered = no idle line)', () => {
        const { result, bt } = solveBtModule(type, { powered: false });
        expect(result.converged).toBe(true);
        const updated = updateComponentState(bt, result);
        expect(updated.state.txdVoltage).toBe(0);
      });

      it('drives STATE high once Connected (Paired), reflecting a real link', () => {
        const { result, bt } = solveBtModule(type, { powered: true, connected: true, logicLevel: 3.3 });
        expect(result.converged).toBe(true);
        const updated = updateComponentState(bt, result);
        expect(updated.state.stateHigh).toBe(true);
        const stateNet = bt.terminals[3].netId;
        const gndNet = bt.terminals[4].netId;
        const stateV = stateNet !== null ? (result.nodeVoltages.get(stateNet) || 0) : 0;
        const gndV = gndNet !== null ? (result.nodeVoltages.get(gndNet) || 0) : 0;
        expect(stateV - gndV).toBeCloseTo(3.3, 5);
      });

      it('keeps STATE low while not Connected, even if Powered', () => {
        const { result, bt } = solveBtModule(type, { powered: true, connected: false });
        expect(result.converged).toBe(true);
        const updated = updateComponentState(bt, result);
        expect(updated.state.stateHigh).toBe(false);
      });

      it('supports non-default UART baud rates as a real, storable property (not hardcoded)', () => {
        const bt = makeComponent(type, 1, { baudRate: '115200' });
        expect(bt.props.baudRate).toBe('115200');
      });
    });
  }
});

describe('UART/Bluetooth Arduino compatibility', () => {
  it('Arduino Uno/Nano/Mega each expose D0 (RX) and D1 (TX) pins to wire an HC-05/HC-06/UART header to', () => {
    for (const board of ['arduino', 'arduinoNano', 'arduinoMega'] as const) {
      const labels = (defaultTerminals[board] || []).map(t => t.label);
      expect(labels).toContain('D0');
      expect(labels).toContain('D1');
    }
  });

  it('an HC-05 TXD can be wired straight into an Arduino Uno D0 (RX) pin and the link solves', () => {
    const uno = makeComponent('arduino', 1);
    const hc05 = makeComponent('hc05', 2, { powered: true, logicLevel: 5 });
    const gnd = makeComponent('ground', 3);
    const unoD0Idx = (defaultTerminals.arduino || []).findIndex(t => t.label === 'D0');
    const unoGndIdx = (defaultTerminals.arduino || []).findIndex(t => t.label === 'GND');
    expect(unoD0Idx).toBeGreaterThanOrEqual(0);
    expect(unoGndIdx).toBeGreaterThanOrEqual(0);

    const wires: Wire[] = [
      wire(1, hc05, 1, uno, unoD0Idx), // HC-05 TXD -> Arduino D0 (RX)
      wire(2, hc05, 4, gnd, 0), // HC-05 GND -> GND
      wire(3, uno, unoGndIdx, gnd, 0), // Arduino GND -> GND
    ];
    const components = [uno, hc05, gnd];
    const result = simulateDC(components, wires);
    expect(result.converged).toBe(true);
  });
});
