/**
 * Property Panel - Edit properties of selected components (and, when a
 * wire is selected instead, its color / net label / routing)
 */

import React from 'react';
import type { Component, Wire } from './types';
import { defaultProperties, componentNames, WIRE_COLORS } from './componentDefs';

const NET_LABEL_PRESETS = ['VCC', 'GND', 'SIGNAL'];

interface PropertyPanelProps {
  selectedComponents: Component[];
  selectedWires?: Wire[];
  onUpdateProperty: (compId: number, key: string, value: number | string | boolean) => void;
  onRename?: (compId: number, label: string) => void;
  onToggleSwitch: (compId: number) => void;
  onDelete: () => void;
  onRotate: () => void;
  onDuplicate: () => void;
  onSetWireColor?: (color: string) => void;
  onSetWireNetLabel?: (label: string) => void;
  onCleanWireRouting?: () => void;
}

export const PropertyPanel: React.FC<PropertyPanelProps> = ({
  selectedComponents,
  selectedWires = [],
  onUpdateProperty,
  onRename,
  onToggleSwitch,
  onDelete,
  onRotate,
  onDuplicate,
  onSetWireColor,
  onSetWireNetLabel,
  onCleanWireRouting,
}) => {
  if (selectedComponents.length === 0 && selectedWires.length > 0) {
    return (
      <WirePanel
        wires={selectedWires}
        onDelete={onDelete}
        onSetWireColor={onSetWireColor}
        onSetWireNetLabel={onSetWireNetLabel}
        onCleanWireRouting={onCleanWireRouting}
      />
    );
  }

  if (selectedComponents.length === 0) {
    return (
      <div className="p-4 text-center">
        <p className="text-xs text-slate-500 font-mono">
          Select a component to edit its properties
        </p>
        <div className="mt-4 space-y-2">
          <p className="text-[10px] text-slate-600 font-mono uppercase tracking-wider">Quick Actions</p>
          <div className="grid grid-cols-2 gap-1.5">
            <button onClick={onDelete} className="px-2 py-1.5 text-[10px] bg-red-500/10 text-red-400 border border-red-500/20 rounded hover:bg-red-500/20 transition-colors font-mono">
              Delete
            </button>
            <button onClick={onRotate} className="px-2 py-1.5 text-[10px] bg-slate-800 text-slate-300 border border-slate-700 rounded hover:bg-slate-700 transition-colors font-mono">
              Rotate
            </button>
          </div>
        </div>
      </div>
    );
  }

  const comp = selectedComponents[0];
  const isMultiSelect = selectedComponents.length > 1;
  const propDefs = defaultProperties[comp.type] || [];

  return (
    <div className="p-3">
      {/* Header */}
      <div className="mb-3 pb-2 border-b border-slate-700/50">
        <h3 className="text-xs font-semibold text-amber-400 font-mono uppercase tracking-wider">
          {isMultiSelect ? `${selectedComponents.length} Components` : componentNames[comp.type]}
        </h3>
        {!isMultiSelect && (
          <LabelField
            key={comp.id}
            value={comp.label}
            onCommit={(val) => onRename?.(comp.id, val)}
          />
        )}
      </div>

      {/* Actions */}
      <div className="grid grid-cols-3 gap-1.5 mb-4">
        <button
          onClick={onRotate}
          className="px-2 py-1.5 text-[10px] bg-slate-800 text-slate-300 border border-slate-700 rounded hover:bg-slate-700 transition-colors font-mono"
        >
          ↻ Rotate
        </button>
        <button
          onClick={onDuplicate}
          className="px-2 py-1.5 text-[10px] bg-slate-800 text-slate-300 border border-slate-700 rounded hover:bg-slate-700 transition-colors font-mono"
        >
          ⧉ Duplicate
        </button>
        <button
          onClick={onDelete}
          className="px-2 py-1.5 text-[10px] bg-red-500/10 text-red-400 border border-red-500/20 rounded hover:bg-red-500/20 transition-colors font-mono"
        >
          ✕ Delete
        </button>
      </div>

      {/* Switch/Interactive toggle */}
      {(comp.type === 'switch' || comp.type === 'pushButton') && !isMultiSelect && (
        <div className="mb-3">
          <button
            onClick={() => onToggleSwitch(comp.id)}
            className={`w-full px-3 py-2 rounded text-xs font-mono font-medium transition-all ${
              comp.type === 'switch'
                ? comp.props.closed
                  ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
                : comp.state.pressed
                  ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
            }`}
          >
            {comp.type === 'switch'
              ? comp.props.closed ? '● Switch: CLOSED' : '○ Switch: OPEN'
              : comp.state.pressed ? '● Button: PRESSED' : '○ Button: RELEASED'}
          </button>
        </div>
      )}

      {/* Properties */}
      {!isMultiSelect && propDefs.length > 0 && (
        <div className="space-y-2.5">
          <p className="text-[10px] text-slate-500 font-mono uppercase tracking-wider">Properties</p>
          {propDefs.map((def) => (
            <PropertyField
              key={def.key}
              def={def}
              value={comp.props[def.key]}
              onChange={(val) => onUpdateProperty(comp.id, def.key, val)}
            />
          ))}
        </div>
      )}

      {/* Simulation readout */}
      {!isMultiSelect && (
        <div className="mt-4 pt-3 border-t border-slate-700/50">
          <p className="text-[10px] text-slate-500 font-mono uppercase tracking-wider mb-2">Readings</p>
          <div className="space-y-1">
            <ReadoutRow label="Voltage" value={`${Math.abs(comp.voltage).toFixed(3)} V`} />
            <ReadoutRow
              label="Current"
              value={Math.abs(comp.current) >= 0.001
                ? `${Math.abs(comp.current).toFixed(4)} A`
                : `${(Math.abs(comp.current) * 1000).toFixed(3)} mA`
              }
            />
            <ReadoutRow
              label="Power"
              value={Math.abs(comp.power) >= 0.001
                ? `${Math.abs(comp.power).toFixed(4)} W`
                : `${(Math.abs(comp.power) * 1000).toFixed(3)} mW`
              }
            />
            {comp.state.brightness !== undefined && (
              <ReadoutRow label="Brightness" value={`${((comp.state.brightness as number) * 100).toFixed(0)}%`} />
            )}
            {comp.state.rpm !== undefined && (
              <ReadoutRow label="Speed" value={`${Math.round(comp.state.rpm as number)} rpm`} />
            )}
            {comp.type === 'waterPump' && comp.state.speedRatio !== undefined && (
              <ReadoutRow
                label="Flow"
                value={`${(Math.min(1, (comp.state.speedRatio as number) || 0) * ((comp.props.flowRate as number) || 0)).toFixed(1)} L/min`}
              />
            )}
            {(comp.state.burned as boolean) && (
              <div className="text-[10px] text-red-400 font-mono bg-red-500/10 px-2 py-1 rounded mt-1">
                ⚠ COMPONENT BURNED OUT
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const LabelField: React.FC<{
  value: string;
  onCommit: (value: string) => void;
}> = ({ value, onCommit }) => {
  const [text, setText] = React.useState(value);

  React.useEffect(() => {
    setText(value);
  }, [value]);

  const commit = () => {
    if (text.trim() && text !== value) onCommit(text.trim());
    else setText(value);
  };

  return (
    <input
      type="text"
      value={text}
      onChange={(e) => setText(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }}
      placeholder="Label…"
      className="w-full mt-0.5 bg-transparent border border-transparent hover:border-slate-700 focus:border-amber-500/50 rounded px-1 -mx-1 py-0.5 text-[10px] text-slate-400 font-mono focus:outline-none focus:bg-slate-800 focus:text-slate-200 transition-colors"
    />
  );
};

const PropertyField: React.FC<{
  def: typeof defaultProperties[string][0];
  value: number | string | boolean;
  onChange: (val: number | string | boolean) => void;
}> = ({ def, value, onChange }) => {
  const label = (
    <label className="block text-[10px] text-amber-400/80 font-mono uppercase tracking-wider mb-1">
      {def.name} {def.unit && <span className="text-slate-500">({def.unit})</span>}
    </label>
  );

  if (def.type === 'boolean') {
    return (
      <div>
        <button
          onClick={() => onChange(!value)}
          className={`w-full px-2 py-1.5 rounded text-[10px] font-mono transition-all ${
            value
              ? 'bg-green-500/15 text-green-400 border border-green-500/30'
              : 'bg-slate-800 text-slate-400 border border-slate-700'
          }`}
        >
          {value ? '● ON' : '○ OFF'}
        </button>
      </div>
    );
  }

  if (def.type === 'select' && def.options) {
    return (
      <div>
        {label}
        <select
          value={String(value)}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-[11px] text-slate-200 font-mono focus:border-amber-500/50 focus:outline-none"
        >
          {def.options.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>
    );
  }

  if (def.type === 'presetNumber' && def.presets) {
    const numValue = Number(value);
    const isPreset = def.presets.includes(numValue);
    return (
      <div>
        {label}
        <select
          value={isPreset ? String(numValue) : 'custom'}
          onChange={(e) => {
            if (e.target.value !== 'custom') onChange(parseFloat(e.target.value));
          }}
          className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-[11px] text-slate-200 font-mono focus:border-amber-500/50 focus:outline-none"
        >
          {def.presets.map((p) => (
            <option key={p} value={p}>{p} {def.unit}</option>
          ))}
          <option value="custom">Custom…</option>
        </select>
        {!isPreset && (
          <input
            type="number"
            value={numValue}
            min={def.min}
            max={def.max}
            step={def.step || 'any'}
            onChange={(e) => onChange(parseFloat(e.target.value))}
            placeholder={`Custom ${def.unit || ''}`}
            className="w-full mt-1 bg-slate-800 border border-slate-700 rounded px-2 py-1 text-[11px] text-slate-200 font-mono focus:border-amber-500/50 focus:outline-none"
          />
        )}
      </div>
    );
  }

  if (def.type === 'string') {
    return (
      <div>
        {label}
        <input
          type="text"
          value={String(value ?? '')}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-[11px] text-slate-200 font-mono focus:border-amber-500/50 focus:outline-none"
        />
      </div>
    );
  }

  return (
    <div>
      {label}
      <input
        type="number"
        value={Number(value)}
        min={def.min}
        max={def.max}
        step={def.step || 'any'}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-[11px] text-slate-200 font-mono focus:border-amber-500/50 focus:outline-none"
      />
    </div>
  );
};

const ReadoutRow: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="flex justify-between items-center text-[10px] font-mono">
    <span className="text-slate-500">{label}</span>
    <span className="text-slate-300">{value}</span>
  </div>
);

const WirePanel: React.FC<{
  wires: Wire[];
  onDelete: () => void;
  onSetWireColor?: (color: string) => void;
  onSetWireNetLabel?: (label: string) => void;
  onCleanWireRouting?: () => void;
}> = ({ wires, onDelete, onSetWireColor, onSetWireNetLabel, onCleanWireRouting }) => {
  const isMulti = wires.length > 1;
  const first = wires[0];
  // Only show a field's current value when every selected wire agrees -
  // otherwise leave it blank rather than implying a value that isn't true
  // for the whole selection.
  const commonColor = wires.every(w => w.color === first.color) ? first.color : '';
  const commonLabel = wires.every(w => (w.netLabel || '') === (first.netLabel || '')) ? (first.netLabel || '') : '';
  const [labelInput, setLabelInput] = React.useState(commonLabel);

  React.useEffect(() => {
    setLabelInput(commonLabel);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wires.map(w => w.id).join(','), commonLabel]);

  const commitLabel = () => onSetWireNetLabel?.(labelInput);

  return (
    <div className="p-3">
      <div className="mb-3 pb-2 border-b border-slate-700/50">
        <h3 className="text-xs font-semibold text-amber-400 font-mono uppercase tracking-wider">
          {isMulti ? `${wires.length} Wires` : 'Wire'}
        </h3>
      </div>

      <div className="grid grid-cols-2 gap-1.5 mb-4">
        <button
          onClick={onDelete}
          className="px-2 py-1.5 text-[10px] bg-red-500/10 text-red-400 border border-red-500/20 rounded hover:bg-red-500/20 transition-colors font-mono"
        >
          ✕ Delete
        </button>
        <button
          onClick={onCleanWireRouting}
          className="px-2 py-1.5 text-[10px] bg-slate-800 text-slate-300 border border-slate-700 rounded hover:bg-slate-700 transition-colors font-mono"
          title="Remove pointless bends left over from manual dragging"
        >
          ⟲ Clean Routing
        </button>
      </div>

      {/* Color */}
      <div className="mb-4">
        <label className="block text-[10px] text-amber-400/80 font-mono uppercase tracking-wider mb-1.5">
          Wire Color
        </label>
        <div className="grid grid-cols-6 gap-1.5 mb-2">
          {WIRE_COLORS.map((color) => (
            <button
              key={color}
              onClick={() => onSetWireColor?.(color)}
              title={color}
              className={`aspect-square rounded border-2 transition-transform hover:scale-110 ${
                commonColor === color ? 'border-white' : 'border-slate-700'
              }`}
              style={{ backgroundColor: color }}
            />
          ))}
        </div>
        <input
          type="color"
          value={commonColor || '#94a3b8'}
          onChange={(e) => onSetWireColor?.(e.target.value)}
          className="w-full h-7 bg-slate-800 border border-slate-700 rounded cursor-pointer"
        />
      </div>

      {/* Net label */}
      <div>
        <label className="block text-[10px] text-amber-400/80 font-mono uppercase tracking-wider mb-1.5">
          Net Label
        </label>
        <div className="flex flex-wrap gap-1.5 mb-1.5">
          {NET_LABEL_PRESETS.map((preset) => (
            <button
              key={preset}
              onClick={() => { setLabelInput(preset); onSetWireNetLabel?.(preset); }}
              className={`px-2 py-1 text-[10px] font-mono rounded border transition-colors ${
                commonLabel.toUpperCase() === preset
                  ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              {preset}
            </button>
          ))}
        </div>
        <input
          type="text"
          value={labelInput}
          onChange={(e) => setLabelInput(e.target.value)}
          onBlur={commitLabel}
          onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }}
          placeholder="Custom label…"
          className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-[11px] text-slate-200 font-mono focus:border-amber-500/50 focus:outline-none"
        />
        <p className="text-[9px] text-slate-500 font-mono mt-1.5 leading-snug">
          Wires with the same label are joined into one net, even without a
          physical connection.
        </p>
      </div>
    </div>
  );
};

export default PropertyPanel;
