/**
 * Component Definitions
 * Defines metadata, properties, terminals, and rendering for all component types
 */

import type { ComponentType, PropertyDef, Component } from './types';

// Grid size in pixels
export const GRID_SIZE = 20;
export const TERMINAL_RADIUS = 5;

// Color palette
export const COLORS = {
  background: '#0f1729',
  gridLine: 'rgba(148, 163, 184, 0.12)',
  gridDot: 'rgba(148, 163, 184, 0.18)',
  componentStroke: '#e2e8f0',
  componentFill: '#1e293b',
  selectedStroke: '#f59e0b',
  selectedFill: 'rgba(245, 158, 11, 0.12)',
  hoveredStroke: '#38bdf8',
  terminalFill: '#f59e0b',
  terminalStroke: '#d97706',
  wireDefault: '#94a3b8',
  wireSelected: '#f59e0b',
  wireHover: '#38bdf8',
  text: '#e2e8f0',
  textDim: '#64748b',
  highlight: '#f59e0b',
  danger: '#ef4444',
  success: '#22c55e',
  ledGlow: '#ff4444',
  // Component-specific colors
  battery: '#d97706',
  resistor: '#d4a574',
  capacitor: '#60a5fa',
  inductor: '#a78bfa',
  diode: '#f87171',
  led: '#ef4444',
  ground: '#22c55e',
  logicHigh: '#22c55e',
  logicLow: '#ef4444',
  arduino: '#00979c',
};

export const WIRE_COLORS = [
  '#94a3b8', '#ef4444', '#f59e0b', '#22c55e',
  '#3b82f6', '#a855f7', '#ec4899', '#14b8a6',
  '#f97316', '#8b5cf6', '#06b6d4', '#84cc16',
];

export function getWireColor(index: number): string {
  return WIRE_COLORS[index % WIRE_COLORS.length];
}

// Linearly interpolate between two '#rrggbb' colors. Used to animate
// component colors (e.g. relay/button contacts) alongside their motion
// instead of snapping color the instant a threshold is crossed.
function lerpColor(hexA: string, hexB: string, t: number): string {
  const clampedT = Math.max(0, Math.min(1, t));
  const a = parseInt(hexA.slice(1), 16);
  const b = parseInt(hexB.slice(1), 16);
  const ar = (a >> 16) & 0xff, ag = (a >> 8) & 0xff, ab = a & 0xff;
  const br = (b >> 16) & 0xff, bg = (b >> 8) & 0xff, bb = b & 0xff;
  const r = Math.round(ar + (br - ar) * clampedT);
  const g = Math.round(ag + (bg - ag) * clampedT);
  const bl = Math.round(ab + (bb - ab) * clampedT);
  return `rgb(${r}, ${g}, ${bl})`;
}

// Helper: draw resistor zigzag
function drawResistorBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  const w = comp.type === 'variableResistor' || comp.type === 'potentiometer' ? 60 : 50;
  const h = 16;
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-w / 2 - 15, 0);
  ctx.lineTo(-w / 2, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(w / 2, 0);
  ctx.lineTo(w / 2 + 15, 0);
  ctx.stroke();

  // Body - zigzag
  ctx.beginPath();
  ctx.strokeStyle = COLORS.resistor;
  ctx.lineWidth = 2.5;
  ctx.lineJoin = 'round';
  const seg = w / 10;
  ctx.moveTo(-w / 2, 0);
  for (let i = 0; i < 5; i++) {
    ctx.lineTo(-w / 2 + seg * (i * 2 + 0.5), -h / 2);
    ctx.lineTo(-w / 2 + seg * (i * 2 + 1.5), h / 2);
  }
  ctx.lineTo(w / 2, 0);
  ctx.stroke();

  // Value label
  const val = comp.props.resistance as number || 1000;
  const label = val >= 1000 ? `${val / 1000}kΩ` : `${val}Ω`;
  ctx.fillStyle = COLORS.text;
  ctx.font = '9px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(label, 0, -h / 2 - 4);

  // Variable resistor arrow
  if (comp.type === 'variableResistor' || comp.type === 'potentiometer') {
    ctx.strokeStyle = COLORS.highlight;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, -h / 2 - 8);
    ctx.lineTo(8, -h / 2 - 18);
    ctx.lineTo(12, -h / 2 - 18);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(8, -h / 2 - 18);
    ctx.lineTo(6, -h / 2 - 15);
    ctx.moveTo(8, -h / 2 - 18);
    ctx.lineTo(10, -h / 2 - 15);
    ctx.stroke();
  }

  ctx.restore();
}

// Helper: draw capacitor body
function drawCapacitorBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-8, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(8, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Plates
  ctx.strokeStyle = COLORS.capacitor;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(-8, -14); ctx.lineTo(-8, 14);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(8, -14); ctx.lineTo(8, 14);
  ctx.stroke();

  // Value
  const val = comp.props.capacitance as number || 1e-6;
  let label: string;
  if (val >= 1e-3) label = `${(val * 1e3).toFixed(1)}mF`;
  else if (val >= 1e-6) label = `${(val * 1e6).toFixed(1)}µF`;
  else if (val >= 1e-9) label = `${(val * 1e9).toFixed(1)}nF`;
  else label = `${(val * 1e12).toFixed(1)}pF`;
  ctx.fillStyle = COLORS.text;
  ctx.font = '9px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(label, 0, -18);

  ctx.restore();
}

// Helper: draw inductor coils
function drawInductorBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-35, 0); ctx.lineTo(-25, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(25, 0); ctx.lineTo(35, 0);
  ctx.stroke();

  // Coils (arcs)
  ctx.strokeStyle = COLORS.inductor;
  ctx.lineWidth = 2;
  const coilW = 50;
  const loops = 4;
  for (let i = 0; i < loops; i++) {
    ctx.beginPath();
    ctx.arc(-coilW / 2 + i * (coilW / loops) + (coilW / loops) / 2, 0, coilW / loops / 2 - 1, Math.PI, 0);
    ctx.stroke();
  }

  // Value
  const val = comp.props.inductance as number || 1e-3;
  let label: string;
  if (val >= 1) label = `${val.toFixed(1)}H`;
  else if (val >= 1e-3) label = `${(val * 1e3).toFixed(1)}mH`;
  else label = `${(val * 1e6).toFixed(1)}µH`;
  ctx.fillStyle = COLORS.text;
  ctx.font = '9px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(label, 0, -14);

  ctx.restore();
}

// Helper: draw diode
function drawDiodeBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean, isZener: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-10, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(10, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Triangle
  ctx.fillStyle = COLORS.diode;
  ctx.beginPath();
  ctx.moveTo(-10, -12);
  ctx.lineTo(10, 0);
  ctx.lineTo(-10, 12);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = COLORS.diode;
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Bar
  ctx.beginPath();
  ctx.moveTo(10, -12); ctx.lineTo(10, 12);
  ctx.stroke();

  // Zener lines
  if (isZener) {
    ctx.beginPath();
    ctx.moveTo(10, -12); ctx.lineTo(14, -14);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(10, 12); ctx.lineTo(14, 14);
    ctx.stroke();
  }

  ctx.restore();
}

// Helper: draw a bipolar junction transistor (NPN or PNP), standard
// schematic symbol - base bar, collector/emitter diagonal leads, and an
// emitter arrow whose direction encodes polarity (pointing away from the
// base bar for NPN - "Not Pointing iN" - and toward it for PNP). Terminal
// order/layout matches defaultTerminals.transistorNpn/transistorPnp below:
// index 0 = Base (left), index 1 = Collector (upper-right), index 2 =
// Emitter (lower-right).
function drawTransistorBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean, isPnp: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  ctx.strokeStyle = COLORS.componentStroke;
  ctx.fillStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;

  // Base lead + bar
  ctx.beginPath();
  ctx.moveTo(-40, 0); ctx.lineTo(-8, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-8, -16); ctx.lineTo(-8, 16);
  ctx.stroke();

  // Collector lead (upper-right, into the base bar)
  ctx.beginPath();
  ctx.moveTo(-8, -8); ctx.lineTo(40, -40);
  ctx.stroke();

  // Emitter lead (lower-right, into the base bar) - carries the arrow
  ctx.beginPath();
  ctx.moveTo(-8, 8); ctx.lineTo(40, 40);
  ctx.stroke();

  // Emitter arrowhead, placed a third of the way along the emitter lead
  // (close to the base bar, matching standard schematic convention).
  // NPN: arrow points away from the base (outward, toward the emitter
  // terminal). PNP: arrow points toward the base (inward).
  const ax = -8 + (40 - -8) / 3;
  const ay = 8 + (40 - 8) / 3;
  const dirX = isPnp ? -1 : 1;
  const dirY = isPnp ? -1 : 1;
  const len = 9;
  const wing = 4;
  const nx = dirX / Math.SQRT2;
  const ny = dirY / Math.SQRT2;
  const tipX = ax + nx * len * 0.5;
  const tipY = ay + ny * len * 0.5;
  const backX = ax - nx * len * 0.5;
  const backY = ay - ny * len * 0.5;
  const perpX = -ny;
  const perpY = nx;
  ctx.beginPath();
  ctx.moveTo(tipX, tipY);
  ctx.lineTo(backX + perpX * wing, backY + perpY * wing);
  ctx.lineTo(backX - perpX * wing, backY - perpY * wing);
  ctx.closePath();
  ctx.fill();

  // Part label
  ctx.fillStyle = COLORS.textDim;
  ctx.font = '8px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(isPnp ? 'PNP' : 'NPN', 0, -24);

  // Switching-state indicator - lit while the base current is driving the
  // Collector/Emitter path into saturation (see `transistorOn` in
  // simulator.ts's updateComponentState/buildNets).
  const on = !!comp.state.transistorOn;
  ctx.beginPath();
  ctx.arc(-8, 28, 3, 0, Math.PI * 2);
  ctx.fillStyle = on ? COLORS.success : '#334155';
  ctx.fill();

  ctx.restore();
}

// Helper: draw an N-channel power MOSFET (IRF520/IRF540/IRLZ44N), standard
// schematic symbol - Gate as a separate insulated plate (no direct
// connection line to the channel, unlike a BJT's base bar), Drain/Source
// leads, and a body-diode-style arrow on the Source lead pointing into the
// channel (N-channel convention). Terminal order/layout matches
// defaultTerminals.irf520/irf540/irlz44n below: index 0 = Gate (left),
// index 1 = Drain (upper-right), index 2 = Source (lower-right).
function drawMosfetBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean, partLabel: string) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  ctx.strokeStyle = COLORS.componentStroke;
  ctx.fillStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;

  // Gate lead + insulated gate plate (no electrical link drawn to the
  // channel bar - the gate is capacitively coupled, not a resistive base).
  ctx.beginPath();
  ctx.moveTo(-40, 0); ctx.lineTo(-14, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-14, -16); ctx.lineTo(-14, 16);
  ctx.stroke();

  // Channel bar, offset from the gate plate to show the insulating gap.
  ctx.beginPath();
  ctx.moveTo(-8, -16); ctx.lineTo(-8, 16);
  ctx.stroke();

  // Drain lead (upper-right)
  ctx.beginPath();
  ctx.moveTo(-8, -8); ctx.lineTo(40, -40);
  ctx.stroke();

  // Source lead (lower-right) - carries the body-diode arrow
  ctx.beginPath();
  ctx.moveTo(-8, 8); ctx.lineTo(40, 40);
  ctx.stroke();

  // Source-side arrowhead: N-channel convention, points inward toward the
  // channel bar (opposite an NPN's outward-pointing emitter arrow).
  const ax = -8 + (40 - -8) / 3;
  const ay = 8 + (40 - 8) / 3;
  const nx = -1 / Math.SQRT2;
  const ny = -1 / Math.SQRT2;
  const len = 9;
  const wing = 4;
  const tipX = ax + nx * len * 0.5;
  const tipY = ay + ny * len * 0.5;
  const backX = ax - nx * len * 0.5;
  const backY = ay - ny * len * 0.5;
  const perpX = -ny;
  const perpY = nx;
  ctx.beginPath();
  ctx.moveTo(tipX, tipY);
  ctx.lineTo(backX + perpX * wing, backY + perpY * wing);
  ctx.lineTo(backX - perpX * wing, backY - perpY * wing);
  ctx.closePath();
  ctx.fill();

  // Part label
  ctx.fillStyle = COLORS.textDim;
  ctx.font = '8px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(partLabel, 0, -24);

  // Switching-state indicator - lit while Gate-Source voltage has crossed
  // Gate Threshold Voltage and the Drain-Source channel is conducting (see
  // `mosfetOn` in simulator.ts's updateComponentState/buildNets).
  const on = !!comp.state.mosfetOn;
  ctx.beginPath();
  ctx.arc(-14, 28, 3, 0, Math.PI * 2);
  ctx.fillStyle = on ? COLORS.success : '#334155';
  ctx.fill();

  ctx.restore();
}

// Helper: draw LED
function drawLEDBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-10, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(10, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Triangle
  const brightness = comp.state.brightness as number || 0;
  const glowColor = comp.props.color as string || '#ff0000';

  // Glow effect
  if (brightness > 0.05) {
    ctx.shadowColor = glowColor;
    ctx.shadowBlur = brightness * 20;
  }

  ctx.fillStyle = brightness > 0.1 ? glowColor : COLORS.led;
  ctx.beginPath();
  ctx.moveTo(-10, -12);
  ctx.lineTo(10, 0);
  ctx.lineTo(-10, 12);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = brightness > 0.3 ? '#ffffff' : COLORS.led;
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.shadowBlur = 0;

  // Bar
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.beginPath();
  ctx.moveTo(10, -12); ctx.lineTo(10, 12);
  ctx.stroke();

  // Permanent "emitting light" arrows — the standard schematic marker that
  // distinguishes an LED symbol from a plain diode. Drawn at all times
  // (not just when lit), colored by whether current is flowing.
  const arrowColor = brightness > 0.1 ? glowColor : COLORS.componentStroke;
  drawLightEmissionArrow(ctx, -1, -15, 7, -23, arrowColor);
  drawLightEmissionArrow(ctx, 4, -12, 12, -20, arrowColor);

  // Light rays (extra glow effect while lit)
  if (brightness > 0.1) {
    ctx.strokeStyle = glowColor;
    ctx.globalAlpha = brightness * 0.6;
    ctx.lineWidth = 1;
    for (let i = -1; i <= 1; i++) {
      ctx.beginPath();
      ctx.moveTo(18, i * 6);
      ctx.lineTo(26, i * 6 - 3);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  // Color label
  ctx.fillStyle = COLORS.text;
  ctx.font = '9px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('LED', 0, -28);

  ctx.restore();
}

// Draws one short arrow (line + arrowhead) used for the LED's fixed
// "emitting light" schematic markers.
function drawLightEmissionArrow(ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number, color: string) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  // Arrowhead
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const headLen = 4;
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(
    x2 - headLen * Math.cos(angle - Math.PI / 6),
    y2 - headLen * Math.sin(angle - Math.PI / 6)
  );
  ctx.lineTo(
    x2 - headLen * Math.cos(angle + Math.PI / 6),
    y2 - headLen * Math.sin(angle + Math.PI / 6)
  );
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

// Helper: draw bulb (lamp)
function drawBulbBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-10, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(10, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Bulb glass
  // Use the eased visual value (advanceVisualState) rather than the raw
  // electrical target so the filament fades smoothly in/out instead of
  // snapping the instant current changes.
  const brightness = (comp.state.visualBrightness as number) || 0;

  // Subtle pulsing "flicker" so a lit bulb reads as alive, not a static
  // color swap. Purely cosmetic — driven by wall-clock time since this is
  // redrawn every animation frame anyway.
  const pulse = brightness > 0.05 ? 0.85 + 0.15 * Math.sin(performance.now() / 220) : 1;
  const glowStrength = brightness * pulse;

  if (glowStrength > 0.05) {
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = glowStrength * 25;
  }

  // Glass circle
  ctx.fillStyle = glowStrength > 0.05
    ? `rgba(255, ${Math.round(220 + 35 * glowStrength)}, ${Math.round(150 + 105 * glowStrength)}, 0.9)`
    : 'rgba(148, 163, 184, 0.3)';
  ctx.beginPath();
  ctx.arc(0, 0, 14, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.shadowBlur = 0;

  // Filament
  ctx.strokeStyle = brightness > 0.5 ? '#f59e0b' : COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-8, 0);
  ctx.quadraticCurveTo(-4, -8, 0, 0);
  ctx.quadraticCurveTo(4, 8, 8, 0);
  ctx.stroke();

  // Radiating light rays, gently pulsing in length/opacity with the glow
  if (brightness > 0.1) {
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 1.5;
    const rayCount = 8;
    const innerR = 17;
    const outerR = innerR + 6 * pulse;
    for (let i = 0; i < rayCount; i++) {
      const angle = (i / rayCount) * Math.PI * 2;
      ctx.globalAlpha = brightness * 0.7 * pulse;
      ctx.beginPath();
      ctx.moveTo(Math.cos(angle) * innerR, Math.sin(angle) * innerR);
      ctx.lineTo(Math.cos(angle) * outerR, Math.sin(angle) * outerR);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  // Power label
  const power = comp.power || 0;
  if (power > 0.001) {
    ctx.fillStyle = COLORS.text;
    ctx.font = '9px "IBM Plex Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`${(power * 1000).toFixed(1)}mW`, 0, -26);
  }

  ctx.restore();
}

// Helper: draw battery
function drawBatteryBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const voltage = comp.props.voltage as number || 9;

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-35, 0); ctx.lineTo(-8, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(8, 0); ctx.lineTo(35, 0);
  ctx.stroke();

  // Battery body
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.battery;
  ctx.lineWidth = 2;
  ctx.fillRect(-8, -10, 16, 20);
  ctx.strokeRect(-8, -10, 16, 20);

  // Positive plate (long line)
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(-14, -6); ctx.lineTo(-2, -6);
  ctx.stroke();

  // Negative plate (short line)
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(-14, 6); ctx.lineTo(-6, 6);
  ctx.stroke();

  // + and - signs
  ctx.fillStyle = COLORS.danger;
  ctx.font = 'bold 10px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('+', -16, -2);
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText('-', -16, 10);

  // Voltage label
  ctx.fillStyle = COLORS.text;
  ctx.font = '10px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(`${voltage}V`, 0, -14);

  ctx.restore();
}

// Helper: draw ground
function drawGroundBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Lead
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, -25); ctx.lineTo(0, -6);
  ctx.stroke();

  // Ground symbol
  ctx.strokeStyle = COLORS.ground;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-14, -6); ctx.lineTo(14, -6);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-10, 0); ctx.lineTo(10, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-6, 6); ctx.lineTo(6, 6);
  ctx.stroke();

  ctx.restore();
}

// Helper: draw switch
function drawSwitchBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const isClosed = comp.props.closed as boolean || false;

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-10, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(10, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Contact points
  ctx.fillStyle = COLORS.componentStroke;
  ctx.beginPath(); ctx.arc(-10, 0, 3, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(10, 0, 3, 0, Math.PI * 2); ctx.fill();

  // Blade
  ctx.strokeStyle = isClosed ? COLORS.success : COLORS.componentStroke;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(-10, 0);
  if (isClosed) {
    ctx.lineTo(10, 0);
  } else {
    ctx.lineTo(8, -12);
  }
  ctx.stroke();

  // Label
  ctx.fillStyle = COLORS.text;
  ctx.font = '9px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(isClosed ? 'CLOSED' : 'OPEN', 0, 16);

  ctx.restore();
}

// Helper: draw push button
function drawPushButtonBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-10, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(10, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Button housing
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-12, -10, 24, 20);
  ctx.strokeRect(-12, -10, 24, 20);

  // Button cap - buttonPos (0 = released, 1 = pressed) is eased over time
  // in advanceVisualState(), so the cap physically travels down/up instead
  // of jumping between its two end positions.
  const buttonPos = (comp.state.buttonPos as number) || 0;
  const capY = -8 + 4 * buttonPos;
  ctx.fillStyle = lerpColor('#475569', COLORS.success, buttonPos);
  ctx.fillRect(-8, capY, 16, 10);
  ctx.strokeRect(-8, capY, 16, 10);

  ctx.restore();
}

// Helper: draw fuse
function drawFuseBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-20, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(20, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Body
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-20, -8, 40, 16);
  ctx.strokeRect(-20, -8, 40, 16);

  // Wire inside
  const blown = comp.state.blown as boolean || false;
  ctx.strokeStyle = blown ? COLORS.danger : COLORS.componentStroke;
  ctx.setLineDash(blown ? [3, 3] : []);
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-14, 0); ctx.lineTo(14, 0);
  ctx.stroke();
  ctx.setLineDash([]);

  // Rating
  const rating = comp.props.currentRating as number || 1;
  ctx.fillStyle = COLORS.text;
  ctx.font = '9px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(`${rating}A`, 0, -12);

  ctx.restore();
}

// Helper: draw polyfuse (resettable PTC fuse). Drawn as the small radial
// disc real PTC parts come in (not the axial cartridge body a one-shot
// Fuse uses), so the two look visually distinct on the canvas even though
// they share a 2-terminal footprint. Color reflects live state: normal
// (cold, conducting), tripped (hot, current-limiting), or cooling back
// down (partway through Reset Time) - a real PTC doesn't snap back to
// normal the instant the fault clears.
function drawPolyfuseBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-16, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(16, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  const tripped = comp.state.tripped as boolean || false;
  const bodyColor = tripped ? COLORS.danger : COLORS.componentFill;

  // Disc body (real Multifuse/Nanosmdc parts are small round discs, not
  // rectangular cartridges).
  ctx.fillStyle = bodyColor;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(0, 0, 16, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Tripped state gets a dashed ring to echo the Fuse's dashed-wire
  // "open" glyph, while still reading as a disc rather than a cartridge.
  if (tripped) {
    ctx.setLineDash([3, 3]);
    ctx.strokeStyle = COLORS.danger;
    ctx.beginPath();
    ctx.arc(0, 0, 10, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Hold current rating, like the Fuse's rating label.
  const holdCurrent = comp.props.holdCurrent as number || 1;
  ctx.fillStyle = COLORS.text;
  ctx.font = '9px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(`${holdCurrent}A`, 0, -20);

  ctx.restore();
}

// Helper: draw DC barrel jack (panel-mount power connector: TIP, SLV/sleeve,
// and a normally-closed detect switch pin, SW, shorted to the sleeve when no
// plug is inserted - matching the real part's third pin).
function drawBarrelJackBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads down to TIP / SLV (bottom) and SW (top)
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(-20, 20); ctx.lineTo(-20, 12); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(20, 20); ctx.lineTo(20, 12); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(0, -20); ctx.lineTo(0, -12); ctx.stroke();

  // Body (barrel housing)
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-22, -12, 44, 24);
  ctx.strokeRect(-22, -12, 44, 24);

  // Barrel (concentric circles for tip/sleeve)
  ctx.beginPath(); ctx.arc(0, 0, 9, 0, Math.PI * 2);
  ctx.fillStyle = COLORS.background;
  ctx.fill();
  ctx.stroke();
  ctx.beginPath(); ctx.arc(0, 0, 3.5, 0, Math.PI * 2);
  ctx.fillStyle = COLORS.componentStroke;
  ctx.fill();

  const polarity = (comp.props.polarity as string) || 'Center Positive';
  ctx.fillStyle = COLORS.text;
  ctx.font = '8px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(polarity === 'Center Positive' ? 'C+' : 'C-', 0, 2.5);
  ctx.fillText('DC JACK', 0, 22);

  ctx.restore();
}

// Helper: draw a 2-position screw terminal block (both screws + wire entry
// slots are purely cosmetic - electrically it's a plain 2-pin connector,
// same as any other passive PCB connector).
function drawScrewTerminalBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(-20, 0); ctx.lineTo(-14, 0); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(20, 0); ctx.lineTo(14, 0); ctx.stroke();

  // Terminal block body
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-14, -9, 28, 18);
  ctx.strokeRect(-14, -9, 28, 18);
  // Divider between the two positions
  ctx.beginPath(); ctx.moveTo(0, -9); ctx.lineTo(0, 9); ctx.stroke();

  // Screw heads (slotted circles)
  for (const cx of [-7, 7]) {
    ctx.beginPath(); ctx.arc(cx, 0, 4.5, 0, Math.PI * 2);
    ctx.fillStyle = COLORS.background;
    ctx.fill();
    ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx - 3, 0); ctx.lineTo(cx + 3, 0); ctx.stroke();
  }

  ctx.fillStyle = COLORS.text;
  ctx.font = '8px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('1', -7, 16);
  ctx.fillText('2', 7, 16);

  ctx.restore();
}

// Helper: draw a JST 2-pin (PH-style) wire-to-board connector - a small
// polarized plastic housing, distinct from the bare-pin header parts.
function drawJstConnectorBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(-16, 0); ctx.lineTo(-10, 0); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(16, 0); ctx.lineTo(10, 0); ctx.stroke();

  // Housing
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-10, -7, 20, 14);
  ctx.strokeRect(-10, -7, 20, 14);
  // Polarization notch (top-left)
  ctx.fillStyle = COLORS.background;
  ctx.fillRect(-10, -7, 4, 3);

  // Pins
  ctx.fillStyle = COLORS.componentStroke;
  ctx.beginPath(); ctx.arc(-4, 0, 2, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(4, 0, 2, 0, Math.PI * 2); ctx.fill();

  ctx.fillStyle = COLORS.text;
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('JST', 0, 17);

  ctx.restore();
}

// Helper: draw a bare 4-pin UART breakout header (VCC/GND/TXD/RXD) - a
// simple pin row, same treatment as the JST/screw-terminal connectors
// above.
function drawUartHeaderBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-18, -6, 36, 12);
  ctx.strokeRect(-18, -6, 36, 12);

  ctx.fillStyle = COLORS.text;
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('UART', 0, -10);

  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, -6);
    ctx.lineTo(px, t.dy * GRID_SIZE);
    ctx.stroke();
    ctx.fillStyle = COLORS.componentStroke;
    ctx.beginPath();
    ctx.arc(px, -6, 1.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = COLORS.textDim;
    ctx.fillText(t.label, px, 14);
  }

  ctx.restore();
}

// Helper: draw an HC-05/HC-06 UART Bluetooth breakout - small PCB with
// the metal-can Bluetooth radio module on top, a status LED (reflects
// Connected/Paired), and the pin row (VCC/TXD/RXD/STATE/GND/EN) below.
function drawBluetoothModuleBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean, label: string) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const bodyW = 46, bodyH = 26;
  const powered = comp.props.powered !== false;
  const connected = !!comp.props.connected;

  // Small breakout PCB
  ctx.fillStyle = '#0f4a3a';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);
  ctx.strokeRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);

  // Metal-can radio module (the actual HC-05/06 module soldered on the
  // breakout board)
  ctx.fillStyle = '#8a939c';
  ctx.fillRect(-bodyW / 2 + 6, -bodyH / 2 + 4, bodyW - 12, bodyH - 14);
  ctx.strokeRect(-bodyW / 2 + 6, -bodyH / 2 + 4, bodyW - 12, bodyH - 14);

  // Status LED (blinks/solid on a real module depending on pairing state -
  // shown here as solid on once Connected)
  ctx.fillStyle = powered ? (connected ? COLORS.success : '#d97706') : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(bodyW / 2 - 6, -bodyH / 2 - 4, 2, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#fff';
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(label, 0, 2);

  // Pin leads + labels (top edge: VCC/TXD/RXD/STATE/GND/EN)
  ctx.font = '6px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, -bodyH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();
    ctx.fillStyle = COLORS.textDim;
    ctx.fillText(t.label, px, py - 3);
  }

  ctx.restore();
}

// Helper: draw a GPS NEO-6M breakout - small PCB with the metal-can GPS
// receiver module on top, a ceramic patch antenna, and a Fix status LED
// (reflects Fix Acquired) - plus the pin row (VCC/TX/RX/GND) below.
function drawGpsModuleBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const bodyW = 40, bodyH = 26;
  const powered = comp.props.powered !== false;
  const fixAcquired = comp.props.fixAcquired !== false;

  // Small breakout PCB
  ctx.fillStyle = '#0f4a3a';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);
  ctx.strokeRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);

  // Ceramic patch antenna (square, tan-colored, the visually distinctive
  // part of a NEO-6M breakout)
  ctx.fillStyle = '#c9a86a';
  ctx.fillRect(-bodyW / 2 + 5, -bodyH / 2 + 3, bodyW - 10, bodyH - 12);
  ctx.strokeRect(-bodyW / 2 + 5, -bodyH / 2 + 3, bodyW - 10, bodyH - 12);

  // Fix status LED (blinks on a real module while searching, solid once
  // it has a Fix - shown here as solid on once Fix Acquired)
  ctx.fillStyle = powered ? (fixAcquired ? COLORS.success : '#d97706') : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(bodyW / 2 - 6, -bodyH / 2 - 4, 2, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#1a1a1a';
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('GPS', 0, 4);

  // Pin leads + labels (top edge: VCC/TX/RX/GND)
  ctx.font = '6px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, -bodyH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();
    ctx.fillStyle = COLORS.textDim;
    ctx.fillText(t.label, px, py - 3);
  }

  ctx.restore();
}

// Helper: draw an ESP8266/ESP32 Wi-Fi breakout - small green PCB with a
// metal-can/module shield, a Wi-Fi status LED (reflects Wi-Fi Connected),
// and the pin row below (order matches defaultTerminals.esp8266/esp32).
function drawEspModuleBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean, label: string) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const pinCount = comp.terminals.length;
  const bodyW = 14 + pinCount * 8, bodyH = 26;
  const powered = comp.props.powered !== false;
  const connected = !!comp.props.connected;

  // Small breakout PCB
  ctx.fillStyle = '#0b3d2e';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);
  ctx.strokeRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);

  // RF shield can (the actual Wi-Fi SoC module soldered on the breakout)
  ctx.fillStyle = '#6b7280';
  ctx.fillRect(-bodyW / 2 + 6, -bodyH / 2 + 4, bodyW - 12, bodyH - 14);
  ctx.strokeRect(-bodyW / 2 + 6, -bodyH / 2 + 4, bodyW - 12, bodyH - 14);

  // Wi-Fi status LED (solid on once Wi-Fi Connected, dim amber if powered
  // but not connected, off if unpowered) - same treatment as HC-05's
  // Connected LED above.
  ctx.fillStyle = powered ? (connected ? COLORS.success : '#d97706') : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(bodyW / 2 - 6, -bodyH / 2 - 4, 2, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#fff';
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(label, 0, 2);

  ctx.font = '6px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, -bodyH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();
    ctx.fillStyle = COLORS.textDim;
    ctx.fillText(t.label, px, py - 3);
  }

  ctx.restore();
}

// Helper: draw an RC522 (MFRC522) 13.56MHz RFID reader breakout - small
// PCB with the square PCB-trace antenna coil filling most of the body,
// and a Card Present status LED - plus the pin row (SDA/SCK/MOSI/MISO/
// RST/3.3V/GND) below (order matches defaultTerminals.rc522).
function drawRc522ModuleBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const bodyW = 44, bodyH = 30;
  const powered = comp.props.powered !== false;
  const cardPresent = comp.props.cardPresent !== false;

  ctx.fillStyle = '#1a4a6b';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);
  ctx.strokeRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);

  // Square PCB-trace antenna coil (the visually distinctive part of an
  // RC522 breakout)
  ctx.strokeStyle = '#c8a951';
  ctx.lineWidth = 1;
  for (let i = 0; i < 3; i++) {
    const inset = 4 + i * 3;
    ctx.strokeRect(-bodyW / 2 + inset, -bodyH / 2 + inset - 2, bodyW - inset * 2, bodyH - inset * 2 - 4);
  }

  // Card Present status LED (lit while a card is in range, matches the
  // idle-high stamp in simulator.ts)
  ctx.fillStyle = powered ? (cardPresent ? COLORS.success : '#374151') : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(bodyW / 2 - 6, -bodyH / 2 + 5, 2, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#fff';
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('RC522', 0, 4);

  ctx.font = '6px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, -bodyH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();
    ctx.fillStyle = COLORS.textDim;
    ctx.fillText(t.label, px, py - 3);
  }

  ctx.restore();
}

// Helper: draw an NRF24L01(+) 2.4GHz SPI transceiver breakout - small PCB
// with the onboard chip antenna trace at one end and the 2x4 pin header
// below (order matches defaultTerminals.nrf24l01).
function drawNrf24ModuleBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const bodyW = 46, bodyH = 30;
  const powered = comp.props.powered !== false;
  const dataReady = !!comp.props.dataReady;

  ctx.fillStyle = '#1a1a1a';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);
  ctx.strokeRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);

  // PCB trace antenna at the top edge
  ctx.strokeStyle = '#c8a951';
  ctx.lineWidth = 1;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.moveTo(-bodyW / 2 + 6 + i * 4, -bodyH / 2);
    ctx.lineTo(-bodyW / 2 + 6 + i * 4, -bodyH / 2 + 8);
    ctx.stroke();
  }

  // IRQ status indicator (active-low: lit once Data Ready, matches the
  // idle-high/active-low stamp in simulator.ts)
  ctx.fillStyle = powered ? (dataReady ? COLORS.success : '#374151') : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(bodyW / 2 - 6, -bodyH / 2 + 5, 2, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#fff';
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('NRF24L01', 0, 4);

  ctx.font = '6px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, -bodyH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();
    ctx.fillStyle = COLORS.textDim;
    ctx.fillText(t.label, px, py - 3);
  }

  ctx.restore();
}

// Helper: draw a MAX485 RS-485 transceiver breakout - small PCB with an
// 8-pin DIP outline and a status LED for RO's idle-high line (order
// matches defaultTerminals.max485).
function drawMax485Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const bodyW = 46, bodyH = 26;
  const powered = comp.props.powered !== false;
  const busIdleHigh = comp.props.busIdleHigh !== false;

  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);
  ctx.strokeRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);

  ctx.fillStyle = powered ? (busIdleHigh ? COLORS.success : '#374151') : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(bodyW / 2 - 6, -bodyH / 2 + 5, 2, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('MAX485', 0, 3);

  ctx.font = '6px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, -bodyH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();
    ctx.fillStyle = COLORS.textDim;
    ctx.fillText(t.label, px, py - 3);
  }

  ctx.restore();
}

// Helper: draw an MCP2515 CAN bus breakout - small PCB with an SPI pin
// row and an INT status LED (active-low: lit once Message Pending,
// matches the idle-high/active-low stamp in simulator.ts).
function drawCanBusModuleBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const bodyW = 42, bodyH = 26;
  const powered = comp.props.powered !== false;
  const messagePending = !!comp.props.messagePending;

  ctx.fillStyle = '#0b1f3d';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);
  ctx.strokeRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH);

  ctx.fillStyle = powered ? (messagePending ? COLORS.success : '#374151') : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(bodyW / 2 - 6, -bodyH / 2 + 5, 2, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#fff';
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('CAN', 0, 3);

  ctx.font = '6px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, -bodyH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();
    ctx.fillStyle = COLORS.textDim;
    ctx.fillText(t.label, px, py - 3);
  }

  ctx.restore();
}

// Helper: draw a passive 4-pin I2C header (VCC/GND/SDA/SCL) - same style
// as drawUartHeaderBody above, no electrical model of its own.
function drawI2cHeaderBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-18, -6, 36, 12);
  ctx.strokeRect(-18, -6, 36, 12);

  ctx.fillStyle = COLORS.text;
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('I2C', 0, -10);

  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, -6);
    ctx.lineTo(px, t.dy * GRID_SIZE);
    ctx.stroke();
    ctx.fillStyle = COLORS.componentStroke;
    ctx.beginPath();
    ctx.arc(px, -6, 1.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = COLORS.textDim;
    ctx.fillText(t.label, px, 14);
  }

  ctx.restore();
}

// Helper: draw relay - electromagnetic coil driving a SPDT contact set.
function drawRelayBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Coil
  ctx.strokeStyle = COLORS.inductor;
  ctx.lineWidth = 2;
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.arc(-20 + i * 12, -10, 5, Math.PI, 0);
    ctx.stroke();
  }

  // Fixed contacts: NC (top) and NO (bottom)
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(10, -25); ctx.lineTo(10, -5);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(10, 5); ctx.lineTo(10, 25);
  ctx.stroke();

  // COM pivot + lead - the common terminal the blade swings around. This
  // was missing entirely before: NC/NO were drawn as two dead-end contacts
  // with nothing actually wired to them.
  ctx.beginPath();
  ctx.moveTo(-2, 0); ctx.lineTo(18, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(-2, 0, 2, 0, Math.PI * 2);
  ctx.fillStyle = COLORS.componentStroke;
  ctx.fill();

  // Blade - contactPos (0 = de-energized/NC, 1 = energized/NO) is eased
  // over time in advanceVisualState(), so the blade physically swings
  // around the COM pivot between contacts instead of teleporting the
  // instant the coil state flips.
  const contactPos = (comp.state.contactPos as number) || 0;
  const bladeY = -15 + 30 * contactPos;
  ctx.strokeStyle = lerpColor(COLORS.componentStroke, COLORS.success, contactPos);
  ctx.beginPath();
  ctx.moveTo(-2, 0);
  ctx.lineTo(10, bladeY);
  ctx.stroke();

  ctx.restore();
}

// Helper: draw relay module - a board-level relay (explicit COM/NO/NC
// screw-terminal labeling, status LED) as opposed to the bare relay above.
// Its contact swing is driven by the same eased contactPos state, but only
// starts moving after the Switching Delay has elapsed in
// advanceVisualState() - a real armature doesn't move the instant the coil
// is commanded.
function drawRelayModuleBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // PCB board
  ctx.fillStyle = COLORS.arduino;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-40, -22, 80, 44);
  ctx.strokeRect(-40, -22, 80, 44);

  // Relay "can" - the actual electromechanical relay mounted on the board
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-16, -16, 26, 26);
  ctx.strokeRect(-16, -16, 26, 26);

  // Status LED - lit while the contacts are actually energized (post-delay)
  const energized = !!comp.state.energized;
  ctx.beginPath();
  ctx.arc(-28, -12, 3, 0, Math.PI * 2);
  ctx.fillStyle = energized ? COLORS.success : '#334155';
  ctx.fill();

  // Coil leads (left side)
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-60, -8); ctx.lineTo(-40, -8);
  ctx.moveTo(-60, 8); ctx.lineTo(-40, 8);
  ctx.stroke();
  ctx.fillStyle = COLORS.textDim;
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'left';
  ctx.fillText('IN+', -38, -10);
  ctx.fillText('IN-', -38, 12);

  // Screw-terminal contacts (right side) - explicitly labeled COM/NO/NC
  ctx.beginPath();
  ctx.moveTo(40, -16); ctx.lineTo(60, -16);
  ctx.moveTo(40, 0); ctx.lineTo(60, 0);
  ctx.moveTo(40, 16); ctx.lineTo(60, 16);
  ctx.stroke();
  ctx.textAlign = 'right';
  ctx.fillText('NC', 38, -18);
  ctx.fillText('COM', 38, 2);
  ctx.fillText('NO', 38, 18);

  // Blade - swings between NC (top) and NO (bottom) around the COM pivot.
  // contactPos (0 = de-energized/NC, 1 = energized/NO) is eased in
  // advanceVisualState(), which itself only starts moving once the
  // configured Switching Delay has elapsed since the coil was commanded.
  const contactPos = (comp.state.contactPos as number) || 0;
  const bladeY = -12 + 24 * contactPos;
  ctx.strokeStyle = lerpColor(COLORS.componentStroke, COLORS.success, contactPos);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(10, 0);
  ctx.lineTo(30, bladeY);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(10, 0, 2, 0, Math.PI * 2);
  ctx.fillStyle = COLORS.componentStroke;
  ctx.fill();

  ctx.textAlign = 'center';
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 8px "IBM Plex Mono", monospace';
  ctx.fillText('RELAY MODULE', 0, -26);

  ctx.restore();
}


// Helper: draw DC motor
function drawMotorBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-35, 0); ctx.lineTo(-18, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(18, 0); ctx.lineTo(35, 0);
  ctx.stroke();

  // Circle body
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 18, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Spinning rotor indicator - angle is continuously advanced in
  // advanceVisualState() based on the (eased) rpm, so this visibly rotates
  // while powered and spins down smoothly rather than stopping instantly.
  const rotationAngle = (comp.state.rotationAngle as number) || 0;
  ctx.save();
  ctx.rotate(rotationAngle);
  ctx.strokeStyle = COLORS.textDim;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-13, 0); ctx.lineTo(13, 0);
  ctx.moveTo(0, -13); ctx.lineTo(0, 13);
  ctx.stroke();
  ctx.restore();

  // M label
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 12px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('M', 0, 0);

  // Speed indicator (smoothed value, matches the visual spin-up/down)
  const rpm = (comp.state.visualRpm as number) || 0;
  if (rpm > 0.5) {
    ctx.fillStyle = COLORS.textDim;
    ctx.font = '8px "IBM Plex Mono", monospace';
    ctx.fillText(`${Math.round(rpm)}rpm`, 0, 24);
  }

  ctx.restore();
}

// Helper: draw water pump — rotating impeller + animated flow through the
// body, driven by the same eased rpm/flow state advanceVisualState()
// produces for 'waterPump' (mirrors the motor's smooth spin-up / instant
// stop pattern).
function drawWaterPumpBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads (electrical +/- terminals, same convention as the DC motor)
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-35, 0); ctx.lineTo(-18, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(18, 0); ctx.lineTo(35, 0);
  ctx.stroke();

  // Pump housing (rounded body)
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 18, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Flowing water — a ring of droplet marks that travel around the
  // housing; their speed is driven by visualFlow (which itself scales
  // with both applied voltage and the pump's Horse Power), and their
  // color brightens slightly with flow to read as "water" rather than a
  // static ring.
  const flowPhase = (comp.state.flowPhase as number) || 0;
  const flowing = ((comp.state.visualFlow as number) || 0) > 0.5;
  if (flowing) {
    ctx.fillStyle = COLORS.textDim;
    const dropletCount = 6;
    for (let i = 0; i < dropletCount; i++) {
      const a = flowPhase + (i / dropletCount) * Math.PI * 2;
      const r = 12;
      ctx.beginPath();
      ctx.arc(Math.cos(a) * r, Math.sin(a) * r, 1.6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Spinning impeller — rotates with rotationAngle (advanced every frame
  // proportional to eased RPM, and its sign encodes spin direction), and
  // snaps to a stop the instant power is removed rather than coasting.
  const rotationAngle = (comp.state.rotationAngle as number) || 0;
  ctx.save();
  ctx.rotate(rotationAngle);
  ctx.strokeStyle = COLORS.textDim;
  ctx.lineWidth = 2;
  for (let blade = 0; blade < 3; blade++) {
    ctx.save();
    ctx.rotate((blade / 3) * Math.PI * 2);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(5, -8, 11, -3);
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();

  // P label
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 11px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('P', 0, 0);

  // Speed indicator (smoothed value, matches the visual spin-up/down)
  const rpm = (comp.state.visualRpm as number) || 0;
  if (rpm > 0.5) {
    ctx.fillStyle = COLORS.textDim;
    ctx.font = '8px "IBM Plex Mono", monospace';
    ctx.fillText(`${Math.round(rpm)}rpm`, 0, 26);
  }

  ctx.restore();
}

// Helper: draw solenoid valve - a plunger that lifts off its seat as the
// coil energizes (visualOpen, eased in advanceVisualState()) and a row of
// flow dots that only travel through the body once it's actually open.
function drawSolenoidValveBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Pipe stubs either side (plumbing only, not electrical nets - same
  // convention as the water pump's inlet/outlet).
  const pipeSize = Math.max(3, (comp.props.pipeSize as number) || 12);
  const pipeHalf = Math.max(3, Math.min(10, pipeSize / 2.5));
  ctx.fillStyle = '#94a3b8';
  ctx.fillRect(-36, -pipeHalf, 16, pipeHalf * 2);
  ctx.fillRect(20, -pipeHalf, 16, pipeHalf * 2);
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1;
  ctx.strokeRect(-36, -pipeHalf, 16, pipeHalf * 2);
  ctx.strokeRect(20, -pipeHalf, 16, pipeHalf * 2);

  // Valve body
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.fillRect(-20, -14, 40, 28);
  ctx.strokeRect(-20, -14, 40, 28);

  // Solenoid coil housing on top
  ctx.fillStyle = '#94a3b8';
  ctx.fillRect(-10, -28, 20, 16);
  ctx.strokeRect(-10, -28, 20, 16);

  // Plunger - rises into the coil housing as the valve opens, clearing the
  // seat so flow can pass. visualOpen is eased (not instant), so it reads
  // as a physical solenoid pull-in rather than a snap.
  const visualOpen = (comp.state.visualOpen as number) || 0;
  const plungerY = -6 - visualOpen * 14;
  ctx.fillStyle = '#64748b';
  ctx.fillRect(-3, plungerY, 6, 14);
  ctx.strokeRect(-3, plungerY, 6, 14);

  // Flow dots - only travel through the body once it's meaningfully open.
  const flowPhase = (comp.state.flowPhase as number) || 0;
  if (visualOpen > 0.3) {
    ctx.fillStyle = COLORS.highlight;
    const dotCount = 4;
    for (let i = 0; i < dotCount; i++) {
      const t = ((flowPhase + i / dotCount) % 1);
      const x = -30 + t * 60;
      ctx.beginPath();
      ctx.arc(x, 8, 1.6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Label
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 8px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(visualOpen > 0.5 ? 'OPEN' : 'CLOSED', 0, 4);
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText(`${Math.round(pipeSize)}mm`, 0, -32);

  ctx.restore();
}

function drawBuzzerBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-14, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(14, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Body - bell shape
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 2, 14, Math.PI, 0);
  ctx.lineTo(14, 2); ctx.lineTo(-14, 2);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Sound waves
  const active = comp.state.active as boolean || false;
  if (active) {
    ctx.strokeStyle = COLORS.highlight;
    ctx.lineWidth = 1.5;
    ctx.globalAlpha = 0.6 + 0.4 * Math.sin(Date.now() / 100);
    ctx.beginPath();
    ctx.arc(0, 2, 20, Math.PI * 1.2, Math.PI * 1.8);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  ctx.restore();
}

function drawActiveBuzzerBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-14, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(14, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Body - classic active-buzzer can (round metal can with a small vent hole)
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 14, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Vent hole + polarity dot (real active buzzers mark the + lead)
  ctx.fillStyle = COLORS.textDim;
  ctx.beginPath();
  ctx.arc(0, 0, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.text;
  ctx.textAlign = 'center';
  ctx.fillText('+', -8, -8);

  // Sound waves - active buzzers just go full volume the instant they're powered
  const active = comp.state.active as boolean || false;
  if (active) {
    ctx.strokeStyle = COLORS.highlight;
    ctx.lineWidth = 1.5;
    ctx.globalAlpha = 0.6 + 0.4 * Math.sin(Date.now() / 100);
    ctx.beginPath();
    ctx.arc(0, 0, 20, Math.PI * 1.2, Math.PI * 1.8);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, 26, Math.PI * 1.15, Math.PI * 1.85);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  ctx.font = '6px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText('ACT', 0, 28);

  ctx.restore();
}

function drawPassiveBuzzerBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-14, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(14, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Body - round can, no polarity dot (passive buzzers are typically
  // unpolarized speaker elements), with a small waveform etched on top
  // to hint that it needs a driven signal rather than switching on its own.
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 14, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  ctx.strokeStyle = COLORS.textDim;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-7, 2); ctx.lineTo(-4, -4); ctx.lineTo(0, 4); ctx.lineTo(4, -4); ctx.lineTo(7, 2);
  ctx.stroke();

  // Sound waves - amplitude/animation speed tracks the driven frequency,
  // so a low PWM frequency visibly pulses slower than a high one.
  const active = comp.state.active as boolean || false;
  const freq = Math.max(20, (comp.state.frequency as number) || 100);
  if (active) {
    ctx.strokeStyle = COLORS.highlight;
    ctx.lineWidth = 1.5;
    ctx.globalAlpha = 0.6 + 0.4 * Math.sin(Date.now() / (2000000 / freq));
    ctx.beginPath();
    ctx.arc(0, 0, 20, Math.PI * 1.2, Math.PI * 1.8);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  ctx.font = '6px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText('PWM', 0, 28);

  ctx.restore();
}

// Helper: draw simple bottom-edge pin leads + labels for a rectangular IC
// body, shared shape used by the new display components below.
function drawIcPinLeads(ctx: CanvasRenderingContext2D, comp: Component, edgeY: number, highLabels?: Set<string>) {
  ctx.font = '6.5px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    ctx.strokeStyle = highLabels?.has(t.label) ? COLORS.logicHigh : COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, py > 0 ? edgeY : -edgeY);
    ctx.lineTo(px, py);
    ctx.stroke();
    ctx.fillStyle = COLORS.text;
    ctx.textAlign = 'center';
    ctx.fillText(t.label, px, py + (py > 0 ? 9 : -6));
  }
}

function drawRgbLedBody(ctx: CanvasRenderingContext2D, comp: Component, isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const r = Math.max(0, Math.min(1, (comp.state.brightnessR as number) || 0));
  const g = Math.max(0, Math.min(1, (comp.state.brightnessG as number) || 0));
  const b = Math.max(0, Math.min(1, (comp.state.brightnessB as number) || 0));
  const lit = r > 0.02 || g > 0.02 || b > 0.02;
  const mixColor = `rgb(${Math.round(r * 255)}, ${Math.round(g * 255)}, ${Math.round(b * 255)})`;

  // Leads
  drawIcPinLeads(ctx, comp, 16);

  // Glow
  if (lit) {
    const glow = ctx.createRadialGradient(0, -6, 2, 0, -6, 26);
    glow.addColorStop(0, mixColor);
    glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow;
    ctx.globalAlpha = 0.55;
    ctx.beginPath();
    ctx.arc(0, -6, 26, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  // Dome body (true RGB mix - not a simulated color swap)
  ctx.fillStyle = lit ? mixColor : 'rgba(255,255,255,0.15)';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(0, -6, 13, Math.PI, 0);
  ctx.lineTo(13, 4); ctx.lineTo(-13, 4);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  ctx.font = '6px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.textAlign = 'center';
  ctx.fillText('RGB', 0, -32);

  if (isHovered) {
    ctx.strokeStyle = COLORS.hoveredStroke;
    ctx.lineWidth = 1;
    ctx.strokeRect(-20, -32, 40, 44);
  }

  ctx.restore();
}

function drawNeopixelBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const count = Math.max(1, Math.min(60, (comp.props.pixelCount as number) || 8));
  const colors = (comp.state.pixelColors as string[]) || [];
  const w = Math.min(220, Math.max(60, count * 16 + 16));
  const h = 34;

  // PCB strip body
  ctx.fillStyle = '#111827';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-w / 2, -h / 2, w, h);
  ctx.strokeRect(-w / 2, -h / 2, w, h);

  // Each LED independently controllable/colored
  const cellW = (w - 12) / count;
  for (let i = 0; i < count; i++) {
    const cx = -w / 2 + 6 + cellW * (i + 0.5);
    const color = colors[i] || '#1e293b';
    const on = !!comp.state.on;
    if (on) {
      ctx.fillStyle = color;
      ctx.globalAlpha = 0.35;
      ctx.beginPath();
      ctx.arc(cx, 0, cellW * 0.55, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
    ctx.fillStyle = on ? color : '#1e293b';
    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, 0, cellW * 0.32, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }

  drawIcPinLeads(ctx, comp, h / 2);

  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.textAlign = 'center';
  ctx.fillText('WS2812', 0, -h / 2 - 6);

  ctx.restore();
}

function drawLcd16x2Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const w = 190, h = 70;
  const on = !!comp.state.on;
  const backlight = comp.props.backlight !== false;

  // Bezel
  ctx.fillStyle = '#0b1f2a';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-w / 2, -h / 2, w, h);
  ctx.strokeRect(-w / 2, -h / 2, w, h);

  // Screen
  const screenLit = on && backlight;
  ctx.fillStyle = screenLit ? '#3b6e4f' : (on ? '#1f2f27' : '#141b18');
  ctx.fillRect(-w / 2 + 10, -h / 2 + 10, w - 20, h - 20);

  // Live character display - two 16-char rows
  const line1 = String(comp.props.line1 ?? '').slice(0, 16);
  const line2 = String(comp.props.line2 ?? '').slice(0, 16);
  ctx.font = '11px "IBM Plex Mono", monospace';
  ctx.textAlign = 'left';
  ctx.fillStyle = on ? '#0a1a10' : 'rgba(10,26,16,0.35)';
  if (on) {
    ctx.fillText(line1.padEnd(16, ' '), -w / 2 + 16, -6);
    ctx.fillText(line2.padEnd(16, ' '), -w / 2 + 16, 14);
  }

  drawIcPinLeads(ctx, comp, h / 2);

  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.textAlign = 'center';
  ctx.fillText('LCD 16x2', 0, -h / 2 - 6);

  ctx.restore();
}

function drawOledBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const w = 128, h = 68;
  const on = !!comp.state.on;

  // Bezel
  ctx.fillStyle = '#111827';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-w / 2, -h / 2, w, h);
  ctx.strokeRect(-w / 2, -h / 2, w, h);

  // Screen
  const sx = -w / 2 + 6, sy = -h / 2 + 20, sw = w - 12, sh = h - 26;
  ctx.fillStyle = '#000';
  ctx.fillRect(sx, sy, sw, sh);

  if (on) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(sx, sy, sw, sh);
    ctx.clip();
    ctx.fillStyle = '#7dd3fc';
    ctx.strokeStyle = '#7dd3fc';

    const pattern = (comp.props.pattern as string) || 'bouncingBall';
    if (pattern === 'bouncingBall') {
      const bx = (comp.state.ballX as number) ?? sw / 2;
      const by = (comp.state.ballY as number) ?? sh / 2;
      ctx.beginPath();
      ctx.arc(sx + bx, sy + by, 6, 0, Math.PI * 2);
      ctx.fill();
    } else if (pattern === 'bars') {
      const phase = (comp.state.animPhase as number) || 0;
      const bars = 12;
      for (let i = 0; i < bars; i++) {
        const barH = (Math.sin(phase + i * 0.6) * 0.5 + 0.5) * (sh - 4) + 2;
        ctx.fillRect(sx + 2 + i * (sw / bars), sy + sh - barH, sw / bars - 2, barH);
      }
    } else if (pattern === 'smiley') {
      const cx = sx + sw / 2, cy = sy + sh / 2;
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(cx, cy, Math.min(sw, sh) / 2 - 3, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(cx - 10, cy - 8, 2.5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(cx + 10, cy - 8, 2.5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(cx, cy, 12, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke();
    } else if (pattern === 'text') {
      ctx.font = 'bold 12px "IBM Plex Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText(String(comp.props.text ?? '').slice(0, 10), sx + sw / 2, sy + sh / 2 + 4);
    }
    ctx.restore();
  }

  drawIcPinLeads(ctx, comp, h / 2);

  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.textAlign = 'center';
  ctx.fillText('SSD1306', 0, -h / 2 - 6);

  ctx.restore();
}

// Classic 7-segment layout, drawn around a local origin so the 4-digit
// variant below can reuse it once per digit.
function drawSevenSegmentDigit(ctx: CanvasRenderingContext2D, segs: Record<string, boolean>, scale = 1) {
  const onColor = '#ef4444';
  const offColor = 'rgba(239, 68, 68, 0.12)';
  const sw = 3 * scale; // segment thickness
  const w = 14 * scale, h = 22 * scale;

  const seg = (on: boolean, x1: number, y1: number, x2: number, y2: number) => {
    ctx.strokeStyle = on ? onColor : offColor;
    ctx.lineWidth = sw;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
  };

  seg(!!segs.a, -w / 2, -h, w / 2, -h);
  seg(!!segs.b, w / 2, -h, w / 2, 0);
  seg(!!segs.c, w / 2, 0, w / 2, h);
  seg(!!segs.d, -w / 2, h, w / 2, h);
  seg(!!segs.e, -w / 2, 0, -w / 2, h);
  seg(!!segs.f, -w / 2, -h, -w / 2, 0);
  seg(!!segs.g, -w / 2, 0, w / 2, 0);

  ctx.fillStyle = segs.dp ? onColor : offColor;
  ctx.beginPath();
  ctx.arc(w / 2 + 4 * scale, h, 1.6 * scale, 0, Math.PI * 2);
  ctx.fill();
}

function drawSevenSegmentBody(ctx: CanvasRenderingContext2D, comp: Component, isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const w = 46, h = 66;
  ctx.fillStyle = '#0f172a';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-w / 2, -h / 2, w, h);
  ctx.strokeRect(-w / 2, -h / 2, w, h);

  const segs = (comp.state.segments as Record<string, boolean>) || {};
  ctx.save();
  ctx.translate(0, -2);
  drawSevenSegmentDigit(ctx, segs, 1);
  ctx.restore();

  drawIcPinLeads(ctx, comp, h / 2);

  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.textAlign = 'center';
  ctx.fillText('7-SEG', 0, -h / 2 - 6);

  if (isHovered) {
    ctx.strokeStyle = COLORS.hoveredStroke;
    ctx.lineWidth = 1;
    ctx.strokeRect(-w / 2 - 4, -h / 2 - 4, w + 8, h + 8);
  }

  ctx.restore();
}

function drawSevenSegment4Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const w = 150, h = 70;
  ctx.fillStyle = '#0f172a';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-w / 2, -h / 2, w, h);
  ctx.strokeRect(-w / 2, -h / 2, w, h);

  const digits = (comp.state.digits as Array<Record<string, boolean>>) || [{}, {}, {}, {}];
  const slotW = w / 4;
  for (let i = 0; i < 4; i++) {
    ctx.save();
    ctx.translate(-w / 2 + slotW * (i + 0.5), -2);
    drawSevenSegmentDigit(ctx, digits[i] || {}, 0.85);
    ctx.restore();
  }

  drawIcPinLeads(ctx, comp, h / 2);

  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.textAlign = 'center';
  ctx.fillText('4-DIGIT 7-SEG', 0, -h / 2 - 6);

  ctx.restore();
}

// Helper: draw measurement instruments
function drawAmmeterBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-16, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(16, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Circle
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 16, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // A
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 14px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('A', 0, 0);

  // Reading
  const current = Math.abs(comp.current || 0);
  ctx.fillStyle = COLORS.highlight;
  ctx.font = '8px "IBM Plex Mono", monospace';
  ctx.fillText(current >= 1 ? `${current.toFixed(2)}A` : `${(current * 1000).toFixed(1)}mA`, 0, -22);

  ctx.restore();
}

function drawVoltmeterBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-30, 0); ctx.lineTo(-16, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(16, 0); ctx.lineTo(30, 0);
  ctx.stroke();

  // Circle
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 16, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // V
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 14px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('V', 0, 0);

  // Reading
  const voltage = Math.abs(comp.voltage || 0);
  ctx.fillStyle = COLORS.highlight;
  ctx.font = '8px "IBM Plex Mono", monospace';
  ctx.fillText(`${voltage.toFixed(2)}V`, 0, -22);

  ctx.restore();
}

// Helper: draw AC source
function drawACSourceBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-35, 0); ctx.lineTo(-16, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(16, 0); ctx.lineTo(35, 0);
  ctx.stroke();

  // Circle
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 16, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Sine wave
  ctx.strokeStyle = COLORS.text;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  for (let x = -10; x <= 10; x += 0.5) {
    const y = -6 * Math.sin((x / 10) * Math.PI);
    if (x === -10) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Value
  const voltage = comp.props.voltage as number || 120;
  const freq = comp.props.frequency as number || 60;
  ctx.fillStyle = COLORS.text;
  ctx.font = '9px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(`${voltage}V ${freq}Hz`, 0, -22);

  ctx.restore();
}

// Helper: draw DC current source
function drawDCCurrentSourceBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-35, 0); ctx.lineTo(-16, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(16, 0); ctx.lineTo(35, 0);
  ctx.stroke();

  // Circle
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 16, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Arrow
  ctx.strokeStyle = COLORS.text;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, -8); ctx.lineTo(0, 8);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-4, 3); ctx.lineTo(0, 8); ctx.lineTo(4, 3);
  ctx.stroke();

  // Value
  const current = comp.props.current as number || 0.1;
  ctx.fillStyle = COLORS.text;
  ctx.font = '9px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(`${(current * 1000).toFixed(0)}mA`, 0, -22);

  ctx.restore();
}

// Helper: draw transformer
function drawTransformerBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  // Transformer has specific orientation, handle rotation specially
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Primary coils (left)
  ctx.strokeStyle = COLORS.inductor;
  ctx.lineWidth = 2;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(-12, -10 + i * 10, 5, Math.PI, 0);
    ctx.stroke();
  }

  // Secondary coils (right)
  ctx.strokeStyle = COLORS.capacitor;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(12, -10 + i * 10, 5, 0, Math.PI);
    ctx.stroke();
  }

  // Core lines
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-3, -18); ctx.lineTo(-3, 18);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(3, -18); ctx.lineTo(3, 18);
  ctx.stroke();

  // Leads
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-12, -25); ctx.lineTo(-12, -15);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-12, 15); ctx.lineTo(-12, 25);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(12, -25); ctx.lineTo(12, -15);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(12, 15); ctx.lineTo(12, 25);
  ctx.stroke();

  ctx.restore();
}

// Helper: draw logic gates
function drawLogicGateBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const gateType = comp.type.replace('Gate', '').toUpperCase();
  const outputHigh = comp.state.outputHigh as boolean || false;

  // Body
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.fillRect(-20, -20, 40, 40);
  ctx.strokeRect(-20, -20, 40, 40);

  // Gate symbol
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 11px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(gateType, 0, 0);

  // Output indicator
  ctx.fillStyle = outputHigh ? COLORS.logicHigh : COLORS.logicLow;
  ctx.beginPath();
  ctx.arc(22, 0, 4, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

function drawNOTGateBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const outputHigh = comp.state.outputHigh as boolean || false;

  // Triangle body
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-18, -16);
  ctx.lineTo(14, 0);
  ctx.lineTo(-18, 16);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Bubble
  ctx.fillStyle = COLORS.componentFill;
  ctx.beginPath();
  ctx.arc(18, 0, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Output indicator
  ctx.fillStyle = outputHigh ? COLORS.logicHigh : COLORS.logicLow;
  ctx.beginPath();
  ctx.arc(24, 0, 3, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

// Helper: draw breadboard
function drawBreadboardBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const w = 140;
  const h = 80;

  // Body
  ctx.fillStyle = '#f1f5f9';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1;
  ctx.fillRect(-w / 2, -h / 2, w, h);
  ctx.strokeRect(-w / 2, -h / 2, w, h);

  // Power rails
  ctx.fillStyle = 'rgba(239, 68, 68, 0.25)';
  ctx.fillRect(-w / 2 + 4, -h / 2 + 4, w - 8, 6);
  ctx.fillRect(-w / 2 + 4, h / 2 - 10, w - 8, 6);
  ctx.fillStyle = 'rgba(59, 130, 246, 0.2)';
  ctx.fillRect(-w / 2 + 4, -h / 2 + 12, w - 8, 6);
  ctx.fillRect(-w / 2 + 4, h / 2 - 18, w - 8, 6);

  // Holes
  ctx.fillStyle = '#94a3b8';
  for (let row = 0; row < 10; row++) {
    for (let col = 0; col < 30; col++) {
      const hx = -w / 2 + 12 + col * 4.2;
      const hy = -h / 2 + 26 + row * 5;
      if (row === 4 || row === 5) continue; // Gap in middle
      ctx.beginPath();
      ctx.arc(hx, hy, 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.restore();
}

// Helper: draw servo motor
function drawServoMotorBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Body
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.fillRect(-18, -14, 36, 28);
  ctx.strokeRect(-18, -14, 36, 28);

  // Shaft housing
  ctx.fillStyle = '#94a3b8';
  ctx.beginPath();
  ctx.arc(0, 0, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Smoothly-eased visual angle (0-180deg), falls back to the raw target
  // angle before the first animation frame has run.
  const visualAngle = (comp.state.visualAngle as number) ?? (comp.state.angle as number) ?? 0;
  const rad = (visualAngle - 90) * Math.PI / 180; // -90..+90 sweep, centered

  // Servo horn (the arm that physically sweeps) - drawn a bit longer than
  // the plain indicator line so the rotation reads clearly.
  ctx.strokeStyle = comp.state.moving ? COLORS.highlight : '#64748b';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(16 * Math.cos(rad), 16 * Math.sin(rad));
  ctx.stroke();
  ctx.fillStyle = comp.state.moving ? COLORS.highlight : '#64748b';
  ctx.beginPath();
  ctx.arc(16 * Math.cos(rad), 16 * Math.sin(rad), 2.5, 0, Math.PI * 2);
  ctx.fill();

  // Label
  ctx.fillStyle = COLORS.text;
  ctx.font = '8px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('SERVO', 0, -18);

  // Angle readout
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillText(`${Math.round(visualAngle)}°`, 0, 20);

  ctx.restore();
}

// Helper: draw stepper motor - a gear-toothed rotor that snaps between
// discrete Step Angle positions (advanceVisualState() drives the eased
// displayAngle), unlike the DC motor's continuous spin.
function drawStepperMotorBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // Leads to the two coil pairs (A+/A-, B+/B-).
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-60, -20); ctx.lineTo(-20, -8);
  ctx.moveTo(-60, 20); ctx.lineTo(-20, 8);
  ctx.moveTo(60, -20); ctx.lineTo(20, -8);
  ctx.moveTo(60, 20); ctx.lineTo(20, 8);
  ctx.stroke();

  // NEMA-style square body
  ctx.fillStyle = COLORS.componentFill;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 2;
  ctx.fillRect(-20, -20, 40, 40);
  ctx.strokeRect(-20, -20, 40, 40);
  // Corner mounting holes
  ctx.fillStyle = 'rgba(255,255,255,0.3)';
  for (const [hx, hy] of [[-15, -15], [15, -15], [-15, 15], [15, 15]] as const) {
    ctx.beginPath();
    ctx.arc(hx, hy, 2.5, 0, Math.PI * 2);
    ctx.fill();
  }

  // Rotor - toothed to visually read as discrete steps rather than a
  // smooth continuous spin, at the eased displayAngle from simulator.ts.
  const stepAngle = Math.max(0.1, (comp.props.stepAngle as number) || 1.8);
  const teeth = Math.max(6, Math.min(24, Math.round(360 / stepAngle) || 12));
  const displayAngleDeg = (comp.state.displayAngle as number) || 0;
  ctx.save();
  ctx.rotate(displayAngleDeg * Math.PI / 180);
  ctx.fillStyle = '#94a3b8';
  ctx.beginPath();
  ctx.arc(0, 0, 13, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1;
  for (let i = 0; i < teeth; i++) {
    const a = (i / teeth) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(11 * Math.cos(a), 11 * Math.sin(a));
    ctx.lineTo(14 * Math.cos(a), 14 * Math.sin(a));
    ctx.stroke();
  }
  // Direction tick - marks "12 o'clock" on the rotor so the step-by-step
  // rotation is visible frame to frame.
  ctx.strokeStyle = comp.state.stepping ? COLORS.highlight : COLORS.textDim;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 0); ctx.lineTo(0, -13);
  ctx.stroke();
  ctx.restore();

  // Direction arrow (CW / CCW) drawn around the body, independent of the
  // rotor's own rotation.
  const dir = comp.props.direction === 'ccw' ? -1 : 1;
  ctx.strokeStyle = COLORS.textDim;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(0, 0, 24, dir > 0 ? -0.6 : Math.PI + 0.6, dir > 0 ? Math.PI - 0.6 : 2 * Math.PI - 0.6);
  ctx.stroke();

  // Label
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 9px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('STEP', 0, -28);

  // RPM readout (smoothed value, matches the eased spin state)
  const rpm = (comp.state.visualRpm as number) || 0;
  if (rpm > 0.5) {
    ctx.fillStyle = COLORS.textDim;
    ctx.font = '7px "IBM Plex Mono", monospace';
    ctx.fillText(`${Math.round(rpm)}rpm ${dir > 0 ? 'CW' : 'CCW'}`, 0, 30);
  }

  ctx.restore();
}

// Helper: draw Arduino Uno / Mega / Nano board
function drawArduinoBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const boardInfo: Record<string, { w: number; h: number; chip: string; label: string }> = {
    arduino: { w: 340, h: 160, chip: 'ATmega328P', label: 'ARDUINO UNO' },
    arduinoMega: { w: 620, h: 220, chip: 'ATmega2560', label: 'ARDUINO MEGA' },
    arduinoNano: { w: 280, h: 130, chip: 'ATmega328P', label: 'ARDUINO NANO' },
  };
  const { w, h, chip, label } = boardInfo[comp.type] || boardInfo.arduino;

  // PCB body
  ctx.fillStyle = COLORS.arduino;
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-w / 2, -h / 2, w, h);
  ctx.strokeRect(-w / 2, -h / 2, w, h);

  // Silkscreen mounting holes
  ctx.fillStyle = 'rgba(255,255,255,0.35)';
  for (const [hx, hy] of [[-w / 2 + 10, -h / 2 + 10], [w / 2 - 10, -h / 2 + 10], [-w / 2 + 10, h / 2 - 10], [w / 2 - 10, h / 2 - 10]] as const) {
    ctx.beginPath();
    ctx.arc(hx, hy, 3, 0, Math.PI * 2);
    ctx.fill();
  }

  // USB connector
  ctx.fillStyle = '#94a3b8';
  ctx.fillRect(-w / 2 - 6, -18, 16, 30);
  ctx.strokeRect(-w / 2 - 6, -18, 16, 30);

  // Microcontroller chip
  ctx.fillStyle = '#111827';
  ctx.strokeStyle = '#000';
  ctx.lineWidth = 1;
  ctx.fillRect(-24, -14, 48, 28);
  ctx.strokeRect(-24, -14, 48, 28);
  ctx.fillStyle = '#94a3b8';
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(chip, 0, 2);

  // Power LED (decorative, always on when placed)
  ctx.fillStyle = COLORS.success;
  ctx.beginPath();
  ctx.arc(w / 2 - 16, -h / 2 + 16, 3, 0, Math.PI * 2);
  ctx.fill();

  // Reset button
  ctx.fillStyle = '#475569';
  ctx.beginPath();
  ctx.arc(w / 2 - 30, h / 2 - 16, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Board label
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 10px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(label, 0, h / 2 - 30);

  // Pin leads + labels + HIGH/LOW indicator dots for digital pins
  ctx.font = '7px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    const edgeY = t.dy < 0 ? -h / 2 : h / 2;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, edgeY);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.text;
    ctx.fillText(t.label, px, t.dy < 0 ? edgeY - 4 : edgeY + 10);

    // Digital pin state dot: reflects each pin's actual mode.
    //  - OUTPUT: the digitalWrite() boolean prop (unchanged behavior).
    //  - PWM: duty-cycle intensity (0-255), same visual language as the
    //    analog dot below since it's really an averaged analog voltage.
    //  - INPUT / INPUT_PULLUP: the live digitalRead() value computed each
    //    tick in updateComponentState(), not the (irrelevant) write prop.
    if (/^D\d+$/.test(t.label)) {
      const pinNum = t.label.slice(1);
      const mode = (comp.props[`d${pinNum}_mode`] as string) || 'OUTPUT';
      if (mode === 'PWM') {
        const duty = Math.max(0, Math.min(255, (comp.props[`d${pinNum}_pwm`] as number) ?? 0));
        const level = duty / 255;
        ctx.fillStyle = `rgba(56, 189, 248, ${0.25 + level * 0.75})`;
      } else if (mode === 'INPUT' || mode === 'INPUT_PULLUP') {
        const digitalValues = (comp.state?.digitalValues as Record<string, boolean>) || {};
        const isHigh = !!digitalValues[t.label];
        ctx.fillStyle = isHigh ? COLORS.logicHigh : '#475569';
      } else {
        const isHigh = !!comp.props[`d${pinNum}`];
        ctx.fillStyle = isHigh ? COLORS.logicHigh : '#475569';
      }
      ctx.beginPath();
      ctx.arc(px, t.dy < 0 ? edgeY - 10 : edgeY + 16, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Analog pin state dot — intensity reflects the live ADC reading
    // (0-1023) computed each simulation step in updateComponentState().
    if (/^A\d+$/.test(t.label)) {
      const analogValues = (comp.state?.analogValues as Record<string, number>) || {};
      const adc = analogValues[t.label] ?? 0;
      const level = Math.max(0, Math.min(1, adc / 1023));
      ctx.fillStyle = `rgba(56, 189, 248, ${0.25 + level * 0.75})`;
      ctx.beginPath();
      ctx.arc(px, t.dy < 0 ? edgeY - 10 : edgeY + 16, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.restore();
}

// Helper: draw HC-SR04 ultrasonic distance sensor — small PCB with two
// round transducer "eyes" and four bottom pins (VCC, Trig, Echo, GND).
function drawHcSr04Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const w = 76, h = 40;

  // PCB body
  ctx.fillStyle = '#1e3a5f';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-w / 2, -h / 2, w, h);
  ctx.strokeRect(-w / 2, -h / 2, w, h);

  // Mounting holes
  ctx.fillStyle = 'rgba(255,255,255,0.3)';
  for (const [hx, hy] of [[-w / 2 + 6, -h / 2 + 6], [w / 2 - 6, -h / 2 + 6]] as const) {
    ctx.beginPath();
    ctx.arc(hx, hy, 2, 0, Math.PI * 2);
    ctx.fill();
  }

  // Ultrasonic transducers ("eyes")
  const enabled = comp.props.enabled !== false;
  for (const ex of [-16, 16]) {
    ctx.fillStyle = '#c0c0c0';
    ctx.strokeStyle = '#8a8a8a';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(ex, -4, 14, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#3a3a3a';
    ctx.beginPath();
    ctx.arc(ex, -4, 9, 0, Math.PI * 2);
    ctx.fill();

    // Active "ping" rings when enabled
    if (enabled) {
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.5)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(ex, -4, 17, 0, Math.PI * 2);
      ctx.stroke();
    }
  }

  // Ultrasonic beam animation — a widening cone that travels outward
  // during the first half of a measurement (outbound ping) and eases
  // back during the second half (returning echo), timed against the
  // same pulse the Echo pin is driven from.
  const pulsing = !!comp.state.pulsing;
  if (pulsing) {
    const elapsed = (comp.state.pulseElapsedMs as number) || 0;
    const duration = (comp.state.pulseDurationMs as number) || 1;
    const progress = Math.max(0, Math.min(1, elapsed / duration));
    // 0 -> 0.5: beam travels out to the obstacle. 0.5 -> 1: echo returns.
    const outbound = progress < 0.5;
    const legProgress = outbound ? progress / 0.5 : (progress - 0.5) / 0.5;
    const reach = 20 + legProgress * 40;
    const alpha = outbound ? 0.7 : 0.7 * (1 - legProgress);

    ctx.save();
    ctx.strokeStyle = `rgba(56, 189, 248, ${alpha})`;
    ctx.fillStyle = `rgba(56, 189, 248, ${alpha * 0.15})`;
    ctx.lineWidth = 1.5;
    const beamHalfAngle = Math.PI / 7;
    ctx.beginPath();
    ctx.moveTo(0, -4);
    ctx.lineTo(-Math.sin(beamHalfAngle) * reach, -4 - Math.cos(beamHalfAngle) * reach);
    ctx.arc(0, -4, reach, -Math.PI / 2 - beamHalfAngle, -Math.PI / 2 + beamHalfAngle);
    ctx.lineTo(0, -4);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  // Label
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 8px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('HC-SR04', 0, h / 2 - 6);

  // Distance reading
  const distance = comp.props.distance as number ?? 0;
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = enabled ? COLORS.success : COLORS.textDim;
  ctx.fillText(`${distance} cm`, 0, -h / 2 - 6);

  // Pin leads + labels (bottom edge) — Trig/Echo leads reflect live signal state
  ctx.font = '7px "IBM Plex Mono", monospace';
  const trigHigh = !!comp.state.trigHigh;
  const echoHigh = !!comp.state.echoHigh;
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;

    let leadColor = COLORS.componentStroke;
    if (t.label === 'Trig' && trigHigh) leadColor = COLORS.logicHigh;
    if (t.label === 'Echo' && echoHigh) leadColor = COLORS.logicHigh;

    ctx.strokeStyle = leadColor;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, h / 2);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.text;
    ctx.fillText(t.label, px, py + 10);
  }

  ctx.restore();
}

// Helper: draw LM35 temperature sensor — realistic TO-92 transistor-style
// package with a flat face, domed back, and three bottom pins (VCC, OUT, GND).
// Generic TO-220-style body for the three linear regulators (7805,
// AMS1117, LM317). Same 3-leads-on-bottom-edge layout as drawLm35Body,
// but with the taller TO-220 tab/mounting-hole silhouette. Pin
// leads/labels are drawn generically off comp.terminals (in whatever
// order defaultTerminals[type] defines), same approach as drawNE555Body.
function drawRegulatorBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean, partLabel: string, outputText: string) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const bodyW = 30, bodyH = 24;
  const enabled = comp.props.enabled !== false;

  // TO-220 tab: rectangular body + a mounting-hole tab poking up top.
  ctx.fillStyle = '#3f3f46';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH, 2);
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.rect(-bodyW / 2 + 5, -bodyH / 2 - 8, bodyW - 10, 8);
  ctx.fill();
  ctx.stroke();
  // Mounting hole in the tab
  ctx.beginPath();
  ctx.arc(0, -bodyH / 2 - 4, 2, 0, Math.PI * 2);
  ctx.fillStyle = COLORS.background;
  ctx.fill();
  ctx.stroke();

  // Part label on the face
  ctx.fillStyle = '#d4d4d8';
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(partLabel, 0, 3);

  // Status indicator - reflects the Enabled property
  ctx.fillStyle = enabled ? COLORS.success : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(bodyW / 2 - 4, -bodyH / 2 + 4, 2, 0, Math.PI * 2);
  ctx.fill();

  // Chip label above
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 8px "IBM Plex Mono", monospace';
  ctx.fillText(partLabel, 0, -bodyH / 2 - 14);

  // Output readout below
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = enabled ? COLORS.success : COLORS.textDim;
  ctx.fillText(outputText, 0, bodyH / 2 + 22);

  // Pin leads + labels (bottom edge)
  ctx.font = '7px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, bodyH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.textDim;
    ctx.textAlign = 'center';
    ctx.fillText(t.label, px, py + 10);
  }

  ctx.restore();
}

function drawLm35Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const bodyW = 22, bodyH = 26;
  const enabled = comp.props.enabled !== false;

  // TO-92 package: domed top, flat front face, flat bottom
  ctx.fillStyle = '#3f3f46';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-bodyW / 2, -bodyH / 2 + 6);
  ctx.arc(0, -bodyH / 2 + 6, bodyW / 2, Math.PI, 0);
  ctx.lineTo(bodyW / 2, bodyH / 2);
  ctx.lineTo(-bodyW / 2, bodyH / 2);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Flat identification face
  ctx.fillStyle = '#27272a';
  ctx.fillRect(-bodyW / 2 + 3, -bodyH / 2 + 10, bodyW - 6, bodyH - 14);

  // Part label on the flat face
  ctx.fillStyle = '#d4d4d8';
  ctx.font = '6px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('LM35', 0, 2);

  // Status indicator (small dot) — reflects the Enabled property
  ctx.fillStyle = enabled ? COLORS.success : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(0, -bodyH / 2 + 3, 2, 0, Math.PI * 2);
  ctx.fill();

  // Label
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 8px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('LM35', 0, -bodyH / 2 - 10);

  // Temperature reading
  const temperature = comp.props.temperature as number ?? 25;
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = enabled ? COLORS.success : COLORS.textDim;
  ctx.fillText(`${temperature}\u00b0C`, 0, bodyH / 2 + 24);

  // Pin leads + labels (bottom edge, VCC / OUT / GND)
  ctx.font = '7px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, bodyH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.text;
    ctx.fillText(t.label, px, py + 10);
  }

  ctx.restore();
}

// Helper: draw LDR (photoresistor) — classic round disc with a zigzag
// cadmium-sulfide track on top and two straight leads exiting the bottom.
function drawLdrBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const radius = 13;
  const enabled = comp.props.enabled !== false;
  const lightLevel = (comp.props.lightLevel as number) ?? 50;

  // Disc body — a light-sensitive translucent yellowish-green package
  ctx.fillStyle = enabled ? '#a3a35a' : '#4b4b3c';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Inner face — brightness reflects the current Light Level property
  const faceBrightness = 0.15 + (lightLevel / 100) * 0.75;
  ctx.fillStyle = enabled
    ? `rgba(250, 240, 137, ${faceBrightness})`
    : 'rgba(120, 120, 110, 0.25)';
  ctx.beginPath();
  ctx.arc(0, 0, radius - 3, 0, Math.PI * 2);
  ctx.fill();

  // Zigzag resistive track (classic LDR "grid" pattern)
  ctx.strokeStyle = '#3f3f28';
  ctx.lineWidth = 1;
  ctx.beginPath();
  const zigzagRadius = radius - 5;
  let angle = -Math.PI / 2;
  const step = (Math.PI * 2) / 10;
  ctx.moveTo(Math.cos(angle) * 2, Math.sin(angle) * 2);
  for (let i = 0; i <= 10; i++) {
    const r = i % 2 === 0 ? zigzagRadius : zigzagRadius * 0.4;
    ctx.lineTo(Math.cos(angle) * r, Math.sin(angle) * r);
    angle += step;
  }
  ctx.stroke();

  // Status indicator dot — reflects the Enabled property
  ctx.fillStyle = enabled ? COLORS.success : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(0, -radius - 6, 2, 0, Math.PI * 2);
  ctx.fill();

  // Label
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 8px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('LDR', 0, -radius - 12);

  // Light level reading
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = enabled ? COLORS.success : COLORS.textDim;
  ctx.fillText(`${lightLevel}%`, 0, radius + 20);

  // Pin leads + labels (Pin 1 / Pin 2, exiting left/right)
  ctx.font = '7px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    const edgeX = px < 0 ? -radius : radius;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(edgeX, 0);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.text;
    ctx.fillText(t.label, px, py + (py < 0 ? -8 : 12));
  }

  ctx.restore();
}

// Helper: draw DHT11 — realistic blue plastic housing with a perforated
// grille (the humidity-sensing element window) and four bottom pins
// (VCC, DATA, NC, GND).
function drawDht11Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const bodyW = 30, bodyH = 34;
  const enabled = comp.props.enabled !== false;

  // Blue plastic housing, slightly rounded top corners
  ctx.fillStyle = enabled ? '#1d6fa5' : '#3a4a54';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-bodyW / 2, -bodyH / 2 + 4);
  ctx.quadraticCurveTo(-bodyW / 2, -bodyH / 2, -bodyW / 2 + 4, -bodyH / 2);
  ctx.lineTo(bodyW / 2 - 4, -bodyH / 2);
  ctx.quadraticCurveTo(bodyW / 2, -bodyH / 2, bodyW / 2, -bodyH / 2 + 4);
  ctx.lineTo(bodyW / 2, bodyH / 2);
  ctx.lineTo(-bodyW / 2, bodyH / 2);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Perforated grille window (the humidity/temperature sensing element)
  ctx.fillStyle = '#0d3a54';
  ctx.fillRect(-bodyW / 2 + 4, -bodyH / 2 + 6, bodyW - 8, bodyH - 16);
  ctx.fillStyle = enabled ? 'rgba(200, 230, 245, 0.5)' : 'rgba(150, 150, 150, 0.25)';
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 4; col++) {
      const hx = -bodyW / 2 + 8 + col * ((bodyW - 16) / 3);
      const hy = -bodyH / 2 + 10 + row * ((bodyH - 22) / 4);
      ctx.beginPath();
      ctx.arc(hx, hy, 1, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Status indicator dot — reflects the Enabled property
  ctx.fillStyle = enabled ? COLORS.success : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(0, -bodyH / 2 - 4, 2, 0, Math.PI * 2);
  ctx.fill();

  // Label
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 8px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('DHT11', 0, -bodyH / 2 - 10);

  // Temperature / humidity reading
  const temperature = (comp.props.temperature as number) ?? 25;
  const humidity = (comp.props.humidity as number) ?? 50;
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = enabled ? COLORS.success : COLORS.textDim;
  ctx.fillText(`${temperature}\u00b0C  ${humidity}%`, 0, bodyH / 2 + 24);

  // Pin leads + labels (bottom edge, VCC / DATA / NC / GND)
  ctx.font = '7px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, bodyH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.text;
    ctx.fillText(t.label, px, py + 10);
  }

  ctx.restore();
}

// Helper: draw PIR Motion Sensor — realistic white dome (Fresnel lens)
// mounted on a small round PCB, with a 3-pin header (VCC, OUT, GND) below.
function drawPirMotionBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const boardW = 26, boardH = 30;
  const enabled = comp.props.enabled !== false;
  const motionDetected = !!comp.props.motionDetected;

  // Small round green PCB behind the dome
  ctx.fillStyle = enabled ? '#1c6b3a' : '#33403a';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(0, -2, boardW / 2, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // White plastic Fresnel-lens dome — the sensor's signature look
  ctx.fillStyle = enabled ? '#f2f2ea' : '#9a9a92';
  ctx.beginPath();
  ctx.arc(0, -4, boardW / 2 - 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.25)';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Fresnel lens facets (concentric hex-ish segments radiating from center)
  ctx.strokeStyle = 'rgba(0,0,0,0.15)';
  ctx.lineWidth = 0.75;
  for (let ring = 1; ring <= 2; ring++) {
    ctx.beginPath();
    ctx.arc(0, -4, (boardW / 2 - 4) * (ring / 2.4), 0, Math.PI * 2);
    ctx.stroke();
  }
  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(0, -4);
    ctx.lineTo(Math.cos(angle) * (boardW / 2 - 4), -4 + Math.sin(angle) * (boardW / 2 - 4));
    ctx.stroke();
  }

  // Status LED — lit when motion is detected (and the sensor is enabled)
  ctx.fillStyle = enabled && motionDetected ? COLORS.success : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(boardW / 2 - 5, boardH / 2 - 3, 1.6, 0, Math.PI * 2);
  ctx.fill();

  // Label
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 8px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('PIR', 0, -boardH / 2 - 6);

  // Pin leads + labels (bottom edge, VCC / OUT / GND)
  ctx.font = '7px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, boardH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.text;
    ctx.fillText(t.label, px, py + 10);
  }

  ctx.restore();
}

// Helper: draw IR Obstacle Sensor — realistic small rectangular PCB with
// paired IR-LED (emitter) / photodiode (receiver) domes at the front edge,
// a sensitivity potentiometer, and a status LED.
function drawIrObstacleBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const boardW = 34, boardH = 22;
  const enabled = comp.props.enabled !== false;
  const obstacleDetected = !!comp.props.obstacleDetected;

  // Small rectangular PCB
  ctx.fillStyle = enabled ? '#1c6b3a' : '#33403a';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(-boardW / 2, -boardH / 2, boardW, boardH, 2);
  ctx.fill();
  ctx.stroke();

  // Paired IR emitter/receiver domes along the front edge
  const domeY = -boardH / 2 - 3;
  for (const dx of [-boardW / 4, boardW / 4]) {
    ctx.fillStyle = enabled ? '#2b2b2b' : '#555';
    ctx.beginPath();
    ctx.arc(dx, domeY, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.4)';
    ctx.lineWidth = 0.75;
    ctx.stroke();
    // clear plastic dome highlight
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    ctx.beginPath();
    ctx.arc(dx - 1, domeY - 1, 1.3, 0, Math.PI * 2);
    ctx.fill();
  }

  // Sensitivity trim potentiometer (small blue square)
  ctx.fillStyle = enabled ? '#2f5fa8' : '#555f6e';
  ctx.fillRect(-4, -3, 8, 8);
  ctx.strokeStyle = 'rgba(0,0,0,0.35)';
  ctx.lineWidth = 0.5;
  ctx.strokeRect(-4, -3, 8, 8);

  // Status LED — lit when an obstacle is detected (and sensor is enabled)
  ctx.fillStyle = enabled && obstacleDetected ? COLORS.success : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(boardW / 2 - 5, boardH / 2 - 4, 1.6, 0, Math.PI * 2);
  ctx.fill();

  // Label
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('IR', 0, boardH / 2 - 3);

  // Pin leads + labels (bottom edge, VCC / GND / OUT)
  ctx.font = '7px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, boardH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.text;
    ctx.fillText(t.label, px, py + 10);
  }

  ctx.restore();
}

// Helper: draw MQ-2 Gas Sensor — realistic module with the characteristic
// round metal sensing can (with mesh) mounted on a small breakout PCB,
// plus a sensitivity trim potentiometer and status LED, matching common
// MQ-series gas/smoke sensor modules.
function drawMq2GasBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const boardW = 40, boardH = 26;
  const enabled = comp.props.enabled !== false;

  // Breakout PCB
  ctx.fillStyle = enabled ? '#1c4b6b' : '#33383f';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(-boardW / 2, -boardH / 2, boardW, boardH, 2);
  ctx.fill();
  ctx.stroke();

  // Round metal sensing can with mesh top (the MQ-2's signature look)
  const canY = -boardH / 2 + 8;
  const canR = 8.5;
  ctx.fillStyle = enabled ? '#9aa0a6' : '#5c6167';
  ctx.beginPath();
  ctx.arc(0, canY, canR, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.45)';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Mesh pattern on top of the can
  ctx.strokeStyle = 'rgba(0,0,0,0.3)';
  ctx.lineWidth = 0.5;
  for (let i = -2; i <= 2; i++) {
    ctx.beginPath();
    ctx.moveTo(-canR + 1, canY + i * 3);
    ctx.lineTo(canR - 1, canY + i * 3);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.arc(0, canY, canR - 2.5, 0, Math.PI * 2);
  ctx.stroke();

  // Sensitivity trim potentiometer (small blue square)
  ctx.fillStyle = enabled ? '#2f5fa8' : '#555f6e';
  ctx.fillRect(-boardW / 2 + 4, boardH / 2 - 10, 7, 7);
  ctx.strokeStyle = 'rgba(0,0,0,0.35)';
  ctx.lineWidth = 0.5;
  ctx.strokeRect(-boardW / 2 + 4, boardH / 2 - 10, 7, 7);

  // Status LED — lit when the digital comparator (DO) has tripped, i.e.
  // gas concentration has reached the configured threshold
  const doHigh = !!comp.state.doHigh;
  ctx.fillStyle = enabled && doHigh ? COLORS.success : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(boardW / 2 - 5, boardH / 2 - 5, 1.6, 0, Math.PI * 2);
  ctx.fill();

  // Label
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('MQ-2', 0, boardH / 2 - 3);

  // Pin leads + labels (bottom edge, VCC / GND / AO / DO)
  ctx.font = '6.5px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, boardH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.text;
    ctx.fillText(t.label, px, py + 10);
  }

  ctx.restore();
}

// Helper: draw Flame Sensor — small breakout module with the characteristic
// dark IR-photodiode dome (tuned to the 760-1100nm band emitted by flame),
// plus a sensitivity trim potentiometer and status LED, matching common
// YG1006/KY-026-style flame sensor modules.
function drawFlameSensorBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const boardW = 34, boardH = 24;
  const enabled = comp.props.enabled !== false;

  // Breakout PCB
  ctx.fillStyle = enabled ? '#5a1c1c' : '#3a3a3a';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(-boardW / 2, -boardH / 2, boardW, boardH, 2);
  ctx.fill();
  ctx.stroke();

  // Dark IR-photodiode dome (the flame sensor's signature look)
  const domeY = -boardH / 2 + 7;
  const domeR = 6;
  ctx.fillStyle = enabled ? '#1a1a1a' : '#4a4a4a';
  ctx.beginPath();
  ctx.arc(0, domeY, domeR, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.5)';
  ctx.lineWidth = 1;
  ctx.stroke();
  // clear plastic dome highlight
  ctx.fillStyle = 'rgba(255,255,255,0.2)';
  ctx.beginPath();
  ctx.arc(-1.5, domeY - 1.5, 1.5, 0, Math.PI * 2);
  ctx.fill();

  // Sensitivity trim potentiometer (small blue square)
  ctx.fillStyle = enabled ? '#2f5fa8' : '#555f6e';
  ctx.fillRect(-boardW / 2 + 3, boardH / 2 - 9, 7, 7);
  ctx.strokeStyle = 'rgba(0,0,0,0.35)';
  ctx.lineWidth = 0.5;
  ctx.strokeRect(-boardW / 2 + 3, boardH / 2 - 9, 7, 7);

  // Status LED — lit when the digital comparator (DO) has tripped, i.e. a
  // flame is currently detected
  const doHigh = comp.state.doHigh !== false; // active-LOW: lit means flame detected (DO low)
  const flameDetected = enabled && !doHigh;
  ctx.fillStyle = flameDetected ? '#ff6a1a' : COLORS.textDim;
  ctx.beginPath();
  ctx.arc(boardW / 2 - 5, boardH / 2 - 5, 1.6, 0, Math.PI * 2);
  ctx.fill();

  // Label
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 6.5px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('FLAME', 0, boardH / 2 - 3);

  // Pin leads + labels (bottom edge, VCC / GND / DO / AO)
  ctx.font = '6.5px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, boardH / 2);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.text;
    ctx.fillText(t.label, px, py + 10);
  }

  ctx.restore();
}

// Helper: draw NE555 Timer - classic 8-pin DIP chip body. Leads/labels are
// drawn generically off comp.terminals (dx/dy), so the pinout in
// defaultTerminals.ne555 stays the single source of truth for layout.
function drawNE555Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const bodyW = 80, bodyH = 76;

  // DIP body
  ctx.fillStyle = '#1c1f26';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH, 3);
  ctx.fill();
  ctx.stroke();

  // Pin-1 orientation notch (top edge, real DIP chips all have one)
  ctx.beginPath();
  ctx.arc(0, -bodyH / 2, 6, 0, Math.PI);
  ctx.fillStyle = '#0f1115';
  ctx.fill();
  ctx.stroke();

  // Leads + pin numbers + labels, generic over whatever terminals are
  // defined (left column = negative dx, right column = positive dx)
  ctx.font = '7px "IBM Plex Mono", monospace';
  comp.terminals.forEach((t, i) => {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    const edgeX = t.dx < 0 ? -bodyW / 2 : bodyW / 2;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(edgeX, py);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.textDim;
    ctx.textAlign = t.dx < 0 ? 'left' : 'right';
    ctx.fillText(String(i + 1), edgeX + (t.dx < 0 ? 3 : -3), py - 3);

    ctx.fillStyle = COLORS.text;
    ctx.textAlign = t.dx < 0 ? 'right' : 'left';
    ctx.fillText(t.label, edgeX - (t.dx < 0 ? 3 : -3), py + 3);
  });

  // Chip label
  ctx.textAlign = 'center';
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 11px "IBM Plex Mono", monospace';
  ctx.fillText('555', 0, -6);
  ctx.font = '6px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText((comp.props.mode === 'monostable' ? 'MONOSTABLE' : 'ASTABLE'), 0, 6);

  // Live OUT indicator - lit whenever the internal oscillator/one-shot
  // currently has OUT driven high, so the mode/timing is visible at a
  // glance without needing to probe the pin.
  const outHigh = !!comp.state.outHigh;
  ctx.beginPath();
  ctx.arc(0, 18, 3, 0, Math.PI * 2);
  ctx.fillStyle = outHigh ? COLORS.success : '#3a3f4a';
  ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.4)';
  ctx.lineWidth = 0.5;
  ctx.stroke();

  ctx.restore();
}

// Shared DIP body + generic pin leads/numbers/labels, factored out of
// drawNE555Body so the op-amp chips render with an identical real 8-pin
// package outline. Draws everything except the chip-specific label(s)
// and any live indicator, which callers add afterward (still inside the
// same translate/rotate transform).
function drawDIPChipBody(ctx: CanvasRenderingContext2D, comp: Component, bodyW: number, bodyH: number) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  // DIP body
  ctx.fillStyle = '#1c1f26';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(-bodyW / 2, -bodyH / 2, bodyW, bodyH, 3);
  ctx.fill();
  ctx.stroke();

  // Pin-1 orientation notch (top edge, real DIP chips all have one)
  ctx.beginPath();
  ctx.arc(0, -bodyH / 2, 6, 0, Math.PI);
  ctx.fillStyle = '#0f1115';
  ctx.fill();
  ctx.stroke();

  // Leads + pin numbers + labels, generic over whatever terminals are
  // defined (left column = negative dx, right column = positive dx)
  ctx.font = '7px "IBM Plex Mono", monospace';
  comp.terminals.forEach((t, i) => {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;
    const edgeX = t.dx < 0 ? -bodyW / 2 : bodyW / 2;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(edgeX, py);
    ctx.lineTo(px, py);
    ctx.stroke();

    ctx.fillStyle = COLORS.textDim;
    ctx.textAlign = t.dx < 0 ? 'left' : 'right';
    ctx.fillText(String(i + 1), edgeX + (t.dx < 0 ? 3 : -3), py - 3);

    ctx.fillStyle = COLORS.text;
    ctx.textAlign = t.dx < 0 ? 'right' : 'left';
    ctx.fillText(t.label, edgeX - (t.dx < 0 ? 3 : -3), py + 3);
  });
  // Caller continues drawing (chip label, live indicators) then must
  // call ctx.restore() itself.
}

// Small triangle op-amp symbol, purely decorative (the real electrical
// behavior lives in simulator.ts), so the chip reads as an op-amp at a
// glance instead of a generic black-box DIP.
function drawOpAmpTriangle(ctx: CanvasRenderingContext2D, cx: number, cy: number, w: number, h: number) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-w / 2, -h / 2);
  ctx.lineTo(-w / 2, h / 2);
  ctx.lineTo(w / 2, 0);
  ctx.closePath();
  ctx.stroke();
  ctx.fillStyle = COLORS.textDim;
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'left';
  ctx.fillText('+', -w / 2 + 2, h / 2 - 2);
  ctx.fillText('-', -w / 2 + 2, -h / 2 + 6);
  ctx.restore();
}

// LM741 - single op-amp, 8-pin DIP. Real pinout drawn generically from
// comp.terminals (see defaultTerminals.lm741). The live indicator shows
// the actual solved OUT voltage (color-coded: green mid-rail, amber near
// either supply rail = saturated), since this is an analog output, not a
// digital high/low like the NE555's.
function drawLM741Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  const bodyW = 80, bodyH = 76;
  drawDIPChipBody(ctx, comp, bodyW, bodyH);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 11px "IBM Plex Mono", monospace';
  ctx.fillText('741', 0, -22);
  drawOpAmpTriangle(ctx, 0, 2, 26, 22);

  const outV = typeof comp.state.outVoltage === 'number' ? comp.state.outVoltage as number : 0;
  const posSupply = (comp.props.positiveSupply as number) ?? 15;
  const negSupply = (comp.props.negativeSupply as number) ?? -15;
  const saturated = outV > posSupply - 1.6 || outV < negSupply + 1.6;
  ctx.beginPath();
  ctx.arc(0, 24, 3, 0, Math.PI * 2);
  ctx.fillStyle = saturated ? COLORS.highlight : COLORS.success;
  ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.4)';
  ctx.lineWidth = 0.5;
  ctx.stroke();
  ctx.fillStyle = COLORS.textDim;
  ctx.font = '6px "IBM Plex Mono", monospace';
  ctx.fillText(`${outV.toFixed(2)}V`, 0, 34);

  ctx.restore();
}

// LM358 - dual op-amp, 8-pin DIP. Same generic pinout rendering, but
// with two live indicators (one per internal amp) since the two halves
// have independent inputs/outputs sharing only the supply rails.
function drawLM358Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  const bodyW = 80, bodyH = 76;
  drawDIPChipBody(ctx, comp, bodyW, bodyH);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 10px "IBM Plex Mono", monospace';
  ctx.fillText('358', 0, -22);
  drawOpAmpTriangle(ctx, -14, 2, 18, 16);
  drawOpAmpTriangle(ctx, 14, 2, 18, 16);

  const posSupply = (comp.props.positiveSupply as number) ?? 5;
  const negSupply = (comp.props.negativeSupply as number) ?? 0;
  const out1 = typeof comp.state.out1Voltage === 'number' ? comp.state.out1Voltage as number : 0;
  const out2 = typeof comp.state.out2Voltage === 'number' ? comp.state.out2Voltage as number : 0;
  [out1, out2].forEach((outV, i) => {
    const x = i === 0 ? -14 : 14;
    const saturated = outV > posSupply - 1.6 || outV < negSupply + 0.05;
    ctx.beginPath();
    ctx.arc(x, 22, 2.5, 0, Math.PI * 2);
    ctx.fillStyle = saturated ? COLORS.highlight : COLORS.success;
    ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.4)';
    ctx.lineWidth = 0.5;
    ctx.stroke();
  });
  ctx.fillStyle = COLORS.textDim;
  ctx.font = '6px "IBM Plex Mono", monospace';
  ctx.fillText(`${out1.toFixed(1)}V / ${out2.toFixed(1)}V`, 0, 34);

  ctx.restore();
}

// L293D - dual H-bridge driver, 16-pin DIP. Real pinout drawn generically
// via drawDIPChipBody (see defaultTerminals.l293d). The two CH1/CH2
// readouts reflect this tick's actual driven direction/enable state
// (computed in updateComponentState() from the wired IN/EN pins, one
// tick delayed the same way the NE555's OUT is - see the comment on
// defaultProperties.l293d), not a scripted animation.
function drawL293DBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  const bodyW = 90, bodyH = 170;
  drawDIPChipBody(ctx, comp, bodyW, bodyH);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 11px "IBM Plex Mono", monospace';
  ctx.fillText('L293D', 0, -6);

  const ch1Enabled = !!comp.state.ch1Enabled;
  const ch1Dir = (comp.state.ch1Direction as number) || 0;
  const ch2Enabled = !!comp.state.ch2Enabled;
  const ch2Dir = (comp.state.ch2Direction as number) || 0;
  const dirLabel = (en: boolean, dir: number) => !en ? 'OFF' : dir > 0 ? 'FWD' : dir < 0 ? 'REV' : 'STOP';
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = ch1Enabled && ch1Dir !== 0 ? COLORS.success : COLORS.textDim;
  ctx.fillText(`CH1: ${dirLabel(ch1Enabled, ch1Dir)}`, 0, 10);
  ctx.fillStyle = ch2Enabled && ch2Dir !== 0 ? COLORS.success : COLORS.textDim;
  ctx.fillText(`CH2: ${dirLabel(ch2Enabled, ch2Dir)}`, 0, 20);

  ctx.restore();
}

// L298N - dual H-bridge driver module, the real-world form factor this
// chip almost always ships as (screw-terminal power/motor block + an
// ENA/IN1-4/ENB control header), rather than the bare 15-pin Multiwatt
// package. Same one-tick-delayed direction/enable readout as the L293D.
function drawL298NBody(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);
  ctx.rotate(comp.rotation * Math.PI / 2);

  const boardW = 150, boardH = 90;

  // Green PCB, distinct from the blue Arduino-style boards elsewhere
  ctx.fillStyle = '#1a5c2e';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.lineWidth = 1.5;
  ctx.fillRect(-boardW / 2, -boardH / 2, boardW, boardH);
  ctx.strokeRect(-boardW / 2, -boardH / 2, boardW, boardH);

  // IC block in the middle, standing in for the L298N chip itself
  // (which sits under a black heatsink on the real board)
  ctx.fillStyle = '#1c1f26';
  ctx.strokeStyle = COLORS.componentStroke;
  ctx.beginPath();
  ctx.rect(-26, -18, 52, 36);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 9px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('L298N', 0, 4);

  const ch1Enabled = !!comp.state.ch1Enabled;
  const ch1Dir = (comp.state.ch1Direction as number) || 0;
  const ch2Enabled = !!comp.state.ch2Enabled;
  const ch2Dir = (comp.state.ch2Direction as number) || 0;
  const dirLabel = (en: boolean, dir: number) => !en ? 'OFF' : dir > 0 ? 'FWD' : dir < 0 ? 'REV' : 'STOP';
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = ch1Enabled && ch1Dir !== 0 ? COLORS.success : COLORS.textDim;
  ctx.fillText(dirLabel(ch1Enabled, ch1Dir), -13, -24);
  ctx.fillStyle = ch2Enabled && ch2Dir !== 0 ? COLORS.success : COLORS.textDim;
  ctx.fillText(dirLabel(ch2Enabled, ch2Dir), 13, -24);

  ctx.fillStyle = COLORS.textDim;
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('MOTOR DRIVER MODULE', 0, -boardH / 2 - 6);

  // Pin leads + labels: side pins (|dx| >= 3.5) are the OUT screw
  // terminals, everything else is a top/bottom header/terminal-block pin.
  ctx.font = '6.5px "IBM Plex Mono", monospace';
  for (const t of comp.terminals) {
    const px = t.dx * GRID_SIZE;
    const py = t.dy * GRID_SIZE;

    ctx.strokeStyle = COLORS.componentStroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    if (Math.abs(t.dx) >= 3.5) {
      const edgeX = t.dx > 0 ? boardW / 2 : -boardW / 2;
      ctx.moveTo(edgeX, py);
      ctx.lineTo(px, py);
      ctx.stroke();
      ctx.fillStyle = COLORS.text;
      ctx.textAlign = t.dx > 0 ? 'left' : 'right';
      ctx.fillText(t.label, px + (t.dx > 0 ? 3 : -3), py + 2);
    } else {
      const edgeY = t.dy > 0 ? boardH / 2 : -boardH / 2;
      ctx.moveTo(px, edgeY);
      ctx.lineTo(px, py);
      ctx.stroke();
      ctx.fillStyle = COLORS.text;
      ctx.textAlign = 'center';
      ctx.fillText(t.label, px, py + (t.dy > 0 ? 10 : -6));
    }
  }

  ctx.restore();
}

// ULN2003 - 7-channel Darlington transistor array, 16-pin DIP. Real
// pinout drawn generically via drawDIPChipBody (see defaultTerminals.uln2003):
// IN1-IN7 down the left side, GND at the bottom-left corner, then COM
// (common flyback-diode cathode, tied to the load supply) and OUT7-OUT1
// back up the right side - matching the actual datasheet pin order. Each
// channel is an independent open-collector low-side switch (not an
// H-bridge like the L293D/L298N above): driving an IN pin high saturates
// that Darlington pair, sinking its OUT pin to near 0V; driving it low
// turns the pair off and OUT floats back up toward COM through whatever
// relay coil/stepper winding is wired there. The seven small indicators
// reflect each channel's actual decoded on/off state from
// updateComponentState() (one-tick delayed, same pattern as the L293D's
// CH1/CH2 readout), not a scripted animation.
function drawULN2003Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  const bodyW = 90, bodyH = 170;
  drawDIPChipBody(ctx, comp, bodyW, bodyH);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 11px "IBM Plex Mono", monospace';
  ctx.fillText('ULN2003', 0, -bodyH / 2 + 16);
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText('DARLINGTON ARRAY', 0, -bodyH / 2 + 26);

  const onKeys = ['out1On', 'out2On', 'out3On', 'out4On', 'out5On', 'out6On', 'out7On'];
  const dotSpacing = 11;
  const startY = -((onKeys.length - 1) * dotSpacing) / 2;
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  onKeys.forEach((key, i) => {
    const on = !!comp.state[key];
    const y = startY + i * dotSpacing;
    ctx.beginPath();
    ctx.arc(-14, y, 3, 0, Math.PI * 2);
    ctx.fillStyle = on ? COLORS.success : COLORS.textDim;
    ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.4)';
    ctx.lineWidth = 0.5;
    ctx.stroke();
    ctx.fillStyle = on ? COLORS.success : COLORS.textDim;
    ctx.textAlign = 'left';
    ctx.fillText(`${i + 1}`, -8, y + 2.5);
  });

  ctx.restore();
}

// 74HC595 - 8-bit serial-in/parallel-out shift register with output
// latch, 16-pin DIP. Real pinout drawn generically via drawDIPChipBody
// (see defaultTerminals['74hc595']): Q1-Q7 down the left side from GND,
// then MR/SH_CP/ST_CP/OE/DS/Q0 back up the right side to VCC - matching
// the actual datasheet pin order. The 8 small indicators show the
// currently latched Q0-Q7 output levels (post-ST_CP-latch, OE-gated),
// computed in updateComponentState() from real rising-edge-clocked shift
// register logic (not a scripted animation) - same one-tick-delayed
// stamp/decode split used by every other sequential IC in this file.
function draw74HC595Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  const bodyW = 90, bodyH = 170;
  drawDIPChipBody(ctx, comp, bodyW, bodyH);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 10px "IBM Plex Mono", monospace';
  ctx.fillText('74HC595', 0, -bodyH / 2 + 16);
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText('SIPO SHIFT REG', 0, -bodyH / 2 + 26);

  const qKeys = ['q0', 'q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7'];
  const dotSpacing = 10;
  const startY = -((qKeys.length - 1) * dotSpacing) / 2;
  ctx.font = 'bold 6.5px "IBM Plex Mono", monospace';
  qKeys.forEach((key, i) => {
    const on = !!comp.state[key];
    const y = startY + i * dotSpacing;
    ctx.beginPath();
    ctx.arc(-14, y, 2.8, 0, Math.PI * 2);
    ctx.fillStyle = on ? COLORS.success : COLORS.textDim;
    ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.4)';
    ctx.lineWidth = 0.5;
    ctx.stroke();
    ctx.fillStyle = on ? COLORS.success : COLORS.textDim;
    ctx.textAlign = 'left';
    ctx.fillText(`Q${i}`, -8, y + 2.3);
  });

  ctx.restore();
}

// 74HC165 - 8-bit parallel-in/serial-out shift register, 16-pin DIP.
// Real pinout drawn generically via drawDIPChipBody (see
// defaultTerminals['74hc165']): SH/LD-CLK-D4-D7-QH' down the left side
// from GND, then CLK INH/SER/D0-D3/QH back up the right side to VCC -
// matching the actual datasheet pin order. QH (and its complement QH')
// reflect the actual current shift-register output bit, computed in
// updateComponentState() from real parallel-load/rising-edge-clocked
// logic - same one-tick-delayed stamp/decode split as the 74HC595 above.
function draw74HC165Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  const bodyW = 90, bodyH = 170;
  drawDIPChipBody(ctx, comp, bodyW, bodyH);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 10px "IBM Plex Mono", monospace';
  ctx.fillText('74HC165', 0, -bodyH / 2 + 16);
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText('PISO SHIFT REG', 0, -bodyH / 2 + 26);

  const qH = !!comp.state.qH;
  const loading = !!comp.state.loading;
  ctx.font = 'bold 8px "IBM Plex Mono", monospace';
  ctx.fillStyle = loading ? COLORS.highlight : COLORS.textDim;
  ctx.fillText(loading ? 'LOAD' : 'SHIFT', 0, 4);
  ctx.beginPath();
  ctx.arc(0, 16, 3.5, 0, Math.PI * 2);
  ctx.fillStyle = qH ? COLORS.success : COLORS.textDim;
  ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.4)';
  ctx.lineWidth = 0.5;
  ctx.stroke();
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText(`QH: ${qH ? 'H' : 'L'}`, 0, 30);

  ctx.restore();
}

// CD4017 - 5-stage Johnson decade counter/divider with 10 decoded
// outputs, 16-pin DIP. Real pinout drawn generically via drawDIPChipBody
// (see defaultTerminals.cd4017): Q5-Q1-Q0-Q2-Q6-Q7-Q3 down the left side
// from VDD, GND at the bottom-left corner, then Q8-Q9-Q4-CARRY OUT-CLOCK
// INHIBIT-CLOCK-RESET back up the right side to VDD - matching the
// actual datasheet pin order (note the non-sequential Q pin numbering,
// a real quirk of this chip's Johnson-code internal layout). Exactly one
// of Q0-Q9 is high at a time; the lit dot reflects the real counter
// state computed in updateComponentState() below from actual
// rising-edge-clocked Johnson-counter logic (one-tick delayed, same
// pattern as every other sequential IC in this file), not a scripted
// animation.
function drawCD4017Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  const bodyW = 90, bodyH = 170;
  drawDIPChipBody(ctx, comp, bodyW, bodyH);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 11px "IBM Plex Mono", monospace';
  ctx.fillText('CD4017', 0, -bodyH / 2 + 16);
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText('JOHNSON COUNTER', 0, -bodyH / 2 + 26);

  const count = ((comp.state.count as number) ?? 0) | 0;
  const dotSpacing = 11;
  const startY = -((5 - 1) * dotSpacing) / 2;
  ctx.font = 'bold 7px "IBM Plex Mono", monospace';
  for (let col = 0; col < 2; col++) {
    for (let row = 0; row < 5; row++) {
      const q = col * 5 + row;
      const on = count === q;
      const x = col === 0 ? -16 : 16;
      const y = startY + row * dotSpacing;
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fillStyle = on ? COLORS.success : COLORS.textDim;
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.4)';
      ctx.lineWidth = 0.5;
      ctx.stroke();
      ctx.fillStyle = on ? COLORS.success : COLORS.textDim;
      ctx.textAlign = col === 0 ? 'left' : 'right';
      ctx.fillText(`Q${q}`, x + (col === 0 ? 6 : -6), y + 2.5);
    }
  }

  ctx.restore();
}

// CD4026 - 5-stage Johnson decade counter with a built-in Johnson-to-
// 7-segment decoder, 16-pin DIP. Real pinout drawn generically via
// drawDIPChipBody (see defaultTerminals.cd4026): CLOCK-CLOCK INHIBIT-
// DISPLAY ENABLE IN-DISPLAY ENABLE OUT-CARRY OUT-g-f down the left side
// from VDD, GND at the bottom-left corner, then d-a-e-b-c-"not 2" (the
// ungated C segment)-RESET back up the right side to VDD - matching the
// actual datasheet pin order. The rendered 7-segment digit mirrors the
// real a-g decoded segment outputs computed in updateComponentState()
// below from actual rising-edge-clocked Johnson-counter + decoder logic
// (one-tick delayed, same pattern as every other sequential IC in this
// file), gated by DISPLAY ENABLE IN exactly like the real part.
function drawCD4026Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  const bodyW = 90, bodyH = 170;
  drawDIPChipBody(ctx, comp, bodyW, bodyH);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 11px "IBM Plex Mono", monospace';
  ctx.fillText('CD4026', 0, -bodyH / 2 + 16);
  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText('7-SEG COUNTER', 0, -bodyH / 2 + 26);

  // Mini 7-segment readout of the current decoded a-g outputs.
  const segOn = (k: string) => !!comp.state[k];
  const segW = 22, segH = 34;
  const cx = 0, cy = 6;
  const onColor = COLORS.success, offColor = 'rgba(255,255,255,0.12)';
  const drawSeg = (key: 'a' | 'b' | 'c' | 'd' | 'e' | 'f' | 'g') => {
    ctx.fillStyle = segOn(key) ? onColor : offColor;
    ctx.beginPath();
    const t = 2.2; // segment thickness
    switch (key) {
      case 'a': ctx.rect(cx - segW / 2 + t, cy - segH - t / 2, segW - 2 * t, t); break;
      case 'g': ctx.rect(cx - segW / 2 + t, cy - segH / 2 - t / 2, segW - 2 * t, t); break;
      case 'd': ctx.rect(cx - segW / 2 + t, cy - t / 2, segW - 2 * t, t); break;
      case 'f': ctx.rect(cx - segW / 2, cy - segH - t / 2, t, segH / 2 + t); break;
      case 'b': ctx.rect(cx + segW / 2 - t, cy - segH - t / 2, t, segH / 2 + t); break;
      case 'e': ctx.rect(cx - segW / 2, cy - segH / 2 - t / 2, t, segH / 2 + t); break;
      case 'c': ctx.rect(cx + segW / 2 - t, cy - segH / 2 - t / 2, t, segH / 2 + t); break;
    }
    ctx.fill();
  };
  (['a', 'b', 'c', 'd', 'e', 'f', 'g'] as const).forEach(drawSeg);

  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.textAlign = 'center';
  const displayEnabled = !!comp.state.displayEnabled;
  ctx.fillText(displayEnabled ? `DIGIT: ${(comp.state.count as number) ?? 0}` : 'DISPLAY OFF', 0, bodyH / 2 - 34);

  ctx.restore();
}

// PC817 - single-channel optocoupler/optoisolator, 4-pin DIP. Real
// pinout drawn generically via drawDIPChipBody (see
// defaultTerminals.pc817): pin 1 = Anode (IR LED), pin 2 = Cathode (IR
// LED), pin 3 = Emitter (phototransistor), pin 4 = Collector
// (phototransistor) - matching the actual datasheet pin order. The LED
// side (pins 1-2) and phototransistor side (pins 3-4) are drawn as two
// visually separate halves with a dashed isolation barrier between them
// to make the point of this part obvious at a glance: there is no wire
// connecting the two sides anywhere in the simulator, only an optical
// coupling (see simulateDC()'s LED-current threshold driving
// buildNets()'s union of the Collector/Emitter terminals, exactly the
// same isolated-contact pattern the Relay uses for its coil/contacts).
// The lit lens glyph and closed-switch glyph both reflect the real,
// one-tick-delayed `ledOn`/`transistorOn` state computed in
// updateComponentState() below - not a scripted animation.
function drawPC817Body(ctx: CanvasRenderingContext2D, comp: Component, _isHovered: boolean) {
  const bodyW = 70, bodyH = 60;
  drawDIPChipBody(ctx, comp, bodyW, bodyH);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 10px "IBM Plex Mono", monospace';
  ctx.fillText('PC817', 0, -bodyH / 2 + 16);

  // Dashed vertical isolation barrier between the LED (left) and
  // phototransistor (right) halves.
  ctx.save();
  ctx.strokeStyle = COLORS.textDim;
  ctx.lineWidth = 1;
  ctx.setLineDash([2, 2]);
  ctx.beginPath();
  ctx.moveTo(0, -bodyH / 2 + 22);
  ctx.lineTo(0, bodyH / 2 - 6);
  ctx.stroke();
  ctx.restore();

  const ledOn = !!comp.state.ledOn;
  const transistorOn = !!comp.state.transistorOn;

  // LED glyph (left half): a small triangle-diode + glowing lens.
  ctx.save();
  ctx.translate(-16, 6);
  ctx.beginPath();
  ctx.arc(0, 0, 6, 0, Math.PI * 2);
  ctx.fillStyle = ledOn ? '#ff5a3c' : 'rgba(255,90,60,0.15)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.4)';
  ctx.lineWidth = 0.5;
  ctx.stroke();
  if (ledOn) {
    // Little emitted-light rays to sell the "optical" part of the coupling.
    ctx.strokeStyle = 'rgba(255,90,60,0.6)';
    ctx.lineWidth = 1;
    for (const dx of [8, 11, 14]) {
      ctx.beginPath();
      ctx.moveTo(dx, -3);
      ctx.lineTo(dx + 3, -3);
      ctx.moveTo(dx, 3);
      ctx.lineTo(dx + 3, 3);
      ctx.stroke();
    }
  }
  ctx.restore();

  // Phototransistor glyph (right half): open/closed switch dot.
  ctx.save();
  ctx.translate(16, 6);
  ctx.beginPath();
  ctx.arc(0, 0, 6, 0, Math.PI * 2);
  ctx.fillStyle = transistorOn ? COLORS.success : COLORS.textDim;
  ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.4)';
  ctx.lineWidth = 0.5;
  ctx.stroke();
  ctx.restore();

  ctx.font = '7px "IBM Plex Mono", monospace';
  ctx.fillStyle = COLORS.textDim;
  ctx.textAlign = 'center';
  ctx.fillText(transistorOn ? 'C-E: ON' : 'C-E: OFF', 0, bodyH / 2 - 8);

  ctx.restore();
}

export const defaultProperties: Record<string, PropertyDef[]> = {
  battery: [
    { name: 'Voltage', key: 'voltage', type: 'number', unit: 'V', min: 0.1, max: 500, step: 0.1, defaultValue: 9 },
    { name: 'Internal Resistance', key: 'internalR', type: 'number', unit: 'Ω', min: 0, max: 100, step: 0.001, defaultValue: 0.001 },
  ],
  resistor: [
    { name: 'Resistance', key: 'resistance', type: 'number', unit: 'Ω', min: 0.001, max: 1000000000, step: 1, defaultValue: 1000 },
  ],
  capacitor: [
    { name: 'Capacitance', key: 'capacitance', type: 'number', unit: 'F', min: 1e-15, max: 100, step: 1e-12, defaultValue: 1e-6 },
  ],
  inductor: [
    { name: 'Inductance', key: 'inductance', type: 'number', unit: 'H', min: 1e-12, max: 1000, step: 1e-6, defaultValue: 1e-3 },
  ],
  fuse: [
    { name: 'Current Rating', key: 'currentRating', type: 'number', unit: 'A', min: 0.001, max: 1000, step: 0.1, defaultValue: 1 },
  ],
  polyfuse: [
    // Real PTC resettable fuses (e.g. Littelfuse Nanosmdc/Multifuse) sit at
    // a small, non-zero "cold" resistance well under Hold Current, self-heat
    // into a high-resistance trip state once current climbs past Trip
    // Current, and stay there (clamping current to a low trickle, not zero)
    // until the fault clears and it's had time to cool back down - unlike a
    // one-shot Fuse, it then resets on its own instead of needing replacement.
    { name: 'Hold Current', key: 'holdCurrent', type: 'number', unit: 'A', min: 0.01, max: 40, step: 0.01, defaultValue: 1 },
    { name: 'Trip Current', key: 'tripCurrent', type: 'number', unit: 'A', min: 0.01, max: 80, step: 0.01, defaultValue: 2 },
    { name: 'Cold Resistance', key: 'coldResistance', type: 'number', unit: 'Ω', min: 0.001, max: 10, step: 0.001, defaultValue: 0.15 },
    { name: 'Tripped Resistance', key: 'trippedResistance', type: 'number', unit: 'Ω', min: 1, max: 100000, step: 1, defaultValue: 4000 },
    // Real PTCs take seconds to cool back below Hold Current once the
    // fault clears - modeled as a cooldown timer (rather than an instant
    // reset) that flips it back to cold resistance once elapsed; if the
    // fault is still there, the very next solve immediately re-trips it,
    // matching the "nuisance cycling" a real PTC shows under a sustained
    // fault.
    { name: 'Reset Time', key: 'resetTimeMs', type: 'number', unit: 'ms', min: 100, max: 60000, step: 100, defaultValue: 3000 },
  ],
  // BJT switching model: the Base-Emitter junction is a real forward-biased
  // diode (same exponential junction equation as diode/led/pc817 - see the
  // stamp in simulator.ts), and once its current crosses Base Turn-On
  // Current the Collector-Emitter path is driven into saturation (unioned
  // into one net, same one-tick-delayed switch pattern the PC817
  // optocoupler and Relay already use elsewhere in this file) applied to a
  // real 3-terminal BJT instead of an optically/magnetically isolated
  // contact.
  transistorNpn: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [
      { label: '2N3904', value: '2N3904' }, { label: 'BC547', value: 'BC547' }, { label: 'S8050', value: 'S8050' },
    ], defaultValue: '2N3904' },
    { name: 'Current Gain (hFE)', key: 'beta', type: 'number', min: 10, max: 1000, step: 1, defaultValue: 200 },
    { name: 'Base-Emitter Turn-On Voltage', key: 'vBEon', type: 'number', unit: 'V', min: 0.3, max: 1, step: 0.01, defaultValue: 0.65 },
    { name: 'Base Turn-On Current', key: 'baseTurnOnCurrent', type: 'number', unit: 'mA', min: 0.001, max: 50, step: 0.001, defaultValue: 0.1 },
    { name: 'Max Collector Current', key: 'maxCollectorCurrent', type: 'number', unit: 'mA', min: 1, max: 5000, step: 1, defaultValue: 200 },
  ],
  transistorPnp: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [
      { label: '2N3906', value: '2N3906' }, { label: 'BC557', value: 'BC557' }, { label: 'S8550', value: 'S8550' },
    ], defaultValue: '2N3906' },
    { name: 'Current Gain (hFE)', key: 'beta', type: 'number', min: 10, max: 1000, step: 1, defaultValue: 200 },
    { name: 'Base-Emitter Turn-On Voltage', key: 'vBEon', type: 'number', unit: 'V', min: 0.3, max: 1, step: 0.01, defaultValue: 0.65 },
    { name: 'Base Turn-On Current', key: 'baseTurnOnCurrent', type: 'number', unit: 'mA', min: 0.001, max: 50, step: 0.001, defaultValue: 0.1 },
    { name: 'Max Collector Current', key: 'maxCollectorCurrent', type: 'number', unit: 'mA', min: 1, max: 5000, step: 1, defaultValue: 200 },
  ],
  // TIP120/TIP122: NPN Darlington power transistors (TO-220). Two BJTs
  // cascaded internally means a much higher effective current gain and a
  // higher Base-Emitter turn-on voltage (two junction drops) than a
  // single small-signal BJT like the transistorNpn parts above - modeled
  // with the exact same saturation-switch stamp (see simulator.ts), just
  // with Darlington-appropriate defaults, so relay coils, small motors,
  // and higher-current LED strings can all be driven straight from a
  // logic/MCU pin without a separate base-driver stage.
  tip120: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'TIP120', value: 'TIP120' }], defaultValue: 'TIP120' },
    { name: 'Current Gain (hFE)', key: 'beta', type: 'number', min: 100, max: 20000, step: 10, defaultValue: 1000 },
    { name: 'Base-Emitter Turn-On Voltage', key: 'vBEon', type: 'number', unit: 'V', min: 0.3, max: 1, step: 0.01, defaultValue: 1 },
    { name: 'Base Turn-On Current', key: 'baseTurnOnCurrent', type: 'number', unit: 'mA', min: 0.001, max: 50, step: 0.001, defaultValue: 0.5 },
    { name: 'Max Collector Current', key: 'maxCollectorCurrent', type: 'number', unit: 'mA', min: 1, max: 5000, step: 1, defaultValue: 5000 },
  ],
  tip122: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'TIP122', value: 'TIP122' }], defaultValue: 'TIP122' },
    { name: 'Current Gain (hFE)', key: 'beta', type: 'number', min: 100, max: 20000, step: 10, defaultValue: 1000 },
    { name: 'Base-Emitter Turn-On Voltage', key: 'vBEon', type: 'number', unit: 'V', min: 0.3, max: 1, step: 0.01, defaultValue: 1 },
    { name: 'Base Turn-On Current', key: 'baseTurnOnCurrent', type: 'number', unit: 'mA', min: 0.001, max: 50, step: 0.001, defaultValue: 0.5 },
    { name: 'Max Collector Current', key: 'maxCollectorCurrent', type: 'number', unit: 'mA', min: 1, max: 5000, step: 1, defaultValue: 5000 },
  ],
  // N-channel power MOSFET switching model: the Gate draws no static
  // current (an ideal insulated gate, same zero-current assumption used
  // for the LM741/LM358 op-amp inputs elsewhere in this file) - only the
  // Gate-Source *voltage* matters. Once Vgs crosses Gate Threshold
  // Voltage, the Drain-Source channel is driven into full conduction
  // (unioned into one net, the same one-tick-delayed switch pattern the
  // BJTs/Relay/PC817 use above), letting it switch a PWM-driven motor
  // load the same way a relay or BJT would, but from a high-impedance
  // logic/PWM pin instead of a base-current-hungry one.
  irf520: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'IRF520', value: 'IRF520' }], defaultValue: 'IRF520' },
    { name: 'Gate Threshold Voltage', key: 'gateThresholdVoltage', type: 'number', unit: 'V', min: 0.5, max: 10, step: 0.1, defaultValue: 4 },
    { name: 'On Resistance (Rds-on)', key: 'rdsOn', type: 'number', unit: 'Ω', min: 0.001, max: 10, step: 0.001, defaultValue: 0.27 },
    { name: 'Max Drain Current', key: 'maxDrainCurrent', type: 'number', unit: 'A', min: 0.1, max: 100, step: 0.1, defaultValue: 9.2 },
    { name: 'Logic Level Gate', key: 'logicLevel', type: 'boolean', defaultValue: false },
  ],
  irf540: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'IRF540', value: 'IRF540' }, { label: 'IRF540N', value: 'IRF540N' }], defaultValue: 'IRF540N' },
    { name: 'Gate Threshold Voltage', key: 'gateThresholdVoltage', type: 'number', unit: 'V', min: 0.5, max: 10, step: 0.1, defaultValue: 4 },
    { name: 'On Resistance (Rds-on)', key: 'rdsOn', type: 'number', unit: 'Ω', min: 0.001, max: 10, step: 0.001, defaultValue: 0.044 },
    { name: 'Max Drain Current', key: 'maxDrainCurrent', type: 'number', unit: 'A', min: 0.1, max: 100, step: 0.1, defaultValue: 33 },
    { name: 'Logic Level Gate', key: 'logicLevel', type: 'boolean', defaultValue: false },
  ],
  irlz44n: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'IRLZ44N', value: 'IRLZ44N' }], defaultValue: 'IRLZ44N' },
    // Logic-level part: fully saturates from a 5V (even 3.3V-ish) MCU/PWM
    // pin, unlike the IRF520/IRF540 above which need a ~10V gate drive to
    // reach their datasheet Rds-on - hence the much lower threshold here.
    { name: 'Gate Threshold Voltage', key: 'gateThresholdVoltage', type: 'number', unit: 'V', min: 0.5, max: 10, step: 0.1, defaultValue: 1.5 },
    { name: 'On Resistance (Rds-on)', key: 'rdsOn', type: 'number', unit: 'Ω', min: 0.001, max: 10, step: 0.001, defaultValue: 0.022 },
    { name: 'Max Drain Current', key: 'maxDrainCurrent', type: 'number', unit: 'A', min: 0.1, max: 100, step: 0.1, defaultValue: 47 },
    { name: 'Logic Level Gate', key: 'logicLevel', type: 'boolean', defaultValue: true },
  ],
  barrelJack: [
    { name: 'Polarity', key: 'polarity', type: 'select', options: [{ label: 'Center Positive', value: 'Center Positive' }, { label: 'Center Negative', value: 'Center Negative' }], defaultValue: 'Center Positive' },
  ],
  screwTerminal2pin: [],
  jstConnector2pin: [],
  // Bare 4-pin passive breakout header (VCC/GND/TXD/RXD) - purely a
  // connector, same treatment as screwTerminal2pin/jstConnector2pin
  // above: no electrical model of its own, it just extends whatever net
  // is wired to each pin.
  uartHeader: [],
  // HC-05/HC-06 UART Bluetooth modules. TXD idles at the module's logic
  // level (real modules run their UART at 3.3V TTL even off a 5V VCC,
  // thanks to an onboard regulator/level-shifter) once Powered, and
  // STATE goes high once Connected (Paired) - mirrors a real HC-05's
  // STATE pin, which a host MCU commonly polls to detect an active
  // Bluetooth link. Baud Rate is exposed purely as a UART-communication
  // parameter (matches the AT+UART command both parts support) - it
  // doesn't affect the DC electrical model, only what a
  // serial-protocol-aware consumer would assume about the link.
  hc05: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'HC-05', value: 'HC-05' }], defaultValue: 'HC-05' },
    // HC-05 (unlike HC-06) can act as either Bluetooth Master or Slave -
    // the real hardware/firmware difference between the two parts.
    { name: 'Role', key: 'role', type: 'select', options: [{ label: 'Slave', value: 'Slave' }, { label: 'Master', value: 'Master' }], defaultValue: 'Slave' },
    { name: 'Baud Rate', key: 'baudRate', type: 'select', options: [
      { label: '9600', value: '9600' }, { label: '19200', value: '19200' }, { label: '38400', value: '38400' },
      { label: '57600', value: '57600' }, { label: '115200', value: '115200' }, { label: '230400', value: '230400' },
      { label: '460800', value: '460800' }, { label: '921600', value: '921600' },
    ], defaultValue: '9600' },
    { name: 'Logic Level', key: 'logicLevel', type: 'number', unit: 'V', min: 1.8, max: 5, step: 0.1, defaultValue: 3.3 },
    { name: 'Powered', key: 'powered', type: 'boolean', defaultValue: true },
    { name: 'Connected (Paired)', key: 'connected', type: 'boolean', defaultValue: false },
  ],
  // HC-06 is Slave-only (no Master role, no Role property to match) -
  // otherwise the same UART/STATE electrical behavior as HC-05 above.
  hc06: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'HC-06', value: 'HC-06' }], defaultValue: 'HC-06' },
    { name: 'Baud Rate', key: 'baudRate', type: 'select', options: [
      { label: '9600', value: '9600' }, { label: '19200', value: '19200' }, { label: '38400', value: '38400' },
      { label: '57600', value: '57600' }, { label: '115200', value: '115200' }, { label: '230400', value: '230400' },
      { label: '460800', value: '460800' }, { label: '921600', value: '921600' },
    ], defaultValue: '9600' },
    { name: 'Logic Level', key: 'logicLevel', type: 'number', unit: 'V', min: 1.8, max: 5, step: 0.1, defaultValue: 3.3 },
    { name: 'Powered', key: 'powered', type: 'boolean', defaultValue: true },
    { name: 'Connected (Paired)', key: 'connected', type: 'boolean', defaultValue: false },
  ],
  // ESP-01/ESP-01S ESP8266 Wi-Fi UART breakout. Like HC-05/06, TXD idles
  // at the module's own 3.3V logic level (the ESP8266 is NOT 5V tolerant
  // on its GPIOs - a real ESP-01 needs a level-shifter/divider on RXD from
  // a 5V host) once Powered. CH_PD (chip-enable, active high) and RST are
  // exposed as pins only (no extra electrical model - same treatment as
  // HC-05's EN/RXD, which are left unstamped/passive). Wi-Fi Connected is
  // tracked as a property (mirrors HC-05's "Connected (Paired)") but has
  // no dedicated status pin on a bare ESP-01, so it isn't stamped onto
  // any terminal - only surfaces via updateComponentState for the UI.
  esp8266: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'ESP-01', value: 'ESP-01' }, { label: 'ESP-01S', value: 'ESP-01S' }], defaultValue: 'ESP-01' },
    { name: 'Baud Rate', key: 'baudRate', type: 'select', options: [
      { label: '9600', value: '9600' }, { label: '19200', value: '19200' }, { label: '38400', value: '38400' },
      { label: '57600', value: '57600' }, { label: '74880', value: '74880' }, { label: '115200', value: '115200' },
    ], defaultValue: '115200' },
    { name: 'Logic Level', key: 'logicLevel', type: 'number', unit: 'V', min: 1.8, max: 3.6, step: 0.1, defaultValue: 3.3 },
    { name: 'Powered', key: 'powered', type: 'boolean', defaultValue: true },
    { name: 'Wi-Fi Connected', key: 'connected', type: 'boolean', defaultValue: false },
  ],
  // ESP32 (DevKit-style) Wi-Fi/BLE module, represented here as a 6-pin
  // UART breakout (VCC/GND/TXD/RXD/EN/IO0) - same simplification the
  // Arduino boards elsewhere in this file use for their programming
  // header. EN is the active-high reset/enable pin (silkscreened "EN" on
  // real ESP32 DevKits); IO0 is the strapping pin used to enter the
  // bootloader (pulled low at boot to flash). Electrically it behaves
  // the same as HC-05/ESP8266's TXD idle-line model above.
  esp32: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [
      { label: 'ESP32-WROOM-32', value: 'ESP32-WROOM-32' }, { label: 'ESP32-S3', value: 'ESP32-S3' },
    ], defaultValue: 'ESP32-WROOM-32' },
    { name: 'Baud Rate', key: 'baudRate', type: 'select', options: [
      { label: '9600', value: '9600' }, { label: '19200', value: '19200' }, { label: '38400', value: '38400' },
      { label: '57600', value: '57600' }, { label: '115200', value: '115200' }, { label: '921600', value: '921600' },
    ], defaultValue: '115200' },
    { name: 'Logic Level', key: 'logicLevel', type: 'number', unit: 'V', min: 1.8, max: 3.6, step: 0.1, defaultValue: 3.3 },
    { name: 'Powered', key: 'powered', type: 'boolean', defaultValue: true },
    { name: 'Wi-Fi Connected', key: 'connected', type: 'boolean', defaultValue: false },
  ],
  // NRF24L01(+) 2.4GHz SPI transceiver breakout. VCC/GND are power;
  // CE/CSN/SCK/MOSI/MISO are the standard SPI + chip-enable control
  // lines (left unstamped/passive, same as HC-05's RXD - a real SPI bus
  // is driven by the host MCU, not modeled as a DC source here). IRQ is
  // the module's one digital *output* - active-low, matching the real
  // chip: it idles high (module's own 3.3V logic level) and is pulled
  // low once Data Ready (RX_DR/TX_DS/MAX_RT) is asserted, exactly like
  // HC-05's STATE pin idles low and goes active once Connected.
  nrf24l01: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'NRF24L01', value: 'NRF24L01' }, { label: 'NRF24L01+', value: 'NRF24L01+' }], defaultValue: 'NRF24L01+' },
    { name: 'Channel', key: 'channel', type: 'number', min: 0, max: 125, step: 1, defaultValue: 76 },
    { name: 'Data Rate', key: 'dataRate', type: 'select', options: [
      { label: '250 kbps', value: '250kbps' }, { label: '1 Mbps', value: '1Mbps' }, { label: '2 Mbps', value: '2Mbps' },
    ], defaultValue: '1Mbps' },
    { name: 'Logic Level', key: 'logicLevel', type: 'number', unit: 'V', min: 1.8, max: 3.6, step: 0.1, defaultValue: 3.3 },
    { name: 'Powered', key: 'powered', type: 'boolean', defaultValue: true },
    { name: 'Data Ready (IRQ)', key: 'dataReady', type: 'boolean', defaultValue: false },
  ],
  // RC522 (MFRC522) 13.56MHz SPI RFID reader/writer breakout. MISO
  // (the module's one SPI data output to the host) idles at the
  // module's Logic Level once Powered - same treatment as NRF24L01's
  // IRQ/MAX485's RO above - and is only meaningfully driven by the
  // module during an active SPI transfer (CS/SDA low), which this DC
  // model approximates as "driven whenever Powered", matching how
  // NRF24L01's IRQ line above is idled rather than tri-stated. "Test
  // Card" offers a few preset UIDs (as printed on common MFRC522 kit
  // cards/keyfobs) plus a Custom option; "Card UID" is the actual
  // manually-editable value a testbench sketch would read back over
  // SPI via the Arduino MFRC522 library, and is freely editable
  // regardless of which Test Card is selected.
  rc522: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'MFRC522', value: 'MFRC522' }], defaultValue: 'MFRC522' },
    { name: 'Logic Level', key: 'logicLevel', type: 'number', unit: 'V', min: 1.8, max: 3.6, step: 0.1, defaultValue: 3.3 },
    { name: 'Powered', key: 'powered', type: 'boolean', defaultValue: true },
    { name: 'Card Present', key: 'cardPresent', type: 'boolean', defaultValue: true },
    { name: 'Test Card', key: 'testCard', type: 'select', options: [
      { label: 'Card 1', value: 'card1' }, { label: 'Card 2', value: 'card2' }, { label: 'Keyfob', value: 'keyfob' }, { label: 'Custom', value: 'custom' },
    ], defaultValue: 'card1' },
    { name: 'Card UID', key: 'cardUid', type: 'string', defaultValue: '04 A3 9F 1B' },
  ],
  // MAX485 RS-485 half-duplex transceiver breakout. RO (receiver output)
  // is the module's one digital *output* to the host UART - idles at the
  // module's logic level once Powered, matching the HC-05/ESP8266 TXD
  // idle-line model above, and is only meaningfully driven while RE is
  // asserted (receive enabled); "Bus Idle High" mirrors a quiescent
  // RS-485 bus (no other node driving), same treatment as NRF24L01's
  // Data Ready. RE/DE/DI/A/B are left unstamped/passive (host- or
  // bus-driven), same as HC-05's RXD.
  max485: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'MAX485', value: 'MAX485' }, { label: 'MAX3485', value: 'MAX3485' }], defaultValue: 'MAX485' },
    { name: 'Logic Level', key: 'logicLevel', type: 'number', unit: 'V', min: 1.8, max: 5, step: 0.1, defaultValue: 5 },
    { name: 'Powered', key: 'powered', type: 'boolean', defaultValue: true },
    { name: 'Bus Idle High', key: 'busIdleHigh', type: 'boolean', defaultValue: true },
  ],
  // MCP2515+TJA1050-style CAN bus breakout (SPI controller + transceiver
  // on one module). INT is the module's one digital *output* -
  // active-low, open-drain with the module's own pull-up, idling high
  // (module's logic level) once Powered and pulled low once a message is
  // pending - exactly the same active-low idle-high pattern as
  // NRF24L01's IRQ above. CS/SO/SI/SCK are the standard SPI lines, left
  // unstamped/passive (host-driven), same as NRF24L01's SPI pins.
  canBusModule: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'MCP2515', value: 'MCP2515' }], defaultValue: 'MCP2515' },
    { name: 'Bit Rate', key: 'bitRate', type: 'select', options: [
      { label: '125 kbps', value: '125kbps' }, { label: '250 kbps', value: '250kbps' }, { label: '500 kbps', value: '500kbps' }, { label: '1 Mbps', value: '1Mbps' },
    ], defaultValue: '500kbps' },
    { name: 'Logic Level', key: 'logicLevel', type: 'number', unit: 'V', min: 1.8, max: 5, step: 0.1, defaultValue: 5 },
    { name: 'Powered', key: 'powered', type: 'boolean', defaultValue: true },
    { name: 'Message Pending (INT)', key: 'messagePending', type: 'boolean', defaultValue: false },
  ],
  // Passive 4-pin I2C breakout header (VCC/GND/SDA/SCL) - a bare header,
  // not a component with its own electrical model. Same treatment as
  // uartHeader above: no voltage-source stamp, terminals only.
  i2cHeader: [],
  // GPS NEO-6M UART GPS receiver module. TX idles at the module's Logic
  // Level (a real NEO-6M breakout runs 3.3V TTL UART off its onboard
  // regulator, same treatment as HC-05/06 above) once Powered and a Fix
  // has been Acquired, referenced to GND. RX is a passive input (not
  // stamped), same as HC-05/06's RXD. Latitude/Longitude/Speed/Altitude
  // are exposed as manually-editable fields (no live NMEA parsing here)
  // so a user can drive the simulated fix data directly, matching how
  // this module is meant to be exercised in a testbench circuit.
  gpsNeo6m: [
    { name: 'Part Number', key: 'partNumber', type: 'select', options: [{ label: 'NEO-6M', value: 'NEO-6M' }], defaultValue: 'NEO-6M' },
    { name: 'Baud Rate', key: 'baudRate', type: 'select', options: [
      { label: '4800', value: '4800' }, { label: '9600', value: '9600' }, { label: '19200', value: '19200' },
      { label: '38400', value: '38400' }, { label: '57600', value: '57600' }, { label: '115200', value: '115200' },
    ], defaultValue: '9600' },
    { name: 'Logic Level', key: 'logicLevel', type: 'number', unit: 'V', min: 1.8, max: 5, step: 0.1, defaultValue: 3.3 },
    { name: 'Powered', key: 'powered', type: 'boolean', defaultValue: true },
    { name: 'Fix Acquired', key: 'fixAcquired', type: 'boolean', defaultValue: true },
    { name: 'Latitude', key: 'latitude', type: 'number', unit: '°', min: -90, max: 90, step: 0.000001, defaultValue: 37.7749 },
    { name: 'Longitude', key: 'longitude', type: 'number', unit: '°', min: -180, max: 180, step: 0.000001, defaultValue: -122.4194 },
    { name: 'Speed', key: 'speed', type: 'number', unit: 'km/h', min: 0, max: 1000, step: 0.1, defaultValue: 0 },
    { name: 'Altitude', key: 'altitude', type: 'number', unit: 'm', min: -500, max: 20000, step: 0.1, defaultValue: 0 },
  ],
  switch: [
    { name: 'Closed', key: 'closed', type: 'boolean', defaultValue: false },
  ],
  pushButton: [
    { name: 'Normally Open', key: 'normallyOpen', type: 'boolean', defaultValue: true },
  ],
  diode: [],
  led: [
    { name: 'Forward Voltage', key: 'forwardVoltage', type: 'number', unit: 'V', min: 0.5, max: 5, step: 0.1, defaultValue: 2 },
    { name: 'Max Current', key: 'maxCurrent', type: 'number', unit: 'mA', min: 1, max: 1000, step: 1, defaultValue: 20 },
    { name: 'Color', key: 'color', type: 'select', options: [{ label: 'Red', value: '#ff0000' }, { label: 'Green', value: '#00ff00' }, { label: 'Blue', value: '#0000ff' }, { label: 'Yellow', value: '#ffff00' }, { label: 'White', value: '#ffffff' }], defaultValue: '#ff0000' },
  ],
  zenerDiode: [
    { name: 'Zener Voltage', key: 'zenerVoltage', type: 'number', unit: 'V', min: 0.1, max: 200, step: 0.1, defaultValue: 5.1 },
  ],
  variableResistor: [
    { name: 'Max Resistance', key: 'resistance', type: 'number', unit: 'Ω', min: 1, max: 10000000, step: 1, defaultValue: 10000 },
    { name: 'Wiper Position', key: 'wiperPosition', type: 'number', min: 0, max: 1, step: 0.01, defaultValue: 0.5 },
  ],
  potentiometer: [
    { name: 'Max Resistance', key: 'resistance', type: 'number', unit: 'Ω', min: 1, max: 10000000, step: 1, defaultValue: 10000 },
    { name: 'Wiper Position', key: 'wiperPosition', type: 'number', min: 0, max: 1, step: 0.01, defaultValue: 0.5 },
  ],
  relay: [
    { name: 'Coil Voltage', key: 'coilVoltage', type: 'number', unit: 'V', min: 1, max: 240, step: 1, defaultValue: 5 },
    { name: 'Contact Rating', key: 'contactRating', type: 'number', unit: 'A', min: 0.1, max: 100, step: 0.1, defaultValue: 5 },
  ],
  relayModule: [
    { name: 'Coil Voltage', key: 'coilVoltage', type: 'number', unit: 'V', min: 1, max: 24, step: 0.5, defaultValue: 5 },
    { name: 'Contact Rating', key: 'contactRating', type: 'number', unit: 'A', min: 0.1, max: 100, step: 0.1, defaultValue: 10 },
    // Real relays don't switch the instant the coil is commanded — the
    // armature takes a few ms to physically pull in/drop out. Board-level
    // "modules" are the natural place to expose that, since the bare relay
    // above is treated as an idealized/instant part.
    { name: 'Switching Delay', key: 'switchingDelay', type: 'number', unit: 'ms', min: 0, max: 200, step: 1, defaultValue: 10 },
  ],
  solenoidValve: [
    { name: 'Voltage', key: 'voltage', type: 'number', unit: 'V', min: 3, max: 240, step: 1, defaultValue: 12 },
    { name: 'Coil Resistance', key: 'coilResistance', type: 'number', unit: 'Ω', min: 1, max: 1000, step: 1, defaultValue: 24 },
    {
      name: 'Pipe Size', key: 'pipeSize', type: 'presetNumber', unit: 'mm',
      presets: [6, 8, 10, 12, 15, 20, 25, 32],
      min: 3, max: 100, step: 1, defaultValue: 12,
    },
  ],
  dcMotor: [
    { name: 'Rated Voltage', key: 'ratedVoltage', type: 'number', unit: 'V', min: 1, max: 500, step: 0.1, defaultValue: 12 },
    { name: 'Coil Resistance', key: 'coilResistance', type: 'number', unit: 'Ω', min: 0.1, max: 10000, step: 0.1, defaultValue: 10 },
  ],
  waterPump: [
    {
      name: 'Horse Power', key: 'horsePower', type: 'presetNumber', unit: 'HP',
      presets: [0.25, 0.5, 0.75, 1, 1.5, 2, 3, 5],
      min: 0.05, max: 50, step: 0.05, defaultValue: 0.5,
    },
    { name: 'Voltage', key: 'voltage', type: 'number', unit: 'V', min: 1, max: 500, step: 0.1, defaultValue: 12 },
    { name: 'Rated Current', key: 'ratedCurrent', type: 'number', unit: 'A', min: 0.01, max: 200, step: 0.01, defaultValue: 3 },
    { name: 'Flow Rate', key: 'flowRate', type: 'number', unit: 'L/min', min: 0.1, max: 100000, step: 0.1, defaultValue: 20 },
    { name: 'Maximum Head', key: 'maxHead', type: 'number', unit: 'm', min: 0.1, max: 1000, step: 0.1, defaultValue: 5 },
    { name: 'RPM', key: 'ratedRpm', type: 'number', unit: 'rpm', min: 1, max: 30000, step: 1, defaultValue: 3000 },
    { name: 'Efficiency', key: 'efficiency', type: 'number', unit: '%', min: 1, max: 100, step: 1, defaultValue: 65 },
  ],
  servoMotor: [
    { name: 'Voltage', key: 'voltage', type: 'number', unit: 'V', min: 3, max: 12, step: 0.1, defaultValue: 5 },
    { name: 'Torque', key: 'torque', type: 'number', unit: 'kg·cm', min: 0.5, max: 30, step: 0.1, defaultValue: 2.5 },
    { name: 'Speed', key: 'speed', type: 'number', unit: '°/s', min: 30, max: 1200, step: 1, defaultValue: 300 },
    { name: 'Min Pulse (ms)', key: 'minPulse', type: 'number', unit: 'ms', min: 0.5, max: 2, step: 0.01, defaultValue: 1 },
    { name: 'Max Pulse (ms)', key: 'maxPulse', type: 'number', unit: 'ms', min: 1, max: 3, step: 0.01, defaultValue: 2 },
  ],
  stepperMotor: [
    {
      name: 'Step Angle', key: 'stepAngle', type: 'presetNumber', unit: '°',
      presets: [1.8, 0.9, 3.75, 7.5, 15, 18],
      min: 0.1, max: 90, step: 0.1, defaultValue: 1.8,
    },
    { name: 'Rated Voltage', key: 'ratedVoltage', type: 'number', unit: 'V', min: 1, max: 48, step: 0.1, defaultValue: 12 },
    { name: 'Coil Resistance', key: 'coilResistance', type: 'number', unit: 'Ω', min: 0.1, max: 200, step: 0.1, defaultValue: 30 },
    { name: 'RPM', key: 'ratedRpm', type: 'number', unit: 'rpm', min: 1, max: 3000, step: 1, defaultValue: 60 },
    { name: 'Holding Torque', key: 'holdingTorque', type: 'number', unit: 'kg·cm', min: 0.1, max: 50, step: 0.1, defaultValue: 4.2 },
    {
      name: 'Direction', key: 'direction', type: 'select', defaultValue: 'cw',
      options: [{ label: 'Clockwise', value: 'cw' }, { label: 'Counter-Clockwise', value: 'ccw' }],
    },
  ],
  buzzer: [
    { name: 'Frequency', key: 'frequency', type: 'number', unit: 'Hz', min: 20, max: 20000, step: 10, defaultValue: 2000 },
  ],
  // Active buzzer: has its own internal oscillator circuit, so it always
  // sounds the same fixed tone the instant it sees enough voltage - it
  // does not care about signal shape, only "on or off".
  activeBuzzer: [
    { name: 'Rated Voltage', key: 'ratedVoltage', type: 'number', unit: 'V', min: 1, max: 24, step: 0.1, defaultValue: 5 },
    { name: 'Fixed Tone', key: 'frequency', type: 'number', unit: 'Hz', min: 20, max: 20000, step: 10, defaultValue: 2300 },
  ],
  // Passive buzzer: no internal oscillator - it's just a driven speaker
  // element, so its pitch directly tracks the frequency of the PWM/AC
  // signal driving it (silent on flat DC).
  passiveBuzzer: [
    { name: 'Min Frequency', key: 'minFrequency', type: 'number', unit: 'Hz', min: 20, max: 20000, step: 10, defaultValue: 100 },
    { name: 'Max Frequency', key: 'maxFrequency', type: 'number', unit: 'Hz', min: 20, max: 20000, step: 10, defaultValue: 4000 },
    { name: 'Drive Voltage', key: 'ratedVoltage', type: 'number', unit: 'V', min: 1, max: 24, step: 0.1, defaultValue: 5 },
  ],
  // RGB LED: three independent LED junctions (R/G/B) sharing one common
  // leg. Each channel is simulated exactly like a regular LED, so wiring
  // different voltages/PWM-ish levels into each color pin genuinely mixes
  // to produce the resulting color, rather than a scripted color swap.
  rgbLed: [
    {
      name: 'Common Lead', key: 'commonType', type: 'select', defaultValue: 'cathode',
      options: [{ label: 'Common Cathode', value: 'cathode' }, { label: 'Common Anode', value: 'anode' }],
    },
    { name: 'Forward Voltage', key: 'forwardVoltage', type: 'number', unit: 'V', min: 1.5, max: 4, step: 0.1, defaultValue: 2.1 },
    { name: 'Max Current', key: 'maxCurrent', type: 'number', unit: 'mA', min: 5, max: 100, step: 1, defaultValue: 20 },
  ],
  // NeoPixel (WS2812) strip: powered over VCC/GND like any digital IC, with
  // a single-wire DIN/DOUT data pass-through for chaining. Real firmware
  // shifts individual 24-bit colors down that data line; since this
  // simulator doesn't execute serial protocols yet, Animation Mode drives
  // a live per-pixel demo pattern today and is the same style of
  // prop-driven interface (like the Arduino's D-pins) that a future code
  // engine can address per-pixel.
  neopixel: [
    { name: 'Pixel Count', key: 'pixelCount', type: 'number', min: 1, max: 60, step: 1, defaultValue: 8 },
    {
      name: 'Animation Mode', key: 'animationMode', type: 'select', defaultValue: 'rainbow',
      options: [
        { label: 'Off', value: 'off' },
        { label: 'Solid Color', value: 'solid' },
        { label: 'Rainbow', value: 'rainbow' },
        { label: 'Chase', value: 'chase' },
        { label: 'Breathing', value: 'breathing' },
      ],
    },
    { name: 'Solid Color', key: 'color', type: 'string', defaultValue: '#00ffaa' },
    { name: 'Brightness', key: 'brightness', type: 'number', min: 0, max: 1, step: 0.05, defaultValue: 1 },
  ],
  // 16x2 character LCD (HD44780-style, 4-bit mode). Text is live/editable
  // from the properties panel today (Live Character Display) and the same
  // RS/EN/D4-D7 pins are exposed for real wiring and future Arduino
  // LiquidCrystal-style code control.
  lcd16x2: [
    { name: 'Line 1', key: 'line1', type: 'string', defaultValue: 'HELLO ENGINIX' },
    { name: 'Line 2', key: 'line2', type: 'string', defaultValue: 'SYSTEM READY' },
    { name: 'Backlight', key: 'backlight', type: 'boolean', defaultValue: true },
  ],
  // 128x64 monochrome OLED (SSD1306, I2C). Pattern drives a live animated
  // demo frame (Live Pixel Graphics) today; VCC/GND/SCL/SDA are real wired
  // pins ready for a future Arduino + Adafruit_SSD1306-style code engine.
  oledSsd1306: [
    {
      name: 'Pattern', key: 'pattern', type: 'select', defaultValue: 'bouncingBall',
      options: [
        { label: 'Bouncing Ball', value: 'bouncingBall' },
        { label: 'Bars', value: 'bars' },
        { label: 'Smiley', value: 'smiley' },
        { label: 'Text', value: 'text' },
        { label: 'Off', value: 'off' },
      ],
    },
    { name: 'Text', key: 'text', type: 'string', defaultValue: 'ENGINIX' },
  ],
  // Single 7-segment display (a-g + dp + common). Segments genuinely light
  // from real wiring (e.g. Arduino digital pins through a resistor) by
  // reading each segment pin's voltage relative to the common leg; Preview
  // Digit is a convenience override for testing before it's wired up.
  sevenSegment: [
    {
      name: 'Common Lead', key: 'commonType', type: 'select', defaultValue: 'cathode',
      options: [{ label: 'Common Cathode', value: 'cathode' }, { label: 'Common Anode', value: 'anode' }],
    },
    {
      name: 'Preview Digit', key: 'previewDigit', type: 'select', defaultValue: 'none',
      options: [
        { label: 'None (use wiring)', value: 'none' },
        ...['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].map(d => ({ label: d, value: d })),
      ],
    },
  ],
  // 4-digit 7-segment display: one shared a-g+dp segment bus plus 4
  // per-digit common legs, exactly like the real multiplexed part. Preview
  // Value is a convenience override; wiring (e.g. driven by an Arduino
  // multiplexing the digit commons) is ready for future code control.
  sevenSegment4: [
    {
      name: 'Common Lead', key: 'commonType', type: 'select', defaultValue: 'cathode',
      options: [{ label: 'Common Cathode', value: 'cathode' }, { label: 'Common Anode', value: 'anode' }],
    },
    { name: 'Preview Value', key: 'previewValue', type: 'string', defaultValue: '' },
  ],
  ground: [],
  junction: [],
  acSource: [
    { name: 'Voltage (RMS)', key: 'voltage', type: 'number', unit: 'V', min: 0.1, max: 10000, step: 0.1, defaultValue: 120 },
    { name: 'Frequency', key: 'frequency', type: 'number', unit: 'Hz', min: 0.01, max: 1000000, step: 1, defaultValue: 60 },
  ],
  dcCurrentSource: [
    { name: 'Current', key: 'current', type: 'number', unit: 'A', min: 1e-12, max: 10000, step: 0.001, defaultValue: 0.1 },
  ],
  transformer: [
    { name: 'Turns Ratio (N2/N1)', key: 'turnsRatio', type: 'number', min: 0.001, max: 1000, step: 0.01, defaultValue: 1 },
  ],
  ammeter: [],
  voltmeter: [],
  bulb: [
    { name: 'Rated Voltage', key: 'ratedVoltage', type: 'number', unit: 'V', min: 0.1, max: 500, step: 0.1, defaultValue: 12 },
    { name: 'Rated Power', key: 'ratedPower', type: 'number', unit: 'W', min: 0.01, max: 1000, step: 0.01, defaultValue: 5 },
    { name: 'On', key: 'on', type: 'boolean', defaultValue: true },
  ],
  breadboard: [],
  andGate: [],
  orGate: [],
  notGate: [],
  nandGate: [],
  norGate: [],
  xorGate: [],
  ...(() => {
    // Real Uno/Nano/Mega PWM-capable pins (the ones with a ~ on the
    // silkscreen) - analogWrite() only works on these; every other
    // digital pin is INPUT/OUTPUT/INPUT_PULLUP only.
    const unoNanoPwmPins = new Set([3, 5, 6, 9, 10, 11]);
    const megaPwmPins = new Set([2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 44, 45, 46]);

    const digitalPinProps = (count: number, pwmPins: Set<number>) =>
      Array.from({ length: count }, (_, i) => {
        const isPwm = pwmPins.has(i);
        return [
          {
            name: `Pin D${i} Mode`, key: `d${i}_mode`, type: 'select' as const,
            defaultValue: 'OUTPUT',
            options: [
              { label: 'OUTPUT', value: 'OUTPUT' },
              { label: 'INPUT', value: 'INPUT' },
              { label: 'INPUT_PULLUP', value: 'INPUT_PULLUP' },
              ...(isPwm ? [{ label: 'PWM (analogWrite)', value: 'PWM' }] : []),
            ],
          },
          { name: `Pin D${i}`, key: `d${i}`, type: 'boolean' as const, defaultValue: false },
          ...(isPwm ? [{
            name: `Pin D${i} PWM Duty`, key: `d${i}_pwm`, type: 'number' as const,
            unit: '/255', min: 0, max: 255, step: 1, defaultValue: 0,
          }] : []),
        ];
      }).flat();

    const unoNanoDigitalProps = digitalPinProps(14, unoNanoPwmPins);
    const megaDigitalProps = digitalPinProps(54, megaPwmPins);
    return {
      arduino: unoNanoDigitalProps,
      arduinoMega: megaDigitalProps,
      arduinoNano: unoNanoDigitalProps,
    };
  })(),
  hcSr04: [
    { name: 'Distance', key: 'distance', type: 'number', unit: 'cm', min: 2, max: 400, step: 1, defaultValue: 50 },
    { name: 'Enabled', key: 'enabled', type: 'boolean', defaultValue: true },
  ],
  lm35: [
    { name: 'Temperature', key: 'temperature', type: 'number', unit: '°C', min: -55, max: 150, step: 0.5, defaultValue: 25 },
    { name: 'Enabled', key: 'enabled', type: 'boolean', defaultValue: true },
  ],
  reg7805: [
    { name: 'Enabled', key: 'enabled', type: 'boolean', defaultValue: true },
  ],
  ams1117: [
    { name: 'Enabled', key: 'enabled', type: 'boolean', defaultValue: true },
  ],
  lm317: [
    { name: 'Output Voltage', key: 'outputVoltage', type: 'number', unit: 'V', min: 1.25, max: 37, step: 0.05, defaultValue: 5 },
    { name: 'Enabled', key: 'enabled', type: 'boolean', defaultValue: true },
  ],
  ldr: [
    { name: 'Light Level', key: 'lightLevel', type: 'number', unit: '%', min: 0, max: 100, step: 1, defaultValue: 50 },
    { name: 'Enabled', key: 'enabled', type: 'boolean', defaultValue: true },
  ],
  dht11: [
    { name: 'Temperature', key: 'temperature', type: 'number', unit: '°C', min: 0, max: 50, step: 0.5, defaultValue: 25 },
    { name: 'Humidity', key: 'humidity', type: 'number', unit: '%', min: 20, max: 90, step: 1, defaultValue: 50 },
    { name: 'Enabled', key: 'enabled', type: 'boolean', defaultValue: true },
  ],
  pirMotion: [
    { name: 'Motion Detected', key: 'motionDetected', type: 'boolean', defaultValue: false },
    { name: 'Enabled', key: 'enabled', type: 'boolean', defaultValue: true },
  ],
  irObstacle: [
    { name: 'Obstacle Detected', key: 'obstacleDetected', type: 'boolean', defaultValue: false },
    { name: 'Detection Distance', key: 'detectionDistance', type: 'number', unit: 'cm', min: 2, max: 30, step: 1, defaultValue: 10 },
    { name: 'Enabled', key: 'enabled', type: 'boolean', defaultValue: true },
  ],
  mq2Gas: [
    { name: 'Gas Concentration', key: 'gasConcentration', type: 'number', unit: '%', min: 0, max: 100, step: 1, defaultValue: 20 },
    { name: 'Digital Threshold', key: 'digitalThreshold', type: 'number', unit: '%', min: 0, max: 100, step: 1, defaultValue: 50 },
    { name: 'Enabled', key: 'enabled', type: 'boolean', defaultValue: true },
  ],
  flameSensor: [
    { name: 'Flame Intensity', key: 'flameIntensity', type: 'number', unit: '%', min: 0, max: 100, step: 1, defaultValue: 0 },
    { name: 'Digital Threshold', key: 'digitalThreshold', type: 'number', unit: '%', min: 0, max: 100, step: 1, defaultValue: 30 },
    { name: 'Enabled', key: 'enabled', type: 'boolean', defaultValue: true },
  ],
  // NE555 Timer IC. Rather than modeling the external R1/R2/C timing
  // network (which would force a specific wiring topology to work at
  // all), Frequency/Duty Cycle (astable) and Pulse Width (monostable) are
  // exposed directly as properties - the same simplification this file
  // already uses for the NeoPixel's Animation Mode - while OUT still
  // drives a real, live voltage other components/wires can react to.
  ne555: [
    {
      name: 'Mode', key: 'mode', type: 'select', defaultValue: 'astable',
      options: [{ label: 'Astable (continuous)', value: 'astable' }, { label: 'Monostable (one-shot)', value: 'monostable' }],
    },
    { name: 'Frequency', key: 'frequency', type: 'number', unit: 'Hz', min: 0.1, max: 100000, step: 0.1, defaultValue: 1 },
    { name: 'Duty Cycle', key: 'dutyCycle', type: 'number', unit: '%', min: 1, max: 99, step: 1, defaultValue: 50 },
    { name: 'Pulse Width', key: 'pulseWidth', type: 'number', unit: 'ms', min: 1, max: 60000, step: 1, defaultValue: 500 },
    { name: 'Supply Voltage', key: 'supplyVoltage', type: 'number', unit: 'V', min: 4.5, max: 16, step: 0.1, defaultValue: 5 },
  ],
  // LM741 - classic single op-amp, normally run off a split (dual) supply.
  // V+ /V- pins are provided on the footprint for correct wiring, but the
  // rails that actually bound the output swing are these two properties
  // (same simplification this file already uses for the NE555's Supply
  // Voltage) - each is independently a real rail an ideal op-amp output
  // saturates against, referenced to circuit ground.
  lm741: [
    { name: 'Positive Supply (V+)', key: 'positiveSupply', type: 'number', unit: 'V', min: 2, max: 18, step: 0.5, defaultValue: 15 },
    { name: 'Negative Supply (V-)', key: 'negativeSupply', type: 'number', unit: 'V', min: -18, max: 0, step: 0.5, defaultValue: -15 },
    { name: 'Open-Loop Gain', key: 'openLoopGain', type: 'number', min: 1000, max: 1000000, step: 1000, defaultValue: 200000 },
  ],
  // LM358 - dual op-amp explicitly designed to run from a single supply
  // down to 0 V (its output can swing to within mV of the negative rail,
  // unlike the LM741's ~1.5 V headroom), so its defaults reflect typical
  // single-supply use while still allowing a split supply if desired.
  lm358: [
    { name: 'Positive Supply (V+)', key: 'positiveSupply', type: 'number', unit: 'V', min: 3, max: 32, step: 0.5, defaultValue: 5 },
    { name: 'Negative Supply (V-/GND)', key: 'negativeSupply', type: 'number', unit: 'V', min: -16, max: 0, step: 0.5, defaultValue: 0 },
    { name: 'Open-Loop Gain', key: 'openLoopGain', type: 'number', min: 1000, max: 1000000, step: 1000, defaultValue: 100000 },
  ],
  // L293D - dual H-bridge driver chip. IN1-4/EN1,2/EN3,4 are real logic
  // inputs read at a fixed ~2.5V threshold (assuming standard 5V logic,
  // e.g. an Arduino digital pin) in updateComponentState() each tick; the
  // resulting direction/enable per channel then gets stamped as the real
  // OUT1-4 voltages on the *next* tick (same one-tick-delayed pattern this
  // file already uses for the NE555's OUT and the HC-SR04's Echo). Motor
  // Supply Voltage is what OUT actually swings between 0V and, since
  // VCC2/Vs isn't solved from wiring (same simplification as the NE555's
  // Supply Voltage property).
  l293d: [
    { name: 'Motor Supply Voltage (Vs)', key: 'motorSupplyVoltage', type: 'number', unit: 'V', min: 4.5, max: 36, step: 0.5, defaultValue: 12 },
  ],
  // L298N - dual H-bridge driver module (sold almost exclusively as this
  // breakout board rather than the bare 15-pin Multiwatt package, so that's
  // the pin layout modeled here). Same electrical behavior as the L293D
  // above, just with real screw-terminal motor supply headroom to 46V and
  // its own ENA/ENB + IN1-4 header, ready to drive straight off an
  // Arduino's digital pins.
  l298n: [
    { name: 'Motor Supply Voltage (Vs)', key: 'motorSupplyVoltage', type: 'number', unit: 'V', min: 5, max: 46, step: 0.5, defaultValue: 12 },
  ],
  // ULN2003 - 7-channel Darlington array. Saturation Voltage is the real
  // Vce(sat) each channel pulls its OUT pin down to while sinking current
  // (~0.9-1.1V typical at rated load, per datasheet, vs. an ideal 0V
  // short). Supply Voltage (COM) is only a fallback for when the COM pin
  // is left unwired; whenever COM *is* wired, simulator.ts uses its real
  // solved net voltage instead (one-tick delayed, same simplification the
  // L293D/L298N use for their own Vs).
  uln2003: [
    { name: 'Saturation Voltage (Vsat)', key: 'saturationVoltage', type: 'number', unit: 'V', min: 0, max: 2, step: 0.05, defaultValue: 0.9 },
    { name: 'Supply Voltage (COM, if unwired)', key: 'comSupplyVoltage', type: 'number', unit: 'V', min: 0, max: 36, step: 0.5, defaultValue: 12 },
  ],
  // 74HC595 - logic HIGH level used to stamp Q0-Q7/Q7' (assumes standard
  // 5V logic, e.g. an Arduino digital pin, same simplifying property
  // pattern the L293D/L298N use for their own supply rather than solving
  // VCC from wiring).
  '74hc595': [
    { name: 'Supply Voltage (VCC)', key: 'supplyVoltage', type: 'number', unit: 'V', min: 2, max: 6, step: 0.5, defaultValue: 5 },
  ],
  // 74HC165 - same logic-level simplification as the 74HC595 above.
  '74hc165': [
    { name: 'Supply Voltage (VCC)', key: 'supplyVoltage', type: 'number', unit: 'V', min: 2, max: 6, step: 0.5, defaultValue: 5 },
  ],
  // CD4017 - logic HIGH level used to stamp Q0-Q9/CARRY OUT. Real part
  // runs 3-15V; default 5V matches a 555 astable's typical logic swing
  // when driving this chip's CLOCK pin straight off its OUT (pin 3).
  cd4017: [
    { name: 'Supply Voltage (VDD)', key: 'supplyVoltage', type: 'number', unit: 'V', min: 3, max: 15, step: 0.5, defaultValue: 5 },
  ],
  // CD4026 - same logic-level simplification as the CD4017 above.
  cd4026: [
    { name: 'Supply Voltage (VDD)', key: 'supplyVoltage', type: 'number', unit: 'V', min: 3, max: 15, step: 0.5, defaultValue: 5 },
  ],
  // PC817 - single-channel optocoupler. Forward Voltage is the internal
  // IR LED's real Vf (~1.2V typical, lower than a visible LED). Current
  // Transfer Ratio (CTR) is the datasheet's actual output/input current
  // ratio spec (typ. 50-200% for the base PC817); it's only used here as
  // an ON/OFF threshold (real LED current needed before the
  // phototransistor saturates), not a continuous analog gain, since the
  // rest of this simulator models transistor-side conduction as a real
  // switch contact (see Relay) rather than a linear current mirror.
  pc817: [
    { name: 'LED Forward Voltage (Vf)', key: 'forwardVoltage', type: 'number', unit: 'V', min: 0.8, max: 1.8, step: 0.05, defaultValue: 1.2 },
    { name: 'Current Transfer Ratio (CTR)', key: 'ctr', type: 'number', unit: '%', min: 20, max: 300, step: 5, defaultValue: 100 },
    { name: 'LED Turn-On Current (Ith)', key: 'thresholdCurrent', type: 'number', unit: 'mA', min: 0.1, max: 20, step: 0.1, defaultValue: 1 },
  ],
};

// Terminal definitions for each component
export const defaultTerminals: Record<string, Array<{ dx: number; dy: number; label: string }>> = {
  battery: [{ dx: -3, dy: 0, label: '+' }, { dx: 3, dy: 0, label: '-' }],
  resistor: [{ dx: -3, dy: 0, label: '1' }, { dx: 3, dy: 0, label: '2' }],
  capacitor: [{ dx: -2, dy: 0, label: '1' }, { dx: 2, dy: 0, label: '2' }],
  inductor: [{ dx: -3, dy: 0, label: '1' }, { dx: 3, dy: 0, label: '2' }],
  fuse: [{ dx: -2, dy: 0, label: '1' }, { dx: 2, dy: 0, label: '2' }],
  polyfuse: [{ dx: -2, dy: 0, label: '1' }, { dx: 2, dy: 0, label: '2' }],
  // Index 0 = Base, 1 = Collector, 2 = Emitter - matches drawTransistorBody
  // and the BE-junction/CE-switch stamps in simulator.ts.
  transistorNpn: [{ dx: -2, dy: 0, label: 'B' }, { dx: 2, dy: -2, label: 'C' }, { dx: 2, dy: 2, label: 'E' }],
  transistorPnp: [{ dx: -2, dy: 0, label: 'B' }, { dx: 2, dy: -2, label: 'C' }, { dx: 2, dy: 2, label: 'E' }],
  // NPN Darlington power transistors - same B/C/E terminal order as
  // transistorNpn above.
  tip120: [{ dx: -2, dy: 0, label: 'B' }, { dx: 2, dy: -2, label: 'C' }, { dx: 2, dy: 2, label: 'E' }],
  tip122: [{ dx: -2, dy: 0, label: 'B' }, { dx: 2, dy: -2, label: 'C' }, { dx: 2, dy: 2, label: 'E' }],
  // N-channel power MOSFETs: Gate/Drain/Source, same terminal layout/index
  // order as the BJTs above (0=control pin, 1=high-side switched pin,
  // 2=low-side switched pin) so PWM/motor-driving wiring patterns carry
  // straight over from transistorNpn.
  irf520: [{ dx: -2, dy: 0, label: 'G' }, { dx: 2, dy: -2, label: 'D' }, { dx: 2, dy: 2, label: 'S' }],
  irf540: [{ dx: -2, dy: 0, label: 'G' }, { dx: 2, dy: -2, label: 'D' }, { dx: 2, dy: 2, label: 'S' }],
  irlz44n: [{ dx: -2, dy: 0, label: 'G' }, { dx: 2, dy: -2, label: 'D' }, { dx: 2, dy: 2, label: 'S' }],
  // TIP/SLV (bottom) match the panel-jack's two power pins; SW (top) is the
  // normally-closed plug-detect pin - left unwired here, same as any other
  // optional/unused pin, matching BARREL_JACK's PCB footprint pad layout.
  barrelJack: [{ dx: -2, dy: 1, label: 'TIP' }, { dx: 2, dy: 1, label: 'SLV' }, { dx: 0, dy: -2, label: 'SW' }],
  screwTerminal2pin: [{ dx: -2, dy: 0, label: '1' }, { dx: 2, dy: 0, label: '2' }],
  jstConnector2pin: [{ dx: -1.5, dy: 0, label: '1' }, { dx: 1.5, dy: 0, label: '2' }],
  uartHeader: [{ dx: -3, dy: 0, label: 'VCC' }, { dx: -1, dy: 0, label: 'GND' }, { dx: 1, dy: 0, label: 'TXD' }, { dx: 3, dy: 0, label: 'RXD' }],
  // Terminal order (fixed - matches the voltage-source stamp/state read in
  // simulator.ts): 0=VCC, 1=TXD, 2=RXD, 3=STATE, 4=GND, 5=EN(KEY).
  hc05: [
    { dx: -2.5, dy: -2, label: 'VCC' }, { dx: -1.5, dy: -2, label: 'TXD' }, { dx: -0.5, dy: -2, label: 'RXD' },
    { dx: 0.5, dy: -2, label: 'STATE' }, { dx: 1.5, dy: -2, label: 'GND' }, { dx: 2.5, dy: -2, label: 'EN' },
  ],
  hc06: [
    { dx: -2.5, dy: -2, label: 'VCC' }, { dx: -1.5, dy: -2, label: 'TXD' }, { dx: -0.5, dy: -2, label: 'RXD' },
    { dx: 0.5, dy: -2, label: 'STATE' }, { dx: 1.5, dy: -2, label: 'GND' }, { dx: 2.5, dy: -2, label: 'EN' },
  ],
  // ESP-01/ESP-01S: 8 pins, matches the real ESP-01 castellated-edge
  // layout order (VCC/GND on one side, the 6 GPIO/control pins on the
  // other). Terminal order (fixed - matches the voltage-source stamp in
  // simulator.ts): 0=VCC, 1=GND, 2=TXD, 3=RXD, 4=CH_PD, 5=RST, 6=GPIO0, 7=GPIO2.
  esp8266: [
    { dx: -3.5, dy: -2, label: 'VCC' }, { dx: -2.5, dy: -2, label: 'GND' }, { dx: -1.5, dy: -2, label: 'TXD' }, { dx: -0.5, dy: -2, label: 'RXD' },
    { dx: 0.5, dy: -2, label: 'CH_PD' }, { dx: 1.5, dy: -2, label: 'RST' }, { dx: 2.5, dy: -2, label: 'GPIO0' }, { dx: 3.5, dy: -2, label: 'GPIO2' },
  ],
  // ESP32 DevKit, simplified to its 6-pin programming/UART header (same
  // simplification used for hc05/hc06 above). Terminal order (fixed -
  // matches the voltage-source stamp in simulator.ts): 0=VCC, 1=TXD,
  // 2=RXD, 3=EN, 4=GND, 5=IO0.
  esp32: [
    { dx: -2.5, dy: -2, label: 'VCC' }, { dx: -1.5, dy: -2, label: 'TXD' }, { dx: -0.5, dy: -2, label: 'RXD' },
    { dx: 0.5, dy: -2, label: 'EN' }, { dx: 1.5, dy: -2, label: 'GND' }, { dx: 2.5, dy: -2, label: 'IO0' },
  ],
  // NRF24L01(+): 8 pins, matches the standard 2x4 breakout pinout.
  // Terminal order (fixed - matches the voltage-source stamp in
  // simulator.ts): 0=VCC, 1=GND, 2=CE, 3=CSN, 4=SCK, 5=MOSI, 6=MISO, 7=IRQ.
  nrf24l01: [
    { dx: -3.5, dy: -2, label: 'VCC' }, { dx: -2.5, dy: -2, label: 'GND' }, { dx: -1.5, dy: -2, label: 'CE' }, { dx: -0.5, dy: -2, label: 'CSN' },
    { dx: 0.5, dy: -2, label: 'SCK' }, { dx: 1.5, dy: -2, label: 'MOSI' }, { dx: 2.5, dy: -2, label: 'MISO' }, { dx: 3.5, dy: -2, label: 'IRQ' },
  ],
  // RC522 (MFRC522) breakout, standard 7-pin SPI pinout. Terminal order
  // (fixed - matches the voltage-source stamp in simulator.ts): 0=SDA,
  // 1=SCK, 2=MOSI, 3=MISO, 4=RST, 5=3.3V, 6=GND.
  rc522: [
    { dx: -3, dy: -2, label: 'SDA' }, { dx: -2, dy: -2, label: 'SCK' }, { dx: -1, dy: -2, label: 'MOSI' }, { dx: 0, dy: -2, label: 'MISO' },
    { dx: 1, dy: -2, label: 'RST' }, { dx: 2, dy: -2, label: '3.3V' }, { dx: 3, dy: -2, label: 'GND' },
  ],
  // MAX485: 8 pins, breakout order (fixed - matches the voltage-source
  // stamp in simulator.ts): 0=VCC, 1=GND, 2=RO, 3=RE, 4=DE, 5=DI, 6=A, 7=B.
  max485: [
    { dx: -3.5, dy: -2, label: 'VCC' }, { dx: -2.5, dy: -2, label: 'GND' }, { dx: -1.5, dy: -2, label: 'RO' }, { dx: -0.5, dy: -2, label: 'RE' },
    { dx: 0.5, dy: -2, label: 'DE' }, { dx: 1.5, dy: -2, label: 'DI' }, { dx: 2.5, dy: -2, label: 'A' }, { dx: 3.5, dy: -2, label: 'B' },
  ],
  // CAN Bus Module (MCP2515+TJA1050): 7-pin SPI header, matches the
  // common breakout pinout. Terminal order (fixed - matches the
  // voltage-source stamp in simulator.ts): 0=VCC, 1=GND, 2=CS, 3=SO,
  // 4=SI, 5=SCK, 6=INT.
  canBusModule: [
    { dx: -3, dy: -2, label: 'VCC' }, { dx: -2, dy: -2, label: 'GND' }, { dx: -1, dy: -2, label: 'CS' }, { dx: 0, dy: -2, label: 'SO' },
    { dx: 1, dy: -2, label: 'SI' }, { dx: 2, dy: -2, label: 'SCK' }, { dx: 3, dy: -2, label: 'INT' },
  ],
  // Passive 4-pin I2C header, matches defaultTerminals.uartHeader's
  // layout style above.
  i2cHeader: [{ dx: -3, dy: 0, label: 'VCC' }, { dx: -1, dy: 0, label: 'GND' }, { dx: 1, dy: 0, label: 'SDA' }, { dx: 3, dy: 0, label: 'SCL' }],
  // GPS NEO-6M breakout, standard 4-pin VCC/TX/RX/GND pinout. Terminal
  // order (fixed - matches the voltage-source stamp in simulator.ts):
  // 0=VCC, 1=TX, 2=RX, 3=GND.
  gpsNeo6m: [{ dx: -3, dy: -2, label: 'VCC' }, { dx: -1, dy: -2, label: 'TX' }, { dx: 1, dy: -2, label: 'RX' }, { dx: 3, dy: -2, label: 'GND' }],
  switch: [{ dx: -2, dy: 0, label: '1' }, { dx: 2, dy: 0, label: '2' }],
  pushButton: [{ dx: -2, dy: 0, label: '1' }, { dx: 2, dy: 0, label: '2' }],
  diode: [{ dx: -2, dy: 0, label: 'A' }, { dx: 2, dy: 0, label: 'K' }],
  led: [{ dx: -2, dy: 0, label: 'A' }, { dx: 2, dy: 0, label: 'K' }],
  zenerDiode: [{ dx: -2, dy: 0, label: 'A' }, { dx: 2, dy: 0, label: 'K' }],
  variableResistor: [{ dx: -3, dy: 0, label: '1' }, { dx: 3, dy: 0, label: '2' }, { dx: 1, dy: -2, label: 'W' }],
  potentiometer: [{ dx: -3, dy: 0, label: '1' }, { dx: 3, dy: 0, label: '2' }, { dx: 0, dy: -2, label: 'W' }],
  // Coil (C+/C-) at indices 0/1 - updateComponentState()'s generic `v`
  // read (terminals[0] vs terminals[1]) depends on that order. COM is
  // appended last (index 4) so it doesn't shift NC/NO's existing indices.
  relay: [{ dx: -3, dy: -1, label: 'C+' }, { dx: -3, dy: 1, label: 'C-' }, { dx: 2, dy: -1, label: 'NC' }, { dx: 2, dy: 1, label: 'NO' }, { dx: 4, dy: 0, label: 'COM' }],
  // Board-style module: coil side broken out as IN+/IN-, contact side
  // explicitly labeled COM/NO/NC (screw-terminal naming), unlike the bare
  // relay above.
  relayModule: [
    { dx: -3, dy: -1, label: 'IN+' },
    { dx: -3, dy: 1, label: 'IN-' },
    { dx: 3, dy: -2, label: 'NC' },
    { dx: 3, dy: 0, label: 'COM' },
    { dx: 3, dy: 2, label: 'NO' },
  ],
  // Coil terminals only - the pipe connections are drawn as plumbing, not
  // electrical nets (matching how the water pump handles its inlet/outlet).
  solenoidValve: [{ dx: -2, dy: 0, label: '+' }, { dx: 2, dy: 0, label: '-' }],
  dcMotor: [{ dx: -3, dy: 0, label: '+' }, { dx: 3, dy: 0, label: '-' }],
  waterPump: [{ dx: -3, dy: 0, label: '+' }, { dx: 3, dy: 0, label: '-' }],
  servoMotor: [{ dx: -2, dy: 0, label: 'S' }, { dx: 2, dy: 0, label: '+' }, { dx: 0, dy: -2, label: 'GND' }],
  // Two coil pairs (A+/A-, B+/B-) - the same 4 coil-end layout used by both
  // an A4988 driver (bipolar, wired straight to these 4 pins) and a
  // ULN2003 board (unipolar, driving the same 4 coil ends through its own
  // IN1-IN4), so either driver can be dropped in later without rewiring.
  stepperMotor: [
    { dx: -3, dy: -1, label: 'A+' },
    { dx: -3, dy: 1, label: 'A-' },
    { dx: 3, dy: -1, label: 'B+' },
    { dx: 3, dy: 1, label: 'B-' },
  ],
  buzzer: [{ dx: -2, dy: 0, label: '+' }, { dx: 2, dy: 0, label: '-' }],
  activeBuzzer: [{ dx: -2, dy: 0, label: '+' }, { dx: 2, dy: 0, label: '-' }],
  passiveBuzzer: [{ dx: -2, dy: 0, label: '+' }, { dx: 2, dy: 0, label: '-' }],
  rgbLed: [
    { dx: -3, dy: 2, label: 'R' },
    { dx: -1, dy: 2, label: 'C' },
    { dx: 1, dy: 2, label: 'G' },
    { dx: 3, dy: 2, label: 'B' },
  ],
  neopixel: [
    { dx: -2, dy: 2, label: 'VCC' },
    { dx: -0.67, dy: 2, label: 'DIN' },
    { dx: 0.67, dy: 2, label: 'DOUT' },
    { dx: 2, dy: 2, label: 'GND' },
  ],
  lcd16x2: [
    { dx: -3.5, dy: 3, label: 'VCC' },
    { dx: -2.5, dy: 3, label: 'GND' },
    { dx: -1.5, dy: 3, label: 'RS' },
    { dx: -0.5, dy: 3, label: 'EN' },
    { dx: 0.5, dy: 3, label: 'D4' },
    { dx: 1.5, dy: 3, label: 'D5' },
    { dx: 2.5, dy: 3, label: 'D6' },
    { dx: 3.5, dy: 3, label: 'D7' },
  ],
  oledSsd1306: [
    { dx: -1.5, dy: 2, label: 'VCC' },
    { dx: -0.5, dy: 2, label: 'GND' },
    { dx: 0.5, dy: 2, label: 'SCL' },
    { dx: 1.5, dy: 2, label: 'SDA' },
  ],
  sevenSegment: [
    { dx: -3.5, dy: 2, label: 'a' },
    { dx: -2.5, dy: 2, label: 'b' },
    { dx: -1.5, dy: 2, label: 'c' },
    { dx: -0.5, dy: 2, label: 'd' },
    { dx: 0.5, dy: 2, label: 'e' },
    { dx: 1.5, dy: 2, label: 'f' },
    { dx: 2.5, dy: 2, label: 'g' },
    { dx: 3.5, dy: 2, label: 'dp' },
    { dx: 0, dy: -2, label: 'COM' },
  ],
  sevenSegment4: [
    { dx: -3.5, dy: -2.5, label: 'a' },
    { dx: -2.5, dy: -2.5, label: 'b' },
    { dx: -1.5, dy: -2.5, label: 'c' },
    { dx: -0.5, dy: -2.5, label: 'd' },
    { dx: 0.5, dy: -2.5, label: 'e' },
    { dx: 1.5, dy: -2.5, label: 'f' },
    { dx: 2.5, dy: -2.5, label: 'g' },
    { dx: 3.5, dy: -2.5, label: 'dp' },
    { dx: -3, dy: 2.5, label: 'D1' },
    { dx: -1, dy: 2.5, label: 'D2' },
    { dx: 1, dy: 2.5, label: 'D3' },
    { dx: 3, dy: 2.5, label: 'D4' },
  ],
  ground: [{ dx: 0, dy: -1, label: 'GND' }],
  // Single terminal at the junction's own position - every wire that
  // meets at this branch point connects to this one terminal id, which is
  // exactly how buildNets() already merges any wires sharing a terminal
  // into one net. No simulator changes needed.
  junction: [{ dx: 0, dy: 0, label: 'J' }],
  acSource: [{ dx: -3, dy: 0, label: 'L' }, { dx: 3, dy: 0, label: 'N' }],
  dcCurrentSource: [{ dx: -3, dy: 0, label: '+' }, { dx: 3, dy: 0, label: '-' }],
  transformer: [{ dx: -2, dy: -1, label: 'P1' }, { dx: -2, dy: 1, label: 'P2' }, { dx: 2, dy: -1, label: 'S1' }, { dx: 2, dy: 1, label: 'S2' }],
  ammeter: [{ dx: -2, dy: 0, label: '1' }, { dx: 2, dy: 0, label: '2' }],
  voltmeter: [{ dx: -2, dy: 0, label: '+' }, { dx: 2, dy: 0, label: '-' }],
  bulb: [{ dx: -2, dy: 0, label: '1' }, { dx: 2, dy: 0, label: '2' }],
  breadboard: [],
  andGate: [{ dx: -2, dy: -1, label: 'A' }, { dx: -2, dy: 1, label: 'B' }, { dx: 2, dy: 0, label: 'Y' }],
  orGate: [{ dx: -2, dy: -1, label: 'A' }, { dx: -2, dy: 1, label: 'B' }, { dx: 2, dy: 0, label: 'Y' }],
  notGate: [{ dx: -2, dy: 0, label: 'A' }, { dx: 2, dy: 0, label: 'Y' }],
  nandGate: [{ dx: -2, dy: -1, label: 'A' }, { dx: -2, dy: 1, label: 'B' }, { dx: 2, dy: 0, label: 'Y' }],
  norGate: [{ dx: -2, dy: -1, label: 'A' }, { dx: -2, dy: 1, label: 'B' }, { dx: 2, dy: 0, label: 'Y' }],
  xorGate: [{ dx: -2, dy: -1, label: 'A' }, { dx: -2, dy: 1, label: 'B' }, { dx: 2, dy: 0, label: 'Y' }],
  ...(() => {
    const evenRow = (labels: string[], span: number, dy: number) => {
      const n = labels.length;
      if (n === 1) return [{ dx: 0, dy, label: labels[0] }];
      const step = span / (n - 1);
      return labels.map((label, i) => ({ dx: -span / 2 + i * step, dy, label }));
    };

    // Arduino Uno / Nano share the ATmega328P pinout: D0-D13 digital,
    // AREF, and analog inputs (Uno: A0-A5, Nano: A0-A7 — the Nano exposes
    // two extra analog-only pins, A6/A7).
    const digital14 = Array.from({ length: 14 }, (_, i) => `D${i}`);
    const unoAnalog = Array.from({ length: 6 }, (_, i) => `A${i}`);
    const nanoAnalog = Array.from({ length: 8 }, (_, i) => `A${i}`);

    // Arduino Mega 2560: D0-D53 digital, A0-A15 analog.
    const megaDigital = Array.from({ length: 54 }, (_, i) => `D${i}`);
    const megaDigitalRow1 = megaDigital.slice(0, 27);
    const megaDigitalRow2 = megaDigital.slice(27);
    const megaAnalog = Array.from({ length: 16 }, (_, i) => `A${i}`);

    // ICSP 2x3 header (MISO/VCC/SCK/MOSI/RESET/GND) - present on every AVR
    // Arduino board for direct-to-bootloader programming, physically
    // separate from the digital/analog headers. Modeled as its own small
    // row of terminals so it's electrically real (wireable) even though
    // the simplified board render doesn't draw the classic 2x3 block.
    const icspRow = (dy: number): Array<{ dx: number; dy: number; label: string }> =>
      evenRow(['ICSP_MISO', 'ICSP_VCC', 'ICSP_SCK', 'ICSP_MOSI', 'ICSP_RESET', 'ICSP_GND'], 6, dy);

    return {
      arduino: [
        ...evenRow(digital14, 15, -3),
        ...evenRow(['GND', '5V', '3V3', 'VIN', 'RESET', 'AREF', ...unoAnalog], 15, 3),
        ...icspRow(-4.5),
      ],
      arduinoMega: [
        ...evenRow(megaDigitalRow1, 28, -4.5),
        ...evenRow(megaDigitalRow2, 28, -3),
        ...evenRow(['GND', '5V', '3V3', 'VIN', 'RESET', 'AREF', ...megaAnalog], 28, 3),
        ...icspRow(-6),
      ],
      arduinoNano: [
        ...evenRow(digital14, 12, -3),
        ...evenRow(['GND', '5V', '3V3', 'VIN', 'RESET', 'AREF', ...nanoAnalog], 12, 3),
        ...icspRow(-4.5),
      ],
    };
  })(),
  hcSr04: [
    { dx: -1.5, dy: 2, label: 'VCC' },
    { dx: -0.5, dy: 2, label: 'Trig' },
    { dx: 0.5, dy: 2, label: 'Echo' },
    { dx: 1.5, dy: 2, label: 'GND' },
  ],
  lm35: [
    { dx: -1, dy: 1.5, label: 'VCC' },
    { dx: 0, dy: 1.5, label: 'OUT' },
    { dx: 1, dy: 1.5, label: 'GND' },
  ],
  reg7805: [
    { dx: -1, dy: 1.5, label: 'IN' },
    { dx: 0, dy: 1.5, label: 'GND' },
    { dx: 1, dy: 1.5, label: 'OUT' },
  ],
  ams1117: [
    { dx: -1, dy: 1.5, label: 'GND' },
    { dx: 0, dy: 1.5, label: 'OUT' },
    { dx: 1, dy: 1.5, label: 'IN' },
  ],
  lm317: [
    { dx: -1, dy: 1.5, label: 'ADJ' },
    { dx: 0, dy: 1.5, label: 'OUT' },
    { dx: 1, dy: 1.5, label: 'IN' },
  ],
  ldr: [
    { dx: -1.2, dy: 0, label: 'Pin 1' },
    { dx: 1.2, dy: 0, label: 'Pin 2' },
  ],
  dht11: [
    { dx: -1.5, dy: 1.5, label: 'VCC' },
    { dx: -0.5, dy: 1.5, label: 'DATA' },
    { dx: 0.5, dy: 1.5, label: 'NC' },
    { dx: 1.5, dy: 1.5, label: 'GND' },
  ],
  pirMotion: [
    { dx: -1, dy: 2, label: 'VCC' },
    { dx: 0, dy: 2, label: 'OUT' },
    { dx: 1, dy: 2, label: 'GND' },
  ],
  irObstacle: [
    { dx: -1, dy: 1.5, label: 'VCC' },
    { dx: 0, dy: 1.5, label: 'GND' },
    { dx: 1, dy: 1.5, label: 'OUT' },
  ],
  mq2Gas: [
    { dx: -1.5, dy: 1.5, label: 'VCC' },
    { dx: -0.5, dy: 1.5, label: 'GND' },
    { dx: 0.5, dy: 1.5, label: 'AO' },
    { dx: 1.5, dy: 1.5, label: 'DO' },
  ],
  flameSensor: [
    { dx: -1.5, dy: 1.5, label: 'VCC' },
    { dx: -0.5, dy: 1.5, label: 'GND' },
    { dx: 0.5, dy: 1.5, label: 'DO' },
    { dx: 1.5, dy: 1.5, label: 'AO' },
  ],
  // Real 8-pin DIP pinout (1=GND, 2=TRIG, 3=OUT, 4=RESET counterclockwise
  // down the left side; 5=CTRL, 6=THRES, 7=DISCH, 8=VCC continuing
  // counterclockwise back up the right side) - array order matches what
  // simulator.ts indexes by position (0=GND..7=VCC), independent of the
  // dx/dy placement below.
  ne555: [
    { dx: -3, dy: -1.5, label: 'GND' },
    { dx: -3, dy: -0.5, label: 'TRIG' },
    { dx: -3, dy: 0.5, label: 'OUT' },
    { dx: -3, dy: 1.5, label: 'RESET' },
    { dx: 3, dy: 1.5, label: 'CTRL' },
    { dx: 3, dy: 0.5, label: 'THRES' },
    { dx: 3, dy: -0.5, label: 'DISCH' },
    { dx: 3, dy: -1.5, label: 'VCC' },
  ],
  // Real 8-pin DIP LM741 pinout: 1=Offset Null, 2=IN-, 3=IN+, 4=V-
  // (counterclockwise down the left side), 5=Offset Null, 6=OUT, 7=V+,
  // 8=NC (continuing counterclockwise back up the right side). Array
  // order matches what simulator.ts indexes by position, independent of
  // the dx/dy placement below.
  lm741: [
    { dx: -3, dy: -1.5, label: 'NC1' },
    { dx: -3, dy: -0.5, label: 'IN-' },
    { dx: -3, dy: 0.5, label: 'IN+' },
    { dx: -3, dy: 1.5, label: 'V-' },
    { dx: 3, dy: 1.5, label: 'NC2' },
    { dx: 3, dy: 0.5, label: 'OUT' },
    { dx: 3, dy: -0.5, label: 'V+' },
    { dx: 3, dy: -1.5, label: 'NC' },
  ],
  // Real 8-pin DIP LM358 pinout (dual op-amp): 1=OUT1, 2=IN1-, 3=IN1+,
  // 4=V-/GND (counterclockwise down the left side), 5=IN2+, 6=IN2-,
  // 7=OUT2, 8=V+/VCC (continuing counterclockwise back up the right
  // side). Array order matches what simulator.ts indexes by position.
  lm358: [
    { dx: -3, dy: -1.5, label: 'OUT1' },
    { dx: -3, dy: -0.5, label: 'IN1-' },
    { dx: -3, dy: 0.5, label: 'IN1+' },
    { dx: -3, dy: 1.5, label: 'V-' },
    { dx: 3, dy: 1.5, label: 'IN2+' },
    { dx: 3, dy: 0.5, label: 'IN2-' },
    { dx: 3, dy: -0.5, label: 'OUT2' },
    { dx: 3, dy: -1.5, label: 'V+' },
  ],
  // Real 16-pin DIP L293D pinout: 1=EN1,2, 2=IN1, 3=OUT1, 4=GND, 5=GND,
  // 6=OUT2, 7=IN2, 8=VCC2 (motor supply Vs) counterclockwise down the
  // left side; 9=EN3,4, 10=IN3, 11=OUT3, 12=GND, 13=GND, 14=OUT4,
  // 15=IN4, 16=VCC1 (logic supply Vss) continuing counterclockwise back
  // up the right side. Array order matches what simulator.ts indexes by
  // position, independent of the dx/dy placement below.
  l293d: [
    { dx: -3, dy: -3.5, label: 'EN1,2' },
    { dx: -3, dy: -2.5, label: 'IN1' },
    { dx: -3, dy: -1.5, label: 'OUT1' },
    { dx: -3, dy: -0.5, label: 'GND' },
    { dx: -3, dy: 0.5, label: 'GND' },
    { dx: -3, dy: 1.5, label: 'OUT2' },
    { dx: -3, dy: 2.5, label: 'IN2' },
    { dx: -3, dy: 3.5, label: 'VCC2' },
    { dx: 3, dy: 3.5, label: 'EN3,4' },
    { dx: 3, dy: 2.5, label: 'IN3' },
    { dx: 3, dy: 1.5, label: 'OUT3' },
    { dx: 3, dy: 0.5, label: 'GND' },
    { dx: 3, dy: -0.5, label: 'GND' },
    { dx: 3, dy: -1.5, label: 'OUT4' },
    { dx: 3, dy: -2.5, label: 'IN4' },
    { dx: 3, dy: -3.5, label: 'VCC1' },
  ],
  // L298N breakout module - real-world boards expose this as a screw-
  // terminal power block (GND / 12V motor supply / 5V logic-out), two
  // motor screw terminals (OUT1/OUT2, OUT3/OUT4), and a control header
  // (ENA, IN1-4, ENB). Array order matches what simulator.ts indexes by
  // position; dx/dy below just lays them out along the board edges.
  l298n: [
    { dx: -3, dy: -2.5, label: 'GND' },
    { dx: -2, dy: -2.5, label: '12V' },
    { dx: -1, dy: -2.5, label: '5V' },
    { dx: -3, dy: 2.5, label: 'ENA' },
    { dx: -2, dy: 2.5, label: 'IN1' },
    { dx: -1, dy: 2.5, label: 'IN2' },
    { dx: -3.5, dy: 0, label: 'OUT1' },
    { dx: -3.5, dy: 1, label: 'OUT2' },
    { dx: 1, dy: 2.5, label: 'ENB' },
    { dx: 2, dy: 2.5, label: 'IN3' },
    { dx: 3, dy: 2.5, label: 'IN4' },
    { dx: 3.5, dy: 0, label: 'OUT3' },
    { dx: 3.5, dy: 1, label: 'OUT4' },
  ],
  // Real 16-pin DIP ULN2003 pinout: 1-7 = IN1-IN7 down the left side, 8 =
  // GND, then continuing up the right side 9 = COM (common flyback-diode
  // cathode), 10-16 = OUT7-OUT1 - matching the datasheet's actual pin
  // order (OUT numbering counts back down as it goes up the right side).
  // Array order matches what simulator.ts indexes by position, independent
  // of the dx/dy placement below. Only IN1-IN4/OUT1-OUT4 need to be wired
  // to drive a 4-lead unipolar stepper's A+/A-/B+/B- or a relay/relayModule
  // coil - the remaining three channels (IN5-IN7/OUT5-OUT7) are free for
  // additional relays, solenoids, or other coils/LEDs.
  uln2003: [
    { dx: -3, dy: -3.5, label: 'IN1' },
    { dx: -3, dy: -2.5, label: 'IN2' },
    { dx: -3, dy: -1.5, label: 'IN3' },
    { dx: -3, dy: -0.5, label: 'IN4' },
    { dx: -3, dy: 0.5, label: 'IN5' },
    { dx: -3, dy: 1.5, label: 'IN6' },
    { dx: -3, dy: 2.5, label: 'IN7' },
    { dx: -3, dy: 3.5, label: 'GND' },
    { dx: 3, dy: 3.5, label: 'COM' },
    { dx: 3, dy: 2.5, label: 'OUT7' },
    { dx: 3, dy: 1.5, label: 'OUT6' },
    { dx: 3, dy: 0.5, label: 'OUT5' },
    { dx: 3, dy: -0.5, label: 'OUT4' },
    { dx: 3, dy: -1.5, label: 'OUT3' },
    { dx: 3, dy: -2.5, label: 'OUT2' },
    { dx: 3, dy: -3.5, label: 'OUT1' },
  ],
  // Real 16-pin DIP 74HC595 pinout: 1-7 = Q1-Q7 down the left side, 8 =
  // GND, then continuing up the right side 9 = Q7' (serial-out cascade
  // to the next chip's DS), 10 = MR (active-low master reset), 11 =
  // SH_CP (shift clock), 12 = ST_CP (storage/latch clock), 13 = OE
  // (active-low output enable), 14 = DS (serial data in), 15 = Q0, 16 =
  // VCC - matching the datasheet's actual pin order. Array order matches
  // what simulator.ts indexes by position, independent of the dx/dy
  // placement below.
  '74hc595': [
    { dx: -3, dy: -3.5, label: 'Q1' },
    { dx: -3, dy: -2.5, label: 'Q2' },
    { dx: -3, dy: -1.5, label: 'Q3' },
    { dx: -3, dy: -0.5, label: 'Q4' },
    { dx: -3, dy: 0.5, label: 'Q5' },
    { dx: -3, dy: 1.5, label: 'Q6' },
    { dx: -3, dy: 2.5, label: 'Q7' },
    { dx: -3, dy: 3.5, label: 'GND' },
    { dx: 3, dy: 3.5, label: "Q7'" },
    { dx: 3, dy: 2.5, label: 'MR' },
    { dx: 3, dy: 1.5, label: 'SH_CP' },
    { dx: 3, dy: 0.5, label: 'ST_CP' },
    { dx: 3, dy: -0.5, label: 'OE' },
    { dx: 3, dy: -1.5, label: 'DS' },
    { dx: 3, dy: -2.5, label: 'Q0' },
    { dx: 3, dy: -3.5, label: 'VCC' },
  ],
  // Real 16-pin DIP 74HC165 pinout: 1 = SH/LD (active-low shift/load),
  // 2 = CLK, 3-6 = D4-D7, 7 = QH' (complementary serial out), 8 = GND,
  // then continuing up the right side 9 = CLK INH (active-low clock
  // enable), 10 = SER (serial data in, cascade), 11-14 = D0-D3, 15 = QH
  // (serial data out), 16 = VCC - matching the datasheet's actual pin
  // order. Array order matches what simulator.ts indexes by position,
  // independent of the dx/dy placement below.
  '74hc165': [
    { dx: -3, dy: -3.5, label: 'SH/LD' },
    { dx: -3, dy: -2.5, label: 'CLK' },
    { dx: -3, dy: -1.5, label: 'D4' },
    { dx: -3, dy: -0.5, label: 'D5' },
    { dx: -3, dy: 0.5, label: 'D6' },
    { dx: -3, dy: 1.5, label: 'D7' },
    { dx: -3, dy: 2.5, label: "QH'" },
    { dx: -3, dy: 3.5, label: 'GND' },
    { dx: 3, dy: 3.5, label: 'CLK INH' },
    { dx: 3, dy: 2.5, label: 'SER' },
    { dx: 3, dy: 1.5, label: 'D0' },
    { dx: 3, dy: 0.5, label: 'D1' },
    { dx: 3, dy: -0.5, label: 'D2' },
    { dx: 3, dy: -1.5, label: 'D3' },
    { dx: 3, dy: -2.5, label: 'QH' },
    { dx: 3, dy: -3.5, label: 'VCC' },
  ],
  // Real 16-pin DIP CD4017 pinout: 1 = Q5, 2 = Q1, 3 = Q0, 4 = Q2, 5 =
  // Q6, 6 = Q7, 7 = Q3, 8 = GND, then continuing up the right side 9 =
  // Q8, 10 = Q9, 11 = Q4, 12 = CARRY OUT, 13 = CLOCK INHIBIT (active-high
  // clock enable), 14 = CLOCK, 15 = RESET (active-high), 16 = VDD -
  // matching the datasheet's actual (non-sequential) pin order. Array
  // order matches what simulator.ts indexes by position, independent of
  // the dx/dy placement below.
  cd4017: [
    { dx: -3, dy: -3.5, label: 'Q5' },
    { dx: -3, dy: -2.5, label: 'Q1' },
    { dx: -3, dy: -1.5, label: 'Q0' },
    { dx: -3, dy: -0.5, label: 'Q2' },
    { dx: -3, dy: 0.5, label: 'Q6' },
    { dx: -3, dy: 1.5, label: 'Q7' },
    { dx: -3, dy: 2.5, label: 'Q3' },
    { dx: -3, dy: 3.5, label: 'GND' },
    { dx: 3, dy: 3.5, label: 'Q8' },
    { dx: 3, dy: 2.5, label: 'Q9' },
    { dx: 3, dy: 1.5, label: 'Q4' },
    { dx: 3, dy: 0.5, label: 'CO' },
    { dx: 3, dy: -0.5, label: 'CLK INH' },
    { dx: 3, dy: -1.5, label: 'CLOCK' },
    { dx: 3, dy: -2.5, label: 'RESET' },
    { dx: 3, dy: -3.5, label: 'VDD' },
  ],
  // Real 16-pin DIP CD4026 pinout: 1 = CLOCK, 2 = CLOCK INHIBIT
  // (active-high), 3 = DISPLAY ENABLE IN (active-high), 4 = DISPLAY
  // ENABLE OUT, 5 = CARRY OUT, 6 = g, 7 = f, 8 = GND, then continuing up
  // the right side 9 = d, 10 = a, 11 = e, 12 = b, 13 = c, 14 = ungated
  // "C" segment output, 15 = RESET (active-high), 16 = VDD - matching
  // the datasheet's actual pin order. Array order matches what
  // simulator.ts indexes by position, independent of the dx/dy
  // placement below.
  cd4026: [
    { dx: -3, dy: -3.5, label: 'CLOCK' },
    { dx: -3, dy: -2.5, label: 'CLK INH' },
    { dx: -3, dy: -1.5, label: 'DEI' },
    { dx: -3, dy: -0.5, label: 'DEO' },
    { dx: -3, dy: 0.5, label: 'CO' },
    { dx: -3, dy: 1.5, label: 'g' },
    { dx: -3, dy: 2.5, label: 'f' },
    { dx: -3, dy: 3.5, label: 'GND' },
    { dx: 3, dy: 3.5, label: 'd' },
    { dx: 3, dy: 2.5, label: 'a' },
    { dx: 3, dy: 1.5, label: 'e' },
    { dx: 3, dy: 0.5, label: 'b' },
    { dx: 3, dy: -0.5, label: 'c' },
    { dx: 3, dy: -1.5, label: "C'" },
    { dx: 3, dy: -2.5, label: 'RESET' },
    { dx: 3, dy: -3.5, label: 'VDD' },
  ],
  // Real 4-pin DIP PC817 pinout: pin 1 = Anode (IR LED), pin 2 = Cathode
  // (IR LED) down the left side, then continuing up the right side pin 3
  // = Emitter (phototransistor), pin 4 = Collector (phototransistor) -
  // matching the actual datasheet pin order. Array order matches what
  // simulator.ts indexes by position, independent of the dx/dy placement
  // below.
  pc817: [
    { dx: -3, dy: -0.5, label: 'A' },
    { dx: -3, dy: 0.5, label: 'K' },
    { dx: 3, dy: 0.5, label: 'E' },
    { dx: 3, dy: -0.5, label: 'C' },
  ],
};

// Component display names
export const componentNames: Record<ComponentType, string> = {
  battery: 'DC Voltage Source',
  resistor: 'Resistor',
  capacitor: 'Capacitor',
  inductor: 'Inductor',
  fuse: 'Fuse',
  polyfuse: 'Polyfuse (PTC Resettable Fuse)',
  transistorNpn: 'NPN Transistor',
  tip120: 'TIP120 NPN Darlington',
  tip122: 'TIP122 NPN Darlington',
  transistorPnp: 'PNP Transistor',
  irf520: 'IRF520 MOSFET',
  irf540: 'IRF540 MOSFET',
  irlz44n: 'IRLZ44N MOSFET',
  switch: 'Switch (SPST)',
  pushButton: 'Push Button',
  diode: 'Diode',
  led: 'LED',
  zenerDiode: 'Zener Diode',
  variableResistor: 'Variable Resistor',
  potentiometer: 'Potentiometer',
  relay: 'Relay',
  relayModule: 'Relay Module',
  solenoidValve: 'Solenoid Valve',
  dcMotor: 'DC Motor',
  waterPump: 'Water Pump',
  servoMotor: 'Servo Motor',
  stepperMotor: 'Stepper Motor',
  buzzer: 'Buzzer',
  activeBuzzer: 'Active Buzzer',
  passiveBuzzer: 'Passive Buzzer',
  rgbLed: 'RGB LED',
  neopixel: 'NeoPixel (WS2812)',
  lcd16x2: 'LCD 16x2',
  oledSsd1306: 'OLED SSD1306',
  sevenSegment: '7-Segment Display',
  sevenSegment4: '4-Digit 7-Segment Display',
  ammeter: 'Ammeter',
  voltmeter: 'Voltmeter',
  ground: 'Ground',
  acSource: 'AC Voltage Source',
  dcCurrentSource: 'DC Current Source',
  transformer: 'Transformer',
  breadboard: 'Breadboard',
  andGate: 'AND Gate',
  orGate: 'OR Gate',
  notGate: 'NOT Gate',
  nandGate: 'NAND Gate',
  norGate: 'NOR Gate',
  xorGate: 'XOR Gate',
  bulb: 'Lamp',
  arduino: 'Arduino Uno',
  arduinoMega: 'Arduino Mega',
  arduinoNano: 'Arduino Nano',
  hcSr04: 'HC-SR04 Ultrasonic Sensor',
  lm35: 'LM35 Temperature Sensor',
  reg7805: '7805 Voltage Regulator',
  ams1117: 'AMS1117 3.3V Regulator',
  lm317: 'LM317 Adjustable Regulator',
  ldr: 'LDR (Photoresistor)',
  dht11: 'DHT11 Temperature & Humidity Sensor',
  pirMotion: 'PIR Motion Sensor',
  irObstacle: 'IR Obstacle Sensor',
  mq2Gas: 'MQ-2 Gas Sensor',
  flameSensor: 'Flame Sensor',
  ne555: 'NE555 Timer',
  lm741: 'LM741 Op-Amp',
  lm358: 'LM358 Dual Op-Amp',
  l293d: 'L293D Dual H-Bridge Driver',
  l298n: 'L298N Motor Driver Module',
  uln2003: 'ULN2003 Darlington Array',
  '74hc595': '74HC595 Shift Register (SIPO)',
  '74hc165': '74HC165 Shift Register (PISO)',
  cd4017: 'CD4017 Decade Counter',
  cd4026: 'CD4026 Decade Counter/Display Driver',
  pc817: 'PC817 Optocoupler',
  barrelJack: 'DC Barrel Jack',
  screwTerminal2pin: '2-Pin Screw Terminal',
  jstConnector2pin: 'JST 2-Pin Connector',
  uartHeader: 'UART Header',
  hc05: 'HC-05 Bluetooth Module',
  hc06: 'HC-06 Bluetooth Module',
  esp8266: 'ESP8266 Wi-Fi Module (ESP-01)',
  esp32: 'ESP32 Wi-Fi/BLE Module',
  nrf24l01: 'NRF24L01+ 2.4GHz Transceiver',
  rc522: 'RFID RC522 Reader (MFRC522)',
  max485: 'MAX485 RS-485 Transceiver',
  canBusModule: 'CAN Bus Module (MCP2515)',
  gpsNeo6m: 'GPS NEO-6M Module',
  i2cHeader: 'I2C Header',
  junction: 'Junction',
};

// Component categories for palette
export const componentCategories: Record<string, ComponentType[]> = {
  sources: ['battery', 'acSource', 'dcCurrentSource'],
  passive: ['resistor', 'capacitor', 'inductor', 'bulb'],
  semiconductor: ['diode', 'led', 'zenerDiode', 'transistorNpn', 'transistorPnp', 'tip120', 'tip122', 'irf520', 'irf540', 'irlz44n'],
  active: ['switch', 'pushButton', 'variableResistor', 'potentiometer', 'fuse', 'polyfuse', 'relay', 'relayModule', 'dcMotor', 'waterPump', 'servoMotor', 'stepperMotor', 'solenoidValve', 'buzzer', 'activeBuzzer', 'passiveBuzzer', 'rgbLed', 'neopixel', 'lcd16x2', 'oledSsd1306', 'sevenSegment', 'sevenSegment4', 'arduino', 'arduinoMega', 'arduinoNano'],
  measurement: ['ammeter', 'voltmeter'],
  other: ['ground', 'transformer', 'breadboard', 'barrelJack', 'screwTerminal2pin', 'jstConnector2pin', 'uartHeader', 'i2cHeader'],
  logic: ['andGate', 'orGate', 'notGate', 'nandGate', 'norGate', 'xorGate'],
  sensors: ['hcSr04', 'lm35', 'ldr', 'dht11', 'pirMotion', 'irObstacle', 'mq2Gas', 'flameSensor'],
  ics: ['ne555', 'lm741', 'lm358', 'l293d', 'l298n', 'uln2003', '74hc595', '74hc165', 'cd4017', 'cd4026', 'pc817', 'reg7805', 'ams1117', 'lm317'],
  communication: ['hc05', 'hc06', 'esp8266', 'esp32', 'nrf24l01', 'max485', 'canBusModule', 'gpsNeo6m', 'rc522'],
};

// Render function dispatcher
export function renderComponent(ctx: CanvasRenderingContext2D, comp: Component, isHovered: boolean) {
  switch (comp.type) {
    case 'battery': drawBatteryBody(ctx, comp, isHovered); break;
    case 'resistor': drawResistorBody(ctx, comp, isHovered); break;
    case 'capacitor': drawCapacitorBody(ctx, comp, isHovered); break;
    case 'inductor': drawInductorBody(ctx, comp, isHovered); break;
    case 'diode': drawDiodeBody(ctx, comp, isHovered, false); break;
    case 'led': drawLEDBody(ctx, comp, isHovered); break;
    case 'zenerDiode': drawDiodeBody(ctx, comp, isHovered, true); break;
    case 'bulb': drawBulbBody(ctx, comp, isHovered); break;
    case 'ground': drawGroundBody(ctx, comp, isHovered); break;
    case 'switch': drawSwitchBody(ctx, comp, isHovered); break;
    case 'pushButton': drawPushButtonBody(ctx, comp, isHovered); break;
    case 'fuse': drawFuseBody(ctx, comp, isHovered); break;
    case 'polyfuse': drawPolyfuseBody(ctx, comp, isHovered); break;
    case 'transistorNpn': drawTransistorBody(ctx, comp, isHovered, false); break;
    case 'transistorPnp': drawTransistorBody(ctx, comp, isHovered, true); break;
    case 'tip120': drawTransistorBody(ctx, comp, isHovered, false); break;
    case 'tip122': drawTransistorBody(ctx, comp, isHovered, false); break;
    case 'irf520': drawMosfetBody(ctx, comp, isHovered, 'IRF520'); break;
    case 'irf540': drawMosfetBody(ctx, comp, isHovered, 'IRF540'); break;
    case 'irlz44n': drawMosfetBody(ctx, comp, isHovered, 'IRLZ44N'); break;
    case 'relay': drawRelayBody(ctx, comp, isHovered); break;
    case 'relayModule': drawRelayModuleBody(ctx, comp, isHovered); break;
    case 'dcMotor': drawMotorBody(ctx, comp, isHovered); break;
    case 'waterPump': drawWaterPumpBody(ctx, comp, isHovered); break;
    case 'solenoidValve': drawSolenoidValveBody(ctx, comp, isHovered); break;
    case 'servoMotor': drawServoMotorBody(ctx, comp, isHovered); break;
    case 'stepperMotor': drawStepperMotorBody(ctx, comp, isHovered); break;
    case 'buzzer': drawBuzzerBody(ctx, comp, isHovered); break;
    case 'activeBuzzer': drawActiveBuzzerBody(ctx, comp, isHovered); break;
    case 'passiveBuzzer': drawPassiveBuzzerBody(ctx, comp, isHovered); break;
    case 'rgbLed': drawRgbLedBody(ctx, comp, isHovered); break;
    case 'neopixel': drawNeopixelBody(ctx, comp, isHovered); break;
    case 'lcd16x2': drawLcd16x2Body(ctx, comp, isHovered); break;
    case 'oledSsd1306': drawOledBody(ctx, comp, isHovered); break;
    case 'sevenSegment': drawSevenSegmentBody(ctx, comp, isHovered); break;
    case 'sevenSegment4': drawSevenSegment4Body(ctx, comp, isHovered); break;
    case 'ammeter': drawAmmeterBody(ctx, comp, isHovered); break;
    case 'voltmeter': drawVoltmeterBody(ctx, comp, isHovered); break;
    case 'acSource': drawACSourceBody(ctx, comp, isHovered); break;
    case 'dcCurrentSource': drawDCCurrentSourceBody(ctx, comp, isHovered); break;
    case 'transformer': drawTransformerBody(ctx, comp, isHovered); break;
    case 'variableResistor':
    case 'potentiometer': drawResistorBody(ctx, comp, isHovered); break;
    case 'andGate':
    case 'orGate':
    case 'nandGate':
    case 'norGate':
    case 'xorGate': drawLogicGateBody(ctx, comp, isHovered); break;
    case 'notGate': drawNOTGateBody(ctx, comp, isHovered); break;
    case 'breadboard': drawBreadboardBody(ctx, comp, isHovered); break;
    case 'arduino': drawArduinoBody(ctx, comp, isHovered); break;
    case 'arduinoMega': drawArduinoBody(ctx, comp, isHovered); break;
    case 'arduinoNano': drawArduinoBody(ctx, comp, isHovered); break;
    case 'hcSr04': drawHcSr04Body(ctx, comp, isHovered); break;
    case 'lm35': drawLm35Body(ctx, comp, isHovered); break;
    case 'ldr': drawLdrBody(ctx, comp, isHovered); break;
    case 'dht11': drawDht11Body(ctx, comp, isHovered); break;
    case 'pirMotion': drawPirMotionBody(ctx, comp, isHovered); break;
    case 'irObstacle': drawIrObstacleBody(ctx, comp, isHovered); break;
    case 'mq2Gas': drawMq2GasBody(ctx, comp, isHovered); break;
    case 'flameSensor': drawFlameSensorBody(ctx, comp, isHovered); break;
    case 'ne555': drawNE555Body(ctx, comp, isHovered); break;
    case 'lm741': drawLM741Body(ctx, comp, isHovered); break;
    case 'lm358': drawLM358Body(ctx, comp, isHovered); break;
    case 'l293d': drawL293DBody(ctx, comp, isHovered); break;
    case 'l298n': drawL298NBody(ctx, comp, isHovered); break;
    case 'uln2003': drawULN2003Body(ctx, comp, isHovered); break;
    case '74hc595': draw74HC595Body(ctx, comp, isHovered); break;
    case '74hc165': draw74HC165Body(ctx, comp, isHovered); break;
    case 'cd4017': drawCD4017Body(ctx, comp, isHovered); break;
    case 'cd4026': drawCD4026Body(ctx, comp, isHovered); break;
    case 'pc817': drawPC817Body(ctx, comp, isHovered); break;
    case 'reg7805': drawRegulatorBody(ctx, comp, isHovered, '7805', `${(comp.state?.outputVoltage as number ?? 5).toFixed(2)}V`); break;
    case 'ams1117': drawRegulatorBody(ctx, comp, isHovered, 'AMS1117', `${(comp.state?.outputVoltage as number ?? 3.3).toFixed(2)}V`); break;
    case 'lm317': drawRegulatorBody(ctx, comp, isHovered, 'LM317', `${(comp.state?.outputVoltage as number ?? (comp.props.outputVoltage as number) ?? 5).toFixed(2)}V`); break;
    case 'barrelJack': drawBarrelJackBody(ctx, comp, isHovered); break;
    case 'screwTerminal2pin': drawScrewTerminalBody(ctx, comp, isHovered); break;
    case 'jstConnector2pin': drawJstConnectorBody(ctx, comp, isHovered); break;
    case 'uartHeader': drawUartHeaderBody(ctx, comp, isHovered); break;
    case 'gpsNeo6m': drawGpsModuleBody(ctx, comp, isHovered); break;
    case 'hc05': drawBluetoothModuleBody(ctx, comp, isHovered, 'HC-05'); break;
    case 'hc06': drawBluetoothModuleBody(ctx, comp, isHovered, 'HC-06'); break;
    case 'esp8266': drawEspModuleBody(ctx, comp, isHovered, 'ESP8266'); break;
    case 'esp32': drawEspModuleBody(ctx, comp, isHovered, 'ESP32'); break;
    case 'rc522': drawRc522ModuleBody(ctx, comp, isHovered); break;
    case 'nrf24l01': drawNrf24ModuleBody(ctx, comp, isHovered); break;
    case 'max485': drawMax485Body(ctx, comp, isHovered); break;
    case 'canBusModule': drawCanBusModuleBody(ctx, comp, isHovered); break;
    case 'i2cHeader': drawI2cHeaderBody(ctx, comp, isHovered); break;
    case 'junction': drawJunctionBody(ctx, comp, isHovered); break;
  }
}

// A wire junction is just a small solid dot marking a branch point - it has
// no body/leads of its own, unlike every other component here.
function drawJunctionBody(ctx: CanvasRenderingContext2D, comp: Component, isHovered: boolean) {
  ctx.save();
  ctx.translate(comp.x * GRID_SIZE, comp.y * GRID_SIZE);

  const accent = isHovered ? COLORS.hoveredStroke : (comp.selected ? COLORS.selectedStroke : COLORS.terminalStroke);

  if (isHovered || comp.selected) {
    ctx.beginPath();
    ctx.arc(0, 0, 9, 0, Math.PI * 2);
    ctx.fillStyle = isHovered ? 'rgba(56, 189, 248, 0.2)' : 'rgba(245, 158, 11, 0.18)';
    ctx.fill();
  }

  ctx.beginPath();
  ctx.arc(0, 0, isHovered ? 6 : 4.5, 0, Math.PI * 2);
  ctx.fillStyle = accent;
  ctx.fill();
  ctx.strokeStyle = COLORS.background;
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.restore();
}
