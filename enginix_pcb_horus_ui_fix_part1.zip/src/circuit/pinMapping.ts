// Automatic pin mapping — Arduino board <-> Circuit Simulator wiring.
//
// Purely a *read* of state the simulator already computes every frame
// (Component.terminals[].netId, SimulationResult.netTerminalCounts — see
// simulator.ts's own `isWired` convention, reused here for consistency).
// This file adds no new solve logic and does not touch rendering or
// wiring behavior; it only classifies each of a board's existing
// terminals into the categories a sketch author cares about, and reports
// whether a wire (or net-label join) actually reaches it.

import type { Component } from './types';

export type PinCategory =
  | 'digital'
  | 'analog'
  | 'pwm'
  | '5V'
  | '3.3V'
  | 'GND'
  | 'VIN'
  | 'AREF'
  | 'RESET'
  | 'other'; // e.g. the ICSP header — real terminals, but outside the requested categories

export interface PinMappingEntry {
  /** Terminal label as drawn on the board, e.g. 'D13', 'A0', '5V'. */
  label: string;
  category: PinCategory;
  /** True if this pin is actually wired to something (directly or via a shared net-label join). */
  connected: boolean;
}

// Duplicated from CircuitPinIO.ts's PWM_PINS rather than imported: that
// file deliberately stays free of any /src/circuit dependency, and this
// module (in /src/circuit) shouldn't reach into /src/arduino either. Both
// copies describe the same fixed hardware fact (which pins are
// PWM-capable), so drift risk is low - see CircuitPinIO.ts's own comment.
const PWM_PINS: Record<string, ReadonlySet<string>> = {
  arduino: new Set(['D3', 'D5', 'D6', 'D9', 'D10', 'D11']),
  arduinoNano: new Set(['D3', 'D5', 'D6', 'D9', 'D10', 'D11']),
  arduinoMega: new Set(['D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9', 'D10', 'D11', 'D12', 'D13', 'D44', 'D45', 'D46']),
};

function categorize(label: string, boardType: string): PinCategory {
  switch (label) {
    case '5V': return '5V';
    case '3V3': return '3.3V';
    case 'GND': return 'GND';
    case 'VIN': return 'VIN';
    case 'AREF': return 'AREF';
    case 'RESET': return 'RESET';
    default: break;
  }
  if (/^A\d+$/.test(label)) return 'analog';
  if (/^D\d+$/.test(label)) {
    const pwmSet = PWM_PINS[boardType] ?? PWM_PINS.arduino;
    return pwmSet.has(label) ? 'pwm' : 'digital';
  }
  return 'other'; // ICSP_* header pins
}

/**
 * Builds the current pin map for one board component. Safe to call every
 * time the canvas changes (or on a light poll) — it's a plain read, no
 * mutation, and handles a board with no `lastResult` yet (e.g. right after
 * being placed) by reporting every pin as disconnected rather than
 * throwing.
 */
export function buildPinMapping(
  board: Component,
  netTerminalCounts: Map<number, number> | undefined,
): PinMappingEntry[] {
  return board.terminals
    .filter(t => !t.label.startsWith('ICSP_')) // real pins only; ICSP header isn't one of the requested categories
    .map(t => ({
      label: t.label,
      category: categorize(t.label, board.type),
      // Mirrors simulator.ts's own `isWired` definition exactly: a net with
      // only one terminal on it is floating, not connected, even though it
      // still has a non-null netId.
      connected: t.netId !== null && (netTerminalCounts?.get(t.netId as number) ?? 0) > 1,
    }));
}
