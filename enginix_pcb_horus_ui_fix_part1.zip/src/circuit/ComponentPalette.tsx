/**
 * Component Palette - Sidebar for selecting and placing components
 */

import React, { useState, useMemo } from 'react';
import { Search } from 'lucide-react';
import type { ComponentType } from './types';
import { componentNames, componentCategories } from './componentDefs';

interface ComponentPaletteProps {
  onSelectComponent: (type: ComponentType) => void;
  selectedTool: string;
}

const categoryLabels: Record<string, string> = {
  sources: 'Sources',
  passive: 'Passive',
  semiconductor: 'Semiconductors',
  active: 'Active',
  measurement: 'Meters',
  other: 'Other',
  logic: 'Logic Gates',
  sensors: 'Sensors',
  ics: 'ICs',
  communication: 'Communication & IoT',
};

const categoryIcons: Record<string, string> = {
  sources: '⚡',
  passive: '🔌',
  semiconductor: '💎',
  active: '⚙️',
  measurement: '📊',
  other: '🔧',
  logic: '🔲',
  sensors: '📡',
  ics: '🧠',
  communication: '📶',
};

export const ComponentPalette: React.FC<ComponentPaletteProps> = ({ onSelectComponent, selectedTool }) => {
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({
    sources: true,
    passive: true,
    semiconductor: true,
    active: true,
    measurement: true,
    logic: true,
    other: false,
    sensors: true,
    ics: true,
    communication: true,
  });
  const [searchQuery, setSearchQuery] = useState('');

  const toggleCategory = (cat: string) => {
    setExpandedCategories(prev => ({ ...prev, [cat]: !prev[cat] }));
  };

  const query = searchQuery.trim().toLowerCase();
  const isSearching = query.length > 0;

  // While searching, only show components whose name matches, and force
  // every category with a match open (so results are always visible).
  const visibleCategories = useMemo(() => {
    return Object.entries(componentCategories).map(([category, types]) => ({
      category,
      types: isSearching
        ? types.filter(type => componentNames[type].toLowerCase().includes(query))
        : types,
    }));
  }, [query, isSearching]);

  return (
    <div className="w-full">
      <h3 className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-3 font-mono">
        Components
      </h3>

      {/* Search bar */}
      <div className="relative mb-3">
        <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search components..."
          className="w-full bg-slate-800/60 border border-slate-700 rounded pl-7 pr-2 py-1.5 text-[11px] text-slate-200 placeholder:text-slate-500 font-mono focus:border-amber-500/50 focus:outline-none"
        />
      </div>

      <div className="space-y-1">
        {visibleCategories.map(({ category, types }) => {
          if (isSearching && types.length === 0) return null;
          const expanded = isSearching ? true : expandedCategories[category];

          return (
            <div key={category} className="rounded overflow-hidden">
              <button
                onClick={() => toggleCategory(category)}
                className="w-full flex items-center gap-2 px-2 py-1.5 text-[11px] text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 transition-colors text-left"
              >
                <span className="text-xs">{expanded ? '▼' : '▶'}</span>
                <span>{categoryIcons[category]}</span>
                <span className="font-medium uppercase tracking-wide">{categoryLabels[category]}</span>
              </button>
              {expanded && (
                <div className="pl-2 space-y-0.5 mt-0.5">
                  {types.map((type) => (
                    <button
                      key={type}
                      onClick={() => onSelectComponent(type)}
                      className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-[11px] transition-all ${
                        selectedTool === type
                          ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                          : 'text-slate-300 hover:bg-slate-800/60 hover:text-slate-100 border border-transparent'
                      }`}
                    >
                      <ComponentIcon type={type} />
                      <span className="truncate">{componentNames[type]}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
        {isSearching && visibleCategories.every(c => c.types.length === 0) && (
          <p className="text-[11px] text-slate-500 font-mono px-2 py-2">No components match "{searchQuery}"</p>
        )}
      </div>
    </div>
  );
};

const ComponentIcon: React.FC<{ type: ComponentType }> = ({ type }) => {
  const iconMap: Record<string, string> = {
    battery: '🔋',
    resistor: '〰️',
    capacitor: '═',
    inductor: '➰',
    fuse: '🧨',
    polyfuse: '♻️',
    transistorNpn: '⏚N',
    tip120: '⏚D',
    tip122: '⏚D',
    transistorPnp: '⏚P',
    irf520: '⏚G',
    irf540: '⏚G',
    irlz44n: '⏚G',
    switch: '🔘',
    pushButton: '⏺️',
    diode: '▶|',
    led: '🔴',
    zenerDiode: '▶|z',
    variableResistor: '⮯',
    potentiometer: '☊',
    relay: '🔀',
    relayModule: '🧩',
    dcMotor: 'M',
    waterPump: 'P',
    servoMotor: 'S',
    stepperMotor: '⚙️',
    solenoidValve: '🚰',
    buzzer: '🔔',
    activeBuzzer: '🔊',
    passiveBuzzer: '🎵',
    rgbLed: '🌈',
    neopixel: '💡',
    lcd16x2: '🖥️',
    oledSsd1306: '📺',
    sevenSegment: '🔢',
    sevenSegment4: '⏱️',
    ammeter: 'A',
    voltmeter: 'V',
    ground: '⏚',
    acSource: '∿',
    dcCurrentSource: 'I',
    transformer: 'T',
    breadboard: '📟',
    andGate: '&',
    orGate: '≥1',
    notGate: '1',
    nandGate: '&̄',
    norGate: '≥̄1',
    xorGate: '=1',
    bulb: '💡',
    arduino: '🎛️',
    arduinoMega: '🎛️',
    arduinoNano: '🎛️',
    hcSr04: '📡',
    uartHeader: '🔌',
    hc05: '📶',
    hc06: '📶',
    esp8266: '📡',
    esp32: '📡',
    nrf24l01: '📻',
    lm35: '🌡️',
    ldr: '☀️',
    dht11: '💧',
    pirMotion: '🚶',
    irObstacle: '📶',
    mq2Gas: '🟢',
    flameSensor: '🔥',
    ne555: '🧠',
    lm741: '📈',
    lm358: '📈',
    l293d: '🔀',
    l298n: '🔀',
    uln2003: '🧲',
    '74hc595': '➡️',
    '74hc165': '⬅️',
    cd4017: '🔢',
    cd4026: '🔟',
    pc817: '🔌',
  };

  return (
    <span className="w-5 h-5 flex items-center justify-center text-[10px] bg-slate-800 rounded flex-shrink-0 font-mono">
      {iconMap[type] || '•'}
    </span>
  );
};

export default ComponentPalette;
