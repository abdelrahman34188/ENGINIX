// Automatic component mapping — which Circuit Simulator components are
// wired to each Arduino pin.
//
// Builds on pinMapping.ts's pin categorization/connection status and adds,
// for every pin, the list of *other* components sharing that pin's net.
// Works generically off Component.terminals[].netId, so every existing and
// future component type is supported automatically - nothing here is
// hardcoded to a specific component list. Purely a read of state the
// simulator already computes every frame; no new solve logic, no changes
// to rendering or wiring behavior.

import type { Component } from './types';
import { buildPinMapping, type PinMappingEntry } from './pinMapping';

export interface WiredComponentRef {
  componentId: number;
  /** Component type as used internally, e.g. 'led', 'servoMotor', 'relay'. */
  type: string;
  /** Display label as shown on the canvas. */
  label: string;
  /** Which terminal of that component is wired to this pin, e.g. 'Anode', 'Signal'. */
  terminal: string;
}

export interface ComponentMapEntry extends PinMappingEntry {
  /** Every other component wired to this pin's net (empty if unconnected). */
  components: WiredComponentRef[];
}

/**
 * Builds the live component map for one board. Safe to call on every
 * canvas change (or a light poll) - a plain read that never mutates
 * anything, and degrades to "no components" per pin (not a throw) when
 * there's no simulation result yet or nothing is wired.
 */
export function buildComponentMapping(
  board: Component,
  allComponents: Component[],
  netTerminalCounts: Map<number, number> | undefined,
): ComponentMapEntry[] {
  const pinEntries = buildPinMapping(board, netTerminalCounts);

  // Index every non-board terminal by the net it sits on, once, rather than
  // rescanning all components per pin.
  const netIndex = new Map<number, WiredComponentRef[]>();
  for (const comp of allComponents) {
    if (comp.id === board.id) continue; // don't list the board's own other pins as "connected components"
    for (const t of comp.terminals) {
      if (t.netId === null) continue;
      const refs = netIndex.get(t.netId) ?? [];
      refs.push({ componentId: comp.id, type: comp.type, label: comp.label || comp.type, terminal: t.label });
      netIndex.set(t.netId, refs);
    }
  }

  const netByLabel = new Map(board.terminals.map(t => [t.label, t.netId] as const));

  return pinEntries.map(entry => {
    const netId = netByLabel.get(entry.label);
    const components = netId !== null && netId !== undefined ? (netIndex.get(netId) ?? []) : [];
    return { ...entry, components };
  });
}
