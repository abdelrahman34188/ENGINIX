// @vitest-environment jsdom
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { CircuitEditor } from './CircuitEditor';
import type { Component, ComponentType } from './types';

function makeEditor(): CircuitEditor {
  vi.spyOn(window, 'requestAnimationFrame').mockReturnValue(0);
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {});
  const canvas = document.createElement('canvas');
  vi.spyOn(canvas, 'getContext').mockReturnValue({
    scale: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    beginPath: () => {},
    fillRect: () => {},
    strokeRect: () => {},
    fill: () => {},
    stroke: () => {},
    arc: () => {},
    moveTo: () => {},
    lineTo: () => {},
    fillText: () => {},
    setLineDash: () => {},
  } as unknown as CanvasRenderingContext2D);
  const container = document.createElement('div');
  vi.spyOn(container, 'getBoundingClientRect').mockReturnValue({
    width: 800, height: 600, top: 0, left: 0, right: 800, bottom: 600, x: 0, y: 0, toJSON: () => {},
  } as DOMRect);
  return new CircuitEditor(canvas, container);
}

// AABB overlap test built from the same terminal-reach half-extent estimate
// autoArrangeCircuit itself uses, so the assertion exercises the real
// no-overlap guarantee rather than a looser proxy for it.
function halfExtent(comp: Component): { hw: number; hh: number } {
  let hw = 1.5, hh = 1.5;
  for (const t of comp.terminals) {
    hw = Math.max(hw, Math.abs(t.dx));
    hh = Math.max(hh, Math.abs(t.dy));
  }
  return { hw: hw + 0.5, hh: hh + 0.5 };
}
function bbox(comp: Component) {
  const { hw, hh } = halfExtent(comp);
  return { minX: comp.x - hw, maxX: comp.x + hw, minY: comp.y - hh, maxY: comp.y + hh };
}
function overlaps(a: Component, b: Component, gap = 0): boolean {
  const A = bbox(a), B = bbox(b);
  return A.minX < B.maxX - gap && A.maxX > B.minX + gap && A.minY < B.maxY - gap && A.maxY > B.minY + gap;
}

describe('CircuitEditor.autoArrangeCircuit', () => {
  let editor: CircuitEditor;
  beforeEach(() => { editor = makeEditor(); });

  it('does nothing (and reports 0 moved) on an empty canvas', () => {
    const out = editor.autoArrangeCircuit();
    expect(out.moved).toBe(0);
    expect(editor.state.components).toEqual([]);
  });

  it('spreads overlapping components into non-overlapping positions with consistent spacing', () => {
    const types: ComponentType[] = ['resistor', 'resistor', 'capacitor', 'led', 'battery'];
    for (const t of types) editor.addComponentAt(t, 0, 0);

    const out = editor.autoArrangeCircuit();
    expect(out.moved).toBe(5);

    const comps = editor.state.components;
    for (let i = 0; i < comps.length; i++) {
      for (let j = i + 1; j < comps.length; j++) {
        expect(overlaps(comps[i], comps[j])).toBe(false);
      }
    }
  });

  it('keeps the Arduino near the centroid of the layout', () => {
    editor.addComponentAt('arduino', 0, 0);
    editor.addComponentAt('hcSr04', 10, 10);
    editor.addComponentAt('dht11', -10, 10);
    editor.addComponentAt('dcMotor', 10, -10);
    editor.addComponentAt('waterPump', -10, -10);
    editor.addComponentAt('battery', 20, 20);
    editor.addComponentAt('resistor', -20, -20);

    editor.autoArrangeCircuit();

    const comps = editor.state.components;
    const arduino = comps.find(c => c.type === 'arduino')!;
    const centroidX = comps.reduce((s, c) => s + c.x, 0) / comps.length;
    const centroidY = comps.reduce((s, c) => s + c.y, 0) / comps.length;
    // Arduino should sit much closer to the overall centroid than the
    // farthest-flung component does.
    const arduinoDist = Math.hypot(arduino.x - centroidX, arduino.y - centroidY);
    const maxDist = Math.max(...comps.map(c => Math.hypot(c.x - centroidX, c.y - centroidY)));
    expect(arduinoDist).toBeLessThan(maxDist);
  });

  it('groups sensors together, actuators together, and power components together', () => {
    editor.addComponentAt('arduino', 0, 0);
    const s1 = editor.addComponentAt('hcSr04', 50, 50);
    const s2 = editor.addComponentAt('dht11', -50, -50);
    const a1 = editor.addComponentAt('dcMotor', 50, -50);
    const a2 = editor.addComponentAt('servoMotor', -50, 50);
    const p1 = editor.addComponentAt('battery', 100, 100);
    const p2 = editor.addComponentAt('acSource', -100, -100);

    editor.autoArrangeCircuit();

    // Same-group components should end up much closer to each other than
    // to a component from an unrelated group.
    const distSensors = Math.hypot(s1.x - s2.x, s1.y - s2.y);
    const distActuators = Math.hypot(a1.x - a2.x, a1.y - a2.y);
    const distPower = Math.hypot(p1.x - p2.x, p1.y - p2.y);
    const distSensorToActuator = Math.hypot(s1.x - a1.x, s1.y - a1.y);
    const distSensorToPower = Math.hypot(s1.x - p1.x, s1.y - p1.y);

    expect(distSensors).toBeLessThan(distSensorToActuator);
    expect(distActuators).toBeLessThan(distSensorToActuator);
    expect(distPower).toBeLessThan(distSensorToPower);
  });

  it('preserves every electrical connection (wire endpoints untouched)', () => {
    const battery = editor.addComponentAt('battery', 0, 0);
    const resistor = editor.addComponentAt('resistor', 5, 0);
    const led = editor.addComponentAt('led', 10, 0);

    editor.state.wires.push({
      id: 9001,
      fromCompId: battery.id, fromTerminalId: battery.terminals[1].id,
      toCompId: resistor.id, toTerminalId: resistor.terminals[0].id,
      color: '#94a3b8', waypoints: [{ x: 2, y: 3 }], selected: false,
    });
    editor.state.wires.push({
      id: 9002,
      fromCompId: resistor.id, fromTerminalId: resistor.terminals[1].id,
      toCompId: led.id, toTerminalId: led.terminals[0].id,
      color: '#94a3b8', waypoints: [], selected: false,
    });

    const wiresBefore = JSON.parse(JSON.stringify(
      editor.state.wires.map(w => ({
        id: w.id, fromCompId: w.fromCompId, fromTerminalId: w.fromTerminalId,
        toCompId: w.toCompId, toTerminalId: w.toTerminalId,
      }))
    ));

    editor.autoArrangeCircuit();

    const wiresAfter = editor.state.wires.map(w => ({
      id: w.id, fromCompId: w.fromCompId, fromTerminalId: w.fromTerminalId,
      toCompId: w.toCompId, toTerminalId: w.toTerminalId,
    }));
    expect(wiresAfter).toEqual(wiresBefore);

    // Terminal absolute positions should have been recomputed to track the
    // component's new location, not left stale at the old spot.
    for (const comp of editor.state.components) {
      for (const t of comp.terminals) {
        expect(t.x).toBeCloseTo(comp.x * 20 + (t.dx * 20));
      }
    }
  });

  it('leaves components fully editable and undo/redo intact afterward', () => {
    const r1 = editor.addComponentAt('resistor', 0, 0);
    editor.addComponentAt('led', 3, 0);
    editor.saveHistory(); // baseline, mirrors how the app records the initial placement

    const beforeX = r1.x, beforeY = r1.y;
    const out = editor.autoArrangeCircuit();
    expect(out.moved).toBe(2);

    // Still fully editable: rotate/duplicate/select all keep working post-arrange.
    editor.state.selectedComponentIds = [r1.id];
    editor.rotateSelected();
    expect(r1.rotation).toBe(1);

    editor.undo(); // undoes the rotate
    editor.undo(); // undoes the arrange
    const restored = editor.state.components.find(c => c.id === r1.id)!;
    expect(restored.x).toBe(beforeX);
    expect(restored.y).toBe(beforeY);

    editor.redo(); // redo the arrange
    const rearranged = editor.state.components.find(c => c.id === r1.id)!;
    expect(rearranged.x === beforeX && rearranged.y === beforeY).toBe(false);
  });

  it('never moves junctions and leaves junction-attached wire routing untouched', () => {
    const a = editor.addComponentAt('battery', 0, 0);
    const b = editor.addComponentAt('resistor', 10, 0);
    const junction = editor.addComponentAt('junction', 5, 0);

    editor.state.wires.push({
      id: 9101, fromCompId: a.id, fromTerminalId: a.terminals[1].id,
      toCompId: junction.id, toTerminalId: junction.terminals[0].id,
      color: '#94a3b8', waypoints: [{ x: 3, y: 1 }], selected: false,
    });
    editor.state.wires.push({
      id: 9102, fromCompId: junction.id, fromTerminalId: junction.terminals[0].id,
      toCompId: b.id, toTerminalId: b.terminals[0].id,
      color: '#94a3b8', waypoints: [{ x: 7, y: 1 }], selected: false,
    });

    editor.autoArrangeCircuit();

    const junctionAfter = editor.state.components.find(c => c.id === junction.id)!;
    expect(junctionAfter.x).toBe(5);
    expect(junctionAfter.y).toBe(0);
    expect(editor.state.wires.find(w => w.id === 9101)!.waypoints).toEqual([{ x: 3, y: 1 }]);
    expect(editor.state.wires.find(w => w.id === 9102)!.waypoints).toEqual([{ x: 7, y: 1 }]);
  });
});
