/**
 * ClaudeCircuitOptimizer — turns a validated Claude circuit-optimization
 * JSON response (see OptimizationEngine for the schema it must follow)
 * into actual property updates on the live CircuitEditor.
 *
 * Parses and applies a validated Claude circuit-optimization response:
 *   1. parseCircuitOptimizationResponse — safely parse + shape-check the
 *      raw text Claude returned, validating every change against the
 *      circuit that was actually sent (so a change never targets a
 *      component that doesn't exist or a prop that isn't valid for it).
 *   2. applyCircuitOptimization — apply the validated changes to the live
 *      editor via its existing updateComponentProperty API (the same one
 *      the Properties panel itself uses), so undo/redo and re-simulation
 *      keep working exactly as they already do.
 *
 * Every failure path returns a friendly, human-readable message instead
 * of throwing, so callers can show it directly in the UI.
 */

import type { CircuitEditor } from './CircuitEditor';
import type { Component } from './types';
import { defaultProperties } from './componentDefs';

export interface CircuitOptimizationChange {
  id: number;
  prop: string;
  newValue: number | string | boolean;
  reason: string;
  /** Filled in during validation from the component's current value, for display. */
  oldValue?: number | string | boolean;
  /** Filled in during validation, so the UI can label the change. */
  componentType?: string;
}

export interface CircuitOptimizationResponse {
  success: boolean;
  summary?: string;
  estimatedPowerSavingsPercent?: number;
  componentChanges?: CircuitOptimizationChange[];
  wiringSuggestions?: string[];
  warnings?: string[];
  errors?: string[];
}

export type OptimizationParseResult =
  | { ok: true; data: CircuitOptimizationResponse }
  | { ok: false; error: string };

export type OptimizationApplyResult =
  | { ok: true; applied: number; warnings: string[] }
  | { ok: false; error: string };

function stripCodeFences(text: string): string {
  const trimmed = text.trim();
  const fenced = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  return fenced ? fenced[1].trim() : trimmed;
}

/**
 * Parse and shape-validate the raw text Claude returned, cross-checking
 * every proposed change against the actual circuit components (so a
 * change can never be applied to a missing id or an invalid prop key).
 */
export function parseCircuitOptimizationResponse(
  rawText: string,
  currentComponents: Component[]
): OptimizationParseResult {
  if (!rawText || !rawText.trim()) {
    return { ok: false, error: "Claude didn't return a response to parse." };
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(stripCodeFences(rawText));
  } catch {
    return { ok: false, error: "Claude's response wasn't valid JSON." };
  }

  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    return { ok: false, error: "Claude's response wasn't a JSON object." };
  }

  const data = parsed as Record<string, unknown>;

  if (typeof data.success !== 'boolean') {
    return { ok: false, error: 'Claude\'s response was missing a valid "success" field.' };
  }

  if (data.success === false) {
    return { ok: true, data: { success: false, errors: Array.isArray(data.errors) ? data.errors.map(String) : [] } };
  }

  const rawChanges = Array.isArray(data.componentChanges) ? data.componentChanges : [];
  const byId = new Map(currentComponents.map((c) => [c.id, c]));
  const validatedChanges: CircuitOptimizationChange[] = [];
  const warnings: string[] = [];

  for (const raw of rawChanges) {
    if (!raw || typeof (raw as { id?: unknown }).id !== 'number' || typeof (raw as { prop?: unknown }).prop !== 'string') {
      warnings.push('Skipped a malformed suggested change.');
      continue;
    }
    const change = raw as { id: number; prop: string; newValue: unknown; reason?: unknown };
    const comp = byId.get(change.id);
    if (!comp) {
      warnings.push(`Skipped a suggestion for component #${change.id} — it isn't in this circuit.`);
      continue;
    }
    const propDefs = defaultProperties[comp.type] || [];
    const propDef = propDefs.find((p) => p.key === change.prop);
    if (!propDef) {
      warnings.push(`Skipped an invalid property "${change.prop}" suggested for ${comp.type} #${change.id}.`);
      continue;
    }
    if (propDef.type === 'number') {
      if (typeof change.newValue !== 'number' || !Number.isFinite(change.newValue)) {
        warnings.push(`Skipped a non-numeric value suggested for ${comp.type} #${change.id}.${change.prop}.`);
        continue;
      }
      if ((propDef.min !== undefined && change.newValue < propDef.min) || (propDef.max !== undefined && change.newValue > propDef.max)) {
        warnings.push(`Skipped an out-of-range value for ${comp.type} #${change.id}.${change.prop}.`);
        continue;
      }
    }
    validatedChanges.push({
      id: change.id,
      prop: change.prop,
      newValue: change.newValue as number | string | boolean,
      reason: typeof change.reason === 'string' ? change.reason : '',
      oldValue: comp.props[change.prop],
      componentType: comp.type,
    });
  }

  return {
    ok: true,
    data: {
      success: true,
      summary: typeof data.summary === 'string' ? data.summary : '',
      estimatedPowerSavingsPercent: typeof data.estimatedPowerSavingsPercent === 'number' ? data.estimatedPowerSavingsPercent : 0,
      componentChanges: validatedChanges,
      wiringSuggestions: Array.isArray(data.wiringSuggestions) ? data.wiringSuggestions.map(String) : [],
      warnings: [...(Array.isArray(data.warnings) ? data.warnings.map(String) : []), ...warnings],
      errors: Array.isArray(data.errors) ? data.errors.map(String) : [],
    },
  };
}

/**
 * Apply a specific set of already-validated changes to the live editor.
 * Callers can pass a subset (e.g. only the changes the person checked in
 * the UI) rather than the full list from the response.
 */
export function applyCircuitOptimization(
  editor: CircuitEditor,
  changes: CircuitOptimizationChange[]
): OptimizationApplyResult {
  if (changes.length === 0) {
    return { ok: false, error: 'No changes to apply.' };
  }

  let applied = 0;
  const warnings: string[] = [];

  for (const change of changes) {
    const comp = editor.state.components.find((c) => c.id === change.id);
    if (!comp) {
      warnings.push(`Component #${change.id} no longer exists — skipped.`);
      continue;
    }
    editor.updateComponentProperty(change.id, change.prop, change.newValue);
    applied += 1;
  }

  if (applied === 0) {
    return { ok: false, error: 'None of the suggested changes could be applied — the circuit may have changed.' };
  }

  return { ok: true, applied, warnings };
}
