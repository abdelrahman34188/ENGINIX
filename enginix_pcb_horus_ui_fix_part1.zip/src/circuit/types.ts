/**
 * Circuit Simulator Type Definitions
 * Core types for the electrical circuit simulation engine
 */

// Unique ID generator
let nextId = 1;
export function uid(): number { return nextId++; }
export function resetIds() { nextId = 1; }

// A terminal (pin) on a component
export interface Terminal {
  id: number;
  componentId: number;
  // Local offset from component center (in grid units)
  dx: number;
  dy: number;
  // Absolute position (computed during rendering)
  x: number;
  y: number;
  label: string;
  // Which net this terminal belongs to (set by wiring system)
  netId: number | null;
}

// Wire connecting two terminals
export interface Wire {
  id: number;
  fromTerminalId: number;
  toTerminalId: number;
  fromCompId: number;
  toCompId: number;
  color: string;
  // Waypoints for routing (in grid coords)
  waypoints: Array<{ x: number; y: number }>;
  selected: boolean;
  // Optional net label (e.g. "VCC", "GND", "SIGNAL"). Two wires sharing the
  // same non-empty label (trimmed, case-insensitive) are treated as
  // electrically joined even when not physically connected - see
  // buildNets in simulator.ts. Undefined on wires from older saved
  // projects; treated the same as an empty/no label.
  netLabel?: string;
}

// Component property definition
export interface PropertyDef {
  name: string;
  key: string;
  type: 'number' | 'string' | 'select' | 'boolean' | 'presetNumber';
  unit?: string;
  min?: number;
  max?: number;
  step?: number;
  options?: Array<{ label: string; value: string }>;
  /** For type 'presetNumber': quick-pick numeric values shown in a dropdown, with a "Custom" option that reveals a free-entry number input (still bounded by min/max/step). */
  presets?: number[];
  defaultValue: number | string | boolean;
}

// Electrical component
export interface Component {
  id: number;
  type: ComponentType;
  // Grid position ( snapped to grid )
  x: number;
  y: number;
  // Rotation in 90-degree increments (0, 1, 2, 3)
  rotation: number;
  // Properties (voltage, resistance, etc.)
  props: Record<string, number | string | boolean>;
  // Connection terminals
  terminals: Terminal[];
  // Display
  label: string;
  selected: boolean;
  // Simulation state (computed each frame)
  voltage: number;
  current: number;
  power: number;
  // For dynamic components (switches, etc.)
  state: Record<string, unknown>;
}

export type ComponentType =
  | 'battery'
  | 'resistor'
  | 'capacitor'
  | 'inductor'
  | 'fuse'
  | 'polyfuse'
  | 'transistorNpn'
  | 'transistorPnp'
  | 'irf520'
  | 'irf540'
  | 'irlz44n'
  | 'tip120'
  | 'tip122'
  | 'uartHeader'
  | 'hc05'
  | 'hc06'
  | 'esp8266'
  | 'esp32'
  | 'nrf24l01'
  | 'max485'
  | 'canBusModule'
  | 'gpsNeo6m'
  | 'rc522'
  | 'i2cHeader'
  | 'switch'
  | 'pushButton'
  | 'diode'
  | 'led'
  | 'zenerDiode'
  | 'variableResistor'
  | 'potentiometer'
  | 'relay'
  | 'relayModule'
  | 'solenoidValve'
  | 'dcMotor'
  | 'waterPump'
  | 'servoMotor'
  | 'stepperMotor'
  | 'buzzer'
  | 'activeBuzzer'
  | 'passiveBuzzer'
  | 'rgbLed'
  | 'neopixel'
  | 'lcd16x2'
  | 'oledSsd1306'
  | 'sevenSegment'
  | 'sevenSegment4'
  | 'ammeter'
  | 'voltmeter'
  | 'ground'
  | 'acSource'
  | 'dcCurrentSource'
  | 'transformer'
  | 'breadboard'
  | 'andGate'
  | 'orGate'
  | 'notGate'
  | 'nandGate'
  | 'norGate'
  | 'xorGate'
  | 'bulb'
  | 'arduino'
  | 'arduinoMega'
  | 'arduinoNano'
  | 'hcSr04'
  | 'lm35'
  | 'ldr'
  | 'dht11'
  | 'pirMotion'
  | 'irObstacle'
  | 'mq2Gas'
  | 'flameSensor'
  | 'ne555'
  | 'lm741'
  | 'lm358'
  | 'l293d'
  | 'l298n'
  | 'uln2003'
  | '74hc595'
  | '74hc165'
  | 'cd4017'
  | 'cd4026'
  | 'pc817'
  | 'barrelJack'
  | 'screwTerminal2pin'
  | 'jstConnector2pin'
  | 'reg7805'
  | 'ams1117'
  | 'lm317'
  // Wire junction: an auto-created branch point with a single terminal.
  // Never placed from the palette - the wiring editor creates/removes
  // these automatically when a wire is split, clicked, or merges back
  // down to a simple pass-through. See CircuitEditor's wire-splitting
  // and junction-cleanup logic.
  | 'junction';

// Component definition (metadata for each type)
export interface ComponentDef {
  type: ComponentType;
  displayName: string;
  category: 'sources' | 'passive' | 'semiconductor' | 'active' | 'measurement' | 'logic' | 'other' | 'sensors';
  description: string;
  width: number;   // Grid units
  height: number;  // Grid units
  properties: PropertyDef[];
  // Terminal definitions (relative to component center)
  terminalDefs: Array<{ dx: number; dy: number; label: string }>;
  // Render function type hint
  render: (ctx: CanvasRenderingContext2D, comp: Component, isHovered: boolean) => void;
}

// Net (connected group of terminals)
export interface Net {
  id: number;
  terminalIds: number[];
  // Computed voltage at this net (relative to ground)
  voltage: number;
}

// Circuit simulation result
export interface SimulationResult {
  converged: boolean;
  iterations: number;
  nodeVoltages: Map<number, number>;  // netId -> voltage
  branchCurrents: Map<number, number>; // componentId -> current
  powers: Map<number, number>;         // componentId -> power
  error: number;
  // How many terminals sit on each net (netId -> count). A count of 1 means
  // that terminal is floating (unwired) - its solved voltage reads 0V the
  // same as an actually-grounded pin, so this is how components with
  // optional active-low inputs (e.g. the NE555's RESET) tell "nothing
  // wired here" apart from "deliberately driven low".
  netTerminalCounts?: Map<number, number>;
}

// Editor state
export interface EditorState {
  components: Component[];
  wires: Wire[];
  nets: Net[];
  // View
  offsetX: number;
  offsetY: number;
  scale: number;
  // Interaction
  mode: 'select' | 'pan' | 'wire' | 'place';
  placingComponentType: ComponentType | null;
  selectedTool: string;
  // Selection
  selectedComponentIds: number[];
  selectedWireIds: number[];
  hoveredTerminalId: number | null;
  hoveredComponentId: number | null;
  hoveredWireId: number | null;
  // Wiring state
  wiringFrom: { componentId: number; terminalId: number } | null;
  // Bend points (grid units) clicked so far while drawing the current wire.
  // Consecutive points (and the start/end terminals) are auto-connected
  // with 90° elbows - see wireRouting.ts.
  wiringWaypoints: Array<{ x: number; y: number }>;
  // Where the in-progress wire would currently snap to, for the live
  // preview (pin/junction, existing wire, or grid). Null when not wiring
  // or nothing is in snap range.
  snapIndicator: { x: number; y: number; kind: 'pin' | 'wire' | 'grid' } | null;
  // Drag
  isDragging: boolean;
  dragStartX: number;
  dragStartY: number;
  // Multi-select rect
  selectRect: { x: number; y: number; w: number; h: number } | null;
  // Grid
  gridSize: number;
  showGrid: boolean;
  snapToGrid: boolean;
  // History for undo/redo
  history: HistoryEntry[];
  historyIndex: number;
  // Simulation
  simulating: boolean;
  lastResult: SimulationResult | null;
}

export interface HistoryEntry {
  components: Component[];
  wires: Wire[];
}

// Terminal hit result
export interface TerminalHit {
  componentId: number;
  terminalId: number;
  x: number;
  y: number;
}
