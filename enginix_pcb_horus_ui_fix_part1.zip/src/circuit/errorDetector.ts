/**
 * Circuit Error Detector
 * Analyzes the current circuit (components, wiring, and the latest
 * simulation result) and reports faults such as short circuits, blown
 * fuses, burned-out components, overloads, and unconnected parts.
 *
 * This module is read-only with respect to the circuit: it never mutates
 * components/wires, it just inspects them and produces a list of findings.
 */

import type { Component, Wire, SimulationResult } from './types';
import { buildNets } from './simulator';

export type ErrorSeverity = 'critical' | 'warning';

export type CircuitErrorType =
  | 'short_circuit'
  | 'blown_fuse'
  | 'polyfuse_tripped'
  | 'burned_component'
  | 'overload'
  | 'unconnected_component'
  | 'open_connection'
  | 'no_power_source'
  | 'no_ground'
  | 'convergence_failure'
  | 'wrong_polarity'
  | 'floating_wire'
  | 'missing_led_resistor'
  | 'unsafe_voltage';

export interface CircuitError {
  // Stable id so callers can diff error lists cheaply (e.g. to avoid
  // re-rendering UI when nothing actually changed).
  id: string;
  type: CircuitErrorType;
  severity: ErrorSeverity;
  message: string;
  componentIds: number[];
}

const terminalId = (compId: number, termIdx: number) => compId * 10000 + termIdx;

function labelFor(comp: Component): string {
  return comp.label && comp.label.trim().length > 0 ? comp.label : comp.type;
}

// Two-terminal component types that are expected to have a voltage
// difference across them. If both of their terminals end up on the same
// electrical net, that component has been wired directly across itself.
const SHORTABLE_TYPES = new Set<Component['type']>([
  'battery', 'resistor', 'variableResistor', 'bulb', 'led', 'diode',
  'zenerDiode', 'capacitor', 'acSource', 'dcCurrentSource',
]);

const SOURCE_TYPES = new Set<Component['type']>(['battery', 'acSource', 'dcCurrentSource', 'arduino', 'arduinoMega', 'arduinoNano']);

// Component types with polarity-sensitive terminals (terminal 0 = anode/+,
// terminal 1 = cathode/-). Zener diodes are excluded — operating them
// reverse-biased is their normal, intended mode (voltage regulation).
const POLARIZED_TYPES = new Set<Component['type']>(['diode', 'led']);

// Types that meaningfully limit current in series with an LED. A wire,
// switch, fuse, ammeter, etc. present essentially zero resistance and don't
// count as protection.
const CURRENT_LIMITING_TYPES = new Set<Component['type']>([
  'resistor', 'variableResistor', 'potentiometer', 'bulb', 'dcMotor', 'waterPump', 'stepperMotor', 'buzzer', 'activeBuzzer', 'passiveBuzzer', 'relay', 'relayModule', 'solenoidValve',
]);

// Typical reverse breakdown voltage for a small-signal LED. Real parts vary,
// but most are only rated for a few volts of reverse bias before the
// junction fails, unlike a rectifier diode which tolerates tens of volts.
const LED_REVERSE_BREAKDOWN_V = 5;

// Extra-low-voltage safety threshold (mirrors the IEC SELV convention).
// Sources above this are still simulated, but flagged as a shock hazard.
const SAFE_TOUCH_VOLTAGE_V = 50;

const terminalNetId = (netMap: Map<number, number>, compId: number, termIdx: number) =>
  netMap.get(terminalId(compId, termIdx));

/**
 * Builds a topology graph over nets: for every component, every pair of its
 * terminals is treated as an edge (labeled with that component) between the
 * two nets those terminals sit on. Used to search for alternate current
 * paths (e.g. to check whether an LED has a current-limiting resistor
 * somewhere in its loop back to a source) without needing a solved
 * simulation result.
 */
function buildNetGraph(components: Component[], netMap: Map<number, number>): Map<number, Array<{ to: number; via: Component }>> {
  const adj = new Map<number, Array<{ to: number; via: Component }>>();
  const addEdge = (a: number, b: number, via: Component) => {
    if (!adj.has(a)) adj.set(a, []);
    adj.get(a)!.push({ to: b, via });
  };
  for (const comp of components) {
    const nets = comp.terminals.map((_, i) => terminalNetId(netMap, comp.id, i));
    for (let i = 0; i < nets.length; i++) {
      for (let j = i + 1; j < nets.length; j++) {
        const a = nets[i];
        const b = nets[j];
        if (a === undefined || b === undefined || a === b) continue;
        addEdge(a, b, comp);
        addEdge(b, a, comp);
      }
    }
  }
  return adj;
}

/** Breadth-first search for a path between two nets, skipping edges that belong to `excludeCompId`. */
function findPath(
  adj: Map<number, Array<{ to: number; via: Component }>>,
  start: number,
  target: number,
  excludeCompId: number
): Component[] | null {
  const visited = new Set<number>([start]);
  const queue: Array<{ net: number; path: Component[] }> = [{ net: start, path: [] }];
  while (queue.length > 0) {
    const { net, path } = queue.shift()!;
    if (net === target && path.length > 0) return path;
    for (const edge of adj.get(net) || []) {
      if (edge.via.id === excludeCompId || visited.has(edge.to)) continue;
      visited.add(edge.to);
      queue.push({ net: edge.to, path: [...path, edge.via] });
    }
  }
  return null;
}

// Error types severe enough that the electrical result would be meaningless
// or actively unsafe to compute/display — callers should skip running the
// solver (and zero out live readouts) while these are present.
const BLOCKING_ERROR_TYPES = new Set<CircuitErrorType>([
  'short_circuit', 'floating_wire', 'missing_led_resistor',
]);

/** Filters a findings list down to the subset that should prevent simulation from running. */
export function getBlockingErrors(errors: CircuitError[]): CircuitError[] {
  return errors.filter(e => e.severity === 'critical' && BLOCKING_ERROR_TYPES.has(e.type));
}

/**
 * Detect faults in the circuit. Safe to call every simulation tick —
 * it does O(components + wires) work and allocates no shared state.
 */
export function detectCircuitErrors(
  components: Component[],
  wires: Wire[],
  result: SimulationResult | null
): CircuitError[] {
  const errors: CircuitError[] = [];
  if (components.length === 0) return errors;

  const netMap = buildNets(components, wires);

  // How many terminals (across all components) share each net —
  // used to spot components that aren't wired to anything.
  const netSize = new Map<number, number>();
  for (const comp of components) {
    for (let i = 0; i < comp.terminals.length; i++) {
      const nid = netMap.get(terminalId(comp.id, i));
      if (nid !== undefined) netSize.set(nid, (netSize.get(nid) || 0) + 1);
    }
  }

  // 1. Simulation failed to converge (contradictory/impossible network)
  if (result && !result.converged) {
    errors.push({
      id: 'convergence',
      type: 'convergence_failure',
      severity: 'critical',
      message: 'Simulation failed to converge — the circuit may contain an impossible or conflicting connection.',
      componentIds: [],
    });
  }

  // 2. Short circuits: a component's two terminals land on the same net
  for (const comp of components) {
    if (SHORTABLE_TYPES.has(comp.type) && comp.terminals.length >= 2) {
      const nA = netMap.get(terminalId(comp.id, 0));
      const nB = netMap.get(terminalId(comp.id, 1));
      if (nA !== undefined && nB !== undefined && nA === nB) {
        const isSource = SOURCE_TYPES.has(comp.type);
        errors.push({
          id: `short-${comp.id}`,
          type: 'short_circuit',
          severity: 'critical',
          message: isSource
            ? `${labelFor(comp)} is short-circuited — its own terminals are wired directly together.`
            : `${labelFor(comp)} is shorted out — both of its terminals are on the same connection.`,
          componentIds: [comp.id],
        });
      }
    }
  }

  // 3. Blown fuses
  for (const comp of components) {
    if (comp.type === 'fuse' && comp.state?.blown) {
      errors.push({
        id: `fuse-${comp.id}`,
        type: 'blown_fuse',
        severity: 'critical',
        message: `${labelFor(comp)} has blown from excess current.`,
        componentIds: [comp.id],
      });
    }
  }

  // 3b. Tripped polyfuses - a warning, not critical, since a resettable
  // PTC recovers on its own once the fault clears and it cools down,
  // unlike a one-shot Fuse which needs replacing.
  for (const comp of components) {
    if (comp.type === 'polyfuse' && comp.state?.tripped) {
      errors.push({
        id: `polyfuse-${comp.id}`,
        type: 'polyfuse_tripped',
        severity: 'warning',
        message: `${labelFor(comp)} has tripped from excess current and is current-limiting until it cools down.`,
        componentIds: [comp.id],
      });
    }
  }

  // 4. Burned-out components (LEDs / bulbs pushed past their limits)
  for (const comp of components) {
    if ((comp.type === 'led' || comp.type === 'bulb') && comp.state?.burned) {
      errors.push({
        id: `burned-${comp.id}`,
        type: 'burned_component',
        severity: 'critical',
        message: `${labelFor(comp)} has burned out from overvoltage or overcurrent.`,
        componentIds: [comp.id],
      });
    }
  }

  // 5. Overload warnings — currently exceeding rating but not yet failed
  if (result) {
    for (const comp of components) {
      const current = Math.abs(result.branchCurrents.get(comp.id) || 0);

      if (comp.type === 'fuse' && !comp.state?.blown) {
        const rating = (comp.props.currentRating as number) || 1;
        if (current > rating) {
          errors.push({
            id: `overload-${comp.id}`,
            type: 'overload',
            severity: 'warning',
            message: `${labelFor(comp)} is carrying ${current.toFixed(2)}A, above its ${rating}A rating.`,
            componentIds: [comp.id],
          });
        }
      }

      if (comp.type === 'led' && !comp.state?.burned) {
        const maxCurrent = ((comp.props.maxCurrent as number) || 20) / 1000;
        if (current > maxCurrent) {
          errors.push({
            id: `overload-${comp.id}`,
            type: 'overload',
            severity: 'warning',
            message: `${labelFor(comp)} is drawing ${(current * 1000).toFixed(1)}mA, above its ${(maxCurrent * 1000).toFixed(0)}mA rating.`,
            componentIds: [comp.id],
          });
        }
      }

      if (comp.type === 'bulb' && !comp.state?.burned) {
        const ratedV = (comp.props.ratedVoltage as number) || 12;
        const nA = comp.terminals.length > 0 ? netMap.get(terminalId(comp.id, 0)) : undefined;
        const nB = comp.terminals.length > 1 ? netMap.get(terminalId(comp.id, 1)) : undefined;
        const vA = nA !== undefined ? (result.nodeVoltages.get(nA) || 0) : 0;
        const vB = nB !== undefined ? (result.nodeVoltages.get(nB) || 0) : 0;
        const v = Math.abs(vA - vB);
        if (v > ratedV * 1.2 && v <= ratedV * 1.5) {
          errors.push({
            id: `overload-${comp.id}`,
            type: 'overload',
            severity: 'warning',
            message: `${labelFor(comp)} is running at ${v.toFixed(1)}V, above its ${ratedV}V rating.`,
            componentIds: [comp.id],
          });
        }
      }
    }
  }

  // 6. Unconnected or partially connected components
  for (const comp of components) {
    if (comp.terminals.length === 0 || comp.type === 'ground' || comp.type === 'junction') continue;

    const sizes = comp.terminals.map((_, i) => netSize.get(netMap.get(terminalId(comp.id, i)) ?? -1) || 1);
    const allIsolated = sizes.every(s => s <= 1);
    const someIsolated = sizes.some(s => s <= 1);

    if (allIsolated) {
      errors.push({
        id: `isolated-${comp.id}`,
        type: 'unconnected_component',
        severity: 'warning',
        message: `${labelFor(comp)} isn't connected to the rest of the circuit.`,
        componentIds: [comp.id],
      });
    } else if (someIsolated) {
      errors.push({
        id: `open-${comp.id}`,
        type: 'open_connection',
        severity: 'warning',
        message: `${labelFor(comp)} has an open (unconnected) terminal.`,
        componentIds: [comp.id],
      });
    }
  }

  // 7a. Floating wires — a wire whose endpoint no longer refers to a real
  // terminal (e.g. its component was deleted without cleaning up the wire).
  // These carry no current: buildNets() silently skips them, so they can
  // hide a connection the diagram makes look intact.
  const compById = new Map(components.map(c => [c.id, c]));
  for (const wire of wires) {
    const fromComp = compById.get(wire.fromCompId);
    const toComp = compById.get(wire.toCompId);
    const fromOk = !!fromComp && fromComp.terminals.some(t => t.id === wire.fromTerminalId);
    const toOk = !!toComp && toComp.terminals.some(t => t.id === wire.toTerminalId);
    if (!fromOk || !toOk) {
      errors.push({
        id: `floating-wire-${wire.id}`,
        type: 'floating_wire',
        severity: 'critical',
        message: `A wire is floating — one end isn't attached to a real component terminal, so it carries no current (KCL requires both ends of a conductor to terminate on a node). Delete and redraw it.`,
        componentIds: [],
      });
    }
  }

  // 7b. Wrong polarity / missing LED series resistor / unsafe voltage.
  // These need the net topology graph regardless of whether we have a
  // solved result yet.
  const netGraph = buildNetGraph(components, netMap);

  for (const comp of components) {
    if (comp.type !== 'led' || comp.terminals.length < 2) continue;
    const netA = terminalNetId(netMap, comp.id, 0); // anode
    const netB = terminalNetId(netMap, comp.id, 1); // cathode
    if (netA === undefined || netB === undefined || netA === netB) continue;

    const path = findPath(netGraph, netA, netB, comp.id);
    if (path) {
      const hasSource = path.some(c => SOURCE_TYPES.has(c.type));
      const hasLimiter = path.some(c => CURRENT_LIMITING_TYPES.has(c.type));
      if (hasSource && !hasLimiter) {
        errors.push({
          id: `missing-resistor-${comp.id}`,
          type: 'missing_led_resistor',
          severity: 'critical',
          message: `${labelFor(comp)} is wired straight across a power source with nothing limiting current (Ohm's law: with ~0Ω in series, I = V/R is enormous). Add a series resistor sized as R = (Vsource − Vforward) / Idesired to keep it under its current rating.`,
          componentIds: [comp.id],
        });
      }
    }
  }

  // Wrong polarity and LED reverse-breakdown need an actual solved result
  // to know which way current is trying to flow.
  if (result) {
    for (const comp of components) {
      if (!POLARIZED_TYPES.has(comp.type) || comp.terminals.length < 2) continue;
      const netA = terminalNetId(netMap, comp.id, 0); // anode
      const netB = terminalNetId(netMap, comp.id, 1); // cathode
      if (netA === undefined || netB === undefined || netA === netB) continue;

      const vd = (result.nodeVoltages.get(netA) || 0) - (result.nodeVoltages.get(netB) || 0);

      if (vd < -0.5) {
        errors.push({
          id: `polarity-${comp.id}`,
          type: 'wrong_polarity',
          severity: 'warning',
          message: `${labelFor(comp)} looks like it's installed backwards — its cathode (K) sits about ${Math.abs(vd).toFixed(1)}V above its anode (A), so the junction is reverse-biased and blocks current by design. Swap the two leads to let it conduct.`,
          componentIds: [comp.id],
        });
      }

      if (comp.type === 'led' && vd < -LED_REVERSE_BREAKDOWN_V) {
        errors.push({
          id: `unsafe-reverse-${comp.id}`,
          type: 'unsafe_voltage',
          severity: 'critical',
          message: `${labelFor(comp)} has ${Math.abs(vd).toFixed(1)}V of reverse bias across it, beyond a typical LED's ~${LED_REVERSE_BREAKDOWN_V}V reverse-breakdown rating — the junction can punch through and fail. Correct the polarity or add a reverse-protection diode.`,
          componentIds: [comp.id],
        });
      }
    }
  }

  // 7c. Unsafe source voltage — flagged structurally (from the component's
  // own rating) so it's caught even before a simulation is run. Mirrors the
  // IEC extra-low-voltage (SELV) convention: above this, exposed conductors
  // are a shock hazard.
  for (const comp of components) {
    if (comp.type !== 'battery' && comp.type !== 'acSource') continue;
    const v = Math.abs((comp.props.voltage as number) || 0);
    if (v > SAFE_TOUCH_VOLTAGE_V) {
      errors.push({
        id: `unsafe-voltage-${comp.id}`,
        type: 'unsafe_voltage',
        severity: 'warning',
        message: `${labelFor(comp)} is set to ${v}V, above the ${SAFE_TOUCH_VOLTAGE_V}V extra-low-voltage safety limit — exposed conductors in this circuit should be treated as a shock hazard.`,
        componentIds: [comp.id],
      });
    }
  }

  // 8. No power source anywhere in the circuit
  const hasSource = components.some(c => SOURCE_TYPES.has(c.type));
  if (!hasSource) {
    errors.push({
      id: 'no-source',
      type: 'no_power_source',
      severity: 'warning',
      message: 'The circuit has no power source (battery, AC source, or current source).',
      componentIds: [],
    });
  }

  // 9. No ground reference (simulation still runs, but voltages are
  // relative to an arbitrary reference node)
  const hasGround = components.some(c => c.type === 'ground');
  if (!hasGround && hasSource) {
    errors.push({
      id: 'no-ground',
      type: 'no_ground',
      severity: 'warning',
      message: 'No ground component found — voltages are measured relative to an arbitrary node.',
      componentIds: [],
    });
  }

  return errors;
}
