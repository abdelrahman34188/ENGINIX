import { describe, it, expect } from 'vitest';
import { defaultProperties, defaultTerminals, componentNames, componentCategories } from './componentDefs';
import { buildNets } from './simulator';
import { FOOTPRINTS } from '../pcb/footprints';
import { footprintKeyFor, hasFootprintFor } from '../pcb/simulatorSync';
import { convertCircuitToPCB } from '../pcb/convertFromCircuit';
import type { Component } from './types';

const NEW_TYPES = ['barrelJack', 'screwTerminal2pin', 'jstConnector2pin'] as const;

function makeComponent(type: Component['type'], id: number, rotation = 0): Component {
  const termDefs = defaultTerminals[type] || [];
  const props: Record<string, number | string | boolean> = {};
  for (const def of defaultProperties[type] || []) props[def.key] = def.defaultValue;
  return {
    id,
    type,
    x: 0,
    y: 0,
    rotation,
    props,
    label: `${type}_${id}`,
    selected: false,
    voltage: 0,
    current: 0,
    power: 0,
    terminals: termDefs.map((td, idx) => ({
      id: id * 100 + idx,
      componentId: id,
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label,
      netId: null,
    })),
    state: {},
  } as Component;
}

describe('New connector components: DC Barrel Jack, 2-Pin Screw Terminal, JST 2-Pin Connector', () => {
  it('are registered as placeable component types with names and terminals', () => {
    for (const type of NEW_TYPES) {
      expect(componentNames[type]).toBeTruthy();
      expect((defaultTerminals[type] || []).length).toBeGreaterThanOrEqual(2);
    }
  });

  it('appear in a palette category so they show up in the Circuit Simulator palette', () => {
    const allListed = Object.values(componentCategories).flat();
    for (const type of NEW_TYPES) {
      expect(allListed).toContain(type);
    }
  });

  it('electrical behavior: two pins on the same connector are NOT internally shorted (a connector is not a wire), but do join into one net once externally wired', () => {
    const jack = makeComponent('barrelJack', 1);
    const netMapUnwired = buildNets([jack], []);
    const tip = netMapUnwired.get(1 * 10000 + 0);
    const slv = netMapUnwired.get(1 * 10000 + 1);
    // Neither terminal should be unioned to the other by default.
    expect(tip).not.toBe(slv);

    // Wiring TIP and SLV to two ends of a resistor should place them on
    // two distinct, externally-defined nets (the connector itself adds no
    // extra connectivity beyond what's wired to it).
    const resistor = makeComponent('resistor', 2);
    const wires = [
      { id: 1, fromTerminalId: jack.terminals[0].id, toTerminalId: resistor.terminals[0].id, fromCompId: 1, toCompId: 2, color: '#fff', waypoints: [], selected: false },
      { id: 2, fromTerminalId: jack.terminals[1].id, toTerminalId: resistor.terminals[1].id, fromCompId: 1, toCompId: 2, color: '#fff', waypoints: [], selected: false },
    ];
    const netMap = buildNets([jack, resistor], wires);
    const netTip = netMap.get(1 * 10000 + 0);
    const netSlv = netMap.get(1 * 10000 + 1);
    const netResA = netMap.get(2 * 10000 + 0);
    const netResB = netMap.get(2 * 10000 + 1);
    expect(netTip).toBe(netResA);
    expect(netSlv).toBe(netResB);
    expect(netTip).not.toBe(netSlv);
  });

  it('have a mapped PCB footprint with real pads', () => {
    for (const type of NEW_TYPES) {
      expect(hasFootprintFor(type)).toBe(true);
      const key = footprintKeyFor(type)!;
      expect(FOOTPRINTS[key]).toBeTruthy();
      expect(FOOTPRINTS[key].pads.length).toBeGreaterThanOrEqual(2);
      expect(FOOTPRINTS[key].category).toBe('Connectors');
    }
  });

  it('support rotation (rotation field is generic and preserved through terminal position computation)', () => {
    const rotated = makeComponent('jstConnector2pin', 3, 2); // 180 degrees (2 * 90)
    expect(rotated.rotation).toBe(2);
    // Rotation is a plain numeric field on Component - nothing type-specific
    // blocks it from being set for these new types.
  });

  it('support save/load (round-trips through plain JSON like every other component)', () => {
    for (const type of NEW_TYPES) {
      const comp = makeComponent(type, 10);
      const json = JSON.stringify(comp);
      const restored = JSON.parse(json) as Component;
      expect(restored.type).toBe(type);
      expect(restored.terminals.length).toBe(comp.terminals.length);
      expect(restored.props).toEqual(comp.props);
    }
  });

  it('support Convert to PCB (each produces a placed footprint, none appear in "unmapped")', () => {
    const comps = NEW_TYPES.map((type, i) => makeComponent(type, i + 1));
    const result = convertCircuitToPCB(comps, []);
    expect(result.unmapped).toEqual([]);
    expect(result.components.length).toBe(NEW_TYPES.length);
    for (const c of result.components) {
      expect(FOOTPRINTS[c.footprint]).toBeTruthy();
    }
  });
});
