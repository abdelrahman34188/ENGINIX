import { describe, it, expect } from 'vitest';
import {
  defaultProperties,
  defaultTerminals,
  componentNames,
  componentCategories,
} from './componentDefs';
import { simulateDC, updateComponentState } from './simulator';
import { FOOTPRINTS } from '../pcb/footprints';
import { footprintKeyFor, hasFootprintFor } from '../pcb/simulatorSync';
import { convertCircuitToPCB } from '../pcb/convertFromCircuit';
import { footprintBBox, padAbsolutePos } from '../pcb/geometry';
import type { Component, Wire } from './types';
import type { PCBComponent } from '../pcb/types';

const DARLINGTON_TYPES = ['tip120', 'tip122'] as const;

function makeComponent(type: Component['type'], id: number, propOverrides: Record<string, number | string | boolean> = {}): Component {
  const termDefs = defaultTerminals[type] || [];
  const props: Record<string, number | string | boolean> = {};
  for (const def of defaultProperties[type] || []) props[def.key] = def.defaultValue;
  Object.assign(props, propOverrides);
  return {
    id,
    type,
    x: 0,
    y: 0,
    rotation: 0,
    props,
    label: `${type}_${id}`,
    selected: false,
    voltage: 0,
    current: 0,
    power: 0,
    terminals: termDefs.map((td, idx) => ({
      id: id * 100 + idx,
      componentId: id,
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label,
      netId: null,
    })),
    state: {},
  } as Component;
}

function wire(id: number, a: Component, aIdx: number, b: Component, bIdx: number): Wire {
  return {
    id,
    fromTerminalId: a.terminals[aIdx].id,
    toTerminalId: b.terminals[bIdx].id,
    fromCompId: a.id,
    toCompId: b.id,
    color: '#fff',
    waypoints: [],
    selected: false,
  };
}

/** Common-emitter switch, load between Vcc and Collector, Emitter -> GND,
 * base driven through baseR off a separate Vbb rail returned through the
 * same GND - identical wiring pattern to the transistorNpn tests, just
 * parameterized over the Darlington part under test and an arbitrary
 * load component (relay coil / motor / LED) instead of a plain resistor. */
function solveDarlingtonSwitch(
  type: (typeof DARLINGTON_TYPES)[number],
  vcc: number,
  load: Component,
  loadTerminalIdx: number,
  vbb: number,
  baseOhms: number,
  priorState: Record<string, unknown> = {},
) {
  const vccSrc = makeComponent('battery', 1, { voltage: vcc });
  const q = makeComponent(type, 3);
  q.state = { ...priorState };
  const gnd = makeComponent('ground', 4);
  const vbbSrc = makeComponent('battery', 5, { voltage: vbb });
  const baseR = makeComponent('resistor', 6, { resistance: baseOhms });

  const wires: Wire[] = [
    wire(1, vccSrc, 0, load, loadTerminalIdx === 0 ? 1 : 0),
    wire(2, load, loadTerminalIdx, q, 1), // load -> Collector (idx 1)
    wire(3, q, 2, gnd, 0), // Emitter (idx 2) -> GND
    wire(4, vccSrc, 1, gnd, 0),
    wire(5, vbbSrc, 0, baseR, 0),
    wire(6, baseR, 1, q, 0), // -> Base (idx 0)
    wire(7, vbbSrc, 1, gnd, 0),
  ];

  const components = [vccSrc, load, q, gnd, vbbSrc, baseR];
  const result = simulateDC(components, wires);
  return { result, components, wires, q };
}

describe('TIP120/TIP122 NPN Darlington transistors', () => {
  it('are registered placeable component types with names and 3 terminals (Base/Collector/Emitter)', () => {
    for (const type of DARLINGTON_TYPES) {
      expect(componentNames[type]).toBeTruthy();
      expect((defaultTerminals[type] || []).length).toBe(3);
      expect((defaultTerminals[type] || []).map(t => t.label)).toEqual(['B', 'C', 'E']);
    }
  });

  it('appear in the semiconductor palette category, skipping nothing already present', () => {
    for (const type of DARLINGTON_TYPES) {
      expect(componentCategories.semiconductor).toContain(type);
    }
    // Existing parts stay untouched.
    expect(componentCategories.semiconductor).toContain('transistorNpn');
    expect(componentCategories.semiconductor).toContain('transistorPnp');
    expect(componentCategories.semiconductor).toContain('irf520');
  });

  it('has Darlington-appropriate default properties: much higher gain/current, higher VBE(on) than a small-signal BJT', () => {
    for (const type of DARLINGTON_TYPES) {
      const keys = (defaultProperties[type] || []).map(p => p.key);
      expect(keys).toEqual(
        expect.arrayContaining(['partNumber', 'beta', 'vBEon', 'baseTurnOnCurrent', 'maxCollectorCurrent']),
      );
      const props: Record<string, unknown> = {};
      for (const def of defaultProperties[type]) props[def.key] = def.defaultValue;
      expect(props.beta as number).toBeGreaterThan((defaultProperties.transistorNpn.find(p => p.key === 'beta')!.defaultValue as number));
      expect(props.maxCollectorCurrent as number).toBeGreaterThanOrEqual(5000);
    }
  });

  it('has a distinct TO-220 PCB footprint (3 pads, Transistors category, B/C/E pinout) - not sharing the small-signal TO-92 footprint', () => {
    for (const type of DARLINGTON_TYPES) {
      expect(hasFootprintFor(type)).toBe(true);
      const key = footprintKeyFor(type)!;
      const fp = FOOTPRINTS[key];
      expect(fp.pads.length).toBe(3);
      expect(fp.pads.map(p => p.id).sort()).toEqual(['B', 'C', 'E']);
      expect(fp.category).toBe('Transistors');
      expect(key).not.toBe(footprintKeyFor('transistorNpn'));
    }
  });

  it('supports Convert to PCB (produces a placed footprint, not left unmapped)', () => {
    const q120 = makeComponent('tip120', 1);
    const q122 = makeComponent('tip122', 2);
    const result = convertCircuitToPCB([q120, q122], []);
    expect(result.unmapped).toEqual([]);
    expect(result.components.length).toBe(2);
    for (const c of result.components) expect(FOOTPRINTS[c.footprint]).toBeTruthy();
  });

  it('supports rotation: PCB footprint bounding box swaps width/height at 90°/270°', () => {
    const key = footprintKeyFor('tip120')!;
    const fp = FOOTPRINTS[key];
    expect(footprintBBox(fp.width, fp.height, 0)).toEqual({ w: fp.width, h: fp.height });
    expect(footprintBBox(fp.width, fp.height, 90)).toEqual({ w: fp.height, h: fp.width });
    expect(footprintBBox(fp.width, fp.height, 180)).toEqual({ w: fp.width, h: fp.height });
    expect(footprintBBox(fp.width, fp.height, 270)).toEqual({ w: fp.height, h: fp.width });
  });

  it('supports flip: pad positions mirror on X when placed on the bottom side', () => {
    const key = footprintKeyFor('tip122')!;
    const fp = FOOTPRINTS[key];
    const topComp: PCBComponent = { id: 1, footprint: key, refDes: 'Q1', x: 0, y: 0, rotation: 0, side: 'top', props: {} };
    const bottomComp: PCBComponent = { ...topComp, side: 'bottom' };
    for (const p of fp.pads) {
      const topPos = padAbsolutePos(topComp, p);
      const bottomPos = padAbsolutePos(bottomComp, p);
      expect(bottomPos.x).toBeCloseTo(-topPos.x, 6);
      expect(bottomPos.y).toBeCloseTo(topPos.y, 6);
    }
  });

  for (const type of DARLINGTON_TYPES) {
    describe(type, () => {
      it('turns on from a real Base-Emitter junction current once it crosses Base Turn-On Current', () => {
        const coilLoad = makeComponent('resistor', 2, { resistance: 400 }); // typical 5V relay coil
        const { result, q } = solveDarlingtonSwitch(type, 12, coilLoad, 0, 5, 10_000, {});
        expect(result.converged).toBe(true);
        const updated = updateComponentState(q, result);
        expect(updated.state.transistorOn).toBe(true);
      });

      it('stays off when base drive is far below Base Turn-On Current', () => {
        const coilLoad = makeComponent('resistor', 2, { resistance: 400 });
        const { result, q } = solveDarlingtonSwitch(type, 12, coilLoad, 0, 0, 10_000, {});
        expect(result.converged).toBe(true);
        const updated = updateComponentState(q, result);
        expect(updated.state.transistorOn).toBe(false);
      });

      it('drives a relay coil (modeled as its equivalent coil resistance): once saturated, real current flows through the Collector-Emitter path', () => {
        const coilLoad = makeComponent('resistor', 2, { resistance: 400 }); // typical 5V relay coil
        const { result } = solveDarlingtonSwitch(type, 12, coilLoad, 0, 5, 10_000, { transistorOn: true });
        expect(result.converged).toBe(true);
        const coilCurrent = Math.abs(result.branchCurrents.get(2) || 0);
        expect(coilCurrent).toBeGreaterThan(0);
      });

      it('drives a DC motor: once saturated, real current flows through the motor winding (Vcc / coilResistance)', () => {
        const motor = makeComponent('dcMotor', 2, { coilResistance: 24 });
        const { result } = solveDarlingtonSwitch(type, 12, motor, 0, 5, 10_000, { transistorOn: true });
        expect(result.converged).toBe(true);
        const motorCurrent = Math.abs(result.branchCurrents.get(2) || 0);
        // 12V / 24 ohm ~= 0.5A through a saturated (near-zero Vce) path.
        expect(motorCurrent).toBeGreaterThan(0.3);
        expect(motorCurrent).toBeLessThan(0.6);
      });

      it('while off, the motor winding sees negligible current (Collector-Emitter path stays open)', () => {
        const motor = makeComponent('dcMotor', 2, { coilResistance: 24 });
        const { result } = solveDarlingtonSwitch(type, 12, motor, 0, 0, 10_000, { transistorOn: false });
        expect(result.converged).toBe(true);
        const motorCurrent = Math.abs(result.branchCurrents.get(2) || 0);
        expect(motorCurrent).toBeLessThan(0.0005);
      });

      it('drives an LED: once saturated, forward current flows through the LED (anode at Vcc, cathode into Collector)', () => {
        const ledLoad = makeComponent('led', 2, { forwardVoltage: 2, maxCurrent: 20 });
        // LED terminals are A(0)/K(1); wire Vcc->A, K->Collector.
        const { result } = solveDarlingtonSwitch(type, 12, ledLoad, 1, 5, 10_000, { transistorOn: true });
        expect(result.converged).toBe(true);
        const ledCurrent = Math.abs(result.branchCurrents.get(2) || 0);
        expect(ledCurrent).toBeGreaterThan(0);
      });

      it('reports the real Base-Emitter voltage (not the generic terminal0/1 diff) as the component voltage', () => {
        const coilLoad = makeComponent('resistor', 2, { resistance: 400 });
        const { result, q } = solveDarlingtonSwitch(type, 12, coilLoad, 0, 5, 10_000, { transistorOn: true });
        const updated = updateComponentState(q, result);
        // Darlington VBE(on) default is 1V - well below the ~12V
        // Base-Collector rail difference the generic calc would give.
        expect(Math.abs(updated.voltage)).toBeGreaterThan(0.4);
        expect(Math.abs(updated.voltage)).toBeLessThan(1.5);
      });
    });
  }
});
