/**
 * Orthogonal ("Manhattan") wire routing helpers.
 *
 * All functions here work in plain grid-unit coordinates - callers convert
 * to/from screen or "world*GRID_SIZE" pixel space themselves, so the same
 * math can be reused for hit-testing (editor) and drawing (renderer)
 * without duplicating the routing logic in two places.
 */

export interface GPoint { x: number; y: number; }

/** Snap a point to quarter-grid-unit increments - matches the existing
 * junction/branch-point convention so wire bends land on tidy spots. */
export function snapToFineGrid(p: GPoint): GPoint {
  return { x: Math.round(p.x * 4) / 4, y: Math.round(p.y * 4) / 4 };
}

// Choose which leg goes first for a single 90° corner between two anchors
// that aren't already aligned: move along whichever axis has the larger
// delta first, so the corner reads naturally (Tinkercad-style single
// L-bend) instead of always defaulting to one fixed orientation.
function elbowPoint(a: GPoint, b: GPoint): GPoint {
  if (Math.abs(b.x - a.x) >= Math.abs(b.y - a.y)) {
    return { x: b.x, y: a.y };
  }
  return { x: a.x, y: b.y };
}

/**
 * Build a full 90°-only polyline through a sequence of anchor points,
 * auto-inserting one elbow corner between any two anchors that aren't
 * already horizontally or vertically aligned. Anchors already aligned are
 * joined with a single straight segment (no pointless jog).
 *
 * Also returns, per output segment, which "leg" (index into the original
 * anchors array) it belongs to - needed when splitting a routed wire so the
 * waypoints on either side of the split can be divided correctly.
 */
export function buildOrthogonalPathWithLegs(anchors: GPoint[]): { points: GPoint[]; legOfSegment: number[] } {
  const points: GPoint[] = anchors.length > 0 ? [anchors[0]] : [];
  const legOfSegment: number[] = [];

  for (let i = 0; i < anchors.length - 1; i++) {
    const a = anchors[i];
    const b = anchors[i + 1];
    if (Math.abs(a.x - b.x) > 1e-6 && Math.abs(a.y - b.y) > 1e-6) {
      const corner = elbowPoint(a, b);
      if (Math.abs(corner.x - a.x) > 1e-6 || Math.abs(corner.y - a.y) > 1e-6) {
        points.push(corner);
        legOfSegment.push(i);
      }
    }
    points.push(b);
    legOfSegment.push(i);
  }

  return { points, legOfSegment };
}

/** Convenience wrapper when the leg mapping isn't needed (rendering). */
export function buildOrthogonalPath(anchors: GPoint[]): GPoint[] {
  return buildOrthogonalPathWithLegs(anchors).points;
}

/**
 * Removes redundant manual waypoints from a wire's routing without
 * changing where the wire actually goes: a waypoint is redundant if the
 * elbow path would look identical without it (it's already implied by its
 * neighbors, sits exactly on the straight segment between them, or
 * duplicates the point next to it). Used for "auto-clean wire routing" -
 * tidies up wires that accumulated pointless bends from manual dragging.
 */
export function simplifyWaypoints(from: GPoint, waypoints: GPoint[], to: GPoint): GPoint[] {
  const anchors = [from, ...waypoints, to];
  let changed = true;

  while (changed && anchors.length > 2) {
    changed = false;
    for (let i = 1; i < anchors.length - 1; i++) {
      const prev = anchors[i - 1];
      const curr = anchors[i];
      const next = anchors[i + 1];

      const dupPrev = Math.abs(curr.x - prev.x) < 1e-6 && Math.abs(curr.y - prev.y) < 1e-6;
      const dupNext = Math.abs(curr.x - next.x) < 1e-6 && Math.abs(curr.y - next.y) < 1e-6;
      // Redundant if it duplicates a neighbor, or if prev->next is already
      // a single straight (horizontal/vertical) run that curr sits on -
      // i.e. removing it changes nothing about the routed path.
      const collinearHorizontal = Math.abs(prev.y - curr.y) < 1e-6 && Math.abs(curr.y - next.y) < 1e-6;
      const collinearVertical = Math.abs(prev.x - curr.x) < 1e-6 && Math.abs(curr.x - next.x) < 1e-6;

      if (dupPrev || dupNext || collinearHorizontal || collinearVertical) {
        anchors.splice(i, 1);
        changed = true;
        break;
      }
    }
  }

  return anchors.slice(1, -1);
}

/** Nearest point on segment [a,b] to p, and the distance to it. */
function nearestOnSegment(p: GPoint, a: GPoint, b: GPoint): { point: GPoint; dist: number } {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const lenSq = dx * dx + dy * dy;
  let t = lenSq === 0 ? 0 : ((p.x - a.x) * dx + (p.y - a.y) * dy) / lenSq;
  t = Math.max(0, Math.min(1, t));
  const cx = a.x + t * dx;
  const cy = a.y + t * dy;
  return { point: { x: cx, y: cy }, dist: Math.hypot(p.x - cx, p.y - cy) };
}

/** Nearest point to p lying anywhere on the (already-built) polyline. */
export function nearestPointOnPath(p: GPoint, points: GPoint[]): { point: GPoint; dist: number } | null {
  if (points.length < 2) return null;
  let best: { point: GPoint; dist: number } | null = null;
  for (let i = 0; i < points.length - 1; i++) {
    const cand = nearestOnSegment(p, points[i], points[i + 1]);
    if (!best || cand.dist < best.dist) best = cand;
  }
  return best;
}

/** Same as nearestPointOnPath, but also reports which original anchor "leg"
 * the nearest point falls on - used to split a wire's waypoints correctly. */
export function nearestPointOnPathWithLegs(
  p: GPoint,
  points: GPoint[],
  legOfSegment: number[]
): { point: GPoint; leg: number; dist: number } | null {
  if (points.length < 2) return null;
  let best: { point: GPoint; leg: number; dist: number } | null = null;
  for (let i = 0; i < points.length - 1; i++) {
    const cand = nearestOnSegment(p, points[i], points[i + 1]);
    if (!best || cand.dist < best.dist) {
      best = { point: cand.point, leg: legOfSegment[i], dist: cand.dist };
    }
  }
  return best;
}
