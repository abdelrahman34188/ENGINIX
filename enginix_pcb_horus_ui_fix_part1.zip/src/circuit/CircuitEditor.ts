/**
 * Circuit Editor - Main controller class
 * Handles all interaction, state management, simulation, and rendering
 */

import type {
  Component, Wire, EditorState, ComponentType,
  HistoryEntry, TerminalHit
} from './types';
import { uid } from './types';
import {
  GRID_SIZE, defaultProperties, defaultTerminals,
  componentNames, getWireColor
} from './componentDefs';
import { simulateDC, updateComponentState, buildNets, advanceVisualState } from './simulator';
import { detectCircuitErrors, getBlockingErrors, type CircuitError } from './errorDetector';
import { CircuitRenderer } from './renderer';
import { circuitAudio } from './circuitAudio';
import {
  buildOrthogonalPathWithLegs, nearestPointOnPathWithLegs,
  snapToFineGrid, simplifyWaypoints, type GPoint
} from './wireRouting';

// Helper: deep clone for history
function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

export function createDefaultState(): EditorState {
  return {
    components: [],
    wires: [],
    nets: [],
    offsetX: 0,
    offsetY: 0,
    scale: 1,
    mode: 'select',
    placingComponentType: null,
    selectedTool: 'select',
    selectedComponentIds: [],
    selectedWireIds: [],
    hoveredTerminalId: null,
    hoveredComponentId: null,
    hoveredWireId: null,
    wiringFrom: null,
    wiringWaypoints: [],
    snapIndicator: null,
    isDragging: false,
    dragStartX: 0,
    dragStartY: 0,
    selectRect: null,
    gridSize: 1,
    showGrid: true,
    snapToGrid: true,
    history: [],
    historyIndex: -1,
    simulating: true,
    lastResult: null,
  };
}

export class CircuitEditor {
  state: EditorState;
  renderer: CircuitRenderer;
  canvas: HTMLCanvasElement;
  container: HTMLElement;

  // Mouse tracking
  mouseX = 0;
  mouseY = 0;
  isMouseDown = false;
  panStartX = 0;
  panStartY = 0;
  panStartOffsetX = 0;
  panStartOffsetY = 0;

  // Callbacks
  onStateChange?: () => void;
  onSelectionChange?: () => void;
  onErrorsChange?: (errors: CircuitError[]) => void;

  // Additional state-change subscribers, additive on top of the single-slot
  // `onStateChange` above (which stays exactly as-is for existing callers).
  // Lets more than one consumer (e.g. Electrical Lab's own UI *and* the
  // Coding tab's board detector) react to component add/remove/move without
  // either overwriting the other's callback.
  private stateChangeListeners: Array<() => void> = [];
  addStateChangeListener(fn: () => void): () => void {
    this.stateChangeListeners.push(fn);
    return () => {
      this.stateChangeListeners = this.stateChangeListeners.filter(l => l !== fn);
    };
  }
  private notifyStateChange() {
    this.onStateChange?.();
    for (const l of this.stateChangeListeners) l();
  }

  // Detected circuit faults (short circuits, blown fuses, overloads, etc.)
  // Recomputed every simulation tick; onErrorsChange only fires when the
  // set of detected issues actually changes, to avoid flooding React.
  errors: CircuitError[] = [];
  private lastErrorsKey = '';

  // Animation
  private animFrame = 0;
  private lastTime = 0;

  // Watches the container's actual box size so the canvas re-sizes itself
  // whenever that changes — including a hidden ancestor becoming visible,
  // which fires no 'resize' event on window but does change the container's
  // rect from 0x0 to real dimensions.
  private resizeObserver?: ResizeObserver;

  constructor(canvas: HTMLCanvasElement, container: HTMLElement) {
    this.canvas = canvas;
    this.container = container;
    this.renderer = new CircuitRenderer(canvas);
    this.state = createDefaultState();
    this.setupEvents();
    this.startLoop();

    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.resize());
      this.resizeObserver.observe(container);
    }
  }

  destroy() {
    cancelAnimationFrame(this.animFrame);
    circuitAudio.stopAll();
    this.resizeObserver?.disconnect();
    this.canvas.removeEventListener('pointerdown', this.onPointerDown);
    this.canvas.removeEventListener('pointermove', this.onPointerMove);
    this.canvas.removeEventListener('pointerup', this.onPointerUp);
    this.canvas.removeEventListener('wheel', this.onWheel);
    this.canvas.removeEventListener('contextmenu', this.onContextMenu);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('resize', this.onResize);
  }

  setupEvents() {
    this.canvas.addEventListener('pointerdown', this.onPointerDown);
    this.canvas.addEventListener('pointermove', this.onPointerMove);
    this.canvas.addEventListener('pointerup', this.onPointerUp);
    this.canvas.addEventListener('wheel', this.onWheel, { passive: false });
    this.canvas.addEventListener('contextmenu', this.onContextMenu);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('resize', this.onResize);
  }

  resize() {
    const rect = this.container.getBoundingClientRect();
    this.renderer.resize(rect.width, rect.height);
    this.render();
  }

  onResize = () => {
    this.resize();
  };

  startLoop() {
    const loop = (time: number) => {
      const dt = time - this.lastTime;
      this.lastTime = time;
      this.update(dt);
      this.render();
      this.animFrame = requestAnimationFrame(loop);
    };
    this.animFrame = requestAnimationFrame(loop);
  }

  update(dt: number) {
    // Run simulation periodically
    if (this.state.simulating) {
      this.runSimulation();
    }

    // Ease lamp brightness, motor rotation, relay contacts, and button
    // travel toward their (possibly just-updated) electrical targets. Runs
    // every frame regardless of `simulating` so components still animate
    // down to their idle/off state smoothly when simulation is paused.
    this.state.components = advanceVisualState(this.state.components, dt);

    // Start/stop/update every simulated sound (buzzer, motor whir, lamp
    // hum, relay/button/switch clicks) to match current component state.
    circuitAudio.sync(this.state.components);
  }

  runSimulation() {
    if (this.state.components.length === 0) return;

    // Structural validation pass — dead shorts, missing LED series
    // resistors, and floating (dangling) wires make the electrical result
    // meaningless or unsafe (e.g. an unbounded current spike). Catch those
    // *before* running the DC solver rather than reporting bogus numbers
    // computed from an invalid network.
    const structuralErrors = detectCircuitErrors(this.state.components, this.state.wires, null);
    const blocking = getBlockingErrors(structuralErrors);
    if (blocking.length > 0) {
      this.state.lastResult = null;
      this.state.components = this.state.components.map(comp => {
        const updated = { ...comp, state: { ...comp.state } };
        updated.current = 0;
        updated.power = 0;
        updated.voltage = 0;
        if (comp.type === 'led' || comp.type === 'bulb') {
          updated.state.brightness = 0;
        }
        return updated;
      });
      this.errors = structuralErrors;
      const blockedKey = `blocked:${structuralErrors.map(e => e.id).join('|')}`;
      if (blockedKey !== this.lastErrorsKey) {
        this.lastErrorsKey = blockedKey;
        this.onErrorsChange?.(structuralErrors);
      }
      return;
    }

    const result = simulateDC(this.state.components, this.state.wires);
    this.state.lastResult = result;

    // Update net assignments
    const netMap = buildNets(this.state.components, this.state.wires);
    const terminalId = (compId: number, termIdx: number) => compId * 10000 + termIdx;
    for (const comp of this.state.components) {
      for (let i = 0; i < comp.terminals.length; i++) {
        const nid = netMap.get(terminalId(comp.id, i));
        if (nid !== undefined) {
          comp.terminals[i].netId = nid;
        }
      }
    }

    // Update component states
    if (result.converged) {
      this.state.components = this.state.components.map(comp =>
        updateComponentState(comp, result)
      );
    }

    // runSimulation() replaces component objects with fresh clones each tick,
    // so anything holding onto an older reference (e.g. the properties panel)
    // needs to be told to re-fetch — otherwise readouts and switch state
    // appear frozen even though the circuit itself has updated.
    if (this.state.selectedComponentIds.length > 0) {
      this.onSelectionChange?.();
    }

    // Check for faults (shorts, blown fuses, overloads, open connections...).
    // Only notify listeners when the set of issues actually changed, since
    // this runs every simulation tick and most ticks nothing changes.
    const errors = detectCircuitErrors(this.state.components, this.state.wires, result);
    this.errors = errors;
    const errorsKey = errors.map(e => e.id).join('|');
    if (errorsKey !== this.lastErrorsKey) {
      this.lastErrorsKey = errorsKey;
      this.onErrorsChange?.(errors);
    }
  }

  // Turn simulation on/off. Turning it off doesn't just stop recomputing —
  // it also zeroes out live electrical readouts (brightness, current, etc.)
  // so components visually go dark/off immediately instead of freezing at
  // whatever state they were last in.
  setSimulating(active: boolean) {
    this.state.simulating = active;
    if (!active) {
      this.state.components = this.state.components.map(comp => {
        const updated = { ...comp, state: { ...comp.state } };
        updated.current = 0;
        updated.power = 0;
        updated.voltage = 0;
        switch (comp.type) {
          case 'led':
          case 'bulb':
            updated.state.brightness = 0;
            break;
          case 'dcMotor':
            updated.state.rpm = 0;
            break;
          case 'waterPump':
            updated.state.rpm = 0;
            updated.state.flowRatio = 0;
            break;
          case 'stepperMotor':
            updated.state.rpm = 0;
            updated.state.powered = false;
            break;
          case 'buzzer':
          case 'activeBuzzer':
            updated.state.active = false;
            break;
          case 'passiveBuzzer':
            updated.state.active = false;
            updated.state.frequency = 0;
            break;
          case 'rgbLed':
            updated.state.brightnessR = 0;
            updated.state.brightnessG = 0;
            updated.state.brightnessB = 0;
            break;
          case 'neopixel':
            updated.state.on = false;
            updated.state.pixelColors = [];
            break;
          case 'lcd16x2':
          case 'oledSsd1306':
            updated.state.on = false;
            break;
          case 'sevenSegment':
            updated.state.segments = {};
            break;
          case 'sevenSegment4':
            updated.state.digits = [{}, {}, {}, {}];
            break;
          case 'relay':
            updated.state.energized = false;
            break;
          case 'relayModule':
            updated.state.energized = false;
            updated.state.commandEnergized = false;
            updated.state.pendingDelayMs = 0;
            break;
          case 'solenoidValve':
            updated.state.open = false;
            break;
          case 'andGate':
          case 'orGate':
          case 'notGate':
          case 'nandGate':
          case 'norGate':
          case 'xorGate':
            updated.state.outputHigh = false;
            break;
        }
        return updated;
      });
      this.state.lastResult = null;
      this.errors = [];
      this.lastErrorsKey = '';
      this.onErrorsChange?.([]);
    }
    this.render();
    if (this.state.selectedComponentIds.length > 0) {
      this.onSelectionChange?.();
    }
  }

  render() {
    const rect = this.container.getBoundingClientRect();
    this.renderer.render(this.state, rect.width, rect.height, this.mouseX, this.mouseY);
  }

  // Hit testing
  hitTestTerminal(mx: number, my: number): TerminalHit | null {
    const world = this.renderer.screenToWorld(mx, my, this.state);
    const wx = world.x * GRID_SIZE;
    const wy = world.y * GRID_SIZE;

    let closest: TerminalHit | null = null;
    let closestDist = Infinity;

    for (const comp of this.state.components) {
      for (const term of comp.terminals) {
        const dx = term.x - wx;
        const dy = term.y - wy;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const threshold = 12 / this.state.scale;
        if (dist < threshold && dist < closestDist) {
          closestDist = dist;
          closest = { componentId: comp.id, terminalId: term.id, x: term.x, y: term.y };
        }
      }
    }

    return closest;
  }

  hitTestComponent(mx: number, my: number): number | null {
    const world = this.renderer.screenToWorld(mx, my, this.state);
    const wx = world.x;
    const wy = world.y;

    // Check in reverse order (top to bottom)
    for (let i = this.state.components.length - 1; i >= 0; i--) {
      const comp = this.state.components[i];
      const dx = Math.abs(comp.x - wx);
      const dy = Math.abs(comp.y - wy);
      const threshold = comp.type === 'junction' ? 0.6 : 4;
      if (dx < threshold && dy < threshold) {
        return comp.id;
      }
    }
    return null;
  }

  hitTestWire(mx: number, my: number): number | null {
    return this.hitTestWireAt(mx, my)?.wireId ?? null;
  }

  /**
   * Same proximity test as hitTestWire, but also returns where along the
   * wire the click landed (in grid units) - the "multiple invisible
   * connection points along every wire" requirement: any point on a wire's
   * length is a valid place to branch from, not just its two endpoints.
   * Used to place/reuse a junction when a wire itself is clicked.
   */
  hitTestWireAt(mx: number, my: number): { wireId: number; x: number; y: number; leg: number } | null {
    const world = this.renderer.screenToWorld(mx, my, this.state);
    const wx = world.x * GRID_SIZE;
    const wy = world.y * GRID_SIZE;

    let closest: { wireId: number; x: number; y: number; leg: number } | null = null;
    let closestDist = Infinity;

    for (const wire of this.state.wires) {
      const fromComp = this.state.components.find(c => c.id === wire.fromCompId);
      const toComp = this.state.components.find(c => c.id === wire.toCompId);
      if (!fromComp || !toComp) continue;

      const fromTerm = fromComp.terminals.find(t => t.id === wire.fromTerminalId);
      const toTerm = toComp.terminals.find(t => t.id === wire.toTerminalId);
      if (!fromTerm || !toTerm) continue;

      // Test against the actual routed (elbowed) path, including any
      // manual bend points - a click near a corner or a bent segment
      // should register the same as one on a straight run.
      const anchors: GPoint[] = [
        { x: fromTerm.x, y: fromTerm.y },
        ...wire.waypoints.map(w => ({ x: w.x * GRID_SIZE, y: w.y * GRID_SIZE })),
        { x: toTerm.x, y: toTerm.y },
      ];
      const { points, legOfSegment } = buildOrthogonalPathWithLegs(anchors);
      const near = nearestPointOnPathWithLegs({ x: wx, y: wy }, points, legOfSegment);
      if (!near) continue;

      // Never let a click on the path register right on top of either
      // endpoint - that's a pin/junction hit already handled by
      // hitTestTerminal, and splitting a wire at its own endpoint would
      // just create a useless zero-length stub.
      if (near.dist < 8 && near.dist < closestDist) {
        const distFromStart = Math.hypot(near.point.x - anchors[0].x, near.point.y - anchors[0].y);
        const distFromEnd = Math.hypot(near.point.x - anchors[anchors.length - 1].x, near.point.y - anchors[anchors.length - 1].y);
        if (distFromStart < 3 || distFromEnd < 3) continue;

        closestDist = near.dist;
        closest = {
          wireId: wire.id,
          x: near.point.x / GRID_SIZE,
          y: near.point.y / GRID_SIZE,
          leg: near.leg,
        };
      }
    }

    return closest;
  }

  /**
   * Splits `wireId` at grid point (gx, gy), inserting a junction there and
   * replacing the one wire with two. If a junction already sits at (or very
   * near) that point, it's reused instead of creating a duplicate - so
   * repeatedly clicking the same spot, or branching a second time off a
   * point that's already a junction, just connects to the existing one.
   * Returns the junction's connection point, ready to use like any
   * terminal hit (start a wire from it, or complete one onto it).
   */
  splitWireAtPoint(wireId: number, gx: number, gy: number, leg = 0): { componentId: number; terminalId: number } | null {
    // Snap to grid for tidy, predictable branch points.
    const snapped = snapToFineGrid({ x: gx, y: gy });
    const sx = snapped.x;
    const sy = snapped.y;

    // Reuse an existing junction sitting at this point, on ANY wire - lets
    // a second branch off an already-split point just connect to it
    // instead of stacking junctions.
    const existing = this.state.components.find(
      c => c.type === 'junction' && Math.abs(c.x - sx) < 0.15 && Math.abs(c.y - sy) < 0.15
    );
    if (existing) {
      return { componentId: existing.id, terminalId: existing.terminals[0].id };
    }

    const wire = this.state.wires.find(w => w.id === wireId);
    if (!wire) return null;
    const fromComp = this.state.components.find(c => c.id === wire.fromCompId);
    const toComp = this.state.components.find(c => c.id === wire.toCompId);
    if (!fromComp || !toComp) return null;
    const fromTerm = fromComp.terminals.find(t => t.id === wire.fromTerminalId);
    const toTerm = toComp.terminals.find(t => t.id === wire.toTerminalId);
    if (!fromTerm || !toTerm) return null;

    const junction = this.addComponentAt('junction', sx, sy);

    // Split the original wire's own bend points between the two new
    // segments at the leg that was clicked, so a wire routed with manual
    // corners keeps its shape on both sides of the split instead of
    // collapsing to straight lines.
    const clampedLeg = Math.max(0, Math.min(wire.waypoints.length, leg));
    const waypointsA = wire.waypoints.slice(0, clampedLeg);
    const waypointsB = wire.waypoints.slice(clampedLeg);

    const wireA: Wire = {
      id: uid(),
      fromCompId: wire.fromCompId,
      fromTerminalId: wire.fromTerminalId,
      toCompId: junction.id,
      toTerminalId: junction.terminals[0].id,
      color: wire.color,
      waypoints: waypointsA,
      selected: false,
    };
    const wireB: Wire = {
      id: uid(),
      fromCompId: junction.id,
      fromTerminalId: junction.terminals[0].id,
      toCompId: wire.toCompId,
      toTerminalId: wire.toTerminalId,
      color: wire.color,
      waypoints: waypointsB,
      selected: false,
    };

    // Replace the original wire in place with the two new segments -
    // preserves the electrical net (both segments still join fromTerm and
    // toTerm through the junction) and existing saved projects that load
    // this wire array keep working the same way.
    this.state.wires = this.state.wires.filter(w => w.id !== wireId);
    this.state.wires.push(wireA, wireB);

    return { componentId: junction.id, terminalId: junction.terminals[0].id };
  }

  /**
   * Removes junctions that no longer do anything useful: ones with no
   * wires left (orphaned dot), ones with only one wire left (dangling
   * stub), and ones with exactly two wires left (a plain pass-through,
   * electrically identical to a single wire) - the last case merges the
   * two wires into one directly connecting their outer endpoints, so
   * deleting a branch wire cleans the junction dot away automatically
   * instead of leaving redundant markers behind. Nets are unaffected: a
   * merged wire still connects the same two terminals the two segments did.
   */
  private cleanupJunctions() {
    let changed = true;
    while (changed) {
      changed = false;
      for (const comp of this.state.components) {
        if (comp.type !== 'junction') continue;
        const term = comp.terminals[0];
        if (!term) continue;
        const attached = this.state.wires.filter(w => w.fromTerminalId === term.id || w.toTerminalId === term.id);

        if (attached.length <= 1) {
          if (attached.length === 1) {
            this.state.wires = this.state.wires.filter(w => w.id !== attached[0].id);
          }
          this.state.components = this.state.components.filter(c => c.id !== comp.id);
          changed = true;
          break;
        }

        if (attached.length === 2) {
          const [w1, w2] = attached;
          const otherEnd = (w: Wire) =>
            w.fromTerminalId === term.id
              ? { compId: w.toCompId, termId: w.toTerminalId }
              : { compId: w.fromCompId, termId: w.fromTerminalId };
          const a = otherEnd(w1);
          const b = otherEnd(w2);
          if (a.compId === comp.id || b.compId === comp.id) continue; // self-loop stub, leave alone

          // Re-orient each half's waypoints so they read a -> junction and
          // junction -> b, then concatenate - keeps the merged wire's
          // route looking the way it did before the junction disappeared.
          const aWaypoints = w1.fromTerminalId === term.id
            ? [...w1.waypoints].reverse()
            : [...w1.waypoints];
          const bWaypoints = w2.fromTerminalId === term.id
            ? [...w2.waypoints]
            : [...w2.waypoints].reverse();

          const merged: Wire = {
            id: uid(),
            fromCompId: a.compId,
            fromTerminalId: a.termId,
            toCompId: b.compId,
            toTerminalId: b.termId,
            color: w1.color,
            waypoints: [...aWaypoints, ...bWaypoints],
            selected: false,
          };
          this.state.wires = this.state.wires.filter(w => w.id !== w1.id && w.id !== w2.id);
          this.state.wires.push(merged);
          this.state.components = this.state.components.filter(c => c.id !== comp.id);
          changed = true;
          break;
        }
      }
    }
  }

  // Actions
  addComponent(type: ComponentType) {
    this.saveHistory();

    const props: Record<string, number | string | boolean> = {};
    const propDefs = defaultProperties[type] || [];
    for (const def of propDefs) {
      props[def.key] = def.defaultValue;
    }

    // Label
    const existing = this.state.components.filter(c => c.type === type).length;
    const baseName = componentNames[type];
    const label = `${baseName}_${existing + 1}`;

    // Position: center of view
    const rect = this.container.getBoundingClientRect();
    const cx = (rect.width / 2 - this.state.offsetX) / (GRID_SIZE * this.state.scale);
    const cy = (rect.height / 2 - this.state.offsetY) / (GRID_SIZE * this.state.scale);

    // Snap to grid
    const x = Math.round(cx / this.state.gridSize) * this.state.gridSize;
    const y = Math.round(cy / this.state.gridSize) * this.state.gridSize;

    // Create terminals
    const termDefs = defaultTerminals[type] || [];
    const terminals = termDefs.map((td, i) => ({
      id: uid(),
      componentId: 0, // set below
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label || `T${i + 1}`,
      netId: null as number | null,
    }));

    const comp: Component = {
      id: uid(),
      type,
      x,
      y,
      rotation: 0,
      props,
      terminals,
      label,
      selected: false,
      voltage: 0,
      current: 0,
      power: 0,
      state: {},
    };

    // Set component ID on terminals and compute positions
    for (const t of comp.terminals) {
      t.componentId = comp.id;
    }

    // Compute terminal positions
    this.computeTerminalPositions(comp);

    this.state.components.push(comp);
    this.state.selectedComponentIds = [comp.id];
    this.state.selectedWireIds = [];

    this.notifyStateChange();
    this.onSelectionChange?.();
  }

  /**
   * Adds a component at an explicit grid position without touching the
   * current selection or centering the view. Used by programmatic circuit
   * builders (e.g. the AI Electrical Engineer) that need to place several
   * components at known coordinates before wiring them together.
   */
  addComponentAt(type: ComponentType, x: number, y: number): Component {
    const props: Record<string, number | string | boolean> = {};
    const propDefs = defaultProperties[type] || [];
    for (const def of propDefs) {
      props[def.key] = def.defaultValue;
    }

    const existing = this.state.components.filter(c => c.type === type).length;
    const baseName = componentNames[type];
    const label = `${baseName}_${existing + 1}`;

    const termDefs = defaultTerminals[type] || [];
    const terminals = termDefs.map((td, i) => ({
      id: uid(),
      componentId: 0,
      dx: td.dx,
      dy: td.dy,
      x: 0,
      y: 0,
      label: td.label || `T${i + 1}`,
      netId: null as number | null,
    }));

    const comp: Component = {
      id: uid(),
      type,
      x,
      y,
      rotation: 0,
      props,
      terminals,
      label,
      selected: false,
      voltage: 0,
      current: 0,
      power: 0,
      state: {},
    };

    for (const t of comp.terminals) {
      t.componentId = comp.id;
    }
    this.computeTerminalPositions(comp);
    this.state.components.push(comp);
    return comp;
  }

  /**
   * Wires two components together by terminal label (e.g. 'A'/'K' on an LED,
   * '1'/'2' on a resistor). Returns the created wire, or null if either
   * terminal label doesn't exist on the given component.
   */
  connectByLabel(compA: Component, labelA: string, compB: Component, labelB: string): Wire | null {
    const tA = compA.terminals.find(t => t.label === labelA);
    const tB = compB.terminals.find(t => t.label === labelB);
    if (!tA || !tB) return null;

    const wire: Wire = {
      id: uid(),
      fromTerminalId: tA.id,
      toTerminalId: tB.id,
      fromCompId: compA.id,
      toCompId: compB.id,
      color: getWireColor(this.state.wires.length),
      waypoints: [],
      selected: false,
    };
    this.state.wires.push(wire);
    return wire;
  }

  /**
   * Runs a builder callback that adds components/wires (via addComponentAt /
   * connectByLabel), committing the whole result as a single undo step and
   * refreshing the canvas + UI once at the end. Used by the AI Electrical
   * Engineer so a generated circuit undoes/redoes atomically.
   */
  buildCircuit(build: (editor: CircuitEditor) => void) {
    this.saveHistory();
    build(this);
    this.state.selectedComponentIds = [];
    this.state.selectedWireIds = [];
    this.updateAllTerminalPositions();
    this.notifyStateChange();
    this.onSelectionChange?.();
  }

  computeTerminalPositions(comp: Component) {
    const cos_r = Math.cos(-comp.rotation * Math.PI / 2);
    const sin_r = Math.sin(-comp.rotation * Math.PI / 2);

    for (const t of comp.terminals) {
      const rx = t.dx * GRID_SIZE * cos_r - t.dy * GRID_SIZE * sin_r;
      const ry = t.dx * GRID_SIZE * sin_r + t.dy * GRID_SIZE * cos_r;
      t.x = comp.x * GRID_SIZE + rx;
      t.y = comp.y * GRID_SIZE + ry;
    }
  }

  updateAllTerminalPositions() {
    for (const comp of this.state.components) {
      this.computeTerminalPositions(comp);
    }
  }

  /** Change the color of one or more wires (e.g. the current selection).
   * Can be called at any time, not just when the wire is first drawn. */
  setWireColor(wireIds: number[], color: string) {
    const targets = this.state.wires.filter(w => wireIds.includes(w.id));
    if (targets.length === 0) return;
    this.saveHistory();
    for (const wire of targets) wire.color = color;
    this.notifyStateChange();
    this.onSelectionChange?.();
  }

  /** Set (or clear, with an empty string) the net label on one or more
   * wires. Wires sharing the same label are treated as one electrical net
   * even when not physically connected - see buildNets in simulator.ts. */
  setWireNetLabel(wireIds: number[], label: string) {
    const targets = this.state.wires.filter(w => wireIds.includes(w.id));
    if (targets.length === 0) return;
    this.saveHistory();
    const trimmed = label.trim();
    for (const wire of targets) wire.netLabel = trimmed || undefined;
    this.notifyStateChange();
    this.onSelectionChange?.();
  }

  /** Strips redundant manual bend points from wires (the current selection,
   * or every wire if none are selected/specified) without changing where
   * any of them actually route - just tidies up bends left over from manual
   * dragging that no longer serve a purpose. */
  cleanWireRouting(wireIds?: number[]) {
    const ids = wireIds && wireIds.length > 0 ? wireIds : null;
    const targets = this.state.wires.filter(w => !ids || ids.includes(w.id));
    if (targets.length === 0) return;

    this.saveHistory();
    for (const wire of targets) {
      const fromComp = this.state.components.find(c => c.id === wire.fromCompId);
      const toComp = this.state.components.find(c => c.id === wire.toCompId);
      if (!fromComp || !toComp) continue;
      const fromTerm = fromComp.terminals.find(t => t.id === wire.fromTerminalId);
      const toTerm = toComp.terminals.find(t => t.id === wire.toTerminalId);
      if (!fromTerm || !toTerm) continue;

      const fromG = { x: fromTerm.x / GRID_SIZE, y: fromTerm.y / GRID_SIZE };
      const toG = { x: toTerm.x / GRID_SIZE, y: toTerm.y / GRID_SIZE };
      wire.waypoints = simplifyWaypoints(fromG, wire.waypoints, toG);
    }
    this.notifyStateChange();
    this.onSelectionChange?.();
  }

  deleteSelected() {
    if (this.state.selectedComponentIds.length === 0 && this.state.selectedWireIds.length === 0) return;
    this.saveHistory();

    // Remove wires connected to deleted components
    const deletedCompIds = new Set(this.state.selectedComponentIds);
    this.state.wires = this.state.wires.filter(
      w => !deletedCompIds.has(w.fromCompId) && !deletedCompIds.has(w.toCompId) && !this.state.selectedWireIds.includes(w.id)
    );

    // Remove selected components
    this.state.components = this.state.components.filter(
      c => !this.state.selectedComponentIds.includes(c.id)
    );

    // Remove selected wires
    this.state.wires = this.state.wires.filter(
      w => !this.state.selectedWireIds.includes(w.id)
    );

    // Tidy up any junctions that deleting those wires/components left
    // orphaned, dangling, or reduced to a plain pass-through.
    this.cleanupJunctions();

    this.state.selectedComponentIds = [];
    this.state.selectedWireIds = [];
    this.notifyStateChange();
    this.onSelectionChange?.();
  }

  rotateSelected() {
    if (this.state.selectedComponentIds.length === 0) return;
    this.saveHistory();

    for (const comp of this.state.components) {
      if (this.state.selectedComponentIds.includes(comp.id)) {
        comp.rotation = (comp.rotation + 1) % 4;
        this.computeTerminalPositions(comp);
      }
    }
    this.notifyStateChange();
  }

  duplicateSelected() {
    if (this.state.selectedComponentIds.length === 0) return;
    this.saveHistory();

    const newIds: number[] = [];
    for (const comp of this.state.components) {
      if (this.state.selectedComponentIds.includes(comp.id)) {
        const newComp: Component = {
          ...deepClone(comp),
          id: uid(),
          x: comp.x + 3,
          y: comp.y + 3,
          selected: true,
          terminals: comp.terminals.map(t => ({
            ...deepClone(t),
            id: uid(),
            componentId: comp.id, // will update below
            netId: null,
          })),
        };
        for (const t of newComp.terminals) {
          t.componentId = newComp.id;
        }
        this.computeTerminalPositions(newComp);
        this.state.components.push(newComp);
        newIds.push(newComp.id);
      }
    }

    this.state.selectedComponentIds = newIds;
    this.state.selectedWireIds = [];
    this.notifyStateChange();
    this.onSelectionChange?.();
  }

  /**
   * Auto Arrange - repositions every real component (junctions are wire
   * branch points, not placeable parts, so they're left alone) into a
   * non-overlapping layout that groups components by role:
   *   - Arduino boards anchor the center.
   *   - Sensors cluster above.
   *   - Actuators/outputs cluster below.
   *   - Power sources/ground cluster to the left.
   *   - Everything else clusters to the right.
   * Within each cluster, components are packed into a grid sized so no two
   * bounding boxes can touch, with consistent spacing between them - the
   * same "size the cell to the largest occupant" trick PCBEngine.autoArrange
   * uses for the same guarantee.
   *
   * Purely a placement pass: never rotates, renames, deletes, or rewires
   * anything, so all existing electrical connections (and every wire's
   * from/to terminals) are untouched. Wires between two moved components
   * have their manual waypoints cleared so they re-route as a clean direct
   * line (shorter wires, no stale diagonal jogs); wires touching a junction
   * keep their routing since the junction anchor doesn't move. Components
   * stay fully editable afterward, and the whole pass is one undo step.
   */
  autoArrangeCircuit(): { moved: number } {
    const movable = this.state.components.filter(c => c.type !== 'junction');
    if (movable.length === 0) return { moved: 0 };

    this.saveHistory();

    const SPACING = 3; // grid units between component bounding boxes
    const CLUSTER_GAP = 5; // grid units between cluster blocks

    // Approximate each component's half-width/half-height from how far its
    // terminals reach - a generic stand-in for a per-type bounding box that
    // works for every component without a hand-maintained size table, with
    // a floor so pinless/tiny parts still get a sane amount of room.
    const halfExtent = (comp: Component): { hw: number; hh: number } => {
      let hw = 1.5, hh = 1.5;
      for (const t of comp.terminals) {
        hw = Math.max(hw, Math.abs(t.dx));
        hh = Math.max(hh, Math.abs(t.dy));
      }
      return { hw: hw + 0.5, hh: hh + 0.5 };
    };

    const centerTypes = new Set<ComponentType>(['arduino', 'arduinoMega', 'arduinoNano']);
    const powerTypes = new Set<ComponentType>(['battery', 'acSource', 'dcCurrentSource', 'ground', 'transformer', 'fuse', 'polyfuse']);
    const sensorTypes = new Set<ComponentType>(['hcSr04', 'lm35', 'ldr', 'dht11', 'pirMotion', 'irObstacle', 'mq2Gas', 'flameSensor']);
    const actuatorTypes = new Set<ComponentType>([
      'relay', 'relayModule', 'dcMotor', 'waterPump', 'servoMotor', 'stepperMotor', 'solenoidValve',
      'buzzer', 'activeBuzzer', 'passiveBuzzer', 'rgbLed', 'neopixel',
      'lcd16x2', 'oledSsd1306', 'sevenSegment', 'sevenSegment4', 'led',
    ]);

    const centerGroup: Component[] = [];
    const sensorGroup: Component[] = [];
    const actuatorGroup: Component[] = [];
    const powerGroup: Component[] = [];
    const otherGroup: Component[] = [];
    for (const comp of movable) {
      if (centerTypes.has(comp.type)) centerGroup.push(comp);
      else if (sensorTypes.has(comp.type)) sensorGroup.push(comp);
      else if (actuatorTypes.has(comp.type)) actuatorGroup.push(comp);
      else if (powerTypes.has(comp.type)) powerGroup.push(comp);
      else otherGroup.push(comp);
    }
    // Deterministic ordering within each cluster so repeated runs are stable.
    const byId = (a: Component, b: Component) => a.id - b.id;
    centerGroup.sort(byId); sensorGroup.sort(byId); actuatorGroup.sort(byId);
    powerGroup.sort(byId); otherGroup.sort(byId);

    // Packs a list of components into a roughly-square grid, laid out so its
    // horizontal center sits at anchorX and its top or bottom edge sits at
    // anchorY (growUp: block extends upward from anchorY; otherwise downward).
    // Returns the block's total half-width/half-height so callers can offset
    // the next cluster clear of this one.
    const packGrid = (
      comps: Component[], anchorX: number, anchorY: number, growUp: boolean
    ): { halfW: number; halfH: number } => {
      if (comps.length === 0) return { halfW: 0, halfH: 0 };
      const extents = comps.map(halfExtent);
      const cellW = Math.max(...extents.map(e => e.hw)) * 2 + SPACING;
      const cellH = Math.max(...extents.map(e => e.hh)) * 2 + SPACING;
      const cols = Math.ceil(Math.sqrt(comps.length));
      const rows = Math.ceil(comps.length / cols);
      const blockW = cols * cellW;
      const blockH = rows * cellH;
      const startX = anchorX - blockW / 2 + cellW / 2;
      const startY = growUp ? anchorY - blockH + cellH / 2 : anchorY + cellH / 2;
      comps.forEach((comp, i) => {
        const col = i % cols;
        const row = Math.floor(i / cols);
        comp.x = Math.round(startX + col * cellW);
        comp.y = Math.round(startY + row * cellH);
      });
      return { halfW: blockW / 2, halfH: blockH / 2 };
    };

    // Anchor the whole layout at the current centroid of movable components
    // so arranging doesn't fling everything off to some arbitrary corner.
    const anchorX = Math.round(movable.reduce((s, c) => s + c.x, 0) / movable.length);
    const anchorY = Math.round(movable.reduce((s, c) => s + c.y, 0) / movable.length);

    // Center cluster (Arduino boards): stacked vertically, centered on the anchor.
    const centerBlock = packGrid(centerGroup, anchorX, anchorY - 0.0001, false);
    // Re-center vertically now that we know its height (packGrid always grows
    // downward from anchorY; shift up by half so the block is centered on it).
    if (centerGroup.length > 0) {
      const shiftY = Math.round(centerBlock.halfH);
      for (const comp of centerGroup) comp.y -= shiftY;
    }
    const centerHalfH = centerGroup.length > 0 ? centerBlock.halfH : 1.5;
    const centerHalfW = centerGroup.length > 0 ? centerBlock.halfW : 1.5;

    packGrid(sensorGroup, anchorX, anchorY - centerHalfH - CLUSTER_GAP, true);
    packGrid(actuatorGroup, anchorX, anchorY + centerHalfH + CLUSTER_GAP, false);

    // Side clusters (power/other) are vertically centered on the anchor,
    // same trick as the center cluster: pack downward from anchorY, then
    // shift the whole block up by half its height.
    const packGridCentered = (comps: Component[], anchorXSide: number) => {
      const block = packGrid(comps, anchorXSide, anchorY, false);
      if (comps.length > 0) {
        const shiftY = Math.round(block.halfH);
        for (const comp of comps) comp.y -= shiftY;
      }
    };
    packGridCentered(powerGroup, anchorX - centerHalfW - CLUSTER_GAP - 6);
    packGridCentered(otherGroup, anchorX + centerHalfW + CLUSTER_GAP + 6);

    for (const comp of movable) this.computeTerminalPositions(comp);

    // Re-route wires between two moved components as a clean direct line -
    // their old manual waypoints were tuned for the old positions and would
    // otherwise cut across the new layout. Wires touching a junction are
    // left alone since the junction (and its anchor point) didn't move.
    const movedIds = new Set(movable.map(c => c.id));
    for (const wire of this.state.wires) {
      if (movedIds.has(wire.fromCompId) && movedIds.has(wire.toCompId)) {
        wire.waypoints = [];
      }
    }

    this.state.selectedComponentIds = [];
    this.state.selectedWireIds = [];
    this.notifyStateChange();
    this.onSelectionChange?.();
    return { moved: movable.length };
  }

  setTool(tool: string) {
    this.state.selectedTool = tool;
    this.state.mode = tool === 'select' ? 'select' : tool === 'pan' ? 'pan' : tool === 'wire' ? 'wire' : 'place';
    if (tool !== 'wire') {
      this.state.wiringFrom = null;
      this.state.wiringWaypoints = [];
    }
    this.notifyStateChange();
  }

  // History
  saveHistory() {
    const entry: HistoryEntry = {
      components: deepClone(this.state.components),
      wires: deepClone(this.state.wires),
    };
    // Truncate forward history if we're not at the end
    this.state.history = this.state.history.slice(0, this.state.historyIndex + 1);
    this.state.history.push(entry);
    this.state.historyIndex = this.state.history.length - 1;
    // Limit history size
    if (this.state.history.length > 100) {
      this.state.history.shift();
      this.state.historyIndex--;
    }
  }

  undo() {
    if (this.state.historyIndex <= 0) return;
    this.state.historyIndex--;
    const entry = this.state.history[this.state.historyIndex];
    this.state.components = deepClone(entry.components);
    this.state.wires = deepClone(entry.wires);
    this.updateAllTerminalPositions();
    this.state.selectedComponentIds = [];
    this.state.selectedWireIds = [];
    this.notifyStateChange();
    this.onSelectionChange?.();
  }

  redo() {
    if (this.state.historyIndex >= this.state.history.length - 1) return;
    this.state.historyIndex++;
    const entry = this.state.history[this.state.historyIndex];
    this.state.components = deepClone(entry.components);
    this.state.wires = deepClone(entry.wires);
    this.updateAllTerminalPositions();
    this.state.selectedComponentIds = [];
    this.state.selectedWireIds = [];
    this.notifyStateChange();
    this.onSelectionChange?.();
  }

  clearAll() {
    this.saveHistory();
    this.state.components = [];
    this.state.wires = [];
    this.state.selectedComponentIds = [];
    this.state.selectedWireIds = [];
    this.notifyStateChange();
    this.onSelectionChange?.();
  }

  // Event handlers
  onPointerDown = (e: PointerEvent) => {
    // Browsers require a user gesture before audio can play - this is the
    // earliest one we get, so unlock/resume the circuit AudioContext here.
    circuitAudio.ensureContext();

    const rect = this.canvas.getBoundingClientRect();
    this.mouseX = e.clientX - rect.left;
    this.mouseY = e.clientY - rect.top;
    this.isMouseDown = true;
    this.canvas.setPointerCapture(e.pointerId);

    if (this.state.mode === 'pan' || e.button === 1) {
      this.panStartX = e.clientX;
      this.panStartY = e.clientY;
      this.panStartOffsetX = this.state.offsetX;
      this.panStartOffsetY = this.state.offsetY;
      return;
    }

    if (this.state.mode === 'wire') {
      // A pin takes priority over a wire when both are under the cursor.
      // Otherwise, clicking directly on a wire (not just its endpoints)
      // is a hit too - covers Pin -> Wire, Wire -> Wire, Wire -> Junction,
      // and "continue wiring from any existing wire". This is also what
      // makes "clicking any wire creates a junction automatically" true:
      // any such click resolves to a real junction component below.
      const termHit = this.hitTestTerminal(this.mouseX, this.mouseY);
      const wireHit = termHit ? null : this.hitTestWireAt(this.mouseX, this.mouseY);

      let hit: { componentId: number; terminalId: number } | null = termHit;
      let isNewSplit = false;

      if (!hit && wireHit) {
        this.saveHistory();
        const before = this.state.components.length;
        hit = this.splitWireAtPoint(wireHit.wireId, wireHit.x, wireHit.y, wireHit.leg);
        isNewSplit = this.state.components.length > before;
      }

      if (hit) {
        if (!this.state.wiringFrom) {
          // Start wiring (possibly from a brand-new junction we just split in)
          this.state.wiringFrom = { componentId: hit.componentId, terminalId: hit.terminalId };
          this.state.wiringWaypoints = [];
          this.updateAllTerminalPositions();
          if (isNewSplit) this.notifyStateChange();
        } else {
          // Complete wiring - but clicking the exact point we started from
          // (e.g. re-clicking the same pin) is a no-op, not a zero-length wire.
          if (hit.componentId !== this.state.wiringFrom.componentId ||
            hit.terminalId !== this.state.wiringFrom.terminalId) {
            if (!isNewSplit) this.saveHistory();
            const wireColor = getWireColor(this.state.wires.length);
            const wire: Wire = {
              id: uid(),
              fromTerminalId: this.state.wiringFrom.terminalId,
              toTerminalId: hit.terminalId,
              fromCompId: this.state.wiringFrom.componentId,
              toCompId: hit.componentId,
              color: wireColor,
              waypoints: this.state.wiringWaypoints.slice(),
              selected: false,
            };
            this.state.wires.push(wire);
            this.state.wiringFrom = null;
            this.state.wiringWaypoints = [];
            this.updateAllTerminalPositions();
            this.notifyStateChange();
          } else if (isNewSplit) {
            this.notifyStateChange();
          }
        }
      } else if (this.state.wiringFrom) {
        // Nothing to connect to under the cursor while actively drawing a
        // wire - drop a manual bend point here instead of cancelling, so a
        // wire can be routed around other components. Snapped to the fine
        // grid for tidy corners; automatic elbows still fill in the rest.
        const world = this.renderer.screenToWorld(this.mouseX, this.mouseY, this.state);
        this.state.wiringWaypoints.push(snapToFineGrid(world));
        this.notifyStateChange();
      } else {
        // Not wiring yet and nothing under the cursor - nothing to start from.
        this.state.wiringFrom = null;
      }
      return;
    }

    if (this.state.mode === 'select') {
      // Check terminal hit for wiring start
      const termHit = this.hitTestTerminal(this.mouseX, this.mouseY);
      if (termHit && e.shiftKey) {
        // Shift+click on terminal starts wiring
        this.state.mode = 'wire';
        this.state.selectedTool = 'wire';
        this.state.wiringFrom = { componentId: termHit.componentId, terminalId: termHit.terminalId };
        this.notifyStateChange();
        return;
      }

      // Check component hit
      const compId = this.hitTestComponent(this.mouseX, this.mouseY);
      if (compId !== null) {
        if (e.ctrlKey || e.metaKey) {
          // Toggle selection
          const idx = this.state.selectedComponentIds.indexOf(compId);
          if (idx >= 0) {
            this.state.selectedComponentIds.splice(idx, 1);
          } else {
            this.state.selectedComponentIds.push(compId);
          }
        } else {
          if (!this.state.selectedComponentIds.includes(compId)) {
            this.state.selectedComponentIds = [compId];
            this.state.selectedWireIds = [];
          }
        }
        // Start drag
        this.state.isDragging = true;
        this.state.dragStartX = this.mouseX;
        this.state.dragStartY = this.mouseY;
        this.onSelectionChange?.();
        return;
      }

      // Check wire hit
      const wireId = this.hitTestWire(this.mouseX, this.mouseY);
      if (wireId !== null) {
        if (e.ctrlKey || e.metaKey) {
          const idx = this.state.selectedWireIds.indexOf(wireId);
          if (idx >= 0) {
            this.state.selectedWireIds.splice(idx, 1);
          } else {
            this.state.selectedWireIds.push(wireId);
          }
        } else {
          this.state.selectedWireIds = [wireId];
          this.state.selectedComponentIds = [];
        }
        this.onSelectionChange?.();
        return;
      }

      // Start selection rectangle
      if (!e.ctrlKey && !e.metaKey && !e.shiftKey) {
        this.state.selectedComponentIds = [];
        this.state.selectedWireIds = [];
        this.state.selectRect = { x: this.mouseX, y: this.mouseY, w: 0, h: 0 };
        this.onSelectionChange?.();
      }
    }
  };

  onPointerMove = (e: PointerEvent) => {
    const rect = this.canvas.getBoundingClientRect();
    this.mouseX = e.clientX - rect.left;
    this.mouseY = e.clientY - rect.top;

    if (this.state.mode === 'pan' || (this.isMouseDown && e.buttons === 4)) {
      const dx = e.clientX - this.panStartX;
      const dy = e.clientY - this.panStartY;
      this.state.offsetX = this.panStartOffsetX + dx;
      this.state.offsetY = this.panStartOffsetY + dy;
      return;
    }

    // Hover detection
    const termHit = this.hitTestTerminal(this.mouseX, this.mouseY);
    this.state.hoveredTerminalId = termHit?.terminalId || null;

    const compId = this.hitTestComponent(this.mouseX, this.mouseY);
    this.state.hoveredComponentId = compId;

    // Wire hover - only meaningful while idle in select mode (not while
    // dragging a component or actively drawing a new wire), and a pin/
    // component under the cursor takes priority over the wire beneath it.
    if (this.state.mode === 'select' && !this.state.isDragging && !termHit && compId === null) {
      this.state.hoveredWireId = this.hitTestWire(this.mouseX, this.mouseY);
    } else if (this.state.hoveredWireId !== null) {
      this.state.hoveredWireId = null;
    }

    // Live snap target for the wiring preview: pins/junctions win over
    // existing wires, which win over a plain grid point. Only computed
    // while actually drawing a wire - cheap enough per-frame either way,
    // but no point doing the work when it won't be shown.
    if (this.state.mode === 'wire' && this.state.wiringFrom) {
      if (termHit) {
        this.state.snapIndicator = { x: termHit.x / GRID_SIZE, y: termHit.y / GRID_SIZE, kind: 'pin' };
      } else {
        const wireHit = this.hitTestWireAt(this.mouseX, this.mouseY);
        if (wireHit) {
          this.state.snapIndicator = { x: wireHit.x, y: wireHit.y, kind: 'wire' };
        } else {
          const world = this.renderer.screenToWorld(this.mouseX, this.mouseY, this.state);
          const g = snapToFineGrid(world);
          this.state.snapIndicator = { x: g.x, y: g.y, kind: 'grid' };
        }
      }
    } else if (this.state.snapIndicator) {
      this.state.snapIndicator = null;
    }

    if (this.state.isDragging && this.state.selectedComponentIds.length > 0) {
      const world1 = this.renderer.screenToWorld(this.state.dragStartX, this.state.dragStartY, this.state);
      const world2 = this.renderer.screenToWorld(this.mouseX, this.mouseY, this.state);
      const dwx = world2.x - world1.x;
      const dwy = world2.y - world1.y;

      for (const comp of this.state.components) {
        if (this.state.selectedComponentIds.includes(comp.id)) {
          // Move freely during drag (no snapping) for smooth motion;
          // grid snap is applied once on pointer release instead.
          comp.x = comp.x + dwx;
          comp.y = comp.y + dwy;
          this.computeTerminalPositions(comp);
        }
      }

      this.state.dragStartX = this.mouseX;
      this.state.dragStartY = this.mouseY;
    }

    if (this.state.selectRect) {
      this.state.selectRect.w = this.mouseX - this.state.selectRect.x;
      this.state.selectRect.h = this.mouseY - this.state.selectRect.y;

      // Select components inside rectangle
      const x1 = Math.min(this.state.selectRect.x, this.state.selectRect.x + this.state.selectRect.w);
      const y1 = Math.min(this.state.selectRect.y, this.state.selectRect.y + this.state.selectRect.h);
      const x2 = Math.max(this.state.selectRect.x, this.state.selectRect.x + this.state.selectRect.w);
      const y2 = Math.max(this.state.selectRect.y, this.state.selectRect.y + this.state.selectRect.h);

      this.state.selectedComponentIds = [];
      for (const comp of this.state.components) {
        const sx = comp.x * GRID_SIZE * this.state.scale + this.state.offsetX;
        const sy = comp.y * GRID_SIZE * this.state.scale + this.state.offsetY;
        if (sx >= x1 && sx <= x2 && sy >= y1 && sy <= y2) {
          this.state.selectedComponentIds.push(comp.id);
        }
      }
    }
  };

  onPointerUp = (_e: PointerEvent) => {
    this.isMouseDown = false;
    if (this.state.isDragging && this.state.snapToGrid) {
      for (const comp of this.state.components) {
        if (this.state.selectedComponentIds.includes(comp.id)) {
          comp.x = Math.round(comp.x / this.state.gridSize) * this.state.gridSize;
          comp.y = Math.round(comp.y / this.state.gridSize) * this.state.gridSize;
          this.computeTerminalPositions(comp);
        }
      }
    }
    this.state.isDragging = false;
    if (this.state.selectRect) {
      this.state.selectRect = null;
      this.onSelectionChange?.();
    }
  };

  onContextMenu = (e: MouseEvent) => {
    if (this.state.mode === 'wire' && this.state.wiringFrom) {
      // Right-click while drawing a wire steps backward instead of opening
      // the browser menu: undo the last manual bend, or cancel the wire
      // entirely if there are none left.
      e.preventDefault();
      if (this.state.wiringWaypoints.length > 0) {
        this.state.wiringWaypoints.pop();
      } else {
        this.state.wiringFrom = null;
      }
      this.notifyStateChange();
    }
  };

  onWheel = (e: WheelEvent) => {
    e.preventDefault();
    const rect = this.canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    const worldBefore = this.renderer.screenToWorld(mx, my, this.state);
    const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
    const newScale = Math.max(0.2, Math.min(5, this.state.scale * zoomFactor));

    this.state.scale = newScale;

    const worldAfter = this.renderer.screenToWorld(mx, my, this.state);
    this.state.offsetX += (worldAfter.x - worldBefore.x) * GRID_SIZE * this.state.scale;
    this.state.offsetY += (worldAfter.y - worldBefore.y) * GRID_SIZE * this.state.scale;
  };

  onKeyDown = (e: KeyboardEvent) => {
    // Don't handle shortcuts when typing in inputs
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement) {
      return;
    }

    switch (e.key) {
      case 'Delete':
      case 'Backspace':
        this.deleteSelected();
        break;
      case 'Escape':
        this.state.wiringFrom = null;
        this.state.wiringWaypoints = [];
        this.state.selectedComponentIds = [];
        this.state.selectedWireIds = [];
        this.state.mode = 'select';
        this.state.selectedTool = 'select';
        this.onSelectionChange?.();
        this.notifyStateChange();
        break;
      case 'r':
      case 'R':
        if (this.state.selectedComponentIds.length > 0) {
          this.rotateSelected();
        }
        break;
      case 'd':
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          this.duplicateSelected();
        }
        break;
      case 'z':
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          if (e.shiftKey) {
            this.redo();
          } else {
            this.undo();
          }
        }
        break;
      case 'y':
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          this.redo();
        }
        break;
      case 'a':
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          this.state.selectedComponentIds = this.state.components.map(c => c.id);
          this.state.selectedWireIds = this.state.wires.map(w => w.id);
          this.onSelectionChange?.();
        }
        break;
    }
  };

  // Property update
  updateComponentProperty(compId: number, key: string, value: number | string | boolean) {
    this.saveHistory();
    const comp = this.state.components.find(c => c.id === compId);
    if (comp) {
      comp.props[key] = value;
    }
    this.notifyStateChange();
    if (this.state.simulating) {
      this.runSimulation();
    }
    this.render();
    if (this.state.selectedComponentIds.length > 0) {
      this.onSelectionChange?.();
    }
  }

  // Rename a component's display label (shown on the canvas and in the
  // Property Panel header).
  renameComponent(compId: number, label: string) {
    this.saveHistory();
    const comp = this.state.components.find(c => c.id === compId);
    if (comp) {
      comp.label = label;
    }
    this.notifyStateChange();
    this.render();
    if (this.state.selectedComponentIds.length > 0) {
      this.onSelectionChange?.();
    }
  }

  // Toggle switch
  toggleSwitch(compId: number) {
    const comp = this.state.components.find(c => c.id === compId);
    if (comp && comp.type === 'switch') {
      comp.props.closed = !comp.props.closed;
      this.notifyStateChange();
    }
    if (comp && comp.type === 'pushButton') {
      comp.state.pressed = !comp.state.pressed;
      // Push button temporarily changes its internal connection
      this.notifyStateChange();
    }
    // Recompute right away (rather than waiting for the next animation
    // frame) so connected lamps/LEDs turn off immediately, even while
    // simulation is paused, and refresh the panel so it isn't stale.
    if (this.state.simulating) {
      this.runSimulation();
    }
    this.render();
    if (this.state.selectedComponentIds.length > 0) {
      this.onSelectionChange?.();
    }
  }

  // Center view
  centerView() {
    if (this.state.components.length === 0) {
      const rect = this.container.getBoundingClientRect();
      this.state.offsetX = rect.width / 2;
      this.state.offsetY = rect.height / 2;
      this.state.scale = 1;
      return;
    }

    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const comp of this.state.components) {
      minX = Math.min(minX, comp.x);
      minY = Math.min(minY, comp.y);
      maxX = Math.max(maxX, comp.x);
      maxY = Math.max(maxY, comp.y);
    }

    const rect = this.container.getBoundingClientRect();
    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;
    const padding = 5;
    const contentW = (maxX - minX + padding * 2) * GRID_SIZE;
    const contentH = (maxY - minY + padding * 2) * GRID_SIZE;

    this.state.scale = Math.min(rect.width / contentW, rect.height / contentH, 2);
    this.state.offsetX = rect.width / 2 - cx * GRID_SIZE * this.state.scale;
    this.state.offsetY = rect.height / 2 - cy * GRID_SIZE * this.state.scale;
  }

  // Import/Export
  exportCircuit(): string {
    return JSON.stringify({
      components: this.state.components,
      wires: this.state.wires,
    }, null, 2);
  }

  importCircuit(json: string) {
    try {
      this.saveHistory();
      const data = JSON.parse(json);
      this.state.components = data.components || [];
      this.state.wires = data.wires || [];
      this.updateAllTerminalPositions();
      this.state.selectedComponentIds = [];
      this.state.selectedWireIds = [];
      this.notifyStateChange();
    } catch (e) {
      console.error('Failed to import circuit:', e);
    }
  }
}
