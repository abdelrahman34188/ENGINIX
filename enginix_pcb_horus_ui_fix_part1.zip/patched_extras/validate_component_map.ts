import { runRegressionSuite } from './src/arduino/testing/regression';
import { ArduinoRuntime } from './src/arduino/ArduinoRuntime';
import { MemoryPinIO } from './src/arduino/testing/MemoryPinIO';
import { CircuitPinIO } from './src/arduino/CircuitPinIO';

console.log('--- Existing regression suite (must be untouched) ---');
const reg = runRegressionSuite();
for (const r of reg.results) console.log(`${r.passed ? 'PASS' : 'FAIL'}  ${r.name}${r.message ? ' -> ' + r.message : ''}`);
console.log(`Regression: ${reg.passed} passed, ${reg.failed} failed`);

console.log('\n--- getComponentMap() backward-compat: MemoryPinIO has no such hook ---');
const rt1 = new ArduinoRuntime();
rt1.attachPinIO(new MemoryPinIO());
const emptyMap = rt1.getComponentMap();
console.log('MemoryPinIO component map (expect []):', JSON.stringify(emptyMap));
if (emptyMap.length !== 0) throw new Error('expected empty component map when PinIO has no getComponentMap');

console.log('\n--- CircuitPinIO.getComponentMap(): board + LED wired to D13 ---');
const board = {
  type: 'arduino',
  props: {},
  state: {},
  id: 1,
  label: 'Uno',
  terminals: [
    { label: 'D13', netId: 100 },
    { label: 'D12', netId: 101 }, // floating: only one terminal on this net
    { label: 'GND', netId: 102 },
    { label: '5V', netId: null },
  ],
};
const led = {
  id: 2,
  type: 'led',
  label: 'LED1',
  terminals: [
    { label: 'Anode', netId: 100 },
    { label: 'Cathode', netId: 102 },
  ],
};
const netTerminalCounts = new Map<number, number>([[100, 2], [101, 1], [102, 2]]);

const pinIO = new CircuitPinIO(
  () => board,
  () => ({ components: [board, led], netTerminalCounts }),
);
const map = pinIO.getComponentMap();
console.log(JSON.stringify(map, null, 2));

const d13 = map.find(m => m.label === 'D13')!;
if (!d13.connected) throw new Error('D13 should be connected');
if (d13.components.length !== 1 || d13.components[0].label !== 'LED1' || d13.components[0].terminal !== 'Anode') {
  throw new Error('D13 should report LED1 (Anode)');
}
const d12 = map.find(m => m.label === 'D12')!;
if (d12.connected) throw new Error('D12 should NOT be connected (floating net)');
if (d12.components.length !== 0) throw new Error('D12 should have no components (safe handling of disconnected pins)');
const gnd = map.find(m => m.label === 'GND')!;
if (!gnd.connected || gnd.components[0].label !== 'LED1' || gnd.components[0].terminal !== 'Cathode') {
  throw new Error('GND should report LED1 (Cathode)');
}
const v5 = map.find(m => m.label === '5V')!;
if (v5.connected) throw new Error('5V (netId null) should be reported as not connected');

console.log('\n--- CircuitPinIO.getComponentMap(): no context given (backward compat) ---');
const pinIONoContext = new CircuitPinIO(() => board);
const mapNoCtx = pinIONoContext.getComponentMap();
if (mapNoCtx.some(m => m.components.length > 0)) throw new Error('expected no components without a context accessor');
console.log('OK: components empty everywhere, no throw, connected flags still computed:', JSON.stringify(mapNoCtx.map(m => ({ label: m.label, connected: m.connected }))));

console.log('\n--- ArduinoRuntime.getComponentMap() passthrough ---');
const rt2 = new ArduinoRuntime();
rt2.attachPinIO(pinIO);
const throughRuntime = rt2.getComponentMap();
if (JSON.stringify(throughRuntime) !== JSON.stringify(map)) throw new Error('runtime passthrough should match pinIO.getComponentMap()');
console.log('OK: ArduinoRuntime.getComponentMap() matches CircuitPinIO.getComponentMap()');

console.log('\n--- Existing digitalWrite/analogRead behavior on the same board object: unaffected ---');
pinIO.pinMode(13, 'OUTPUT');
pinIO.digitalWrite(13, 1);
if ((board.props as any).d13 !== true) throw new Error('digitalWrite should still work exactly as before');
console.log('OK: existing PinIO methods unaffected by the new optional context param');

if (reg.failed > 0) process.exit(1);
console.log('\nALL CHECKS PASSED');
